/**
 * FastMoss 验证码测试台 - 本地代理
 *
 * 只转发 /api/captcha/* 到 www.fastmoss.com，并补上 CORS 头，
 * 让 captcha-test.html 能在本地直接调用（浏览器端跨域会被拦）。
 *
 * 用法: node proxy.js   ->  http://localhost:8787
 * 无第三方依赖。
 */
'use strict';

const http = require('http');
const https = require('https');

const PORT = Number(process.env.PORT || 8787);
const TARGET_HOST = 'www.fastmoss.com';
const ALLOW_PREFIX = '/api/captcha/';
const UPSTREAM_ORIGIN = 'https://www.fastmoss.com';

const server = http.createServer((req, res) => {
  const origin = req.headers.origin || 'http://localhost:' + PORT;

  // ---- CORS ----
  res.setHeader('Access-Control-Allow-Origin', origin);
  res.setHeader('Access-Control-Allow-Credentials', 'true');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, lang');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Vary', 'Origin');

  if (req.method === 'OPTIONS') {
    res.writeHead(204);
    res.end();
    return;
  }

  if (!req.url.startsWith(ALLOW_PREFIX)) {
    res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
    res.end('proxy only forwards ' + ALLOW_PREFIX + '*');
    return;
  }

  const chunks = [];
  req.on('data', (c) => chunks.push(c));
  req.on('end', () => {
    const body = Buffer.concat(chunks);

    const headers = {
      'Content-Type': req.headers['content-type'] || 'application/json',
      'lang': req.headers['lang'] || 'zh-CN',
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/131.0.0.0 Safari/537.36',
      'Origin': UPSTREAM_ORIGIN,
      'Referer': UPSTREAM_ORIGIN + '/zh/e-commerce/saleslist'
    };
    if (req.headers.cookie) headers['Cookie'] = req.headers.cookie;
    if (body.length) headers['Content-Length'] = body.length;

    const upstream = https.request(
      { host: TARGET_HOST, path: req.url, method: req.method, headers },
      (upRes) => {
        const outHeaders = Object.assign({}, upRes.headers);
        delete outHeaders['content-length'];
        delete outHeaders['content-security-policy'];
        delete outHeaders['transfer-encoding'];
        delete outHeaders['content-encoding']; // 不请求压缩，保持简单

        // 强制改写为本地页可用的 CORS 头（上游只会放行 https://www.fastmoss.com）
        outHeaders['access-control-allow-origin'] = origin;
        outHeaders['access-control-allow-credentials'] = 'true';
        outHeaders['access-control-expose-headers'] = '*';
        outHeaders['vary'] = 'Origin';

        // 服务端会按 Origin 反射 cookie 域名（如 domain=localhost），去掉 Domain 让它落到当前 host
        if (outHeaders['set-cookie']) {
          outHeaders['set-cookie'] = outHeaders['set-cookie'].map((c) =>
            c.replace(/;\s*domain=[^;]+/i, '').replace(/;\s*secure/ig, '')
          );
        }

        console.log('[proxy]', req.method, req.url, '->', upRes.statusCode);
        res.writeHead(upRes.statusCode, outHeaders);
        upRes.pipe(res);
      }
    );

    upstream.on('error', (err) => {
      console.error('[proxy] upstream error:', err.message);
      if (!res.headersSent) res.writeHead(502, { 'Content-Type': 'text/plain; charset=utf-8' });
      res.end('upstream error: ' + err.message);
    });

    upstream.end(body);
  });
});

server.listen(PORT, () => {
  console.log('captcha proxy listening: http://localhost:' + PORT);
  console.log('forwards: ' + ALLOW_PREFIX + '*  ->  https://' + TARGET_HOST);
  console.log('open captcha-test.html with API Base = http://localhost:' + PORT);
});
