# FastMoss 验证码接口拆解 + 独立测试台

目标页：`https://www.fastmoss.com/zh/e-commerce/saleslist?date_type=1&date_value=2026-10-22`

## 1. 结论

FastMoss 的验证码是**腾讯防水墙 TencentCaptcha**（`https://turing.captcha.qcloud.com/TJCaptcha.js`），
前端只是包了一层配置/校验接口。客户端代码里写死：任何接口返回 `code === "MSG_SAFE_0001"` 就自动弹验证码。

## 2. 接口

全部在 `https://www.fastmoss.com` 下，`Content-Type: application/json`，带 `lang` 头。

### POST /api/captcha/config

获取腾讯验证码配置。

```json
{"platform":1,"business_id":1,"scene_id":1,"type":1}
```

实测响应（`ext.is_login` 表示是否登录）：

```json
{"code":200,"data":{"appid":"195941100","bizState":{"test":1},"userLanguage":"en",
 "type":"popup","loading":true,"enableDarkMode":false,"sdkOpts":{"width":140,"height":140}},
 "msg":"success","ext":{"is_login":0}}
```

### POST /api/captcha/verify

页面级风控校验（`type=1`），通过后前端会 `window.location.reload()`。

### POST /api/captcha/smsVerify

发送短信验证码前的校验（`type` 非 1 时走这里）。

两者请求体一致：

```json
{"ticket":"<腾讯回调的 ticket>","randstr":"<腾讯回调的 randstr>",
 "platform":1,"business_id":1,"scene_id":1,
 "id":<MSG_SAFE_0001 响应里的 data.id，无则 0>,"type":1,"lang":"zh-CN"}
```

成功判据：`data.is_ok === 1`。ticket 还会写入 `localStorage["captcha_ticket_data"]`。

## 3. 完整流程

```
页面/接口请求  ──► 返回 {"code":"MSG_SAFE_0001","data":{"id":...}}
                     │
                     ▼
        POST /api/captcha/config        → 拿 appid
                     │
                     ▼
   new TencentCaptcha(appid, cb).show() → 人工完成
                     │
                     ▼  回调 {ret:0, ticket, randstr}
        POST /api/captcha/verify        → {"data":{"is_ok":1}}
                     │
                     ▼
              （type=1 时）刷新页面
```

## 4. 文件

| 文件 | 说明 |
|---|---|
| `captcha-test.html` | 独立测试页：取配置 → 弹腾讯验证码 → 人工完成 → 提交 ticket |
| `proxy.js` | 无依赖 Node 代理，只转发 `/api/captcha/*`，补 CORS 头（上游只放行 `https://www.fastmoss.com` 源） |
| `fastmoss-captcha.user.js` | Tampermonkey 用户脚本，在 fastmoss 同源页面右下角注入测试面板（最稳） |

## 5. 使用

### 方式 A：本地代理 + 测试页

```bash
node proxy.js          # http://localhost:8787
```

浏览器打开 `captcha-test.html`，API Base 保持 `http://localhost:8787`，
点「弹出验证码」→ 手动完成 → 查看 ticket / `is_ok`。

> 代理会把上游 `Set-Cookie` 的 `Domain` 去掉（服务端会按 Origin 反射 `domain=localhost`），
> 并把 `Access-Control-Allow-Origin` 改写成页面自身的 Origin。

### 方式 B：同源用户脚本（推荐）

把 `fastmoss-captcha.user.js` 装进 Tampermonkey，打开任意 `www.fastmoss.com` 页面，
右下角出现「FastMoss 验证码测试」面板，直接测试。

同源方式能带上站点 cookie、Referer 也正确，比本地页更接近真实链路。

## 6. 限制与边界

- ticket/randstr 由**腾讯服务端签发**，FastMoss 服务端再拿 appid 密钥去腾讯**二次校验**，
  没有密钥无法离线伪造。本工具只做「单独调起 + 人工完成 + 回填校验」。
- `id` 用于把验证结果绑定到具体的风控事件；手工触发时填 0，服务端仍会返回 `is_ok`。
- 腾讯 appid 可能配置了业务域名白名单，若本地页弹不出/报错，用方式 B（同源）。
- 仅用于联调自己的账号流程；自动化绕过风控属于另一回事，需 FastMoss 书面授权。
  正式取数建议走官方开放平台 `https://developers.fastmoss.com`。
