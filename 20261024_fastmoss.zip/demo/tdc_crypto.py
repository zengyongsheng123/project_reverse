# -*- coding: utf-8 -*-
"""Pure-Python TDC.getData() payload cipher (Tencent TCaptcha v2, aid 192962660).

Build anchors (tdc.js is re-randomised per HTTP request, so every constant is
per-build; see PROFILES and scripts/derive_build.py):
  * "cur2" — first build captured on 2026-10-24, confirmed against three
    independent live captures (scripts/capture_full_{b,c,d}.json);
  * "cur3"/"cur4" — later builds of the same session, confirmed against
    capture_full_e.json and three consecutive live TDC.getData() calls.

Signed profiles emitted by scripts/derive_build.py are auto-loaded from
js/live_src/profile_*.json at import time.

Pipeline
--------
plaintext (multiples of 8 bytes)  ->  8-byte blocks  ->  XTEA-like Feistel
  ->  ciphertext  ->  24/168-byte segment rotation  ->  base64
  ->  urllib.parse.quote(..., safe='')  ->  the `data` form field

No browser is needed to produce `data` from a plaintext; see tdc_collect.py
for the plaintext builder.

Cipher details (all arithmetic with JS Number semantics):
  * 32 rounds, delta = 0x9E3779B9, sum is a plain double that ends at 32*delta
  * rounds use the ORIGINAL xtea shape but with per-round addends (K[i]+C[i])
  * C is a per-build table keyed by the round's `sum & 3` (second half: `(sum>>>11)&3`)
  * <<, >>>, ^, & operate on ToInt32/ToUint32 views of the double values
"""

M32 = 0xFFFFFFFF
DELTA = 2654435769
SUM_END = 32 * DELTA          # 84941944608

# build "cur2" key schedule (enclosing register file slot 7 / array1)
KEY = [1111583825, 1145594698, 1764444233, 1310729274]   # 0x42416C51 ...
# per-build case table: C[sum & 3]
CASE = [0, 0, 1776391, 2368534]

SEG = (24, 192, 24)           # rotate ct as ct[24:192] + ct[0:24] + ct[192:]
SPLIT = 192                   # rotation boundary (bytes) for the cur2 build

# Per-build profiles.  `split` is the segment boundary: the payload is emitted
# as ct[24:split] + ct[0:24] + ct[split:].  The boundary equals
# 24 + len(cd head up to and including the "[]" field), so it moves when the
# environment strings (canvas/UA) change length.
PROFILES = {
    "cur2": {"key": KEY, "case": CASE, "split": 192},
    "cur3": {"key": [1733836872, 1178823514, 1364019046, 1432772683],
             "case": [657947, 0, 0, 460550], "split": 240},
}


def _load_profiles():
    """Pick up profiles emitted by scripts/derive_build.py (verified builds)."""
    import glob
    import json
    import os
    base = os.path.join(os.path.dirname(os.path.abspath(__file__)), "js", "live_src")
    for path in sorted(glob.glob(os.path.join(base, "profile_*.json"))):
        try:
            d = json.load(open(path, encoding="utf-8"))
        except Exception:
            continue
        if not d.get("verified") or not d.get("name"):
            continue
        PROFILES[d["name"]] = {"key": d["key"], "case": d["case"],
                               "split": d["split"]}


_load_profiles()


def _i32(x):
    x &= M32
    return x - 0x100000000 if x & 0x80000000 else x


def _u32(x):
    return x & M32


def _mix(v, k, c):
    """((v<<4 ^ v>>>5) + v) ^ (sum + K[i] + C[i]) with JS coercion rules."""
    return _i32((_i32(v << 4) ^ (_u32(v) >> 5)) + v) ^ _i32(k + c)


def _block(v0, v1, key=None, case=None):
    """Encrypt one (word0, word1) pair exactly as the VM closure does."""
    if key is None:
        key = KEY
    if case is None:
        case = CASE
    s = 0
    while s != SUM_END:
        i = _u32(s) & 3
        v0 = v0 + _mix(v1, s + key[i], case[i])
        s += DELTA
        i = (_u32(s) >> 11) & 3
        v1 = v1 + _mix(v0, s + key[i], case[i])
    return v0, v1


def _w2b(x):
    x = _u32(x)
    return bytes((x & 255, (x >> 8) & 255, (x >> 16) & 255, (x >> 24) & 255))


def _b2w(b):
    return (b[0] | (b[1] << 8) | (b[2] << 16) | (b[3] << 24),)


def encrypt_blocks(pt, key=None, case=None):
    """XTEA-encrypt `pt` (len % 8 == 0) into the raw ciphertext bytes."""
    if len(pt) % 8:
        raise ValueError("plaintext must be a multiple of 8 bytes, got %d" % len(pt))
    out = bytearray()
    for i in range(0, len(pt), 8):
        w0 = pt[i] | (pt[i + 1] << 8) | (pt[i + 2] << 16) | (pt[i + 3] << 24)
        w1 = pt[i + 4] | (pt[i + 5] << 8) | (pt[i + 6] << 16) | (pt[i + 7] << 24)
        v0, v1 = _block(w0, w1, key, case)
        out += _w2b(v0) + _w2b(v1)
    return bytes(out)


def rotate(ct, split=None):
    """Reorder ciphertext segments: output = ct[24:split] + ct[0:24] + ct[split:]."""
    if split is None:
        split = SPLIT
    return ct[24:split] + ct[0:24] + ct[split:]


def unrotate(raw, split=None):
    """Inverse of rotate(); used to check the ciphertext against block dumps."""
    if split is None:
        split = SPLIT
    k = split - 24
    return raw[k:split] + raw[0:k] + raw[split:]


def get_data(pt, key=None, case=None, split=None):
    """Full TDC.getData() transform: plaintext -> form-encoded `data` string."""
    import base64
    import urllib.parse
    raw = rotate(encrypt_blocks(pt, key, case), split)
    return urllib.parse.quote(base64.b64encode(raw).decode("ascii"), safe="")


def decode_data(data, key=None, case=None, split=None):
    """Inverse for validation: `data` string -> plaintext bytes."""
    import base64
    import urllib.parse
    raw = base64.b64decode(urllib.parse.unquote(data))
    ct = unrotate(raw, split)
    out = bytearray()
    for i in range(0, len(ct), 8):
        w0 = ct[i] | (ct[i + 1] << 8) | (ct[i + 2] << 16) | (ct[i + 3] << 24)
        w1 = ct[i + 4] | (ct[i + 5] << 8) | (ct[i + 6] << 16) | (ct[i + 7] << 24)
        v0, v1 = _block_decrypt(w0, w1, key, case)
        out += _w2b(v0) + _w2b(v1)
    return bytes(out)


def _block_decrypt(v0, v1, key=None, case=None):
    if key is None:
        key = KEY
    if case is None:
        case = CASE
    s = SUM_END
    while s:
        i = (_u32(s) >> 11) & 3
        v1 = v1 - (_mix(v0, s + key[i], case[i]))
        s -= DELTA
        i = _u32(s) & 3
        v0 = v0 - (_mix(v1, s + key[i], case[i]))
    return v0, v1


def profile_params(name):
    """Return (key, case, split) for a named build profile."""
    p = PROFILES[name]
    return p["key"], p["case"], p["split"]


def get_data_profile(name, pt):
    k, c, sp = profile_params(name)
    return get_data(pt, k, c, sp)


def decode_data_profile(name, data):
    k, c, sp = profile_params(name)
    return decode_data(data, k, c, sp)


if __name__ == "__main__":
    # self-check against the three captured plaintext/ciphertext pairs
    import json
    import os
    import sys

    here = os.path.dirname(os.path.abspath(__file__))
    sys.path.insert(0, os.path.join(here, "scripts"))
    ok = True
    for name in ("b", "c", "d"):
        cap = json.load(open(os.path.join(here, "scripts", "capture_full_%s.json" % name)))
        pt = bytearray()
        for h in cap["hits"]:
            for w in h["pre"]:
                w &= M32
                pt += bytes((w & 255, (w >> 8) & 255, (w >> 16) & 255, (w >> 24) & 255))
        got = get_data(bytes(pt))
        match = got == cap["data"]
        back = decode_data(cap["data"]) == bytes(pt)
        ok &= match and back
        print("sample %s: data=%d bytes  match=%s  roundtrip=%s"
              % (name, len(pt), match, back))
    print("ALL OK" if ok else "FAILED")
