# -*- coding: utf-8 -*-
"""腾讯滑块验证码（aid 192962660）——纯 Python 请求与求解，无浏览器。

按 mfw.py 的组织方式重写：两个类 + loguru 日志 + requests 验证。
与原版的区别在"怎么算"，不在"怎么组织"：

    mfw.py                         本文件
    ------------------------------ ------------------------------
    SliderCaptchaSolver(cv2)       SliderCaptchaSolver(numpy)
    execjs + tx_env_jsdow.js       pure_flow.py 的内嵌常量 + 纯 Python 加密
    DrissionPage 拖滑块           不需要：ans 本地算，collect 本地组
    requests 发 verify            同左（只发一次）

流程：prehandle -> 取图 -> 识别 -> 组 collect（本地加密）-> PoW -> verify

保持自包含：密码学、识别、常量都在本文件内，只依赖
requests + numpy + Pillow（loguru 可选，没装则退回标准库 logging）。

安全边界：默认 dry run；--submit 只发一条 POST；仅公开 demo aid
192962660；每次提交需用户当次授权。
"""
import base64
import hashlib
import json
import os
import random
import re
import sys
import time
import urllib.parse
from collections import deque

import numpy as np
import requests
from PIL import Image

try:                                    # loguru 可选，没装就退回标准库
    from loguru import logger
except ImportError:
    import logging

    logging.basicConfig(level=logging.DEBUG,
                        format="%(asctime)s | %(levelname)-7s | %(message)s")
    logging.getLogger("urllib3").setLevel(logging.WARNING)

    class _StdLogger:
        """最小 shim：只实现本文件用到的 debug/success/warning/error。"""

        def __getattr__(self, name):
            level = {"success": "info"}.get(name, name)
            return getattr(logging.getLogger("flow"), level)

    logger = _StdLogger()

HERE = os.path.dirname(os.path.abspath(__file__))
AID = "192962660"
BASE = "https://turing.captcha.qcloud.com"
ENTRY_URL = "https://cloud.tencent.com/product/captcha"
UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36")

# --------------------------------------------------------------------------- #
# per-build constants (static; extracted from tdc.js once, reused here)
# --------------------------------------------------------------------------- #
PROFILE = {'name': 'cur9', 'sha256_16': '83bd1bbee1c6cad8', 'key': [1366125416, 1247952441, 1315062119, 1213807443], 'case': [0, 197429, 0, 657937], 'split': 456, 'eks': 'tsk6OO36Ybs4wl1K69V/INtWLxCkEI+5PR51d+U0C0LMSLYoUllG2RNEQDWbJow3MZiwUAMw9Ij9sN5cHTU5pUWATebsceFcfE7AZQX/IXWPM2/zXq172QBueIc+GhPT4jJswF/26bS903xjugOfOOTSxpfCKtK4OQ5fbvLF3+RlL+MzhoMbVjKNEnddzXPd8v7CedQlKvEh9891V1oaMfjzOSWIfQfIYzTgO9Qv63tvBE4W74H+2Q==', 'layout': {'prefix': '[[1,1,12]]              {"cd":[', 'tokens': ['32', '0', '"GgoAAAANSUhEUgAAASwAAACWCAYAAA76+IlaBIhKxWufqtcCsxKQ71/n6pjUB0H3elg4cAvgAAAABJRU5ErkJggg=="', '[]', '27', '1950354050', '["zh-CN","zh"]', '"ANGLE (NVIDIA, NVIDIA GeForce RTX 3060 Ti (0x00002489) Direct3D11 vs_5_0 ps_5_0, D3D11)"', '0', '"Google Inc. (NVIDIA)"', '1920', '0', '1', '"1920-1080-1032-32-*-*-|-*"', '1023', '"Win32"', '8', '"UTF-8"', '1080', '"+08"', '"https://cloud.tencent.com/product/captcha"', '""', '1792825037', '1792824655', '890859047', '1792807554', '0', '""', '              ', '[360,358]', '0', '"98k"', '"top"', '""', '2', '"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36"', '0', '"https://cloud.tencent.com/product/captcha?rand=1519713624347"'], 'suffix': '],      "sd":{"od":"C","ft":"6f_7ff__H"}}', 'dynamic': {'now_sec': 22, 'counter': 4, 'positions': [4, 22], 'prefix_dynamic': False, 'pads': {}, 'suffix_pad_width': None}}, 'samples_verified': 12}

LAYOUT = PROFILE["layout"]


# --------------------------------------------------------------------------- #
# cipher: XTEA variant + segment rotation + base64/percent encoding
# --------------------------------------------------------------------------- #
M32 = 0xFFFFFFFF


DELTA = 2654435769


SUM_END = 32 * DELTA


def _i32(x):
    x &= M32
    return x - 0x100000000 if x & 0x80000000 else x


def _u32(x):
    return x & M32


def _mix(v, k, c):
    """((v<<4 ^ v>>>5) + v) ^ (sum + K[i] + C[i]) with JS coercion rules."""
    return _i32((_i32(v << 4) ^ (_u32(v) >> 5)) + v) ^ _i32(k + c)


def _block(v0, v1, key, case):
    s = 0
    while s != SUM_END:
        i = _u32(s) & 3
        v0 = v0 + _mix(v1, s + key[i], case[i])
        s += DELTA
        i = (_u32(s) >> 11) & 3
        v1 = v1 + _mix(v0, s + key[i], case[i])
    return v0, v1


def _block_decrypt(v0, v1, key, case):
    s = SUM_END
    while s:
        i = (_u32(s) >> 11) & 3
        v1 = v1 - _mix(v0, s + key[i], case[i])
        s -= DELTA
        i = _u32(s) & 3
        v0 = v0 - _mix(v1, s + key[i], case[i])
    return v0, v1


def _w2b(x):
    x = _u32(x)
    return bytes((x & 255, (x >> 8) & 255, (x >> 16) & 255, (x >> 24) & 255))


def _b2w(b):
    return b[0] | (b[1] << 8) | (b[2] << 16) | (b[3] << 24)


def encrypt_blocks(pt, key, case):
    if len(pt) % 8:
        raise ValueError("plaintext must be a multiple of 8 bytes")
    out = bytearray()
    for i in range(0, len(pt), 8):
        v0, v1 = _block(_b2w(pt[i:i + 4]), _b2w(pt[i + 4:i + 8]), key, case)
        out += _w2b(v0) + _w2b(v1)
    return bytes(out)


def rotate(ct, split):
    """data_raw = ct[24:split] + ct[0:24] + ct[split:]"""
    return ct[24:split] + ct[0:24] + ct[split:]


def unrotate(raw, split):
    k = split - 24
    return raw[k:split] + raw[0:k] + raw[split:]


def get_data(pt, prof):
    raw = rotate(encrypt_blocks(pt, prof["key"], prof["case"]), prof["split"])
    return urllib.parse.quote(base64.b64encode(raw).decode("ascii"), safe="")


def decode_data(data, prof):
    """TDC collect string -> plaintext bytes (validation / analysis path)."""
    raw = base64.b64decode(urllib.parse.unquote(data))
    ct = unrotate(raw, prof["split"])
    out = bytearray()
    for i in range(0, len(ct), 8):
        v0, v1 = _block_decrypt(_b2w(ct[i:i + 4]), _b2w(ct[i + 4:i + 8]),
                                prof["key"], prof["case"])
        out += _w2b(v0) + _w2b(v1)
    return bytes(out)

# --------------------------------------------------------------------------- #
# solver internals (numpy): mask path + darkened-hole template fallback
# --------------------------------------------------------------------------- #
def _components(mask, min_area):
    h, w = mask.shape
    seen = mask.copy()
    out = []
    ys, xs = np.nonzero(mask)
    for sy, sx in zip(ys, xs):
        if not seen[sy, sx]:
            continue
        q = deque([(sy, sx)])
        seen[sy, sx] = False
        n = 0
        minx = maxx = sx
        miny = maxy = sy
        pix = []
        while q:
            y, x = q.popleft()
            n += 1
            pix.append((y, x))
            if x < minx: minx = x
            if x > maxx: maxx = x
            if y < miny: miny = y
            if y > maxy: maxy = y
            for dy, dx in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                ny, nx = y + dy, x + dx
                if 0 <= ny < h and 0 <= nx < w and seen[ny, nx]:
                    seen[ny, nx] = False
                    q.append((ny, nx))
        if n >= min_area:
            out.append({"area": n, "pix": pix,
                        "bbox": (minx, miny, maxx - minx + 1, maxy - miny + 1)})
    return out


def _hole_mask(bg_rgb, bg_lum):
    """Desaturated, mid-dark overlay = hole (rendering variant A)."""
    a = bg_rgb.astype(np.int16)
    sat = (a.max(2) - a.min(2)).astype(np.float32)
    return (bg_lum >= 40) & (bg_lum <= 140) & (sat <= 22)


def _iou(a_mask, a_off, b_mask, b_off, shift=(0, 0)):
    ax0, ay0 = a_off
    bx0, by0 = b_off[0] + shift[0], b_off[1] + shift[1]
    x0 = min(ax0, bx0); y0 = min(ay0, by0)
    x1 = max(ax0 + a_mask.shape[1], bx0 + b_mask.shape[1])
    y1 = max(ay0 + a_mask.shape[0], by0 + b_mask.shape[0])
    A = np.zeros((y1 - y0, x1 - x0), bool)
    B = np.zeros_like(A)
    A[ay0 - y0:ay0 - y0 + a_mask.shape[0],
      ax0 - x0:ax0 - x0 + a_mask.shape[1]] = a_mask
    B[by0 - y0:by0 - y0 + b_mask.shape[0],
      bx0 - x0:bx0 - x0 + b_mask.shape[1]] = b_mask
    inter = (A & B).sum()
    union = (A | B).sum()
    return inter / union if union else 0.0


def find_hole(bg_rgb, bg_lum, piece_mask, piece_bbox, expected_y=None):
    """Hole content origin via connected components + mask IoU.

    The thresholded hole mask is eroded by the anti-aliased rim.  Its y is
    known exactly (the piece only moves horizontally), so the y erosion is
    measured and applied to x as well.  That correction is 1-2 px and is NOT
    always valid for x; prefer the raw bbox when in doubt (see README 5.4).
    """
    pw, ph = piece_bbox[2], piece_bbox[3]
    mask = _hole_mask(bg_rgb, bg_lum)
    comps = _components(mask, int(piece_mask.sum() * 0.35))
    pm = piece_mask[piece_bbox[1]:piece_bbox[1] + ph,
                    piece_bbox[0]:piece_bbox[0] + pw]
    cands = []
    for c in comps:
        cx, cy, cw, ch = c["bbox"]
        if not (0.6 * pw <= cw <= 1.45 * pw and 0.55 * ph <= ch <= 1.6 * ph):
            continue
        cm = np.zeros((ch, cw), bool)
        for y, x in c["pix"]:
            cm[y - cy, x - cx] = True
        best = (0.0, 0, 0)
        for dy in range(-4, 5):
            for dx in range(-4, 5):
                score = _iou(pm, (0, 0), cm, (dx, dy))
                if score > best[0]:
                    best = (score, dx, dy)
        cands.append((best[0], cx + best[1], cy + best[2], cw, ch, cx, cy))
    if not cands:
        return None
    cands.sort(reverse=True)
    iou, hx, hy, cw, ch, bx, by = cands[0]
    corr = None
    if expected_y is not None:
        corr = int(by - expected_y)
        if -1 <= corr <= 6:
            hx = bx - corr
            hy = int(expected_y)
        else:
            corr = None
    return {"hole_x": int(hx), "hole_y": int(hy), "iou": round(float(iou), 3),
            "comp_w": int(cw), "comp_h": int(ch), "edge_corr": corr,
            "comp_bbox": [int(bx), int(by)], "method": "mask",
            "margin": round(float(cands[0][0] - cands[1][0]), 3)
            if len(cands) > 1 else None}


def match_piece(bg_rgb, sprite_rgba, fg, expected_y=None):
    """Template matching fallback (rendering variant B: hole = photo * k).

    Zero-mean normalised correlation over the eroded opaque core, y searched
    around the known value, k<0.8 prior to reject flat bright patches.
    """
    sx, sy = fg["sprite_pos"]
    w, h = fg["size_2d"]
    init_x, init_y = fg["init_pos"]
    crop = sprite_rgba[sy:sy + h, sx:sx + w]
    mask = crop[:, :, 3] > 128
    if not mask.any():
        raise ValueError("empty piece mask")
    ys, xs = np.nonzero(mask)
    ox, oy = int(xs.min()), int(ys.min())
    pw, ph = int(xs.max() - ox + 1), int(ys.max() - oy + 1)
    piece = crop[oy:oy + ph, ox:ox + pw, :3].astype(np.float32)
    pl = piece.mean(2)
    core = mask[oy:oy + ph, ox:ox + pw].copy()
    for _ in range(3):
        core = (core & np.roll(core, 1, 0) & np.roll(core, -1, 0)
                & np.roll(core, 1, 1) & np.roll(core, -1, 1))
    if core.sum() < 50:
        core = mask[oy:oy + ph, ox:ox + pw].copy()

    y0 = int(expected_y if expected_y is not None else init_y + oy)
    H, W = bg_rgb.shape[:2]
    bgl = bg_rgb.astype(np.float32)
    bg_l = bgl.mean(2)
    a = piece[core]
    pa = pl[core]
    pa0 = pa - pa.mean()
    dena = float(np.sqrt((pa0 * pa0).sum())) + 1e-9
    scores = []
    for y in range(max(0, y0 - 6), min(H - ph, y0 + 6) + 1):
        for x in range(0, W - pw + 1):
            p = bg_l[y:y + ph, x:x + pw][core]
            p0 = p - p.mean()
            ncc = float((pa0 * p0).sum() /
                        (dena * (float(np.sqrt((p0 * p0).sum())) + 1e-9)))
            b = bgl[y:y + ph, x:x + pw][core]
            k = float((a * b).sum() / ((a * a).sum() + 1e-6))
            resid = float(np.abs(b - a * k).mean())
            scores.append((ncc, -resid, x, y, k, resid))
    scores.sort(reverse=True)
    dark = [s for s in scores if s[4] < 0.8]
    pool = dark if dark else scores
    ncc, _neg, best_x, best_y, k, resid = pool[0]
    around = [s for s in pool if abs(s[2] - best_x) > pw // 2]
    second = around[0][0] if around else None
    return {"hole_x": int(best_x), "hole_y": int(y0), "iou": round(float(ncc), 3),
            "comp_w": pw, "comp_h": ph, "edge_corr": None,
            "comp_bbox": [int(best_x), int(best_y)], "method": "template",
            "margin": round(ncc - second, 3) if second is not None else None,
            "k": round(float(k), 3), "resid": round(resid, 2)}

# --------------------------------------------------------------------------- #
# trajectory (generated; not embedded in collect)
# --------------------------------------------------------------------------- #
def make_trajectory(init_x, init_y, target_x, target_y,
                    duration_ms=None, n=None):
    """生成接近真实客户端的拖动轨迹，返回 {elapsed_ms: "x,y"}。

    节奏取自 2026-10-24 抓到的真实事件串（scripts/real_event_capture.json：
    一次拖动 61 条事件，dt 集中在 3~11ms，偶发 20~80ms 停顿），轨迹为
    ease-out，末端有轻微过冲再回落到目标点。n/duration_ms 仅为兼容旧调用。
    """
    if duration_ms is None:
        duration_ms = random.randint(600, 1000)
    dx = target_x - init_x
    dy = target_y - init_y
    over = random.uniform(0.01, 0.035)          # 末端过冲比例
    drift = random.uniform(-1.5, 1.5)           # 手指/鼠标的纵向漂移
    steps = (3, 3, 3, 4, 4, 4, 5, 6, 6, 6, 6, 6, 7, 8, 9, 9, 9, 9, 9, 9,
             9, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 11, 11,
             11, 11, 11, 11, 11, 12, 16, 20, 20, 20, 37, 40, 40, 41, 50, 50,
             80)

    def pos(p):
        if p < 0.85:
            e = (1 - (1 - p / 0.85) ** 3) * (1 + over)
        else:                                    # 收尾：回落到 1.0
            q = (p - 0.85) / 0.15
            e = 1 + over * (1 - q) * (1 - q)
        return int(round(init_x + dx * e)), int(round(init_y + dy * e + drift))

    pts = {}
    t = 0
    while t < duration_ms:
        pts[t] = "%d,%d" % pos(min(1.0, t / float(duration_ms)))
        t += random.choice(steps)
    pts[duration_ms] = "%d,%d" % (target_x, target_y)
    return pts


def make_event_trace(traj, start_ms=None):
    """{elapsed_ms: "x,y"} -> TDC 事件串 JSON：[[dx,dy,dt], ...]。

    真实样本（拆包得到）里每个元素是 [dx,dy,dt]：首元素是绝对坐标，
    之后是相对上一点的位移与时间差，末尾固定一个 [1,1,12]。
    服务端不要求轨迹（无轨迹也通过过），但写进去更接近真实客户端。
    """
    items = sorted((int(ms), v) for ms, v in traj.items())
    if start_ms is None:
        start_ms = random.randint(600, 2000)     # 从页面加载到开始拖动
    out = []
    prev = None
    for ms, xy in items:
        x, y = [int(t) for t in xy.split(",")]
        if prev is None:
            out.append([x, y, start_ms + ms])
        else:
            out.append([x - prev[0], y - prev[1], ms - prev[2]])
        prev = (x, y, ms)
    out.append([1, 1, 12])
    return json.dumps(out, separators=(",", ":"))


# 事件串剩余部分拼接的位置：cur9 布局里 counter 补位是 tokens[28]（14 个空格），
# tdc.js 就把事件串的 [24:] 拼在它后面。
EVENT_INSERT_AFTER = 28


def build_plaintext(now_sec, counter=1, events=None):
    """Layout -> plaintext bytes for a new call.

    `now_sec`/`counter` 是每次调用真正变化的字段；`events` 是轨迹串，
    按 tdc.js 的方式写入：先空格补齐到 24 的倍数，前 24 字符占头部槽位，
    其余拼在 counter 补位之后。
    """
    toks = list(LAYOUT["tokens"])
    dyn = LAYOUT.get("dynamic") or {}
    if dyn.get("now_sec") is not None:
        toks[int(dyn["now_sec"])] = str(int(now_sec))
    if dyn.get("counter") is not None:
        toks[int(dyn["counter"])] = str(int(counter))
        nd = len(str(int(counter)))
        for j, width in (dyn.get("pads") or {}).items():
            w = int(width) - nd
            if w >= 0:
                toks[int(j)] = " " * w

    head = LAYOUT["prefix"]
    insert = ""
    if events is not None:
        ev = str(events)
        ev += " " * ((-len(ev)) % 24)       # 事件串补齐到 24 的整数倍
        head = ev[:24] + '{"cd":['
        if len(ev) > 24:
            insert = ev[24:]

    s = head + ",".join(toks) + LAYOUT["suffix"]
    if insert:
        j = EVENT_INSERT_AFTER
        off = len(head) + sum(len(t) for t in toks[:j]) + j + len(toks[j])
        s = s[:off] + insert + s[off:]
    return (s + "\x00" * ((-len(s)) % 8)).encode("latin-1")

# --------------------------------------------------------------------------- #
# 1. 滑块识别（接口参考 mfw.py 的 SliderCaptchaSolver）
# --------------------------------------------------------------------------- #
class SliderCaptchaSolver:
    """缺口/距离求解器：只吃本地图片 + prehandle 的 dyn_show_info。"""

    def __init__(self, background_path, sprite_path, dsi):
        self.bg_path = background_path
        self.sprite_path = sprite_path
        self.dsi = dsi
        self.bg_rgb = None
        self.bg_lum = None
        self.sprite = None
        self.fg = None
        self.piece_mask = None
        self.piece_offset = None
        self.init_pos = None
        self.hole = None

    def load_images(self):
        """读取两图并裁出拼图块内容（等价原版 crop_slider）。"""
        self.fg = [e for e in self.dsi["fg_elem_list"] if e.get("id") == 1][0]
        sx, sy = self.fg["sprite_pos"]
        w, h = self.fg["size_2d"]
        self.init_pos = self.fg["init_pos"]

        self.sprite = np.array(Image.open(self.sprite_path).convert("RGBA"))
        crop = self.sprite[sy:sy + h, sx:sx + w]
        self.piece_mask = crop[:, :, 3] > 128
        ys, xs = np.nonzero(self.piece_mask)
        ox, oy = int(xs.min()), int(ys.min())
        pw, ph = int(xs.max() - ox + 1), int(ys.max() - oy + 1)
        self.piece_offset = (ox, oy, pw, ph)

        self.bg_rgb = np.array(Image.open(self.bg_path).convert("RGB"))
        self.bg_lum = np.array(Image.open(self.bg_path).convert("L")).astype(np.float32)
        logger.debug(f"图片已加载: bg={self.bg_rgb.shape} "
                     f"sprite={self.sprite.shape} piece_bbox={self.piece_offset}")
        return self

    def find_gap_position(self):
        """返回缺口信息（设计像素坐标）。"""
        if self.bg_rgb is None:
            self.load_images()
        expected_y = self.init_pos[1] + self.piece_offset[1]
        hole = find_hole(self.bg_rgb, self.bg_lum, self.piece_mask,
                         self.piece_offset, expected_y=expected_y)
        if hole is None or hole.get("iou", 0) < 0.5:
            alt = match_piece(self.bg_rgb, self.sprite, self.fg,
                              expected_y=expected_y)
            if hole is None or alt["iou"] >= 0.5:
                hole = alt
        self.hole = hole
        logger.debug(f"缺口: {hole}")
        return hole

    def calculate_move_distance(self):
        """ans_x = 缺口内容 x - 拼图块内容偏移 x（原版的 distance）。"""
        hole = self.find_gap_position()
        return int(hole["hole_x"] - self.piece_offset[0])

    def build_answer(self, distance=None):
        if distance is None:
            distance = self.calculate_move_distance()
        y = self.init_pos[1]
        return {"x": int(distance), "y": int(y),
                "data": "%d,%d" % (int(distance), y)}


# --------------------------------------------------------------------------- #
# 2. 验证器（接口参考 mfw.py 的 TencentCaptchaVerifier）
# --------------------------------------------------------------------------- #
class TencentCaptchaVerifier:
    """prehandle / PoW / collect / verify，全部纯 requests。"""

    def __init__(self, aid=AID, entry_url=ENTRY_URL, output_dir="output"):
        self.aid = aid
        self.entry_url = entry_url
        self.output_dir = output_dir
        self.http = self._make_session()
        self.tkid = None
        self.sess = None
        self.dsi = None
        self.pow_cfg = None
        self.bg_url = None
        self.sprite_url = None
        self.init_pos = None
        self.pow_answer = None
        self.pow_calc_time = None

    @staticmethod
    def _make_session():
        s = requests.Session()
        s.headers.update({
            "Accept": "*/*",
            "Accept-Language": "zh-CN,zh;q=0.9",
            "Referer": "https://cloud.tencent.com/",
            "Origin": "https://cloud.tencent.com",
            "User-Agent": UA,
            "sec-ch-ua": '"Chromium";v="146", "Not-A.Brand";v="24", '
                         '"Google Chrome";v="146"',
            "sec-ch-ua-mobile": "?0",
            "sec-ch-ua-platform": '"Windows"',
        })
        return s

    def get_captcha_images(self, bg_path, sprite_path):
        """prehandle + 下载两张图（等价原版同名方法）。"""
        self.tkid = str(int(time.time() * 1000) % 1000000000)
        cb = "_aq_%d" % random.randint(10000, 99999)
        params = {
            "aid": self.aid, "protocol": "https", "accver": "1",
            "showtype": "popup",
            "ua": base64.b64encode(UA.encode()).decode(),
            "noheader": "1", "fb": "1", "aged": "0", "enableAged": "0",
            "enableDarkMode": "0", "grayscale": "1", "clientype": "2",
            "cap_cd": "", "uid": "", "lang": "zh-cn",
            "entry_url": self.entry_url, "elder_captcha": "0",
            "js": "/tgJCap.2f0b2c65.js", "login_appid": "",
            "wb": "2", "tkid": self.tkid, "subsid": "1",
            "callback": cb, "sess": "",
        }
        r = self.http.get(BASE + "/cap_union_prehandle", params=params,
                          timeout=10)
        r.raise_for_status()
        m = re.search(r"^%s\((.*)\)$" % re.escape(cb), r.text.strip(), re.S)
        pre = json.loads(m.group(1) if m else r.text)
        data = pre["data"]
        self.sess = pre.get("sess") or data.get("sess") or ""
        if not self.sess:
            raise RuntimeError("prehandle 响应里没有 sess")
        self.dsi = data["dyn_show_info"]
        self.pow_cfg = data["comm_captcha_cfg"]["pow_cfg"]
        fg = [e for e in self.dsi["fg_elem_list"] if e.get("id") == 1][0]
        self.init_pos = fg["init_pos"]
        self.bg_url = self.dsi["bg_elem_cfg"]["img_url"]
        self.sprite_url = self.dsi["sprite_url"]

        for url, path in ((self.bg_url, bg_path),
                          (self.sprite_url, sprite_path)):
            if url.startswith("/"):
                url = BASE + url
            rr = self.http.get(url + "&tkid=" + self.tkid, timeout=10)
            rr.raise_for_status()
            with open(path, "wb") as f:
                f.write(rr.content)

        logger.success(f"prehandle: sess={len(self.sess)} tkid={self.tkid} "
                       f"init_pos={self.init_pos}")
        logger.debug(f"pow_cfg: {self.pow_cfg}")
        return self

    def compute_pow(self):
        prefix, target = self.pow_cfg["prefix"], self.pow_cfg["md5"]
        t0 = time.time()
        n = 0
        while hashlib.md5((prefix + str(n)).encode()).hexdigest() != target:
            n += 1
        self.pow_answer = prefix + str(n)
        self.pow_calc_time = max(1, int((time.time() - t0) * 1000))
        logger.debug(f"pow: {self.pow_answer} in {self.pow_calc_time} ms")
        return self.pow_answer, self.pow_calc_time

    def build_collect(self, now_sec=None, counter=1, events=None):
        """组 collect：内嵌布局填时间/计数（可选轨迹串）-> 加密 -> 回环自检。"""
        if now_sec is None:
            now_sec = int(time.time())
        pt = build_plaintext(now_sec, counter, events=events)
        data = get_data(pt, PROFILE)
        if decode_data(data, PROFILE) != pt:
            raise RuntimeError("collect 自检失败（解密 != 明文）")
        logger.debug(f"collect: plaintext={len(pt)} raw={len(data)} "
                     f"decoded={len(urllib.parse.unquote(data))} "
                     f"eks={len(PROFILE['eks'])}")
        return data, pt

    def verify_captcha(self, distance, submit=False, events=None):
        """组装并（可选）提交一次 verify。"""
        ans = [{"elem_id": 1, "type": "DynAnswerType_POS",
                "data": "%d,%d" % (int(distance), self.init_pos[1])}]
        collect, pt = self.build_collect(events=events)
        tlg = len(collect)
        pow_answer, pow_ms = self.compute_pow()
        body = {
            "collect": collect, "tlg": str(tlg),
            "eks": PROFILE["eks"], "sess": self.sess,
            "ans": json.dumps(ans, separators=(",", ":")),
            "tkid": self.tkid, "pow_answer": pow_answer,
            "pow_calc_time": str(pow_ms),
        }
        summary = {"ans": ans[0]["data"], "tlg": tlg,
                   "plaintext_len": len(pt),
                   "collect_decoded_len": len(urllib.parse.unquote(collect)),
                   "pow_calc_time": pow_ms}
        if not submit:
            logger.warning("DRY RUN: 未提交（--submit 才会发，且只发一次）")
            summary["dry_run"] = True
            return summary

        r = self.http.post(BASE + "/cap_union_new_verify", data=body,
                           timeout=15)
        logger.success(f"HTTP {r.status_code} {r.text[:400]}")
        try:
            result = json.loads(r.text)
        except Exception:
            result = {"raw": r.text}
        result["_summary"] = summary
        return result


# --------------------------------------------------------------------------- #
# 3. 入口
# --------------------------------------------------------------------------- #
def main():
    submit = "--submit" in sys.argv
    os.makedirs("output", exist_ok=True)
    bg = os.path.join("output", "bg.png")
    sp = os.path.join("output", "sprite.png")

    verifier = TencentCaptchaVerifier()
    verifier.get_captcha_images(bg, sp)

    solver = SliderCaptchaSolver(bg, sp, verifier.dsi)
    solver.load_images()
    distance = solver.calculate_move_distance()
    answer = solver.build_answer(distance)
    logger.success(f"答案: {answer['data']} "
                   f"(method={solver.hole.get('method', 'mask')}, "
                   f"iou={solver.hole.get('iou')})")

    traj = make_trajectory(*solver.init_pos, answer["x"], answer["y"])
    events = make_event_trace(traj)
    logger.debug(f"轨迹: {len(traj)} 点 -> 事件串 {len(events)} 字符（已写入 collect）")

    result = verifier.verify_captcha(distance, submit=submit, events=events)
    print(json.dumps(result, ensure_ascii=False, indent=1))
    if submit:
        sys.exit(0 if result.get("errorCode") == "0" else 2)
    sys.exit(0)


if __name__ == "__main__":
    main()
