# -*- coding: utf-8 -*-
"""Tencent TCaptcha v2 slider (aid 192962660) — the whole flow in one file.

Pipeline
--------
  1. fresh browser tab (CDP 9222) opens the public demo and the widget
  2. prehandle response / both images / tdc.js source are captured from that
     tab's own network traffic (so every parameter belongs to ONE session)
  3. puzzle answer is solved locally (numpy + Pillow only)
  4. a human-like drag trajectory is generated locally
  5. the trajectory is fed to the page's TDC via TDC.setData, then
     TDC.getData(true) / TDC.getInfo().info are read
  6. the captured collect is DECRYPTED and RE-ENCRYPTED locally with the
     per-build XTEA-variant cipher, proving the algorithm on this session
  7. PoW is solved locally
  8. (only with --submit) one form-encoded POST to /cap_union_new_verify

What is local and what is not
-----------------------------
Local: PoW, answer/geometry, trajectory, decrypt + re-encrypt of `collect`,
       request assembly.
From the browser: `collect` (the drag trace must be written by the page's own
       event recorder), `eks` (a per-build constant embedded in tdc.js), and
       the per-session `sess`/`tkid` — a captcha session is bound to the
       browser context that created it, so a pure-`requests` prehandle cannot
       be paired with a browser `collect` (and vice versa).

The per-build cipher parameters (key/case/split + build sha) are loaded from
`js/live_src/profile_*.json`.  tdc.js is re-randomised on every request, so a
fresh tab usually presents a build with no profile; the flow then calls the
repo's static analyser (`scripts/derive_build.py`, offline, on the source this
tab already loaded + this session's collects) to create one, and only then
runs step 6.  `--no-derive` skips that and just warns.

Safety / authorization
----------------------
* exactly ONE POST per invocation, no retry loop, and only with --submit;
* default is a dry run that never posts;
* the tab is private to this process and closed on exit;
* the POST has been explicitly authorized by the user for this public demo aid
  only, with a hard cap on total submissions; do not raise that cap yourself.

Usage
-----
    python solve_flow.py              # dry run (no POST), auto-derives build
    python solve_flow.py --no-derive  # skip derivation if the build is new
    python solve_flow.py --submit     # one POST, only if re-authorized
Exit code 0 on success, 2 on a failed verify, 1 on setup errors.
"""
import base64
import hashlib
import http.client
import json
import os
import random
import re
import subprocess
import sys
import time
import urllib.parse
from collections import deque

import numpy as np
import requests
import websocket
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
PROFILE_DIR = os.path.join(HERE, "js", "live_src")

AID = "192962660"
BASE = "https://turing.captcha.qcloud.com"
PAGE = "https://cloud.tencent.com/product/captcha"
UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36")
CDP_PORT = 9222

OUT = os.path.join(HERE, "solve_flow_result.json")
BG_PATH = os.path.join(HERE, "solve_flow_bg.png")
SP_PATH = os.path.join(HERE, "solve_flow_sprite.png")


# --------------------------------------------------------------------------- #
# 1. collect cipher: XTEA variant (32 rounds), 24/split segment rotation,
#    base64 + percent-encoding.  Every constant is per-build.
# --------------------------------------------------------------------------- #
M32 = 0xFFFFFFFF
DELTA = 2654435769
SUM_END = 32 * DELTA

P = {}                      # build sha256_16 -> {"key","case","split","name"}


def load_profiles():
    import glob
    for path in sorted(glob.glob(os.path.join(PROFILE_DIR, "profile_*.json"))):
        try:
            d = json.load(open(path, encoding="utf-8"))
        except Exception:
            continue
        if not d.get("verified") or not d.get("sha256_16"):
            continue
        P[d["sha256_16"]] = {"key": d["key"], "case": d["case"],
                             "split": int(d["split"]), "name": d.get("name")}


def _i32(x):
    x &= M32
    return x - 0x100000000 if x & 0x80000000 else x


def _u32(x):
    return x & M32


def _mix(v, k, c):
    """((v<<4 ^ v>>>5) + v) ^ (sum + K[i] + C[i]) with JS coercion rules."""
    return _i32((_i32(v << 4) ^ (_u32(v) >> 5)) + v) ^ _i32(k + c)


def _block(v0, v1, key, case):
    s = 0
    while s != SUM_END:
        i = _u32(s) & 3
        v0 = v0 + _mix(v1, s + key[i], case[i])
        s += DELTA
        i = (_u32(s) >> 11) & 3
        v1 = v1 + _mix(v0, s + key[i], case[i])
    return v0, v1


def _block_decrypt(v0, v1, key, case):
    s = SUM_END
    while s:
        i = (_u32(s) >> 11) & 3
        v1 = v1 - _mix(v0, s + key[i], case[i])
        s -= DELTA
        i = _u32(s) & 3
        v0 = v0 - _mix(v1, s + key[i], case[i])
    return v0, v1


def _w2b(x):
    x = _u32(x)
    return bytes((x & 255, (x >> 8) & 255, (x >> 16) & 255, (x >> 24) & 255))


def _b2w(b):
    return b[0] | (b[1] << 8) | (b[2] << 16) | (b[3] << 24)


def encrypt_blocks(pt, key, case):
    if len(pt) % 8:
        raise ValueError("plaintext must be a multiple of 8 bytes")
    out = bytearray()
    for i in range(0, len(pt), 8):
        v0, v1 = _block(_b2w(pt[i:i + 4]), _b2w(pt[i + 4:i + 8]), key, case)
        out += _w2b(v0) + _w2b(v1)
    return bytes(out)


def rotate(ct, split):
    """data_raw = ct[24:split] + ct[0:24] + ct[split:]"""
    return ct[24:split] + ct[0:24] + ct[split:]


def unrotate(raw, split):
    k = split - 24
    return raw[k:split] + raw[0:k] + raw[split:]


def get_data(pt, prof):
    raw = rotate(encrypt_blocks(pt, prof["key"], prof["case"]), prof["split"])
    return urllib.parse.quote(base64.b64encode(raw).decode("ascii"), safe="")


def decode_data(data, prof):
    """TDC collect string -> plaintext bytes (validation / analysis path)."""
    raw = base64.b64decode(urllib.parse.unquote(data))
    ct = unrotate(raw, prof["split"])
    out = bytearray()
    for i in range(0, len(ct), 8):
        v0, v1 = _block_decrypt(_b2w(ct[i:i + 4]), _b2w(ct[i + 4:i + 8]),
                                prof["key"], prof["case"])
        out += _w2b(v0) + _w2b(v1)
    return bytes(out)


# --------------------------------------------------------------------------- #
# 2. slider solver (mask path + darkened-hole template fallback)
# --------------------------------------------------------------------------- #
def _components(mask, min_area):
    h, w = mask.shape
    seen = mask.copy()
    out = []
    ys, xs = np.nonzero(mask)
    for sy, sx in zip(ys, xs):
        if not seen[sy, sx]:
            continue
        q = deque([(sy, sx)])
        seen[sy, sx] = False
        n = 0
        minx = maxx = sx
        miny = maxy = sy
        pix = []
        while q:
            y, x = q.popleft()
            n += 1
            pix.append((y, x))
            if x < minx: minx = x
            if x > maxx: maxx = x
            if y < miny: miny = y
            if y > maxy: maxy = y
            for dy, dx in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                ny, nx = y + dy, x + dx
                if 0 <= ny < h and 0 <= nx < w and seen[ny, nx]:
                    seen[ny, nx] = False
                    q.append((ny, nx))
        if n >= min_area:
            out.append({"area": n, "pix": pix,
                        "bbox": (minx, miny, maxx - minx + 1, maxy - miny + 1)})
    return out


def _hole_mask(bg_rgb, bg_lum):
    """Desaturated, mid-dark overlay = hole (rendering variant A)."""
    a = bg_rgb.astype(np.int16)
    sat = (a.max(2) - a.min(2)).astype(np.float32)
    return (bg_lum >= 40) & (bg_lum <= 140) & (sat <= 22)


def _iou(a_mask, a_off, b_mask, b_off, shift=(0, 0)):
    ax0, ay0 = a_off
    bx0, by0 = b_off[0] + shift[0], b_off[1] + shift[1]
    x0 = min(ax0, bx0); y0 = min(ay0, by0)
    x1 = max(ax0 + a_mask.shape[1], bx0 + b_mask.shape[1])
    y1 = max(ay0 + a_mask.shape[0], by0 + b_mask.shape[0])
    A = np.zeros((y1 - y0, x1 - x0), bool)
    B = np.zeros_like(A)
    A[ay0 - y0:ay0 - y0 + a_mask.shape[0],
      ax0 - x0:ax0 - x0 + a_mask.shape[1]] = a_mask
    B[by0 - y0:by0 - y0 + b_mask.shape[0],
      bx0 - x0:bx0 - x0 + b_mask.shape[1]] = b_mask
    inter = (A & B).sum()
    union = (A | B).sum()
    return inter / union if union else 0.0


def find_hole(bg_rgb, bg_lum, piece_mask, piece_bbox, expected_y=None):
    """Hole content origin via connected components + mask IoU.

    The thresholded hole mask is eroded by the anti-aliased rim.  Its y is
    known exactly (the piece only moves horizontally), so the y erosion is
    measured and applied to x as well.  That correction is 1-2 px and is NOT
    always valid for x; prefer the raw bbox when in doubt (see README 5.4).
    """
    pw, ph = piece_bbox[2], piece_bbox[3]
    mask = _hole_mask(bg_rgb, bg_lum)
    comps = _components(mask, int(piece_mask.sum() * 0.35))
    pm = piece_mask[piece_bbox[1]:piece_bbox[1] + ph,
                    piece_bbox[0]:piece_bbox[0] + pw]
    cands = []
    for c in comps:
        cx, cy, cw, ch = c["bbox"]
        if not (0.6 * pw <= cw <= 1.45 * pw and 0.55 * ph <= ch <= 1.6 * ph):
            continue
        cm = np.zeros((ch, cw), bool)
        for y, x in c["pix"]:
            cm[y - cy, x - cx] = True
        best = (0.0, 0, 0)
        for dy in range(-4, 5):
            for dx in range(-4, 5):
                score = _iou(pm, (0, 0), cm, (dx, dy))
                if score > best[0]:
                    best = (score, dx, dy)
        cands.append((best[0], cx + best[1], cy + best[2], cw, ch, cx, cy))
    if not cands:
        return None
    cands.sort(reverse=True)
    iou, hx, hy, cw, ch, bx, by = cands[0]
    corr = None
    if expected_y is not None:
        corr = int(by - expected_y)
        if -1 <= corr <= 6:
            hx = bx - corr
            hy = int(expected_y)
        else:
            corr = None
    return {"hole_x": int(hx), "hole_y": int(hy), "iou": round(float(iou), 3),
            "comp_w": int(cw), "comp_h": int(ch), "edge_corr": corr,
            "comp_bbox": [int(bx), int(by)], "method": "mask",
            "margin": round(float(cands[0][0] - cands[1][0]), 3)
            if len(cands) > 1 else None}


def match_piece(bg_rgb, sprite_rgba, fg, expected_y=None):
    """Template matching fallback (rendering variant B: hole = photo * k).

    Zero-mean normalised correlation over the eroded opaque core, y searched
    around the known value, k<0.8 prior to reject flat bright patches.
    """
    sx, sy = fg["sprite_pos"]
    w, h = fg["size_2d"]
    init_x, init_y = fg["init_pos"]
    crop = sprite_rgba[sy:sy + h, sx:sx + w]
    mask = crop[:, :, 3] > 128
    if not mask.any():
        raise ValueError("empty piece mask")
    ys, xs = np.nonzero(mask)
    ox, oy = int(xs.min()), int(ys.min())
    pw, ph = int(xs.max() - ox + 1), int(ys.max() - oy + 1)
    piece = crop[oy:oy + ph, ox:ox + pw, :3].astype(np.float32)
    pl = piece.mean(2)
    core = mask[oy:oy + ph, ox:ox + pw].copy()
    for _ in range(3):
        core = (core & np.roll(core, 1, 0) & np.roll(core, -1, 0)
                & np.roll(core, 1, 1) & np.roll(core, -1, 1))
    if core.sum() < 50:
        core = mask[oy:oy + ph, ox:ox + pw].copy()

    y0 = int(expected_y if expected_y is not None else init_y + oy)
    H, W = bg_rgb.shape[:2]
    bgl = bg_rgb.astype(np.float32)
    bg_l = bgl.mean(2)
    a = piece[core]
    pa = pl[core]
    pa0 = pa - pa.mean()
    dena = float(np.sqrt((pa0 * pa0).sum())) + 1e-9
    scores = []
    for y in range(max(0, y0 - 6), min(H - ph, y0 + 6) + 1):
        for x in range(0, W - pw + 1):
            p = bg_l[y:y + ph, x:x + pw][core]
            p0 = p - p.mean()
            ncc = float((pa0 * p0).sum() /
                        (dena * (float(np.sqrt((p0 * p0).sum())) + 1e-9)))
            b = bgl[y:y + ph, x:x + pw][core]
            k = float((a * b).sum() / ((a * a).sum() + 1e-6))
            resid = float(np.abs(b - a * k).mean())
            scores.append((ncc, -resid, x, y, k, resid))
    scores.sort(reverse=True)
    dark = [s for s in scores if s[4] < 0.8]
    pool = dark if dark else scores
    ncc, _neg, best_x, best_y, k, resid = pool[0]
    around = [s for s in pool if abs(s[2] - best_x) > pw // 2]
    second = around[0][0] if around else None
    return {"hole_x": int(best_x), "hole_y": int(y0), "iou": round(float(ncc), 3),
            "comp_w": pw, "comp_h": ph, "edge_corr": None,
            "comp_bbox": [int(best_x), int(best_y)], "method": "template",
            "margin": round(ncc - second, 3) if second is not None else None,
            "k": round(float(k), 3), "resid": round(resid, 2)}


def answer_from_session(bg_path, sprite_path, dsi):
    """Return the ans value plus the geometry that led to it."""
    fg = [e for e in dsi["fg_elem_list"] if e.get("id") == 1][0]
    sx, sy = fg["sprite_pos"]
    w, h = fg["size_2d"]
    init_x, init_y = fg["init_pos"]

    sprite = np.array(Image.open(sprite_path).convert("RGBA"))
    crop = sprite[sy:sy + h, sx:sx + w]
    pmask = crop[:, :, 3] > 128
    ys, xs = np.nonzero(pmask)
    ox, oy = int(xs.min()), int(ys.min())
    pw, ph = int(xs.max() - ox + 1), int(ys.max() - oy + 1)

    bg = np.array(Image.open(bg_path).convert("RGB"))
    bg_lum = np.array(Image.open(bg_path).convert("L")).astype(np.float32)
    expected_y = init_y + oy
    hole = find_hole(bg, bg_lum, pmask, (ox, oy, pw, ph), expected_y=expected_y)
    if hole is None or hole.get("iou", 0) < 0.5:
        alt = match_piece(bg, sprite, fg, expected_y=expected_y)
        if hole is None or alt["iou"] >= 0.5:
            hole = alt
    ans_x = hole["hole_x"] - ox
    dy = hole["hole_y"] - expected_y
    return {"x": int(ans_x), "y": int(init_y),
            "data": "%d,%d" % (ans_x, init_y),
            "piece_offset": (ox, oy), "hole": hole,
            "init_pos": [init_x, init_y], "y_check_ok": abs(dy) <= 4}


# --------------------------------------------------------------------------- #
# 3. trajectory (one entry per elapsed ms, design pixels)
# --------------------------------------------------------------------------- #
def make_trajectory(init_x, init_y, target_x, target_y,
                    duration_ms=1500, n=30):
    pts = {}
    for i in range(n):
        p = i / float(n - 1)
        e = 4 * p ** 3 if p < 0.5 else 1 - ((-2 * p + 2) ** 3) / 2.0
        x = int(init_x + (target_x - init_x) * e)
        y = int(init_y + (target_y - init_y) * e)
        if 0.1 < p < 0.9:
            x += random.choice((-1, 0, 1))
            y += random.choice((-1, 0, 1))
        pts[int(p * duration_ms)] = "%d,%d" % (x, y)
    pts[duration_ms] = "%d,%d" % (target_x, target_y)
    return pts


# --------------------------------------------------------------------------- #
# 4. minimal CDP client (fresh private tab)
# --------------------------------------------------------------------------- #
def new_target():
    c = http.client.HTTPConnection("127.0.0.1", CDP_PORT, timeout=5)
    c.request("PUT", "/json/new?about:blank")
    return json.loads(c.getresponse().read())


def close_target(tid):
    try:
        c = http.client.HTTPConnection("127.0.0.1", CDP_PORT, timeout=5)
        c.request("PUT", "/json/close/" + tid)
        c.getresponse().read()
    except Exception:
        pass


class CDP:
    def __init__(self, url, timeout=120):
        self.ws = websocket.create_connection(url, timeout=timeout,
                                              suppress_origin=True)
        self.i = 0
        self.events = []

    def call(self, method, timeout=60, **p):
        self.i += 1
        mid = self.i
        self.ws.send(json.dumps({"id": mid, "method": method, "params": p}))
        end = time.time() + timeout
        while True:
            self.ws.settimeout(max(0.5, end - time.time()))
            m = json.loads(self.ws.recv())
            if m.get("id") == mid:
                if "error" in m:
                    raise RuntimeError("%s -> %s" % (method, m["error"]))
                return m.get("result", {})
            if "method" in m:
                self.events.append(m)

    def ev(self, expr, timeout=60, await_promise=True):
        r = self.call("Runtime.evaluate", expression=expr, returnByValue=True,
                      awaitPromise=await_promise, timeout=timeout)
        if r.get("exceptionDetails"):
            return {"__exc": str(r["exceptionDetails"])[:300]}
        return r.get("result", {}).get("value")


def pump(c, secs):
    end = time.time() + secs
    while time.time() < end:
        c.ev("1", await_promise=False)
        time.sleep(0.15)


def open_widget(c):
    """Navigate and open the demo captcha; wait for TDC.

    Returns the tab to the caller; the caller closes it.
    """
    c.call("Runtime.enable")
    c.call("Page.enable")
    c.call("Network.enable")
    c.call("Page.navigate", url=PAGE)
    for _ in range(40):
        time.sleep(0.5)
        if c.ev("document.readyState", await_promise=False) == "complete":
            break
    c.ev("(function(){var b=[...document.querySelectorAll('a.tpm-btn')]"
         ".filter(function(e){return e.textContent.trim()==='立即体验';})[0];"
         "if(b){b.click();return 1}return 0})()", await_promise=False)
    for _ in range(60):
        time.sleep(0.5)
        if c.ev("typeof window.TDC==='object'", await_promise=False):
            return True
    return False


# --------------------------------------------------------------------------- #
# 5. capture one session's network artifacts
# --------------------------------------------------------------------------- #
def capture_session(c, deadline=45):
    """Collect prehandle cfg, images and tdc.js source from this tab."""
    pre_req = {}
    pre_id = None
    img_req = {}
    img_ids = {}
    tdc_id = None
    bodies = {}
    tdc_app_data = None
    end = time.time() + deadline
    while time.time() < end:
        pump(c, 0.4)
        for e in c.events:
            m = e.get("method")
            p = e.get("params", {})
            if m == "Network.requestWillBeSent":
                u = p.get("request", {}).get("url", "")
                q = urllib.parse.urlparse(u)
                if "cap_union_prehandle" in u:
                    pre_req[p["requestId"]] = urllib.parse.parse_qs(q.query)
                elif "cap_union_new_getcapbysig" in u:
                    img_req[p["requestId"]] = urllib.parse.parse_qs(q.query)
                elif q.path.endswith("/tdc.js"):
                    tdc_app_data = urllib.parse.parse_qs(q.query).get(
                        "app_data", [""])[0]
            elif m == "Network.responseReceived":
                u = p.get("response", {}).get("url", "")
                rid = p["requestId"]
                if "cap_union_prehandle" in u:
                    pre_id = rid
                elif "cap_union_new_getcapbysig" in u:
                    img_ids[rid] = u
                elif urllib.parse.urlparse(u).path.endswith("/tdc.js"):
                    tdc_id = rid
        for rid in ([pre_id] if pre_id else []) + list(img_ids) + \
                   ([tdc_id] if tdc_id else []):
            if rid and rid not in bodies:
                try:
                    bodies[rid] = c.call("Network.getResponseBody", requestId=rid)
                except Exception:
                    pass
        if pre_id and len(img_ids) >= 2 and tdc_id \
                and pre_id in bodies and all(r in bodies for r in img_ids) \
                and tdc_id in bodies:
            break
    if not pre_id or pre_id not in bodies:
        raise SystemExit("prehandle response not captured")
    if not tdc_id or tdc_id not in bodies:
        raise SystemExit("tdc.js source not captured")

    raw = bodies[pre_id]["body"]
    if bodies[pre_id].get("base64Encoded"):
        raw = base64.b64decode(raw).decode("utf-8", "replace")
    m = re.search(r"^[^(]*\((.*)\)\s*;?\s*$", raw.strip(), re.S)
    pre = json.loads(m.group(1) if m else raw)

    tdc = bodies[tdc_id]["body"]
    if bodies[tdc_id].get("base64Encoded"):
        tdc = base64.b64decode(tdc).decode("utf-8", "replace")

    blobs = {}
    for rid, u in img_ids.items():
        idx = (img_req.get(rid, {}).get("img_index") or ["?"])[0]
        b = bodies[rid]
        blobs[idx] = (base64.b64decode(b["body"]) if b.get("base64Encoded")
                      else b["body"].encode("latin-1"))
    return {"pre": pre,
            "pre_q": pre_req.get(pre_id, {}),
            "images": blobs,
            "tdc_src": tdc,
            "tdc_app_data": tdc_app_data}


def take_samples(c, n=2, gap=1.1):
    """n collects from the same session, spaced so now_sec differs."""
    out = []
    for i in range(n):
        if i:
            time.sleep(gap)
        out.append(c.ev(
            "(function(){return {d:TDC.getData(true),"
            "now:Math.floor(Date.now()/1000)}})()", await_promise=False))
    return out


def derive_profile(sha, tdc_src, samples):
    """Derive the per-build cipher constants for an unknown build.

    Reuses the repo's proven static analyser (scripts/derive_build.py) on the
    source this tab actually loaded plus the collects of this same session.
    Writes js/live_src/profile_flow<sha8>.json and returns its name.
    """
    name = "flow" + sha[:8]
    src_path = os.path.join(PROFILE_DIR, "tdc_%s.js" % name)
    with open(src_path, "w", encoding="utf-8") as f:
        f.write(tdc_src)
    probe = os.path.join(HERE, "scripts", "solve_flow_probe_%s.json" % name)
    json.dump({"sha256_16": sha, "src": src_path, "datas": samples},
              open(probe, "w"), indent=1)
    cmd = [sys.executable,
           os.path.join(HERE, "scripts", "derive_build.py"), name,
           "--src", src_path, "--from-json", probe]
    print("deriving build %s via scripts/derive_build.py ..." % sha)
    r = subprocess.run(cmd, cwd=os.path.join(HERE, "scripts"),
                       capture_output=True, text=True, timeout=600)
    tail = (r.stdout or "").strip().splitlines()[-3:]
    for line in tail:
        print("  " + line)
    if r.returncode != 0:
        print("  derive failed (%d): %s" % (r.returncode,
                                            (r.stderr or "").strip()[:200]))
        return None
    load_profiles()
    return name if sha in P else None


# --------------------------------------------------------------------------- #
# 6. PoW
# --------------------------------------------------------------------------- #
def solve_pow(pow_cfg):
    prefix, target = pow_cfg["prefix"], pow_cfg["md5"]
    t0 = time.time()
    n = 0
    while hashlib.md5((prefix + str(n)).encode()).hexdigest() != target:
        n += 1
    return prefix + str(n), max(1, int((time.time() - t0) * 1000))


# --------------------------------------------------------------------------- #
# 7. end-to-end flow
# --------------------------------------------------------------------------- #
def run(submit, derive=True):
    load_profiles()
    t = new_target()
    tid = t["id"]
    c = CDP(t["webSocketDebuggerUrl"])
    result = {"submit": submit}
    try:
        if not open_widget(c):
            raise SystemExit("TDC did not load")
        cap = capture_session(c)

        data = cap["pre"]["data"]
        sess = cap["pre"].get("sess") or data.get("sess") or ""
        tkid = (cap["pre_q"].get("tkid") or [""])[0]
        if not sess or not tkid:
            raise SystemExit("sess/tkid missing in prehandle")
        dsi = data["dyn_show_info"]
        pow_cfg = data["comm_captcha_cfg"]["pow_cfg"]
        fg = [e for e in dsi["fg_elem_list"] if e.get("id") == 1][0]
        init_x, init_y = fg["init_pos"]
        print("session: sess=%d tkid=%s init_pos=%s" %
              (len(sess), tkid, fg["init_pos"]))

        # same-session sanity: the TDC instance must be built for this
        # prehandle's app_data, otherwise the server decrypts with other keys
        app_data = urllib.parse.parse_qs(
            urllib.parse.urlparse(data["comm_captcha_cfg"]["tdc_path"]).query
        ).get("app_data", [""])[0]
        if app_data and cap["tdc_app_data"] and app_data != cap["tdc_app_data"]:
            raise SystemExit("TDC build belongs to a different prehandle")

        # --- images -------------------------------------------------------
        for idx, blob in cap["images"].items():
            if idx == "1":
                open(BG_PATH, "wb").write(blob)
            elif idx == "0":
                open(SP_PATH, "wb").write(blob)
        if not (os.path.exists(BG_PATH) and os.path.exists(SP_PATH)):
            raise SystemExit("background/sprite image missing")
        print("images: bg=%d bytes sprite=%d bytes" %
              (os.path.getsize(BG_PATH), os.path.getsize(SP_PATH)))

        # --- baseline collects + build profile + PoW + cookies -----------
        # Everything that can be slow runs BEFORE the final collect, so the
        # POST can follow getData immediately: a collect that is minutes old
        # is at best unnecessary risk for a server-side freshness check.
        base_samples = take_samples(c, 2)
        sha = hashlib.sha256(cap["tdc_src"].encode()).hexdigest()[:16]
        prof = P.get(sha)
        if prof is None and derive:
            derive_profile(sha, cap["tdc_src"], base_samples)
            prof = P.get(sha)
        pow_answer, pow_ms = solve_pow(pow_cfg)
        S = requests.Session()
        S.headers.update({
            "User-Agent": UA, "Accept": "*/*",
            "Origin": "https://cloud.tencent.com",
            "Referer": "https://cloud.tencent.com/",
        })
        if submit:
            try:
                for ck in c.call("Storage.getCookies").get("cookies", []):
                    dom = (ck.get("domain") or "").lstrip(".")
                    if "qcloud.com" in dom:
                        S.cookies.set(ck["name"], ck["value"], domain=dom,
                                      path=ck.get("path", "/"))
            except Exception as e:
                print("cookie copy failed:", e)

        # --- solve --------------------------------------------------------
        ans = answer_from_session(BG_PATH, SP_PATH, dsi)
        print("ans: %s  method=%s  iou=%.3f  edge_corr=%s" % (
            ans["data"], ans["hole"].get("method"), ans["hole"].get("iou"),
            ans["hole"].get("edge_corr")))
        result.update({"ans": ans["data"], "ans_meta": ans["hole"],
                       "init_pos": [init_x, init_y]})

        # --- trajectory -> TDC.setData -> collect ------------------------
        traj = make_trajectory(init_x, init_y, ans["x"], ans["y"])
        js = ("(function(){try{TDC.setData(%s);return 'ok'}"
              "catch(e){return 'ERR '+e}})()" % json.dumps(traj))
        setdata = c.ev(js, await_promise=False)
        t_collect = time.time()
        collect = c.ev("TDC.getData(true)", await_promise=False)
        eks = c.ev("TDC.getInfo().info", await_promise=False)
        if not collect or not eks:
            raise SystemExit("TDC collect/eks unavailable")
        tlg = len(collect)
        ans_json = json.dumps([{"elem_id": 1, "type": "DynAnswerType_POS",
                                "data": ans["data"]}], separators=(",", ":"))
        body = {"collect": collect, "tlg": str(tlg), "eks": eks, "sess": sess,
                "ans": ans_json, "tkid": tkid,
                "pow_answer": pow_answer, "pow_calc_time": str(pow_ms)}
        print("collect: raw=%d decoded=%d eks=%d  setData=%s (%d pts)" % (
            tlg, len(urllib.parse.unquote(collect)), len(eks), setdata,
            len(traj)))
        result.update({"collect_len": tlg, "setdata": setdata,
                       "traj_points": len(traj),
                       "collect_decoded_len": len(urllib.parse.unquote(collect)),
                       "eks_len": len(eks),
                       "pow_answer": pow_answer, "pow_calc_time": pow_ms,
                       "body": {k: (v if len(v) < 300 else "len=%d" % len(v))
                                for k, v in body.items()}})

        # --- local algorithm check: decrypt then re-encrypt ---------------
        if prof is None:
            print("WARNING: build %s has no profile (run "
                  "scripts/derive_build.py <name> --fresh); "
                  "skipping local cipher check" % sha)
            result["build_sha"] = sha
        else:
            pt = decode_data(collect, prof)
            again = get_data(pt, prof)
            ok = again == collect
            print("cipher: build=%s(%s) pt=%d bytes  decrypt+reencrypt=%s" % (
                sha, prof["name"], len(pt), "OK" if ok else "MISMATCH"))
            result.update({"build_sha": sha, "profile": prof["name"],
                           "plaintext_len": len(pt), "cipher_ok": ok,
                           "plaintext_head":
                               pt[:120].decode("latin-1", "replace")})
            if not ok:
                raise SystemExit("local cipher check failed")

        if not submit:
            result["timing"] = {"collect_age_s": round(time.time() - t_collect, 2)}
            print("DRY RUN: nothing posted. Re-run with --submit (one POST) "
                  "only if the user has re-authorized an attempt.")
            return 0, result

        t_post = time.time()
        r = S.post(BASE + "/cap_union_new_verify", data=body, timeout=15)
        result["timing"] = {"collect_age_s": round(t_post - t_collect, 2)}
        print("collect age at POST: %.2fs" % (t_post - t_collect))
        print("HTTP", r.status_code, r.text[:600])
        result.update({"http": r.status_code, "response": r.text[:4000]})
        try:
            err = json.loads(r.text).get("errorCode")
        except Exception:
            err = None
        return (0 if err == "0" else 2), result
    finally:
        try:
            c.ws.close()
        except Exception:
            pass
        close_target(tid)


def main():
    submit = "--submit" in sys.argv
    derive = "--no-derive" not in sys.argv
    code, result = run(submit, derive)
    json.dump(result, open(OUT, "w"), indent=1)
    print("result ->", OUT)
    sys.exit(code)


if __name__ == "__main__":
    main()
