# -*- coding: utf-8 -*-
"""Browser-free (pure Python) TCaptcha slider flow, aid 192962660.

No browser, no CDP, no JS execution.  Everything is built with `requests` +
`numpy`/`Pillow` and the repo's proven pure-Python modules:

    prehandle  ->  images  ->  answer  ->  collect  ->  eks  ->  PoW  ->  verify

What each step uses
-------------------
  prehandle/images : plain HTTP (same parameters a real client sends)
  answer           : slider_solver.py (mask + template fallback)
  trajectory       : generated here (ease-in-out), reported in the result
  collect          : tdc_collect.build_from_layout() replays a saved plaintext
                     layout (environment blob: canvas PNG, UA, WebGL, times,
                     `sd`), then tdc_crypto.get_data() encrypts it with the
                     per-build key of the chosen profile
  eks              : the per-build constant stored in the profile
  PoW              : local md5 search

The honest limitation
---------------------
tdc.js is re-randomised on every HTTP request and its cipher constants (K/C,
segment split, eks) change with it.  A profile therefore belongs to ONE build.
A real browser fetches tdc.js for the session and is bound to that build; this
script never fetches tdc.js, so it presents the build of `--profile` (default:
the one with the most verified samples).  Whether the server accepts a collect
encrypted with another build's key for this `sess` is **unproven** - it is the
single open assumption of this offline path.  Everything else in the request
is computed locally.

Also still replayed rather than generated: the canvas PNG blob and `sd.ft`
(environment/session constants), and the drag-event trace (the widget writes
it via TDC.setData; its serialization inside tdc.js is not reversed yet, so
the collect here carries the baseline event header only - the run that first
passed the oracle had no drag trace either).

Usage
-----
    python offline_flow.py                 # build everything, do not POST
    python offline_flow.py --submit        # one POST, explicit grant needed
    python offline_flow.py --profile live  # pick a save profile by name
Exit codes: 0 ok, 2 server said no, 1 setup error.
"""
import base64
import hashlib
import json
import os
import random
import re
import sys
import time
import urllib.parse

import requests

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, "scripts"))

import slider_solver        # noqa: E402
import tdc_collect          # noqa: E402
import tdc_crypto           # noqa: E402

AID = "192962660"
BASE = "https://turing.captcha.qcloud.com"
UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36")
OUT = os.path.join(HERE, "offline_flow_result.json")
BG = os.path.join(HERE, "offline_bg.png")
SP = os.path.join(HERE, "offline_sprite.png")


# --------------------------------------------------------------------------- #
# HTTP session (keeps any Set-Cookie from prehandle -> verify)
# --------------------------------------------------------------------------- #
def make_session():
    s = requests.Session()
    s.headers.update({
        "User-Agent": UA, "Accept": "*/*",
        "Referer": "https://cloud.tencent.com/",
        "Origin": "https://cloud.tencent.com",
        "sec-ch-ua": '"Chromium";v="146", "Not-A.Brand";v="24", '
                     '"Google Chrome";v="146"',
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-platform": '"Windows"',
    })
    return s


def prehandle(s):
    """Pure-Python cap_union_prehandle; returns (tkid, response dict)."""
    tkid = str(int(time.time() * 1000) % 1000000000)
    cb = "_aq_%d" % random.randint(10000, 99999)
    params = {
        "aid": AID, "protocol": "https", "accver": "1", "showtype": "popup",
        "ua": base64.b64encode(UA.encode()).decode(),
        "noheader": "1", "fb": "1", "aged": "0", "enableAged": "0",
        "enableDarkMode": "0", "grayscale": "1", "clientype": "2",
        "cap_cd": "", "uid": "", "lang": "zh-cn",
        "entry_url": "https://cloud.tencent.com/product/captcha",
        "elder_captcha": "0", "js": "/tgJCap.2f0b2c65.js", "login_appid": "",
        "wb": "2", "tkid": tkid, "subsid": "1", "callback": cb, "sess": "",
    }
    r = s.get(BASE + "/cap_union_prehandle", params=params, timeout=10)
    r.raise_for_status()
    m = re.search(r"^%s\((.*)\)$" % re.escape(cb), r.text.strip(), re.S)
    return tkid, json.loads(m.group(1) if m else r.text)


def get_image(s, url, tkid):
    if url.startswith("/"):
        url = BASE + url
    r = s.get(url + "&tkid=" + tkid, timeout=10)
    r.raise_for_status()
    return r.content


# --------------------------------------------------------------------------- #
# collect: replay a saved plaintext layout, encrypt with the profile's key
# --------------------------------------------------------------------------- #
def load_profile(name):
    path = os.path.join(HERE, "js", "live_src", "profile_%s.json" % name)
    d = json.load(open(path, encoding="utf-8"))
    if not d.get("verified") or not d.get("layout"):
        raise SystemExit("profile %s is not a verified layout profile" % name)
    if not d.get("eks"):
        raise SystemExit("profile %s has no eks constant" % name)
    return d


def best_profile():
    """The verified layout profile with the most reproduced samples."""
    import glob
    best = None
    for p in sorted(glob.glob(os.path.join(HERE, "js", "live_src",
                                           "profile_*.json"))):
        try:
            d = json.load(open(p, encoding="utf-8"))
        except Exception:
            continue
        if not d.get("verified") or not d.get("layout") or not d.get("eks"):
            continue
        n = int(d.get("samples_verified") or 0)
        if best is None or n > best[0]:
            best = (n, d["name"])
    if best is None:
        raise SystemExit("no verified layout profile under js/live_src")
    return best[1]


def build_collect(prof, now_sec, counter=1):
    """Plaintext -> collect string, plus a self-check round trip."""
    pt = tdc_collect.build_from_layout(prof["layout"], now_sec=now_sec,
                                       counter=counter)
    data = tdc_crypto.get_data(pt, prof["key"], prof["case"], prof["split"])
    back = tdc_crypto.decode_data(data, prof["key"], prof["case"],
                                  prof["split"])
    if back != pt:
        raise SystemExit("collect self-check failed (decrypt != plaintext)")
    return data, pt


# --------------------------------------------------------------------------- #
# trajectory (same generator as solve_flow.py; not embedded in the collect)
# --------------------------------------------------------------------------- #
def make_trajectory(init_x, init_y, target_x, target_y,
                    duration_ms=1500, n=30):
    pts = {}
    for i in range(n):
        p = i / float(n - 1)
        e = 4 * p ** 3 if p < 0.5 else 1 - ((-2 * p + 2) ** 3) / 2.0
        x = int(init_x + (target_x - init_x) * e)
        y = int(init_y + (target_y - init_y) * e)
        if 0.1 < p < 0.9:
            x += random.choice((-1, 0, 1))
            y += random.choice((-1, 0, 1))
        pts[int(p * duration_ms)] = "%d,%d" % (x, y)
    pts[duration_ms] = "%d,%d" % (target_x, target_y)
    return pts


def solve_pow(cfg):
    prefix, target = cfg["prefix"], cfg["md5"]
    t0 = time.time()
    n = 0
    while hashlib.md5((prefix + str(n)).encode()).hexdigest() != target:
        n += 1
    return prefix + str(n), max(1, int((time.time() - t0) * 1000))


# --------------------------------------------------------------------------- #
# flow
# --------------------------------------------------------------------------- #
def run(submit, profile_name):
    prof = load_profile(profile_name)
    result = {"submit": submit, "profile": profile_name,
              "build_sha": prof.get("sha256_16")}

    s = make_session()
    tkid, pre = prehandle(s)
    data = pre["data"]
    sess = pre.get("sess") or data.get("sess") or ""
    if not sess:
        raise SystemExit("sess missing in prehandle response")
    dsi = data["dyn_show_info"]
    pow_cfg = data["comm_captcha_cfg"]["pow_cfg"]
    fg = [e for e in dsi["fg_elem_list"] if e.get("id") == 1][0]
    init_x, init_y = fg["init_pos"]
    print("prehandle: sess=%d tkid=%s init_pos=%s pow=%s" % (
        len(sess), tkid, fg["init_pos"], pow_cfg["prefix"]))

    open(BG, "wb").write(get_image(s, dsi["bg_elem_cfg"]["img_url"], tkid))
    open(SP, "wb").write(get_image(s, dsi["sprite_url"], tkid))
    print("images: bg=%d sprite=%d bytes" % (
        os.path.getsize(BG), os.path.getsize(SP)))

    ans = slider_solver.answer_from_session(BG, SP, dsi)
    print("ans: %s  method=%s  iou=%.3f" % (
        ans["data"], ans["hole"].get("method", "mask"),
        ans["hole"].get("iou")))

    traj = make_trajectory(init_x, init_y, ans["x"], ans["y"])
    print("trajectory: %d points (not embedded; see module docstring)" %
          len(traj))
    result.update({"ans": ans["data"], "ans_meta": ans["hole"],
                   "init_pos": [init_x, init_y], "traj_points": len(traj),
                   "sess_len": len(sess), "tkid": tkid})

    now = int(time.time())
    collect, pt = build_collect(prof, now, counter=1)
    tlg = len(collect)
    eks = prof["eks"]
    print("collect: plaintext=%d raw=%d decoded=%d eks=%d  now=%d" % (
        len(pt), tlg, len(urllib.parse.unquote(collect)), len(eks), now))
    result.update({"collect_len": tlg, "plaintext_len": len(pt),
                   "collect_decoded_len": len(urllib.parse.unquote(collect)),
                   "eks_len": len(eks),
                   "plaintext_head": pt[:120].decode("latin-1", "replace")})

    pow_answer, pow_ms = solve_pow(pow_cfg)
    print("pow: %s in %d ms" % (pow_answer, pow_ms))

    ans_json = json.dumps([{"elem_id": 1, "type": "DynAnswerType_POS",
                            "data": ans["data"]}], separators=(",", ":"))
    body = {"collect": collect, "tlg": str(tlg), "eks": eks, "sess": sess,
            "ans": ans_json, "tkid": tkid,
            "pow_answer": pow_answer, "pow_calc_time": str(pow_ms)}
    result.update({"pow_answer": pow_answer, "pow_calc_time": pow_ms,
                   "body": {k: (v if len(v) < 300 else "len=%d" % len(v))
                            for k, v in body.items()}})

    if not submit:
        print("DRY RUN: nothing posted (browser-free build only). "
              "Re-run with --submit after an explicit grant.")
        return 0, result

    t0 = time.time()
    r = s.post(BASE + "/cap_union_new_verify", data=body, timeout=15)
    print("HTTP", r.status_code, r.text[:600])
    result.update({"http": r.status_code, "response": r.text[:4000],
                   "pre_post_ms": int((time.time() - t0) * 1000)})
    try:
        err = json.loads(r.text).get("errorCode")
    except Exception:
        err = None
    return (0 if err == "0" else 2), result


def main():
    submit = "--submit" in sys.argv
    profile_name = None
    if "--profile" in sys.argv:
        profile_name = sys.argv[sys.argv.index("--profile") + 1]
    if not profile_name:
        profile_name = best_profile()
    print("using profile:", profile_name)
    code, result = run(submit, profile_name)
    json.dump(result, open(OUT, "w"), indent=1)
    print("result ->", OUT)
    sys.exit(code)


if __name__ == "__main__":
    main()
