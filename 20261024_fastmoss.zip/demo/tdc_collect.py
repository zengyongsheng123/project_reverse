# -*- coding: utf-8 -*-
"""Pure-Python builder for the plaintext that TDC.getData() encrypts.

The plaintext is what tdc.js hands to its XTEA-like cipher (see tdc_crypto.py).
Three independent live captures (scripts/capture_full_{b,c,d}.json) were
reassembled byte-for-byte with this builder:

    24-byte event header  |  168-byte "cd" head (space padded)  |
    tail fields  |  "sd" section  |  NUL padding to a multiple of 8

Fields were read off the running page (Windows 10 / Chrome 146 / 1920x1080),
so the environment-derived strings in `DEFAULT_ENV` describe *this* browser.
Replace them with the target browser's values for other environments; the
formatting rules (padding widths, ordering, block alignment) stay the same.

Observed layout
---------------
    "[[1,1,12]]" + 13 spaces ......  24 bytes, event/session header
        fields: [1,1,12] -- constant for this build/page
    {"cd":[ ... ]  head, padded ....  bytes 24..192 (168 bytes)
        seed, innerHeight, "", perf, 32, "UTF-8", location,
        now_sec, "+08", 8, screen_geom, []
    tail fields ....................  bytes 192..(~705)
        ,0,"",<canvas-png-b64>,"top",["zh-CN","zh"],"",webgl_vendor,
        0,2,1023,0,1,webgl_renderer,location,ua,[360,358],0,0,"Win32",0,
        t_init,891...,t_load,<counter padded to 10>,innerWidth
    ,"sd":{"od":"C","ft":"6f_7ff__H"}}
    NUL bytes ......................  last 0-7 bytes, total % 8 == 0

`counter` is the only field that grows between successive calls on the same
page (9 -> 12 -> 13 across the three captures); it is right-padded with spaces
to 10 characters, which keeps the rest of the payload at fixed offsets.
`now_sec` is the call's Unix timestamp. Everything else was session-stable.
"""

import re

# Constant 24-byte header for this page/build: "[[1,1,12]]" + padding.
HEADER_EVENTS = "[[1,1,12]]"
HEADER_LEN = 24

# "cd" head must fill exactly bytes 24..192.
CD_HEAD_END = 192

# Session-stable environment blob for the captured browser.
DEFAULT_ENV = {
    # cd[0] -- per-build constant embedded in tdc.js (NOT page randomness):
    # same build sha -> same value on every page; extract statically with
    # scripts/extract_build_const.py, see README §6.10
    "seed": 2120394880,              # 0x7E62A880
    "inner_height": 1080,
    "perf_tag": "98k",               # short perf string
    "color_depth": 32,
    "charset": "UTF-8",
    "location": "https://cloud.tencent.com/product/captcha?rand=1519713624347",
    "location2": "https://cloud.tencent.com/product/captcha",   # clean URL
    "tz": "+08",
    "tz_n": 8,
    "screen_geom": "1920-1080-1032-32-*-*-|-*",
    # tail
    "canvas_png": ("GgoAAAANSUhEUgAAASwAAACWCAYAAA76+IlaBIhKxWufqtcCsxKQ71/n6pjU"
                   "B0H3elg4cAvgAAAABJRU5ErkJggg=="),
    "frame": "top",
    "languages": ["zh-CN", "zh"],
    "webgl_vendor": "Google Inc. (NVIDIA)",
    "webgl_renderer": ("ANGLE (NVIDIA, NVIDIA GeForce RTX 3060 Ti (0x00002489) "
                       "Direct3D11 vs_5_0 ps_5_0, D3D11)"),
    "ua": ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
           "(KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36"),
    "misc_pair": [360, 358],
    "platform": "Win32",
    # tail timestamps and the fixed pseudo-random id
    "t_init": 1792818958,            # unix seconds, page handle created
    "rand_id": 890859047,
    "t_load": 1792807554,            # unix seconds, page/TDC load
    "inner_width": 1920,
    "counter_width": 10,
    "sd": '{"od":"C","ft":"6f_7ff__H"}',
}


def _json_str(s):
    """Compact JSON string literal (the page's strings contain no quotes)."""
    return '"' + s.replace("\\", "\\\\").replace('"', '\\"') + '"'


def _json_list(v):
    return "[" + ",".join(_json_str(x) if isinstance(x, str) else str(x) for x in v) + "]"


def build_collect(now_sec, counter, env=None):
    """Return the plaintext bytes handed to the cipher.

    now_sec -- current Unix time in seconds (cd timestamp)
    counter -- monotonically growing per-page counter (the field observed to
               take 9 / 12 / 13 across captures)
    env     -- override DEFAULT_ENV entries (browser-dependent strings)
    """
    e = dict(DEFAULT_ENV)
    if env:
        e.update(env)

    head = HEADER_EVENTS
    if len(head) > HEADER_LEN:
        raise ValueError("event header longer than %d bytes" % HEADER_LEN)
    head = head.ljust(HEADER_LEN)

    cd_head = (
        '{"cd":[' + str(int(e["seed"])) + "," + str(int(e["inner_height"]))
        + ',' + _json_str("") + "," + _json_str(e["perf_tag"])
        + "," + str(int(e["color_depth"])) + "," + _json_str(e["charset"])
        + "," + _json_str(e["location"]) + "," + str(int(now_sec))
        + "," + _json_str(e["tz"]) + "," + str(int(e["tz_n"]))
        + "," + _json_str(e["screen_geom"]) + ",[]"
    )
    # the comma that separates this field from the next is emitted before the
    # space padding, so the padded head is exactly 168 bytes
    head_section = (cd_head + ",").ljust(CD_HEAD_END - HEADER_LEN)

    tail = (
        ',0,' + _json_str("")
        + "," + _json_str(e["canvas_png"])
        + "," + _json_str(e["frame"])
        + "," + _json_list(e["languages"])
        + "," + _json_str("")
        + "," + _json_str(e["webgl_vendor"])
        + ",0,2,1023,0,1"
        + "," + _json_str(e["webgl_renderer"])
        + "," + _json_str(e["location2"])
        + "," + _json_str(e["ua"])
        + "," + _json_list(e["misc_pair"])
        + ',0,0,' + _json_str(e["platform"])
        + ",0," + str(int(e["t_init"]))
        + "," + str(int(e["rand_id"]))
        + "," + str(int(e["t_load"]))
        + "," + str(int(counter))
        + "," + str(int(e["inner_width"]))
        + '],'
        # the counter is followed by a space run that pads the pair to 10 chars
        + " " * max(0, int(e["counter_width"]) - len(str(int(counter))))
        + '"sd":' + e["sd"] + "}"
    )

    pt = head + head_section + tail
    pad = (-len(pt)) % 8
    return (pt + "\x00" * pad).encode("latin-1")


# ---------------------------------------------------------------------------
# Build "cur3" (tdc.js served 2026-10-24, sha 1914ca67b6c95a05)
#
# Same cipher, but a different plaintext layout: field order changed, the
# 24-byte event header is "[[1,1,12]]" + 14 spaces, the cd head runs to the
# "[]" field (bytes 24..240), and the trailing space run is 6 - len(counter).
# Key/C/segment boundary for this build live in tdc_crypto.PROFILES["cur3"].
# ---------------------------------------------------------------------------

V3_ENV = {
    "header": "[[1,1,12]]",          # padded to 24 bytes
    "header_len": 24,
    "inner_height": 1080,
    "frame": "top",
    "perf_tag": "98k",
    "webgl_vendor": "Google Inc. (NVIDIA)",
    "location": "https://cloud.tencent.com/product/captcha",
    "canvas_png": ("GgoAAAANSUhEUgAAASwAAACWCAYAAA76+IlaBIhKxWufqtcCsxKQ71/n6pjU"
                   "B0H3elg4cAvgAAAABJRU5ErkJggg=="),
    "charset": "UTF-8",
    # variable slot between "UTF-8" and "Win32": 16 spaces in the quiet state,
    # "[2,-1,10]" when pointer/event state is present
    "slot": " " * 16,
    "platform": "Win32",
    "color_depth": 32,
    "inner_width": 1920,
    "location_rand": "https://cloud.tencent.com/product/captcha?rand=1519713624347",
    "languages": ["zh-CN", "zh"],
    "ua": ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
           "(KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36"),
    "misc_pair": [360, 358],
    "rand_id": 890859047,
    "t_load": 1792807554,
    "t_state": 1792821287,           # session/state timestamp, session-stable
    "webgl_renderer": ("ANGLE (NVIDIA, NVIDIA GeForce RTX 3060 Ti (0x00002489) "
                       "Direct3D11 vs_5_0 ps_5_0, D3D11)"),
    "tz": "+08",
    "screen_geom": "1920-1080-1032-32-*-*-|-*",
    # same per-build embedded constant as cur2's `seed`, different layout
    # slot; the old `event_ts` name is a misnomer (it is not a timestamp)
    "event_ts": 1550352522,
    "trailer_a": 1023,
    "trailer_b": 8,
    "counter_width": 6,              # trailing space run = width - digits
    "sd": '{"od":"C","ft":"6f_7ff__H"}',
}


def build_collect_v3(now_sec, counter, env=None):
    """Plaintext for the cur3 build (see V3_ENV / tdc_crypto.PROFILES)."""
    e = dict(V3_ENV)
    if env:
        e.update(env)
    head = e["header"]
    if len(head) > e["header_len"]:
        raise ValueError("event header longer than %d bytes" % e["header_len"])
    head = head.ljust(e["header_len"])

    cd_head = (
        '{"cd":[' + str(int(e["inner_height"]))
        + "," + _json_str(e["frame"])
        + "," + _json_str(e["perf_tag"])
        + "," + _json_str("")
        + ",1," + _json_str(e["webgl_vendor"])
        + "," + _json_str(e["location"])
        + "," + _json_str(e["canvas_png"])
        + ",[]"
    )
    tail = (
        "," + _json_str(e["charset"])
        + "," + e["slot"]
        + "," + _json_str(e["platform"])
        + "," + str(int(e["color_depth"]))
        + "," + str(int(e["inner_width"]))
        + ",0," + _json_str("") + ",0"
        + "," + _json_str(e["location_rand"])
        + "," + str(int(counter))
        + "," + _json_list(e["languages"])
        + "," + _json_str(e["ua"])
        + ",0," + _json_list(e["misc_pair"])
        + ",0,0," + str(int(e["rand_id"]))
        + "," + str(int(e["t_load"]))
        + "," + str(int(e["t_state"]))
        + "," + _json_str(e["webgl_renderer"])
        + "," + _json_str(e["tz"])
        + ",0,2," + _json_str(e["screen_geom"])
        + "," + str(int(e["event_ts"]))
        + "," + str(int(now_sec))
        + "," + _json_str("")
        + "," + str(int(e["trailer_a"]))
        + "," + str(int(e["trailer_b"]))
        + "],"
        + " " * max(0, int(e["counter_width"]) - len(str(int(counter))))
        + '"sd":' + e["sd"] + "}"
    )
    pt = head + cd_head + tail
    return (pt + "\x00" * ((-len(pt)) % 8)).encode("latin-1")


def split_v3(env=None):
    """Rotation boundary for cur3 = 24 + length of head up to and incl. "[]"."""
    e = dict(V3_ENV)
    if env:
        e.update(env)
    head = e["header"].ljust(e["header_len"])
    cd_head = (
        '{"cd":[' + str(int(e["inner_height"]))
        + "," + _json_str(e["frame"])
        + "," + _json_str(e["perf_tag"])
        + "," + _json_str("")
        + ",1," + _json_str(e["webgl_vendor"])
        + "," + _json_str(e["location"])
        + "," + _json_str(e["canvas_png"])
        + ",[]"
    )
    # Only valid for this (cur3) template: on it the segment boundary happens
    # to sit 24 bytes past the end of the cd head.  Other layouts do not follow
    # this rule (e.g. build 43b7f6: head rule says 94, the real split is 168),
    # so unknown layouts must brute-force S and use the profile/layout path.
    return len(head) + len(cd_head) + 1 + len(head)


# --------------------------------------------------------------- v3 parsing
def _split_top(s):
    """Split on top-level commas (string/bracket aware)."""
    out, cur, depth, instr, esc = [], [], 0, None, False
    for ch in s:
        if instr:
            cur.append(ch)
            if esc:
                esc = False
            elif ch == "\\":
                esc = True
            elif ch == instr:
                instr = None
        else:
            if ch in "\"'":
                instr = ch
                cur.append(ch)
            elif ch in "([{":
                depth += 1
                cur.append(ch)
            elif ch in ")]}":
                depth -= 1
                cur.append(ch)
            elif ch == "," and depth == 0:
                out.append("".join(cur))
                cur = []
            else:
                cur.append(ch)
    out.append("".join(cur))
    return out


def parse_v3(pt):
    """Inverse of build_collect_v3: -> (env, now_sec, counter, fields).

    The payload is `header.ljust(24)` + `{"cd":[<38 fields>],"sd":{...}}`
    (the counter padding is plain whitespace before `"sd"`).  The slot at
    index 10 is raw text (spaces or an event array), not a JSON value.
    """
    import json
    import re
    s = pt.decode("latin-1").rstrip("\x00")
    if not s.startswith("["):
        raise ValueError("not a collect payload")
    p = s.find('{"cd":[')
    m = None
    for m in re.finditer(r'\],(\s*)"sd":', s):
        pass
    if p < 0 or m is None:
        raise ValueError("cd/sd markers not found")
    q = m.start()                      # index of the "]" closing cd
    pad = m.group(1)                   # whitespace that padded the counter
    ljust = s[:p]
    toks = _split_top(s[p + 7:q])
    vals = []
    for t in toks:
        t2 = t.strip()
        vals.append(None if t2 == "" else json.loads(t2))
    if len(vals) < 38:
        raise ValueError("unknown cd layout: %d fields" % len(vals))
    # the template this function knows: numbers at 0 / 18 / 34.  Other
    # layouts can hit those three slots by accident, so also check the shape
    # of discriminating fields (frame/perf_tag/vendor/canvas/languages/tz...).
    if not all(isinstance(vals[i], int) for i in (0, 18, 34)):
        raise ValueError("unknown cd layout (field order changed)")
    if not all(isinstance(vals[i], str) for i in (1, 2, 5, 7, 11, 28, 29, 32)):
        raise ValueError("unknown cd layout (field order changed)")
    if not (isinstance(vals[19], list) and isinstance(vals[22], list)):
        raise ValueError("unknown cd layout (field order changed)")
    counter = vals[18]
    env = {
        "header": ljust.rstrip(),
        "header_len": len(ljust),
        "inner_height": vals[0],
        "frame": vals[1],
        "perf_tag": vals[2],
        "webgl_vendor": vals[5],
        "location": vals[6],
        "canvas_png": vals[7],
        "charset": vals[9],
        "slot": toks[10],                 # raw text, keep spaces
        "platform": vals[11],
        "color_depth": vals[12],
        "inner_width": vals[13],
        "location_rand": vals[17],
        "languages": vals[19],
        "ua": vals[20],
        "misc_pair": vals[22],
        "rand_id": vals[25],
        "t_load": vals[26],
        "t_state": vals[27],
        "webgl_renderer": vals[28],
        "tz": vals[29],
        "screen_geom": vals[32],
        "event_ts": vals[33],
        "trailer_a": vals[36],
        "trailer_b": vals[37],
        # spaces = width - len(counter); recover the width the page used
        "counter_width": len(pad) + len(str(counter)),
        "sd": s[m.end():-1],
    }
    return env, vals[34], counter, vals


def env_from_plaintext(pt):
    env, now_sec, counter, _ = parse_v3(pt)
    return env, now_sec, counter


def split_from_plaintext(pt):
    """Rotation boundary: S = 24 + (offset just after the "[]" field)."""
    i = pt.find(b"[],")
    if i < 0:
        raise ValueError('"[]," not found')
    return i + 3 + 24


# ------------------------------------------------- layout-agnostic plumbing
# The field order inside "cd" is NOT stable across tdc.js builds (two builds
# observed on 2026-10-24 use completely different orders).  Everything below
# works on the raw token list, so it survives a layout change.
def payload_parts(pt):
    """Split a plaintext into prefix / cd tokens / suffix.

    Returns {"prefix", "tokens", "suffix"} where prefix ends right after
    '{"cd":[' and suffix starts at the ']' that closes the cd array.
    """
    import re
    s = pt.decode("latin-1").rstrip("\x00")
    p = s.find('{"cd":[')
    m = None
    for m in re.finditer(r'\],(\s*)"sd":', s):
        pass
    if p < 0 or m is None:
        raise ValueError("cd/sd markers not found")
    return {"prefix": s[:p + 7],
            "tokens": _split_top(s[p + 7:m.start()]),
            "suffix": s[m.start():]}


def split_events(pt):
    """Detect the "long event trace" payload variant.

    When the serialized event list is longer than 24 characters, tdc.js puts
    the first 24 chars in the header slot (no padding, may cut mid-number) and
    splices the *remainder* into the cd stream right after the counter pad.
    The two halves concatenate back into a valid JSON array, e.g.

        header   "[[350,150,2466],[-22,-42"
        insert   ",11],[-10,5,8],[1,1,12]]"
        events   "[[350,150,2466],[-22,-42,11],[-10,5,8],[1,1,12]]"

    Returns (normalized_plaintext, insert_index, remainder) where the
    remainder includes the event JSON's trailing space padding (the event
    string is padded to a multiple of 24) and the normalized plaintext has
    the whole remainder removed, so the ordinary token layout applies.
    Returns None when the sample is the ordinary shape.
    """
    import json as _json
    s = pt.decode("latin-1").rstrip("\x00")
    p = s.find('{"cd":[')
    if p < 0:
        return None
    head = s[:p]
    try:
        v = _json.loads(head.strip())
        if isinstance(v, list):
            return None                    # ordinary header (complete JSON)
    except ValueError:
        pass
    if len(head) != 24:
        return None                        # not the split-at-24 scheme
    depth = 0
    for ch in head:
        if ch in "[{":
            depth += 1
        elif ch in "]}":
            depth -= 1
    if depth <= 0:
        return None
    # the remainder starts at the first non-space character that follows a
    # whitespace run (the counter pad) and completes head into valid JSON
    for i in range(p + 1, len(s)):
        if s[i].isspace() or not s[i - 1].isspace():
            continue
        d, j = depth, None
        for k in range(i, len(s)):
            ch = s[k]
            if ch in "[{":
                d += 1
            elif ch in "]}":
                d -= 1
            if d == 0:
                j = k + 1
                break
        if j is None:
            continue
        try:
            ev = _json.loads(head + s[i:j])
        except ValueError:
            continue
        if isinstance(ev, list):
            # the full event string is padded with spaces to a multiple of 24
            # (10-char silent trace -> 24, 78-char trace -> 96)
            total = 24 + (j - i)
            pad = (-total) % 24
            if any(not ch.isspace() for ch in s[j:j + pad]):
                pad = 0
            jj = j + pad
            return (s[:i] + s[jj:]).encode("latin-1"), i, s[i:jj]
    return None


def join_parts(parts, tokens=None):
    """Inverse of payload_parts(); re-adds NUL padding to a multiple of 8."""
    toks = parts["tokens"] if tokens is None else tokens
    s = parts["prefix"] + ",".join(toks) + parts["suffix"]
    return (s + "\x00" * ((-len(s)) % 8)).encode("latin-1")


_PAD_SUFFIX_RE = re.compile(r'^\],(\s*)"sd":(.*)$', re.S)


def _ndigits(n):
    return len(str(abs(int(n))))


def dynamic_positions(a, b):
    """Token indices that differ between two calls of the same page.

    Also classifies each by value: a Unix-second-sized number is the call
    timestamp, anything else is the per-page call counter.

    The prefix (event trace + whitespace padding) is allowed to change
    between calls; it is reported as ``prefix_dynamic`` instead of raising,
    because tdc.js appends events to it independently of getData().

    Whitespace-only tokens (and the whitespace run before ``"sd"``) are a
    fixed-width slot for the counter: their length is ``width - digits``.
    When that relation holds it is recorded in ``pads`` /
    ``suffix_pad_width`` so a rebuild can reproduce a different counter.
    """
    ta, tb = a["tokens"], b["tokens"]
    if len(ta) != len(tb):
        raise ValueError("layout changed between samples")
    idx = [i for i in range(len(ta)) if ta[i] != tb[i]]
    out = {"now_sec": None, "counter": None, "positions": idx,
           "prefix_dynamic": a["prefix"] != b["prefix"]}
    for i in idx:
        try:
            v = int(tb[i].strip())
        except ValueError:
            continue
        if 1_600_000_000 <= v <= 2_100_000_000:
            out["now_sec"] = i
        else:
            out["counter"] = i
    ci = out["counter"]
    ca = int(ta[ci]) if ci is not None else None
    cb = int(tb[ci]) if ci is not None else None
    da = _ndigits(ca) if ca is not None else None
    db = _ndigits(cb) if cb is not None else None
    pads = {}
    for i in idx:
        if ta[i].strip() == "" and tb[i].strip() == "":
            if da is not None and len(ta[i]) + da == len(tb[i]) + db:
                pads[i] = len(ta[i]) + da
    out["pads"] = pads
    out["suffix_pad_width"] = None
    if a["suffix"] != b["suffix"]:
        ma = _PAD_SUFFIX_RE.match(a["suffix"])
        mb = _PAD_SUFFIX_RE.match(b["suffix"])
        ok = False
        if ma and mb and ma.group(2) == mb.group(2) and da is not None:
            wa, wb = len(ma.group(1)), len(mb.group(1))
            if wa + da == wb + db:
                out["suffix_pad_width"] = wa + da
                ok = True
        if not ok:
            raise ValueError("layout changed between samples")
    return out


def refine_layout(layout, pts):
    """Widen pad detection with *all* samples.

    A single pair only reveals counter-width pads when the counter crosses a
    digit boundary between those two calls.  Scanning every sample makes the
    detection reliable; anything that still varies is a real layout change.
    """
    dyn = layout["dynamic"]
    ci = dyn["counter"]
    if ci is None or len(pts) < 2:
        return layout
    parts = [payload_parts(p) for p in pts]
    toks = [x["tokens"] for x in parts]
    if any(len(t) != len(toks[0]) for t in toks):
        raise ValueError("layout changed between samples")
    cnts = [int(t[ci].strip()) for t in toks]
    digs = [_ndigits(c) for c in cnts]
    pads = {int(j): w for j, w in (dyn.get("pads") or {}).items()}
    for j in range(len(toks[0])):
        if j == ci:
            continue
        if all(t[j].strip() == "" for t in toks):
            widths = [len(t[j]) for t in toks]
            tot = {w + d for w, d in zip(widths, digs)}
            if len(tot) == 1 and len(set(digs)) > 1:
                pads[j] = widths[0] + digs[0]
    dyn["pads"] = pads
    ms = [_PAD_SUFFIX_RE.match(x["suffix"]) for x in parts]
    if all(ms):
        tails = {m.group(2) for m in ms}
        widths = [len(m.group(1)) for m in ms]
        tot = {w + d for w, d in zip(widths, digs)}
        if len(tails) == 1 and len(tot) == 1 and len(set(digs)) > 1:
            dyn["suffix_pad_width"] = widths[0] + digs[0]
        elif len(tails) != 1:
            raise ValueError("layout changed between samples")
    elif len({x["suffix"] for x in parts}) != 1:
        raise ValueError("layout changed between samples")
    return layout


def layout_from_pair(pt_a, pt_b):
    """Build a reusable layout profile from two consecutive plaintexts."""
    a, b = payload_parts(pt_a), payload_parts(pt_b)
    dyn = dynamic_positions(a, b)
    return {"prefix": a["prefix"],
            "tokens": a["tokens"],
            "suffix": a["suffix"],
            "dynamic": dyn}


def build_from_layout(layout, now_sec=None, counter=None, prefix=None,
                      events=None, insert_after_token=None):
    """Rebuild a payload for a new call from a layout profile.

    ``prefix`` overrides the stored prefix: the event trace it contains is
    written by the page at call time, so verification of a live sample must
    reuse that sample's own prefix rather than the one from the first sample.

    ``events`` is the serialized event list (a JSON string).  It is padded
    with spaces to a multiple of 24 characters; the first 24 go into the
    header slot and the remainder is spliced in right after the counter pad,
    mirroring tdc.js.  ``insert_after_token`` names the whitespace token the
    remainder follows; it is needed when the pad width could not be proven
    from the samples (no counter digit boundary was crossed).
    """
    toks = list(layout["tokens"])
    dyn = layout.get("dynamic") or {}
    if now_sec is not None and dyn.get("now_sec") is not None:
        toks[dyn["now_sec"]] = str(int(now_sec))
    suffix = layout["suffix"]
    if counter is not None and dyn.get("counter") is not None:
        toks[dyn["counter"]] = str(int(counter))
        if dyn.get("pads"):
            for j, width in dyn["pads"].items():
                w = int(width) - _ndigits(counter)
                if w >= 0:
                    toks[int(j)] = " " * w
        w = dyn.get("suffix_pad_width")
        if w is not None:
            m = _PAD_SUFFIX_RE.match(suffix)
            if m:
                suffix = ("]," + " " * max(0, int(w) - _ndigits(counter))
                          + '"sd":' + m.group(2))
    head = layout["prefix"] if prefix is None else prefix
    insert = ""
    if events is not None:
        ev = str(events)
        ev += " " * ((-len(ev)) % 24)      # event JSON is padded to 24-char units
        head = ev[:24] + '{"cd":['
        if len(ev) > 24:
            insert = ev[24:]
    s = head + ",".join(toks) + suffix
    if insert:
        j = None
        if insert_after_token is not None:
            j = int(insert_after_token)
            if not 0 <= j < len(toks):
                raise ValueError("insert token index out of range")
        else:
            pads = dyn.get("pads") or {}
            if pads:
                j = min(int(x) for x in pads)
            if j is None:
                raise ValueError("event remainder needs a known counter pad")
        off = len(head) + sum(len(t) for t in toks[:j]) + j + len(toks[j])
        s = s[:off] + insert + s[off:]
    return (s + "\x00" * ((-len(s)) % 8)).encode("latin-1")


def values_at(layout, pt):
    """Read the dynamic values of an existing payload (for verification)."""
    parts = payload_parts(pt)
    dyn = layout["dynamic"]
    out = {}
    if dyn.get("now_sec") is not None:
        out["now_sec"] = int(parts["tokens"][dyn["now_sec"]].strip())
    if dyn.get("counter") is not None:
        out["counter"] = int(parts["tokens"][dyn["counter"]].strip())
    return out


if __name__ == "__main__":
    import json
    import os
    import re
    import sys

    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    import tdc_crypto

    here = os.path.dirname(os.path.abspath(__file__))
    ok = True
    for name in ("b", "c", "d"):
        path = os.path.join(here, "scripts", "capture_full_%s.json" % name)
        cap = json.load(open(path))
        ref = bytearray()
        for h in cap["hits"]:
            for w in h["pre"]:
                w &= 0xFFFFFFFF
                ref += bytes((w & 255, (w >> 8) & 255, (w >> 16) & 255, (w >> 24) & 255))
        ref = bytes(ref)
        s = ref.decode("latin-1")
        # pull the two dynamic fields straight out of the reference payload
        now_sec = int(re.search(r'rand=\d+",(\d+),', s).group(1))
        counter = int(re.search(r",(\d+),1920\]", s).group(1))
        got = build_collect(now_sec, counter)
        same_pt = got == ref
        same_data = tdc_crypto.get_data(got) == cap["data"]
        ok &= same_pt and same_data
        print("sample %s: now=%d counter=%d  plaintext=%s  data=%s  (%d bytes)"
              % (name, now_sec, counter, same_pt, same_data, len(ref)))

    # layout-agnostic plumbing: two consecutive calls of the v3 template
    a = build_collect_v3(1792821287, 1)
    b = build_collect_v3(1792821288, 2)
    lay = layout_from_pair(a, b)
    dyn = lay["dynamic"]
    rb = build_from_layout(lay, 1792821288, 2)
    same = (rb == b and dyn["now_sec"] is not None and dyn["counter"] is not None
            and values_at(lay, b) == {"now_sec": 1792821288, "counter": 2})
    ok &= same
    print("layout diff: now@%s counter@%s rebuild=%s"
          % (dyn["now_sec"], dyn["counter"], same))

    # a live page can append an event to the prefix between two getData()
    # calls (Family C); the tokens must still line up and rebuild per sample
    pa = a.replace(b"[[1,1,12]]", b"[[1,1,12],[2,9,1]]")
    pb = b.replace(b"[[1,1,12]]", b"[[1,1,12],[2,9,2]]")
    lay2 = layout_from_pair(pa, pb)
    d2 = lay2["dynamic"]
    parts_b = payload_parts(pb)
    rb2 = build_from_layout(lay2, 1792821288, 2, prefix=parts_b["prefix"])
    same2 = (rb2 == pb and d2["prefix_dynamic"] and d2["counter"] is not None
             and parts_b["prefix"] != lay2["prefix"])
    ok &= same2
    print("dynamic prefix: counter@%s rebuild=%s" % (d2["counter"], same2))

    # counter gains a digit: the space run before "sd" shrinks (cur3 template)
    a3 = build_collect_v3(1792821287, 9)
    b3 = build_collect_v3(1792821288, 10)
    lay3 = layout_from_pair(a3, b3)
    d3 = lay3["dynamic"]
    same3 = (build_from_layout(lay3, 1792821288, 10) == b3
             and d3.get("suffix_pad_width") == 6)
    ok &= same3
    print("suffix counter-pad: width=%s rebuild=%s"
          % (d3.get("suffix_pad_width"), same3))

    # ...and one where the pad is a raw whitespace token inside cd
    # (build 0x516d6b68 puts it at token 28 instead of the suffix)
    pa, pb = payload_parts(a3), payload_parts(b3)
    pa["tokens"][10] = " " * 16
    pb["tokens"][10] = " " * 15
    pa, pb = join_parts(pa), join_parts(pb)
    lay4 = layout_from_pair(pa, pb)
    d4 = lay4["dynamic"]
    same4 = (build_from_layout(lay4, 1792821288, 10) == pb
             and d4["pads"].get(10) == 17)
    ok &= same4
    print("in-cd counter-pad: pads=%s rebuild=%s" % (d4["pads"], same4))

    # long event trace: header keeps events[:24], the rest is spliced in
    # after the counter pad (observed on build 0x6d565d3f)
    lay5 = {"prefix": "[[1,1,12]]              " + '{"cd":[',
            "tokens": ["0", '"top"', "1", "     ", "1023"],
            "suffix": '],  "sd":{"od":"C"}}',
            "dynamic": {"now_sec": None, "counter": 2, "positions": [2],
                        "prefix_dynamic": False, "pads": {3: 6},
                        "suffix_pad_width": None}}
    ev = "[[350,150,2466],[-22,-42,11],[-10,5,8],[1,1,12]]"
    p5 = build_from_layout(lay5, counter=12, events=ev)
    s5 = p5.decode("latin-1").rstrip("\x00")
    sv = split_events(p5)
    same5 = (sv is not None and sv[2] == ev[24:]
             and s5[sv[1]:sv[1] + len(sv[2])] == sv[2]
             and sv[0].decode("latin-1")
             == s5[:sv[1]] + s5[sv[1] + len(sv[2]):])
    ok &= same5
    print("events split: remainder=%r rebuild=%s"
          % (sv[2] if sv else None, same5))

    # long trace: 78-char event JSON is padded to 96 (4 x 24) before splitting;
    # the 18 trailing spaces travel with the remainder and normalization must
    # remove them again so the ordinary token layout comes back.
    ev2 = ("[[22,13,2844],[15,-4,10],[12,-2,8],[217,-5,10],"
           "[21,-2,11],[27,205,9],[1,1,12]]")
    p6 = build_from_layout(lay5, counter=12, events=ev2)
    sv6 = split_events(p6)
    padded = ev2 + " " * ((-len(ev2)) % 24)
    base = payload_parts(build_from_layout(lay5, counter=12))
    same6 = False
    if sv6 and len(ev2) == 78 and len(padded) == 96:
        q6 = sv6[0]
        parts6 = payload_parts(q6)
        same6 = (sv6[2] == padded[24:] and len(sv6[2]) == 72
                 and parts6["tokens"] == base["tokens"]
                 and parts6["suffix"] == base["suffix"]
                 and q6.decode("latin-1")[sv6[1] - 1] == " "
                 and q6.decode("latin-1")[sv6[1]] == ",")
    ok &= same6
    print("events split (padded 78->96): remainder=%d chars rebuild=%s"
          % (len(sv6[2]) if sv6 else 0, same6))
    print("ALL OK" if ok else "FAILED")
