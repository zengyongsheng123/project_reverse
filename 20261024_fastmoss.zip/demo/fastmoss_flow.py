# -*- coding: utf-8 -*-
"""FastMoss 腾讯验证码（aid 195941100）—— 单文件、无浏览器、全流程。

模块对照（抓包四个请求的整合结果）：

    prehandle 取会话/挑战        <- cap_union_prehandle.py
      -> 同一个 Session 下载背景图与拼图雪碧图
      -> GapRecognizer 识别缺口（默认 ZNCC 内容匹配；可选 captcha-recognizer）
      -> 轨迹 -> collect 明文（FastMoss build 布局）
      -> TDCCipher 加密成 collect
      -> 本地 PoW
      -> cap_union_new_verify 提交        <- cap_union_new_verify.py
      -> 拿 ticket/randstr 交业务后端     <- verify.py

内嵌常量来自 2026-10-25 从 FastMoss 本次加载的 tdc.js 推导（derive_build.py +
fastmoss_fit.py）：
    sha256_16 = "ab1b27fe1c2d932b"
    K = [1646604608, 1146244947, 1701009766, 1195989327]
    C = [2697486, 0, 0, 723722]，split = 648
    eks = 248 字符 per-build 常量
    明文布局 = 38 token（now_sec=14、counter=26、counter 补位 pads={33:3}，
                build_const=2093523104）
推导时 12 次 TDC.getData() 样本 12/12 逐字节复现，另加 1 条 setData 注入
轨迹的样本也逐字节复现。profile 见 js/live_src/profile_fastmoss.json。

与 demo（aid 192962660）的差异：FastMoss 这个 build 把拖动轨迹存成
``"sd":{"<毫秒>":"<x,y>",...}`` 对象，而不是 demo 那种塞进 ``cd`` 的
``[[dx,dy,dt]]`` 数组；``--events`` 时按前一种格式拼。

依赖：requests、numpy、Pillow（全部只用 CPU，无 scipy 依赖）。
识别默认用内容匹配（ZNCC），也能切 --recognizer captcha-recognizer / builtin。

运行方式
--------
    python fastmoss_flow.py                 无浏览器模式（默认）：Python 算缺口，
                                            本会话的 tdc.js 在 Node 里出 collect
    python fastmoss_flow.py --dry           同上但不发 verify
    python fastmoss_flow.py --submit        真正发那一条 cap_union_new_verify
    python fastmoss_flow.py --browser       浏览器混合模式（Chrome + CDP 真拖动）
    python fastmoss_flow.py --static        纯 Python 静态常量路径（多半已过期）
    python fastmoss_flow.py --recognizer captcha-recognizer

三种模式
--------
  * 无浏览器（默认，需要 Node）：tdc.js 每个会话都重新随机化（K/C/字节码/
    split/eks/明文字段顺序全变），静态常量算出的 collect 服务端解不开，
    表现为 errorCode 12（验证失败）。所以 collect 交给「本会话自己的 tdc.js」
    生成——但不需要浏览器进程，只在 Node 里用一层极简 DOM 垫片
    （scripts/node_tdc/）跑这个 build，调它的出口直接拿 collect 和 eks。
    Python 只负责用 ZNCC 算缺口。
  * 浏览器混合（--browser）：同样让页面自己的 SDK 出 collect，但拖动由 CDP
    鼠标事件闭环完成。2026-10-25 实测 errorCode 0 + ticket + 本地业务校验
    is_ok=1，是兜底方案。
  * 纯 Python（--static）：完整复现了抓包时的 collect 加密，但常量绑死在那
    一次 build 上；保留作离线对拍与推导校验。

安全边界
--------
  * 每次调用只对 cap_union_new_verify POST 一次，无重试循环；
  * 不批量拉取验证码样本、不换 aid；
  * 仅用于用户已获授权的 FastMoss 联调环境（用户 2026-10-25 确认有授权）。

退出码：0 成功，2 服务端拒绝，1 初始化错误。
"""
import base64
import hashlib
import http.client
import json
import math
import os
import random
import re
import subprocess
import sys
import time
import urllib.parse
from collections import deque

import numpy as np
import requests
from PIL import Image

# --------------------------------------------------------------------------- #
# 全局配置
# --------------------------------------------------------------------------- #
HERE = os.path.dirname(os.path.abspath(__file__))
AID = "195941100"                                   # FastMoss 的验证码 aid
BASE = "https://turing.captcha.qcloud.com"
LOCAL_VERIFY = "http://localhost:8787/api/captcha/verify"
UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36")
ENTRY_URL = "file:///D:/20261024_fastmoss/captcha-test.html"

# 传输层指纹：curl_cffi 的 impersonate 目标（Chrome 版本要跟 UA 大致对得上）
IMPERSONATE = "chrome"
NO_IMPERSONATE = False
OUT = os.path.join(HERE, "fastmoss_flow_result.json")
BG = os.path.join(HERE, "fastmoss_bg.png")
SP = os.path.join(HERE, "fastmoss_sprite.png")

# tlg 口径：= 服务端**表单解析后**拿到的 collect 长度（也就是 unquote 之后）。
# 实测浏览器：JS 里的 collect 串 1198 字符（内含 %2B/%2F/%3D），SDK 拼 body 时
# 不转义 %，服务端解析成 1144，tlg 正好发 1144。我们这边同样是「原始串带 %XX、
# 按 % 不转义拼表单」，所以 tlg 取 len(unquote(collect))。
# （曾经翻成 False 试过 raw 长度，就是 errorCode 12 —— 见 encode_form 注释。）
TLG_DECODED = True

# FastMoss build（2026-10-25 由 derive_build.py 推导，12 样本验证）
PROFILE = {
    "name": "fastmoss",
    "sha256_16": "ab1b27fe1c2d932b",
    "key": [1646604608, 1146244947, 1701009766, 1195989327],
    "case": [2697486, 0, 0, 723722],
    "split": 648,
    "eks": ("nGpnMquo+qyvMje+hnyyQqcjRjGLxD+TE8W1em5uKFr15r8o1776xqDPgicWAU1i"
            "qDC8j3o834yuFTYE6mw453f03MM/oGlbdha0G1+qTV8st+7NoOXmauq3FGcdiz2a7"
            "BioiRuxzMAymAV86MnQAr9vNmw+Z/CIYiLrpJOIDCLTmE0egs6gxYh2qQEVErNAkh"
            "A21SUcUQMrNHmYAUr2pcuPOBRLaqF2fTHPewb+Wc0eDeTwzPTPJA=="),
    "build_const": 2093523104,
    "layout": {
        "prefix": '[[1,1,12]]              {"cd":[',
        "tokens": [
            '0', '["zh-CN","zh"]', '1007', '2093523104', '1080', '"UTF-8"',
            '"%s?rand=1519713624347"' % ENTRY_URL,       # [6]  入口+随机数
            '0', '"%s"' % ENTRY_URL, '1792894748', '0',
            '"Google Inc. (NVIDIA)"',
            '"GgoAAAANSUhEUgAAASwAAACWCAYAAAlErJpdmJ+zOvX1ErIJFJOK1zpWrwTn'
            'MA9Ih7pTo3V/wAAAAASUVORK5CYII="',            # [12] canvas PNG
            '1920', '1792894749', '"Win32"', '""', '""', '"+08"', '0',
            '"top"', '[360,363]', '0',
            '"ANGLE (NVIDIA, NVIDIA GeForce RTX 4060 Ti (0x00002803) '
            'Direct3D11 vs_5_0 ps_5_0, D3D11)"',           # [23] WebGL
            '"%s"' % UA, '""', '1', '370838444', '1792894619', '[]', '2',
            '1', '"1920-1080-1032-32-*-*-|-*"', '  ', '32', '"98k"', '0', '8',
        ],
        "suffix": '],         "sd":{"od":"C"}}',
        "dynamic": {"now_sec": 14, "counter": 26,
                    "positions": [14, 26],
                    "prefix_dynamic": False, "pads": {33: 3},
                    "suffix_pad_width": None},
    },
}


# --------------------------------------------------------------------------- #
# 1. collect 加解密（与 tdc.js 一致：XTEA 变体 32 轮 + 24/split 分段轮转）
# --------------------------------------------------------------------------- #
class TDCCipher:
    """TDC `collect` 的加密/解密器。"""

    M32 = 0xFFFFFFFF
    DELTA = 2654435769
    SUM_END = 32 * DELTA

    def __init__(self, profile):
        self.key = profile["key"]
        self.case = profile["case"]
        self.split = profile["split"]

    @staticmethod
    def _i32(x):
        x &= 0xFFFFFFFF
        return x - 0x100000000 if x & 0x80000000 else x

    @staticmethod
    def _u32(x):
        return x & 0xFFFFFFFF

    def _mix(self, v, k, c):
        return self._i32((self._i32(v << 4) ^ (self._u32(v) >> 5)) + v) ^ \
            self._i32(k + c)

    def _encrypt_block(self, v0, v1):
        s = 0
        while s != self.SUM_END:
            i = self._u32(s) & 3
            v0 = v0 + self._mix(v1, s + self.key[i], self.case[i])
            s += self.DELTA
            i = (self._u32(s) >> 11) & 3
            v1 = v1 + self._mix(v0, s + self.key[i], self.case[i])
        return v0, v1

    def _decrypt_block(self, v0, v1):
        s = self.SUM_END
        while s:
            i = (self._u32(s) >> 11) & 3
            v1 = v1 - self._mix(v0, s + self.key[i], self.case[i])
            s -= self.DELTA
            i = self._u32(s) & 3
            v0 = v0 - self._mix(v1, s + self.key[i], self.case[i])
        return v0, v1

    @staticmethod
    def _w2b(x):
        x = x & 0xFFFFFFFF
        return bytes((x & 255, (x >> 8) & 255, (x >> 16) & 255, (x >> 24) & 255))

    @staticmethod
    def _b2w(b):
        return b[0] | (b[1] << 8) | (b[2] << 16) | (b[3] << 24)

    def encrypt_blocks(self, pt):
        if len(pt) % 8:
            raise ValueError("plaintext must be a multiple of 8 bytes")
        out = bytearray()
        for i in range(0, len(pt), 8):
            v0, v1 = self._encrypt_block(self._b2w(pt[i:i + 4]),
                                         self._b2w(pt[i + 4:i + 8]))
            out += self._w2b(v0) + self._w2b(v1)
        return bytes(out)

    def rotate(self, ct):
        return ct[24:self.split] + ct[0:24] + ct[self.split:]

    def unrotate(self, raw):
        k = self.split - 24
        return raw[k:self.split] + raw[0:k] + raw[self.split:]

    def get_data(self, pt):
        raw = self.rotate(self.encrypt_blocks(pt))
        return urllib.parse.quote(base64.b64encode(raw).decode("ascii"), safe="")

    def decode_data(self, data):
        raw = base64.b64decode(urllib.parse.unquote(data))
        ct = self.unrotate(raw)
        out = bytearray()
        for i in range(0, len(ct), 8):
            v0, v1 = self._decrypt_block(self._b2w(ct[i:i + 4]),
                                         self._b2w(ct[i + 4:i + 8]))
            out += self._w2b(v0) + self._w2b(v1)
        return bytes(out)


# --------------------------------------------------------------------------- #
# 2. 缺口识别（内容匹配 ZNCC 为主，captcha-recognizer / 内置解算回退）
# --------------------------------------------------------------------------- #
class GapRecognizer:
    """滑块缺口识别器，返回 ans 坐标与调试信息。

    为什么默认用 ZNCC 而不是「找暗块」：FastMoss 这个弹窗模板的背景图里
    有两个拼图形状，一个是真缺口（内容被压暗），另一个是诱饵（平涂/内容
    对不上）。只按「暗/平」去挑会挑到诱饵（x=556，真缺口 x=276，ZNCC
    0.77 对 0.36，且 556 还越过了 move_cfg 的 x<=552 上限）。

    errorCode 语义（2026-10-25 定案）：50 = 答案不对；12 = 请求本身没解出来
    （collect 的表单编码错了一层，见 FastMossCaptchaFlow.encode_form）。
    所以 12 别往「答案/会话」上找，先看发出去的字节。

    ZNCC 对「整体乘一个暗化系数」不敏感，正好用来找被压暗的真缺口。
    """

    _model = None

    def __init__(self, engine="zncc"):
        self.engine = engine

    def recognize(self, bg_path, sprite_path, dsi):
        if self.engine == "zncc":
            return self._recognize_zncc(bg_path, sprite_path, dsi)
        if self.engine == "captcha-recognizer":
            try:
                return self._recognize_model(bg_path, sprite_path, dsi)
            except ImportError:
                print("captcha-recognizer not installed -> built-in solver")
            except Exception as exc:
                print("captcha-recognizer failed (%s) -> built-in solver" % exc)
        return self._recognize_builtin(bg_path, sprite_path, dsi)

    @staticmethod
    def piece_geometry(sprite_path, dsi):
        """返回 (裁剪块, 不透明掩码, offset_x, offset_y, init_x, init_y)。"""
        fg = [e for e in dsi["fg_elem_list"] if e.get("id") == 1][0]
        sx, sy = fg["sprite_pos"]
        w, h = fg["size_2d"]
        init_x, init_y = fg["init_pos"]
        sprite = np.array(Image.open(sprite_path).convert("RGBA"))
        crop = sprite[sy:sy + h, sx:sx + w]
        pmask = crop[:, :, 3] > 128
        ys, xs = np.nonzero(pmask)
        return crop, pmask, int(xs.min()), int(ys.min()), init_x, init_y

    # ---- 内容匹配（ZNCC）相关的小工具 ---------------------------------- #
    @staticmethod
    def _corr_valid(a, b):
        """有效区互相关：out[y,x] = Σ a[y+u,x+v]·b[u,v]（FFT 实现）。"""
        H, W = a.shape
        ph, pw = b.shape
        sh, sw = H + ph - 1, W + pw - 1
        fa = np.fft.rfft2(a, s=(sh, sw))
        fb = np.fft.rfft2(b[::-1, ::-1], s=(sh, sw))
        return np.fft.irfft2(fa * fb, s=(sh, sw))[ph - 1:H, pw - 1:W]

    @staticmethod
    def _erode(mask, k=3):
        """把掩码往内收 k 像素：拼图块自带 2px 白描边，不剔掉会污染匹配。"""
        out = mask.copy()
        for _ in range(k):
            m = out
            e = m.copy()
            e[1:, :] &= m[:-1, :]
            e[:-1, :] &= m[1:, :]
            e[:, 1:] &= m[:, :-1]
            e[:, :-1] &= m[:, 1:]
            out = e
        return out

    def _recognize_zncc(self, bg_path, sprite_path, dsi):
        """拿拼图块的内容在背景图上滑，取零均值归一化相关最高的位置。"""
        crop, pmask, ox, oy, init_x, init_y = self.piece_geometry(
            sprite_path, dsi)
        ys, xs = np.nonzero(pmask)
        y1, x1 = int(ys.max()) + 1, int(xs.max()) + 1
        mask = self._erode(pmask[oy:y1, ox:x1], 3)
        patch = crop[oy:y1, ox:x1, :3].astype(np.float64).mean(axis=2)
        bg = np.array(Image.open(bg_path).convert("RGB")
                      ).astype(np.float64).mean(axis=2)

        m = mask.astype(np.float64)
        n = float(m.sum())
        pv = patch[mask]
        mp = float(pv.mean())
        pn = float(np.sqrt(((pv - mp) ** 2).sum())) or 1.0
        s1 = self._corr_valid(bg, m)
        s2 = self._corr_valid(bg * bg, m)
        mean_b = s1 / n
        var_b = np.maximum(s2 / n - mean_b ** 2, 1e-3)
        corr = self._corr_valid(bg, (patch - mp) * m) \
            / (np.sqrt(var_b * n) * pn)

        # 缺口在竖直方向和拼图块的初始位置重合（move_factor 是 [1,0]），
        # 所以只在 expected_y 附近找，避免被别处的纹理带偏。
        expected_y = init_y + oy
        lo = max(0, expected_y - 8)
        hi = min(corr.shape[0], expected_y + 9)
        band = corr[lo:hi]
        by, bx = np.unravel_index(np.argmax(band), band.shape)
        by += lo
        peak = float(band[by - lo, bx])
        gy, gx = np.unravel_index(np.argmax(corr), corr.shape)

        ans_x = int(bx) - ox
        dy = int(by) - expected_y
        print("zncc: peak=%.3f@(%d,%d) band_y=[%d,%d] global=%.3f@(%d,%d)"
              % (peak, bx, by, lo, hi - 1, float(corr[gy, gx]), gx, gy))
        if peak < 0.45:
            print("zncc: peak %.3f 偏低，缺口内容可能被遮挡" % peak)
        return {"x": ans_x, "y": init_y, "data": "%d,%d" % (ans_x, init_y),
                "piece_offset": (ox, oy), "engine": "zncc",
                "hole": {"hole_x": int(bx), "hole_y": int(by),
                         "box": [int(bx) - ox, int(by) - oy,
                                 int(bx) - ox + (x1 - ox),
                                 int(by) - oy + (y1 - oy)],
                         "confidence": peak, "method": "zncc",
                         "iou": None, "dy": dy,
                         "global_peak": float(corr[gy, gx])},
                "init_pos": [init_x, init_y], "y_check_ok": abs(dy) <= 4}

    def _recognize_model(self, bg_path, sprite_path, dsi):
        if GapRecognizer._model is None:
            from captcha_recognizer.slider import Slider
            GapRecognizer._model = Slider()
        _crop, _pmask, ox, oy, init_x, init_y = self.piece_geometry(
            sprite_path, dsi)
        box, confidence = GapRecognizer._model.identify(source=bg_path)
        if not box:
            raise RuntimeError("captcha-recognizer found no gap")
        hole_x = int(round(min(box[0], box[2])))
        hole_y = int(round(min(box[1], box[3])))
        ans_x = hole_x - ox
        dy = hole_y - (init_y + oy)
        return {"x": ans_x, "y": init_y, "data": "%d,%d" % (ans_x, init_y),
                "piece_offset": (ox, oy), "engine": "captcha-recognizer",
                "hole": {"hole_x": hole_x, "hole_y": hole_y, "box": list(box),
                         "confidence": float(confidence),
                         "method": "captcha-recognizer", "iou": None, "dy": dy},
                "init_pos": [init_x, init_y], "y_check_ok": abs(dy) <= 6}

    def _recognize_builtin(self, bg_path, sprite_path, dsi):
        crop, pmask, ox, oy, init_x, init_y = self.piece_geometry(
            sprite_path, dsi)
        fg = [e for e in dsi["fg_elem_list"] if e.get("id") == 1][0]
        ys, xs = np.nonzero(pmask)
        pw, ph = int(xs.max() - ox + 1), int(ys.max() - oy + 1)
        bg = np.array(Image.open(bg_path).convert("RGB"))
        bg_lum = np.array(Image.open(bg_path).convert("L")).astype(np.float32)
        expected_y = init_y + oy
        hole = self.find_hole(bg, bg_lum, pmask, (ox, oy, pw, ph),
                              expected_y=expected_y)
        if hole is None or hole.get("iou", 0) < 0.5:
            alt = self.match_piece(bg,
                                   np.array(Image.open(sprite_path)
                                            .convert("RGBA")),
                                   fg, expected_y=expected_y)
            if hole is None or alt["iou"] >= 0.5:
                hole = alt
        ans_x = hole["hole_x"] - ox
        dy = hole["hole_y"] - expected_y
        return {"x": int(ans_x), "y": int(init_y),
                "data": "%d,%d" % (ans_x, init_y),
                "piece_offset": (ox, oy), "hole": hole, "engine": "builtin",
                "init_pos": [init_x, init_y], "y_check_ok": abs(dy) <= 4}

    @staticmethod
    def _components(mask, min_area):
        h, w = mask.shape
        seen = mask.copy()
        out = []
        ys, xs = np.nonzero(mask)
        for sy, sx in zip(ys, xs):
            if not seen[sy, sx]:
                continue
            q = deque([(sy, sx)])
            seen[sy, sx] = False
            n = 0
            minx = maxx = sx
            miny = maxy = sy
            pix = []
            while q:
                y, x = q.popleft()
                n += 1
                pix.append((y, x))
                if x < minx: minx = x
                if x > maxx: maxx = x
                if y < miny: miny = y
                if y > maxy: maxy = y
                for dy, dx in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    ny, nx = y + dy, x + dx
                    if 0 <= ny < h and 0 <= nx < w and seen[ny, nx]:
                        seen[ny, nx] = False
                        q.append((ny, nx))
            if n >= min_area:
                out.append({"area": n, "pix": pix,
                            "bbox": (minx, miny, maxx - minx + 1,
                                     maxy - miny + 1)})
        return out

    @staticmethod
    def _hole_mask(bg_rgb, bg_lum):
        a = bg_rgb.astype(np.int16)
        sat = (a.max(2) - a.min(2)).astype(np.float32)
        return (bg_lum >= 40) & (bg_lum <= 140) & (sat <= 22)

    @staticmethod
    def _iou(a_mask, a_off, b_mask, b_off, shift=(0, 0)):
        ax0, ay0 = a_off
        bx0, by0 = b_off[0] + shift[0], b_off[1] + shift[1]
        x0 = min(ax0, bx0); y0 = min(ay0, by0)
        x1 = max(ax0 + a_mask.shape[1], bx0 + b_mask.shape[1])
        y1 = max(ay0 + a_mask.shape[0], by0 + b_mask.shape[0])
        A = np.zeros((y1 - y0, x1 - x0), bool)
        B = np.zeros_like(A)
        A[ay0 - y0:ay0 - y0 + a_mask.shape[0],
          ax0 - x0:ax0 - x0 + a_mask.shape[1]] = a_mask
        B[by0 - y0:by0 - y0 + b_mask.shape[0],
          bx0 - x0:bx0 - x0 + b_mask.shape[1]] = b_mask
        inter = (A & B).sum()
        union = (A | B).sum()
        return inter / union if union else 0.0

    def find_hole(self, bg_rgb, bg_lum, piece_mask, piece_bbox,
                  expected_y=None):
        pw, ph = piece_bbox[2], piece_bbox[3]
        mask = self._hole_mask(bg_rgb, bg_lum)
        comps = self._components(mask, int(piece_mask.sum() * 0.35))
        pm = piece_mask[piece_bbox[1]:piece_bbox[1] + ph,
                        piece_bbox[0]:piece_bbox[0] + pw]
        cands = []
        for c in comps:
            cx, cy, cw, ch = c["bbox"]
            if not (0.6 * pw <= cw <= 1.45 * pw and 0.55 * ph <= ch <= 1.6 * ph):
                continue
            cm = np.zeros((ch, cw), bool)
            for y, x in c["pix"]:
                cm[y - cy, x - cx] = True
            best = (0.0, 0, 0)
            for dy in range(-4, 5):
                for dx in range(-4, 5):
                    score = self._iou(pm, (0, 0), cm, (dx, dy))
                    if score > best[0]:
                        best = (score, dx, dy)
            cands.append((best[0], cx + best[1], cy + best[2], cw, ch, cx, cy))
        if not cands:
            return None
        cands.sort(reverse=True)
        iou, hx, hy, cw, ch, bx, by = cands[0]
        corr = None
        if expected_y is not None:
            corr = int(by - expected_y)
            if -1 <= corr <= 6:
                hx = bx - corr
                hy = int(expected_y)
            else:
                corr = None
        return {"hole_x": int(hx), "hole_y": int(hy),
                "iou": round(float(iou), 3), "comp_w": int(cw),
                "comp_h": int(ch), "edge_corr": corr,
                "comp_bbox": [int(bx), int(by)], "method": "mask",
                "margin": round(float(cands[0][0] - cands[1][0]), 3)
                if len(cands) > 1 else None}

    def match_piece(self, bg_rgb, sprite_rgba, fg, expected_y=None):
        sx, sy = fg["sprite_pos"]
        w, h = fg["size_2d"]
        init_x, init_y = fg["init_pos"]
        crop = sprite_rgba[sy:sy + h, sx:sx + w]
        mask = crop[:, :, 3] > 128
        if not mask.any():
            raise ValueError("empty piece mask")
        ys, xs = np.nonzero(mask)
        ox, oy = int(xs.min()), int(ys.min())
        pw, ph = int(xs.max() - ox + 1), int(ys.max() - oy + 1)
        piece = crop[oy:oy + ph, ox:ox + pw, :3].astype(np.float32)
        pl = piece.mean(2)
        core = mask[oy:oy + ph, ox:ox + pw].copy()
        for _ in range(3):
            core = (core & np.roll(core, 1, 0) & np.roll(core, -1, 0)
                    & np.roll(core, 1, 1) & np.roll(core, -1, 1))
        if core.sum() < 50:
            core = mask[oy:oy + ph, ox:ox + pw].copy()
        y0 = int(expected_y if expected_y is not None else init_y + oy)
        H, W = bg_rgb.shape[:2]
        bgl = bg_rgb.astype(np.float32)
        bg_l = bgl.mean(2)
        a = piece[core]
        pa = pl[core]
        pa0 = pa - pa.mean()
        dena = float(np.sqrt((pa0 * pa0).sum())) + 1e-9
        scores = []
        for y in range(max(0, y0 - 6), min(H - ph, y0 + 6) + 1):
            for x in range(0, W - pw + 1):
                p = bg_l[y:y + ph, x:x + pw][core]
                p0 = p - p.mean()
                ncc = float((pa0 * p0).sum() /
                            (dena * (float(np.sqrt((p0 * p0).sum())) + 1e-9)))
                b = bgl[y:y + ph, x:x + pw][core]
                k = float((a * b).sum() / ((a * a).sum() + 1e-6))
                resid = float(np.abs(b - a * k).mean())
                scores.append((ncc, -resid, x, y, k, resid))
        scores.sort(reverse=True)
        dark = [s for s in scores if s[4] < 0.8]
        pool = dark if dark else scores
        ncc, _neg, best_x, best_y, k, resid = pool[0]
        around = [s for s in pool if abs(s[2] - best_x) > pw // 2]
        second = around[0][0] if around else None
        return {"hole_x": int(best_x), "hole_y": int(y0),
                "iou": round(float(ncc), 3), "comp_w": pw, "comp_h": ph,
                "edge_corr": None, "comp_bbox": [int(best_x), int(best_y)],
                "method": "template",
                "margin": round(ncc - second, 3) if second is not None else None,
                "k": round(float(k), 3), "resid": round(resid, 2)}


# --------------------------------------------------------------------------- #
# 3. 拖动轨迹 + TDC 事件串
# --------------------------------------------------------------------------- #
class Trajectory:
    """生成拖动轨迹并序列化成 collect 里的事件串。"""

    STEP_POOL = (3, 3, 3, 4, 4, 4, 5, 6, 6, 6, 6, 6, 7, 8, 9, 9, 9, 9, 9, 9,
                 9, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 11,
                 11, 11, 11, 11, 11, 11, 12, 16, 20, 20, 20, 37, 40, 40, 41,
                 50, 50, 80)

    @classmethod
    def make(cls, init_x, init_y, target_x, target_y, duration_ms=None):
        if duration_ms is None:
            duration_ms = random.randint(600, 1000)
        dx = target_x - init_x
        dy = target_y - init_y
        over = random.uniform(0.01, 0.035)
        drift = random.uniform(-1.5, 1.5)

        def pos(p):
            if p < 0.85:
                e = (1 - (1 - p / 0.85) ** 3) * (1 + over)
            else:
                q = (p - 0.85) / 0.15
                e = 1 + over * (1 - q) * (1 - q)
            return int(round(init_x + dx * e)), int(round(init_y + dy * e + drift))

        pts = {}
        t = 0
        while t < duration_ms:
            pts[t] = "%d,%d" % pos(min(1.0, t / float(duration_ms)))
            t += random.choice(cls.STEP_POOL)
        pts[duration_ms] = "%d,%d" % (target_x, target_y)
        return pts

    @staticmethod
    def event_trace(traj, start_ms=None):
        items = sorted((int(ms), v) for ms, v in traj.items())
        if start_ms is None:
            start_ms = random.randint(600, 2000)
        out = []
        prev = None
        for ms, xy in items:
            x, y = [int(t) for t in xy.split(",")]
            if prev is None:
                out.append([x, y, start_ms + ms])
            else:
                out.append([x - prev[0], y - prev[1], ms - prev[2]])
            prev = (x, y, ms)
        out.append([1, 1, 12])
        return json.dumps(out, separators=(",", ":"))


# --------------------------------------------------------------------------- #
# 4. collect 明文构造
# --------------------------------------------------------------------------- #
class CollectBuilder:
    """回放 FastMoss build 的明文布局，填入 now_sec/counter 后加密。"""

    def __init__(self, profile):
        self.profile = profile
        self.layout = profile["layout"]
        self.cipher = TDCCipher(profile)

    _PAD_SUFFIX_RE = re.compile(r'^\],(\s*)"sd":(.*)$', re.S)

    @staticmethod
    def _event_obj(events):
        """轨迹 {毫秒: "x,y"} -> `"0":"120,300","10":"128,300"`（sd 对象格式）。"""
        items = events.items() if isinstance(events, dict) else events
        return ",".join('"%s":"%s"' % (int(ms), xy) for ms, xy in items)

    def build_plaintext(self, now_sec, counter=1, events=None):
        """生成 collect 明文。

        动态字段：now_sec、counter，以及 counter 宽度补位 ``pads``；
        counter 跨十进制位时，``suffix_pad_width``（若存在）同步收窄。

        ``events``（可选）是拖动轨迹 {毫秒: "x,y"}：FastMoss 这个 build 把
        轨迹存成 ``"sd":{...}`` 里的对象，而不是 demo 那种塞进 cd 的三元组
        数组——这也是本文件与 pure_flow.py 的布局差异点。
        """
        toks = list(self.layout["tokens"])
        dyn = self.layout.get("dynamic") or {}
        suffix = self.layout["suffix"]
        if now_sec is not None and dyn.get("now_sec") is not None:
            toks[int(dyn["now_sec"])] = str(int(now_sec))
        if counter is not None and dyn.get("counter") is not None:
            cnt = int(counter)
            nd = len(str(cnt))
            toks[int(dyn["counter"])] = str(cnt)
            for j, width in (dyn.get("pads") or {}).items():
                w = int(width) - nd
                if w >= 0:
                    toks[int(j)] = " " * w
            w = dyn.get("suffix_pad_width")
            if w is not None:
                m = self._PAD_SUFFIX_RE.match(suffix)
                if m:
                    suffix = ("]," + " " * max(0, int(w) - nd)
                              + '"sd":' + m.group(2))
        if events:
            suffix = suffix.replace('"sd":{',
                                    '"sd":{' + self._event_obj(events) + ',', 1)
        s = self.layout["prefix"] + ",".join(toks) + suffix
        return (s + "\x00" * ((-len(s)) % 8)).encode("latin-1")

    def make_collect(self, now_sec, counter=1, events=None):
        pt = self.build_plaintext(now_sec, counter, events=events)
        data = self.cipher.get_data(pt)
        if self.cipher.decode_data(data) != pt:
            raise SystemExit("collect self-check failed (decrypt != plaintext)")
        return data, pt


# --------------------------------------------------------------------------- #
# 5. 完整流程
# --------------------------------------------------------------------------- #
class FastMossCaptchaFlow:
    """一次完整的 FastMoss 滑块验证流程。

    典型用法：
        flow = FastMossCaptchaFlow()
        code, result = flow.run(submit=False)
    """

    def __init__(self, recognizer="zncc"):
        self.recognizer_engine = recognizer
        self.recognizer = GapRecognizer(recognizer)
        self.builder = CollectBuilder(PROFILE)

    @staticmethod
    def make_session():
        # 服务端除了看 collect，还会看传输层指纹（TLS/JA3、HTTP2 帧序）。
        # python-requests 的 JA3 一眼就是脚本；collect 里写着 Chrome、
        # 连接却是 OpenSSL，这种「声明与传输不符」正是风控最容易抓的点。
        # curl_cffi 走的是真 Chrome 的 TLS/HTTP2 指纹，装了就默认用它。
        s = None
        if not globals().get("NO_IMPERSONATE"):
            try:
                from curl_cffi import requests as _cffi
                s = _cffi.Session(impersonate=IMPERSONATE)
                print("HTTP: curl_cffi impersonate=%s" % IMPERSONATE)
            except Exception as exc:
                print("curl_cffi 不可用（%s），退回 requests" % exc)
        if s is None:
            s = requests.Session()
        # 会话级头 = 抓包里 prehandle / tdc.js 那两个 <script> 请求的真值。
        # 注意：浏览器**不在**这两个请求上带 Origin（file:// 页面里 <script>
        # 不发 Origin），我们的 Origin: null 只该出现在 verify 那条 POST 上。
        # Sec-Fetch-* 也照抓包带上：dest=script / mode=no-cors / site=cross-site。
        s.headers.update({"User-Agent": UA, "Accept": "*/*",
                          "Accept-Language": "zh,zh-CN;q=0.9",
                          "Cache-Control": "no-cache", "Pragma": "no-cache",
                          "Sec-Fetch-Site": "cross-site",
                          # 抓包里浏览器真值：主版本号必须和 UA 一致（146）。
                          # 之前写成 156 / "Not:A-Brand";v="8" 和 UA 对不上，
                          # 属于「声明自相矛盾」，风控最容易抓这种。
                          "sec-ch-ua": '"Chromium";v="146", '
                                       '"Not-A.Brand";v="24", '
                                       '"Google Chrome";v="146"',
                          "sec-ch-ua-mobile": "?0",
                          "sec-ch-ua-platform": '"Windows"'})
        return s

    # 抓包里 <script> 那两个请求的 Sec-Fetch-* 三件套
    SCRIPT_HDRS = {"Sec-Fetch-Dest": "script", "Sec-Fetch-Mode": "no-cors",
                   "Sec-Fetch-Site": "cross-site",
                   "Sec-Fetch-Storage-Access": "active"}

    @staticmethod
    def prehandle(s, tkid=None):
        """请求 cap_union_prehandle，返回 (tkid, 响应 JSON)。

        参数 2026-10-25 用 CDP 抓「能过的浏览器会话」逐字段校准过
        （scripts/prehandle_param_cmp.py）：
            fb=1 / lang=zh-cn / subsid=1，且**不发** userLanguage。
        旧值 fb=0 / lang=zh / subsid=3 / userLanguage=zh-cn 来自最早那次抓包，
        和现在 SDK 实发的不一致（zh 配 userLanguage=zh-cn 本身还自相矛盾）。
        prehandle 决定 sess，verify 时服务端就是拿这个 sess 的风险档位来判的。
        """
        if tkid is None:
            tkid = str(int(time.time() * 1000) % 1000000000)
        cb = "_aq_%d" % random.randint(10000, 99999)
        params = {
            "aid": AID, "protocol": "https", "accver": "1",
            "showtype": "popup",
            "ua": base64.b64encode(UA.encode()).decode(),
            "noheader": "1", "fb": "1", "aged": "0", "enableAged": "0",
            "enableDarkMode": "0", "grayscale": "1", "clientype": "2",
            "cap_cd": "", "uid": "", "lang": "zh-cn",
            "entry_url": ENTRY_URL, "elder_captcha": "0",
            "js": "/tgJCap.2f0b2c65.js", "login_appid": "",
            "wb": "1", "tkid": tkid, "subsid": "1", "callback": cb, "sess": "",
        }
        r = s.get(BASE + "/cap_union_prehandle", params=params, timeout=15,
                  headers=FastMossCaptchaFlow.SCRIPT_HDRS)
        r.raise_for_status()
        m = re.search(r"^%s\((.*)\)$" % re.escape(cb), r.text.strip(), re.S)
        return tkid, json.loads(m.group(1) if m else r.text)

    @staticmethod
    def get_image(s, url, tkid):
        if url.startswith("/"):
            url = BASE + url
        sep = "&" if "?" in url else "?"
        # 图的请求在浏览器里是 <img>：dest=image / mode=no-cors
        r = s.get(url + sep + "tkid=" + tkid, timeout=15,
                  headers={"Accept": "image/avif,image/webp,image/apng,"
                                     "image/svg+xml,image/*,*/*;q=0.8",
                           "Sec-Fetch-Dest": "image",
                           "Sec-Fetch-Mode": "no-cors",
                           "Sec-Fetch-Site": "cross-site"})
        r.raise_for_status()
        return r.content

    # 会话 build 指纹：tdc.js 每次 HTTP 请求都重新随机化，K/C/字节码/eks 全都变。
    # 所以静态常量只对「当初推导它的那次请求」有效，拿它去提交必然被拒。
    EKS_PAT = re.compile(r"window\.([A-Za-z_$][\w$]*)\s*=\s*'([A-Za-z0-9+/=]{40,400})'")

    @staticmethod
    def encode_form(body):
        """按 SDK 的口径拼 x-www-form-urlencoded 表单。

        关键：**不要转义 `%`**。tdc.js 产出的 collect / eks 本身就是预编码串
        （里面是 %2B / %2F / %3D），SDK 拼 body 时只转义其它字符，`%` 原样留着；
        服务端表单解析时把它们解回 + / =（实测 1198 -> 1144），再按 tlg 解密。

        用 data=dict 交给 requests/curl_cffi 会把 `%` 再编一层成 `%25`，
        服务端解一次后拿到的还是带 %XX 的长串（长度也多 46），解密直接失败 ->
        errorCode 12。这就是之前「怎么调都是 12」的根因（2026-10-25 定案：
        浏览器抓到的 wire body 里 collect 段 %25 计数为 0，只有 %2B/%2F/%3D）。
        """
        return "&".join("%s=%s" % (k, urllib.parse.quote(v, safe="%"))
                        for k, v in body.items()).encode("utf-8")

    @staticmethod
    def tdc_url(path):
        """prehandle 给的 tdc_path + info 页 SDK 实际会补上的 appid。

        2026-10-25 用 CDP 抓到真页面请求的是
            /tdc.js?app_data=<sid>&t=<rand>&appid=195941100
        而 prehandle 的 comm_captcha_cfg.tdc_path 里**没有 appid**，照着补上。
        """
        url = path if path.startswith("http") else BASE + path
        if "appid=" not in url:
            url += ("&" if "?" in url else "?") + "appid=" + AID
        return url

    def session_build(self, s, data):
        """取本会话 tdc.js 里的 eks，用来判断 PROFILE 是否过期。"""
        cfg = data.get("comm_captcha_cfg") or {}
        path = cfg.get("tdc_path")
        if not path:
            return None, None
        try:
            js = s.get(self.tdc_url(path), timeout=15,
                       headers=FastMossCaptchaFlow.SCRIPT_HDRS).text
        except Exception as exc:
            print("tdc.js fetch failed:", exc)
            return None, None
        for _name, val in self.EKS_PAT.findall(js):
            try:
                if len(base64.b64decode(val + "=" * (-len(val) % 4))) == 184:
                    return val, path
            except Exception:
                continue
        return None, path

    @staticmethod
    def solve_pow(cfg):
        prefix, target = cfg["prefix"], cfg["md5"]
        t0 = time.time()
        n = 0
        while hashlib.md5((prefix + str(n)).encode()).hexdigest() != target:
            n += 1
        return prefix + str(n), max(1, int((time.time() - t0) * 1000))

    def run(self, submit=False, with_events=True):
        result = {"submit": submit, "aid": AID,
                  "build_sha": PROFILE["sha256_16"],
                  "recognizer": self.recognizer_engine}

        # 1) prehandle
        s = self.make_session()
        tkid, pre = self.prehandle(s)
        data = pre.get("data") or {}
        sess = pre.get("sess") or data.get("sess") or ""
        if not sess:
            result["prehandle"] = pre
            print("prehandle has no sess:", json.dumps(pre)[:800])
            return 1, result
        dsi = data["dyn_show_info"]
        pow_cfg = data["comm_captcha_cfg"]["pow_cfg"]
        fg = [e for e in dsi["fg_elem_list"] if e.get("id") == 1][0]
        init_x, init_y = fg["init_pos"]
        print("prehandle: sess=%d tkid=%s init_pos=%s pow=%s" % (
            len(sess), tkid, fg["init_pos"], pow_cfg["prefix"]))

        # 1b) 本会话 build 指纹 vs PROFILE：tdc.js 每次请求重新随机化（K/C/字节码/eks），
        #     静态常量基本必然过期；过期就别浪费一次提交。
        eks_now, tdc_path = self.session_build(s, data)
        stale = eks_now is not None and eks_now != PROFILE["eks"]
        use_sess_eks = "--use-session-eks" in sys.argv and eks_now
        eks_send = eks_now if use_sess_eks else PROFILE["eks"]
        result.update({"session_eks": (eks_now or "")[:24],
                       "profile_stale": stale,
                       "eks_source": "session" if use_sess_eks else "profile"})
        print("build: tdc.js eks=%s profile %s"
              % ((eks_now or "?")[:16] + "...",
                 "STALE" if stale else "ok"))
        if use_sess_eks:
            print("eks: 用本会话的值（K 仍是静态 PROFILE，用于判定服务端是否真的解密）")
        if stale and submit and "--force-stale" not in sys.argv \
                and not use_sess_eks:
            print("ABORT: 本会话 tdc.js 的 eks 与 PROFILE 不同 -> K/C/split 都变了，"
                  "静态常量不可能被服务端解开。\n"
                  "       要么先跑 scripts/fastmoss_live.py 现推常量，要么用 "
                  "--force-stale 强制提交（验证用）。")
            return 1, result

        # 2) 取图
        open(BG, "wb").write(self.get_image(s, dsi["bg_elem_cfg"]["img_url"], tkid))
        open(SP, "wb").write(self.get_image(s, dsi["sprite_url"], tkid))
        print("images: bg=%d sprite=%d bytes" % (
            os.path.getsize(BG), os.path.getsize(SP)))

        # 3) 识别缺口
        ans = self.recognizer.recognize(BG, SP, dsi)
        print("ans: %s  engine=%s  method=%s  iou=%s  conf=%s" % (
            ans["data"], ans.get("engine"), ans["hole"].get("method", "mask"),
            ans["hole"].get("iou"), ans["hole"].get("confidence")))

        # 4) 轨迹（可选）+ collect。events 是 {毫秒: "x,y"}，写进 sd 对象。
        events = None
        traj_n = 0
        if with_events:
            events = Trajectory.make(init_x, init_y, ans["x"], ans["y"])
            traj_n = len(events)
            print("trajectory: %d points (sd object)" % traj_n)

        now = int(time.time())
        collect, pt = self.builder.make_collect(now, counter=1, events=events)
        tlg = len(urllib.parse.unquote(collect)) if TLG_DECODED else len(collect)
        print("collect: plaintext=%d encoded=%d tlg=%d now=%d" % (
            len(pt), len(collect), tlg, now))
        result.update({"ans": ans["data"], "ans_meta": ans["hole"],
                       "init_pos": [init_x, init_y], "traj_points": traj_n,
                       "tkid": tkid, "sess_len": len(sess),
                       "collect_encoded_len": len(collect), "tlg": tlg,
                       "plaintext_len": len(pt), "now_sec": now,
                       "tlG_decoded": TLG_DECODED,
                       "plaintext_head": pt[:120].decode("latin-1", "replace")})

        # 5) PoW
        pow_answer, pow_ms = self.solve_pow(pow_cfg)
        print("pow: %s in %d ms" % (pow_answer, pow_ms))

        # 6) 组装 verify 表单
        ans_json = json.dumps([{"elem_id": 1, "type": "DynAnswerType_POS",
                                "data": ans["data"]}], separators=(",", ":"))
        body = {"collect": collect, "tlg": str(tlg), "eks": eks_send,
                "sess": sess, "ans": ans_json, "tkid": tkid,
                "pow_answer": pow_answer, "pow_calc_time": str(pow_ms)}
        result["body_preview"] = {k: (v if len(v) < 300 else "len=%d" % len(v))
                                  for k, v in body.items()}

        if not submit:
            print("DRY RUN: nothing posted. 不加 --dry 时默认发一条 POST。")
            return 0, result

        # 7) 提交（仅一次，无重试）
        print("POST verify (authorized: one submission per invocation)")
        t0 = time.time()
        r = s.post(BASE + "/cap_union_new_verify",
                   data=self.encode_form(body),
                   headers={"Accept": "application/json, text/javascript, "
                                       "*/*; q=0.01",
                            "Content-Type": "application/x-www-form-urlencoded; "
                                            "charset=UTF-8",
                            "Origin": "null", "Sec-Fetch-Dest": "empty",
                            "Sec-Fetch-Mode": "cors",
                            "Sec-Fetch-Site": "cross-site"}, timeout=20)
        post_ms = int((time.time() - t0) * 1000)
        print("HTTP", r.status_code, r.text[:600])
        result.update({"http": r.status_code, "response": r.text[:4000],
                       "post_ms": post_ms})
        try:
            js = r.json()
        except Exception:
            js = {}
        err = js.get("errorCode")
        ticket = js.get("ticket") or ""
        randstr = js.get("randstr") or ""
        result.update({"errorCode": err, "ticket_len": len(ticket),
                       "randstr": randstr})
        if err != "0" or not ticket:
            return 2, result

        # 8) 业务后端校验（localhost:8787，先 node proxy.js）
        try:
            lr = s.post(LOCAL_VERIFY, json={
                "ticket": ticket, "randstr": randstr, "platform": 1,
                "business_id": 1, "scene_id": 1, "id": 0, "type": 1,
                "lang": "zh-CN"},
                headers={"Accept": "*/*",
                         "Content-Type": "application/json",
                         "Origin": "null", "lang": "zh-CN",
                         "Sec-Fetch-Dest": "empty",
                         "Sec-Fetch-Mode": "cors",
                         "Sec-Fetch-Site": "cross-site"}, timeout=15)
            print("local verify: HTTP", lr.status_code, lr.text[:400])
            result.update({"local_http": lr.status_code,
                           "local_response": lr.text[:4000]})
        except Exception as exc:
            print("local verify skipped/failed:", exc)
            result["local_error"] = str(exc)[:300]
        return 0, result

    # ---------------- 无浏览器：Node 跑本会话 tdc.js ----------------
    def run_node(self, submit=False, with_events=False):
        """全流程，不依赖浏览器：prehandle -> 识图 -> Node 出 collect -> 提交。"""
        result = {"mode": "node", "submit": submit, "aid": AID,
                  "recognizer": self.recognizer_engine,
                  "with_events": with_events}
        s = self.make_session()
        tkid, pre = self.prehandle(s)
        data = pre.get("data") or {}
        sess = pre.get("sess") or data.get("sess") or ""
        if not sess:
            result["prehandle"] = pre
            print("prehandle 没有 sess:", json.dumps(pre)[:400])
            return 1, result
        dsi = data["dyn_show_info"]
        pow_cfg = data["comm_captcha_cfg"]["pow_cfg"]
        fg = [e for e in dsi["fg_elem_list"] if e.get("id") == 1][0]
        init_x, init_y = fg["init_pos"]
        print("prehandle: sess=%d tkid=%s init_pos=%s" % (len(sess), tkid,
                                                         fg["init_pos"]))

        # 本会话的 tdc.js —— collect 只能由它算
        tdc_path = (data.get("comm_captcha_cfg") or {}).get("tdc_path") or ""
        tdc_url = self.tdc_url(tdc_path)
        js = s.get(tdc_url, timeout=20,
                   headers=FastMossCaptchaFlow.SCRIPT_HDRS).text
        print("tdc.js: %d 字符" % len(js))

        # 取图 + 识别
        open(BG, "wb").write(self.get_image(s, dsi["bg_elem_cfg"]["img_url"], tkid))
        open(SP, "wb").write(self.get_image(s, dsi["sprite_url"], tkid))
        ans = self.recognizer.recognize(BG, SP, dsi)
        print("ans=%s engine=%s peak=%s" % (
            ans["data"], ans.get("engine"), ans["hole"].get("global_peak")))
        result.update({"ans": ans["data"], "ans_meta": ans["hole"],
                       "init_pos": [init_x, init_y], "sess_len": len(sess)})
        # 提交机会只有一次：识别不确定就别发，换一张图重来。
        # 两个条件（2026-10-25 校准，全部历史样本都对得上）：
        #   1) 带内峰值 >= MIN_SUBMIT_CONF；
        #   2) 带内峰值不能明显低于**全图**峰值 —— 缺口在竖直方向与拼图块对齐，
        #      全图最强匹配落在带外就说明带内那个只是运气（那次 0.642 带内 /
        #      0.709 带外，提交就是 errorCode 50 答案错）。
        conf = (ans["hole"] or {}).get("confidence")
        gp = (ans["hole"] or {}).get("global_peak")
        weak = conf is not None and (
            conf < MIN_SUBMIT_CONF or (gp is not None and conf < gp - 0.02))
        if submit and weak:
            print("识别不可靠（带内 %.3f / 全图 %s），这次不发；重跑换图"
                  % (conf if conf is not None else -1,
                     "%.3f" % gp if gp is not None else "?"))
            return 1, result

        # Node 出 collect
        if not NodeCollector.available():
            print("没找到 node，无法走无浏览器模式")
            return 1, result
        # 真 collect 会把拖动轨迹作为开头的三元组带出去：tdc.js 靠页面上的
        # 鼠标事件积累，所以这里按同样的几何发一遍合成事件。
        # --no-drag：不发轨迹（collect 里不含拖动三元组）。2026-10-25 实测服务端
        # 对「没有轨迹的 collect + 正确答案」照样发 ticket，所以轨迹不是必需项。
        drag = None
        if not with_events and "--no-drag" not in sys.argv:
            dist = (ans["x"] - init_x) * DRAG_SCALE
            drag = human_drag(dist)
            print("拖动: dist=%.1fpx 步数=%d" % (dist, len(drag) - 1))

        nc = NodeCollector(events=with_events)
        try:
            sd = None if with_events else SD_FT
            collect, eks = nc.collect(
                js, sd, drag,
                (init_x, init_y) if with_events else None,
                (ans["x"], ans["y"]) if with_events else None)
        except Exception as exc:
            print("Node 出 collect 失败:", exc)
            return 1, result
        if not eks:
            eks = PROFILE["eks"]
            print("警告：Node 没给 eks，退回 PROFILE 的（多半会被拒）")
        # tlg 该发哪种长度：SDK 发的是 len(collect) —— **原始串**长度，里面有多少
        # 个 %XX 就按多少个字符算。之前这里写死成 unquote 后的长度；唯一一次
        # 「解码长度也能过」的实验（node_collect_probe）里 Node 的 collect 恰好
        # 一个转义都没有（raw 920 == decoded 920），所以那个结论根本没验证到。
        # 正常 collect 是 raw 966 / decoded 920，差 46 —— 服务端拿 tlg 当长度
        # 时差一个字节就解不开 -> errorCode 12。
        tlg = len(urllib.parse.unquote(collect)) if TLG_DECODED else len(collect)
        print("collect: %d 字符 tlg=%d eks=%d 字符" % (len(collect), tlg, len(eks)))
        result.update({"collect_len": len(collect), "tlg": tlg,
                       "session_eks": eks[:24], "with_events_in_collect": with_events})

        pow_answer, pow_ms = self.solve_pow(pow_cfg)
        ans_json = json.dumps([{"elem_id": 1, "type": "DynAnswerType_POS",
                                "data": ans["data"]}], separators=(",", ":"))
        body = {"collect": collect, "tlg": str(tlg), "eks": eks,
                "sess": sess, "ans": ans_json, "tkid": tkid,
                "pow_answer": pow_answer, "pow_calc_time": str(pow_ms)}

        if not submit:
            print("DRY RUN：不发包（不加 --dry 时默认就发一条）")
            return 0, result

        print("POST verify（每次调用只发一条）")
        r = s.post(BASE + "/cap_union_new_verify",
                   data=self.encode_form(body),
                   headers={"Accept": "application/json, text/javascript, "
                                       "*/*; q=0.01",
                            "Content-Type": "application/x-www-form-urlencoded; "
                                            "charset=UTF-8",
                            "Origin": "null", "Sec-Fetch-Dest": "empty",
                            "Sec-Fetch-Mode": "cors",
                            "Sec-Fetch-Site": "cross-site"}, timeout=20)
        print("HTTP", r.status_code, r.text[:600])
        result.update({"http": r.status_code, "response": r.text[:4000]})
        try:
            js2 = r.json()
        except Exception:
            js2 = {}
        err = js2.get("errorCode")
        ticket, randstr = js2.get("ticket") or "", js2.get("randstr") or ""
        result.update({"errorCode": err, "ticket_len": len(ticket),
                       "randstr": randstr})
        if err != "0" or not ticket:
            return 2, result

        try:
            lr = requests.post(LOCAL_VERIFY, json={
                "ticket": ticket, "randstr": randstr, "platform": 1,
                "business_id": 1, "scene_id": 1, "id": 0, "type": 1,
                "lang": "zh-CN"},
                headers={"Accept": "*/*", "Content-Type": "application/json",
                         "Origin": "null", "lang": "zh-CN"}, timeout=15)
            print("本地业务校验 HTTP %d %s" % (lr.status_code, lr.text[:300]))
            result.update({"local_http": lr.status_code,
                           "local_response": lr.text[:1000]})
        except Exception as exc:
            print("本地业务校验失败：", exc)
            result["local_error"] = str(exc)[:300]
        return 0, result


# --------------------------------------------------------------------------- #
# 5a. 无浏览器 collect：用 Node 跑「本会话的 tdc.js」，只取 collect
# --------------------------------------------------------------------------- #
NODE_ASSETS = os.path.join(HERE, "scripts", "node_tdc")
NODE_BIN = "node"
MIN_SUBMIT_CONF = 0.55      # 低于这个识图置信度就不浪费提交机会

# 页面 SDK（TJCaptcha.js）在拖动结束时会调一次 TDC.setData({"ft": ...})，
# 这个 token 会进 collect 的 sd 字段。浏览器里连测两次（不同 build）拿到的都是
# 同一个值，所以按常量用；换 SDK 版本时用 scripts/sd_capture.py 重新取。
SD_FT = {"ft": "6f_7Pf__H"}

# 拖拽几何（来自弹窗实测）：滑块中心在页面上的位置，以及
# 「图像坐标 -> 显示坐标」的比例 = 拼图显示宽 / 拼图图宽 = 59 / 120。
DRAG_THUMB = (352.66, 542.0)
DRAG_SCALE = 0.49102
DRAG_STEPS = 26

# tdc.js 的轨迹三元组第三位是「距页面加载多少毫秒」。Node 一启动就 getData
# 只有十几毫秒，真浏览器最少也是一两秒，所以先空转一会儿再动鼠标。
WARMUP_MS = 4200
DRAG_GAP_MS = 30            # 拖动事件的间隔（会抖动 0.65~1.45 倍）


def human_drag(dist, steps=DRAG_STEPS, thumb=DRAG_THUMB):
    """按人手拖动的样子生成轨迹（页面坐标）。

    匀速直线 + 固定间隔是最典型的机器人特征，所以这里：
      * x 用余弦缓动（起步慢、中段快、末端慢），最后 12% 过冲 2% 再回正；
      * y 叠一条很轻的正弦抖动，越到后面越小（真人松手前基本在一个高度）；
      * 每一步间隔由 run.js 抖动，不在这里做（那里才能真的等）。
    """
    x0, y0 = thumb
    pts = []
    for i in range(steps + 1):
        p = i / steps
        if p < 0.88:
            q = p / 0.88
            e = 0.5 - 0.5 * math.cos(math.pi * q)
            x = x0 + dist * e
        else:
            q = (p - 0.88) / 0.12
            x = x0 + dist * (1.0 + 0.02 * math.sin(math.pi * q) * (1.0 - q))
        y = y0 + math.sin(p * 5.2) * 0.9 * (1.0 - 0.4 * p)
        pts.append([round(x, 2), round(y, 2)])
    return pts


class NodeCollector:
    """在 Node 里加载本会话的 tdc.js，调 TDC.getData() 拿 collect。

    为什么纯 Python 复刻不了（2026-10-25 用 5 个会话反解真 collect 标定）
    ---------------------------------------------------------------------
    每会话随机化的至少有三处：
      1) K 数组在 (7,8)/(7,9) 两个候选里随机，且和 cipher 的 upvalue 无关，
         离线无法判定该选哪个；
      2) split（把首 24 字节插到哪）每会话不同，也推不出来；
      3) 明文字段顺序整体打乱（同一批字段，顺序每次不同）。
    所以只能让 build 自己算。Node 不是浏览器：只用一份很小的 DOM 垫片
    （scripts/node_tdc/shim.js），canvas/WebGL 返回值由垫片给。
    实测：同一 build 在 Node 里出的 collect，用浏览器那条会话的 K/C/split
    能一次解开，且字段顺序完全一致。
    """

    def __init__(self, events=False, timeout=120):
        self.events = events
        self.timeout = timeout

    @staticmethod
    def available():
        try:
            r = subprocess.run([NODE_BIN, "--version"], capture_output=True,
                               timeout=10)
            return r.returncode == 0
        except Exception:
            return False

    def collect(self, js_text, sd=None, drag=None, init_xy=None, ans_xy=None):
        work = os.path.join(HERE, ".node_tdc_work")
        os.makedirs(work, exist_ok=True)
        p = os.path.join(work, "tdc_session.js")
        with open(p, "w", encoding="utf-8") as fh:
            fh.write(js_text)
        cmd = [NODE_BIN, os.path.join(NODE_ASSETS, "run.js"), p, "--calls", "1",
               "--warmup", str(WARMUP_MS), "--drag-gap", str(DRAG_GAP_MS)]
        if sd:
            cmd += ["--sd", json.dumps(sd, separators=(",", ":"))]
        if drag:
            cmd += ["--drag", json.dumps(drag, separators=(",", ":"))]
        if self.events:
            cmd.append("--events")
            if init_xy:
                cmd += ["--from", "%d,%d" % tuple(init_xy)]
            if ans_xy:
                cmd += ["--to", "%d,%d" % tuple(ans_xy)]
        r = subprocess.run(cmd, capture_output=True, timeout=self.timeout,
                           text=True, encoding="utf-8", errors="replace")
        lines = [l for l in (r.stdout or "").strip().splitlines()
                 if l.startswith("{")]
        if not lines:
            raise RuntimeError("node 没有输出：%s" % ((r.stderr or "")[:400]))
        out = json.loads(lines[-1])
        if not out.get("ok"):
            raise RuntimeError("node 执行失败：%s" % out.get("err"))
        info = out.get("info") or {}
        collect = out["datas"][0]["d"]
        # 留档：tdc_session.js + collect.txt，方便离线用候选 K/C/split 反解核对
        with open(os.path.join(work, "collect.txt"), "w") as fh:
            fh.write(collect)
        return collect, (info.get("text") or "")


# --------------------------------------------------------------------------- #
# 5b. 浏览器混合模式：本会话的 tdc.js 出 collect，Python 只负责算答案
# --------------------------------------------------------------------------- #
class _CDP:
    """最小的 CDP 客户端（只依赖 websocket-client）。"""

    def __init__(self, url, timeout=120):
        import websocket
        self.ws = websocket.create_connection(url, timeout=timeout,
                                              suppress_origin=True)
        self.i = 0
        self.events = []

    def call(self, method, timeout=60, **p):
        self.i += 1
        mid = self.i
        self.ws.send(json.dumps({"id": mid, "method": method, "params": p}))
        end = time.time() + timeout
        while True:
            self.ws.settimeout(max(0.5, end - time.time()))
            m = json.loads(self.ws.recv())
            if m.get("id") == mid:
                if "error" in m:
                    raise RuntimeError("%s -> %s" % (method, m["error"]))
                return m.get("result", {})
            if "method" in m:
                self.events.append(m)

    def ev(self, expr, timeout=60):
        r = self.call("Runtime.evaluate", expression=expr, returnByValue=True,
                      timeout=timeout)
        if r.get("exceptionDetails"):
            return {"__exc": str(r["exceptionDetails"])[:400]}
        return r.get("result", {}).get("value")


class BrowserHybrid:
    """为什么需要这个模式
    --------------------
    tdc.js 每个会话都重新随机化（K 数组 / C 常量 / VM 字节码 / eks 全都变），
    所以用固定 PROFILE 加密出来的 collect 服务端解不开。collect 只能由
    **本会话自己的 JS 运行时**生成。

    （注：errorCode 12 后来定案不是这个原因 —— 是表单把 collect 的 `%` 又
    转义了一层，见 FastMossCaptchaFlow.encode_form。这里留着是因为静态
    PROFILE 那条路确实不可用：每会话 build 都不同。）

    分工：浏览器出环境指纹 + collect + 发 verify；Python 出缺口答案 + 拖拽闭环。

    2026-10-25 实测：一次会话 ans=265 -> errorCode 0 + ticket -> 本地业务
    校验 is_ok=1（整条链路打通）。拖拽映射已量化：
        thumb 显示位移 = (ans_x - init_x) * (拼图显示宽 / 拼图图宽)
    """

    CHROME = r"D:\cloakbrowser\chrome.exe"
    PORT = 9222
    PAGE = ENTRY_URL

    LOAD = r"""
(async function(){
  if (!window.TencentCaptcha) {
    await new Promise(function(res, rej){
      var s = document.createElement('script');
      s.src = 'https://turing.captcha.qcloud.com/TJCaptcha.js';
      s.async = true; s.onload = res; s.onerror = rej;
      document.body.appendChild(s);
    });
  }
  if (!window.__fmShown) {
    window.__fmShown = 1;
    new window.TencentCaptcha('%s', function(r){ window.__fmCb = r; }).show();
  }
  return typeof window.TDC;
})()
"""

    GEO = r"""
(function(){
  var img = document.querySelector('.tencent-captcha-dy__image-area');
  var fg  = document.querySelector('.tencent-captcha-dy__fg-item');
  var th  = document.querySelector('.tencent-captcha-dy__slider-block');
  if (!img || !fg || !th) return null;
  var ri = img.getBoundingClientRect();
  var rf = fg.getBoundingClientRect();
  var rt = th.getBoundingClientRect();
  return {
    img:   [ri.left, ri.top, ri.width, ri.height],
    fg:    [rf.left, rf.top, rf.width, rf.height],
    thumb: [rt.left, rt.top, rt.width, rt.height],
    fgTf:  getComputedStyle(fg).transform
  };
})()
"""

    def __init__(self, recognizer="zncc", chrome=None, port=None):
        self.engine = recognizer
        self.chrome = chrome or self.CHROME
        self.port = port or self.PORT
        self.proc = None

    # ---------------- 浏览器生命周期 ----------------
    def _alive(self):
        try:
            c = http.client.HTTPConnection("127.0.0.1", self.port, timeout=2)
            c.request("GET", "/json/version")
            return c.getresponse().status == 200
        except Exception:
            return False

    def _launch(self):
        if self._alive():
            print("复用 9222 上已有的 CDP 实例")
            return None
        profile = os.path.join(HERE, ".cdp_tmp")
        print("启动浏览器", self.chrome)
        self.proc = subprocess.Popen([
            self.chrome, "--remote-debugging-port=%d" % self.port,
            "--user-data-dir=%s" % profile,
            "--no-first-run", "--no-default-browser-check",
            "--disable-blink-features=AutomationControlled", "about:blank",
        ], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        for _ in range(60):
            time.sleep(0.5)
            if self._alive():
                return self.proc
        raise SystemExit("浏览器没有在 %d 端口暴露 CDP" % self.port)

    def _new_target(self):
        c = http.client.HTTPConnection("127.0.0.1", self.port, timeout=5)
        c.request("PUT", "/json/new?about:blank")
        return json.loads(c.getresponse().read())

    def _close_target(self, tid):
        try:
            c = http.client.HTTPConnection("127.0.0.1", self.port, timeout=5)
            c.request("PUT", "/json/close/" + tid)
            c.getresponse().read()
        except Exception:
            pass

    # ---------------- 小工具 ----------------
    @staticmethod
    def _drain(c, rounds=6, pause=0.2):
        """借一次无害调用把已到达的 CDP 事件收进 c.events。"""
        for _ in range(rounds):
            c.call("Runtime.evaluate", expression="1")
            time.sleep(pause)

    @staticmethod
    def _jsonp(text):
        t = (text or "").strip()
        i, j = t.find("("), t.rfind(")")
        if i < 0 or j <= i:
            return None
        try:
            return json.loads(t[i + 1:j])
        except Exception:
            return None

    @staticmethod
    def _net(c, needle):
        """返回 (响应体列表, 请求体列表)，均为 URL 含 needle 的那些。"""
        resps, reqs = [], []
        for e in c.events:
            m = e.get("method")
            p = e.get("params") or {}
            if m == "Network.requestWillBeSent":
                if needle in (p.get("request") or {}).get("url", ""):
                    reqs.append({"url": p["request"]["url"],
                                 "postData": p["request"].get("postData", "")})
            elif m == "Network.responseReceived":
                if needle in (p.get("response") or {}).get("url", ""):
                    try:
                        b = c.call("Network.getResponseBody",
                                   requestId=p["requestId"]).get("body", "")
                    except Exception as exc:
                        b = "ERR %s" % exc
                    resps.append({"url": p["response"]["url"],
                                  "status": p["response"].get("status"),
                                  "body": b[:200000]})
        return resps, reqs

    @staticmethod
    def _tdc_source(c):
        """取本页实际加载的 tdc.js 源码（要求已 Debugger.enable）。

        不能改用 prehandle 里的 tdc_path 重新下载：那是另一次 prehandle 的 build，
        K/C/字节码都不一样，拿它解 collect 会直接解不开。
        """
        sid, url = None, None
        for e in c.events:
            if e.get("method") == "Debugger.scriptParsed":
                u = e["params"].get("url") or ""
                if "tdc.js" in u:
                    sid, url = e["params"]["scriptId"], u
        if sid is None:
            return None, None
        try:
            return (c.call("Debugger.getScriptSource",
                           scriptId=sid)["scriptSource"], url)
        except Exception:
            return None, url

    @staticmethod
    def _mouse(c, kind, x, y, buttons=0):
        c.call("Input.dispatchMouseEvent", type=kind, x=x, y=y,
               button="left", clickCount=1, buttons=buttons,
               pointerType="mouse")

    # ---------------- 主流程 ----------------
    def run(self, dry=False, submit_local=True, intercept_verify=False):
        """intercept_verify=True 时：松手后把 SDK 的 verify 请求截住（不发给服务端），
        把完整的 body / headers / cookie 交回去，由调用方决定怎么发。用来把
        「collect 内容」和「传输层」拆开验证。"""
        result = {"mode": "browser-hybrid", "dry": dry, "aid": AID,
                  "recognizer": self.engine}
        self._launch()
        t = self._new_target()
        tid = t["id"]
        c = _CDP(t["webSocketDebuggerUrl"])
        try:
            c.call("Runtime.enable")
            c.call("Page.enable")
            c.call("Network.enable")
            if intercept_verify:
                c.call("Fetch.enable", patterns=[{
                    "urlPattern": "*cap_union_new_verify*",
                    "requestStage": "Request"}])
                c.call("Debugger.enable")   # 为了拿本页真正加载的 tdc.js 源码
            c.call("Page.navigate", url=self.PAGE)
            time.sleep(1.5)
            c.ev(self.LOAD % AID)
            for _ in range(80):
                time.sleep(0.5)
                if c.ev("typeof window.TDC") == "object":
                    break
            for _ in range(60):
                time.sleep(0.5)
                if c.ev("!!document.querySelector("
                        "'.tencent-captcha-dy__slider-block')"):
                    break
            time.sleep(1.0)
            self._drain(c)
            if intercept_verify:
                js_src, js_url = self._tdc_source(c)
                js_src = js_src or ""
                result["tdc_js"] = js_src
                result["tdc_js_url"] = js_url or ""
                print("本页 tdc.js 源码 %d 字符" % len(js_src))
                print("本页 tdc.js URL: %s" % (js_url or "?"))
            # 探针用：页面就绪后注入一段 JS（比如把 TDC.setData 包起来记录参数）
            if getattr(self, "hook_js", None):
                try:
                    c.ev(self.hook_js)
                except Exception as exc:
                    print("hook 注入失败:", exc)

            # 1) 本会话 prehandle：sess / init_pos / 图片 URL
            resps, _ = self._net(c, "cap_union_prehandle")
            pre = None
            for r in reversed(resps):
                pre = self._jsonp(r["body"])
                if pre:
                    break
            if not pre:
                print("没抓到本会话的 prehandle")
                return 1, result
            d = pre.get("data") or {}
            dsi = d["dyn_show_info"]
            fg_cfg = [e for e in dsi["fg_elem_list"] if e.get("id") == 1][0]
            init_x, init_y = fg_cfg["init_pos"]
            print("会话 sess=%d init_pos=%s" % (len(pre.get("sess") or ""),
                                               [init_x, init_y]))
            result.update({"sess_len": len(pre.get("sess") or ""),
                           "init_pos": [init_x, init_y],
                           # 留档 prehandle 全文：pow_cfg 就在里面，
                           # 用来核对「我们自己算的 PoW」和 SDK 的完全等价
                           "pre": pre})
            # 本会话的 tdc.js 路径：NodeCollector 要用同一份 build 才能对上 collect 字段，
            # 探针脚本也靠它拿到明文参数（key/case/split）。
            result["tdc_path"] = ((d.get("comm_captcha_cfg") or {})
                                  .get("tdc_path") or "")

            # 2) 下载本会话图片（URL 自带 sess，不需要 tkid）
            hdr = {"User-Agent": UA, "Accept": "image/avif,image/webp,image/png,*/*",
                   "Referer": self.PAGE}
            for path, dst in ((dsi["bg_elem_cfg"]["img_url"], BG),
                              (dsi["sprite_url"], SP)):
                url = path if path.startswith("http") else BASE + path
                r = requests.get(url, headers=hdr, timeout=20)
                r.raise_for_status()
                open(dst, "wb").write(r.content)
            print("图片：bg=%dB sprite=%dB" % (os.path.getsize(BG),
                                             os.path.getsize(SP)))

            # 3) Python 识别缺口
            ans = GapRecognizer(self.engine).recognize(BG, SP, dsi)
            print("ans=%s engine=%s conf=%s peak=%s" % (
                ans["data"], ans.get("engine"), ans["hole"].get("confidence"),
                ans["hole"].get("global_peak")))
            result.update({"ans": ans["data"], "ans_meta": ans["hole"]})

            # 4) 几何 -> 闭环拖拽
            g = c.ev(self.GEO)
            if not g:
                print("弹窗几何没取到")
                return 1, result
            img_l = g["img"][0]
            th_l, th_t, th_w, th_h = g["thumb"]
            scale = g["fg"][2] / 120.0            # 拼图图片宽 120px
            print("几何 scale=%.5f thumb=%s" % (scale, g["thumb"]))
            result["geometry"] = {"img": g["img"], "thumb": g["thumb"],
                                  "fg": g["fg"], "scale": scale}

            def piece_x():
                gg = c.ev(self.GEO)
                return (gg["fg"][0] - img_l) / scale

            x0 = piece_x()
            print("拖动前 piece_x=%.2f（init_x=%d）" % (x0, init_x))
            sx, sy = th_l + th_w / 2.0, th_t + th_h / 2.0
            self._mouse(c, "mousePressed", sx, sy, buttons=1)
            time.sleep(0.05)

            target = float(ans["x"])
            done, cur = sx, x0
            best_done, best_cur = done, cur
            for it in range(4):
                err = target - cur                 # 图像像素
                if abs(err) <= 1.5:                # 1.5 内够用（容差远大于此）
                    break
                need = err * scale                 # 显示像素
                if abs(need) < 1.0:
                    # 浏览器会把鼠标坐标取整，亚像素移动反而放大成 1~2px 跳动
                    print("  残差 %.2f 图像像素，亚像素不值得动，停" % err)
                    break
                for k in range(1, 13):
                    self._mouse(c, "mouseMoved", done + need * k / 12.0,
                                sy + (1.0 if k % 3 else 0.0), buttons=1)
                    time.sleep(0.012)
                done += need
                time.sleep(0.08)
                prev_cur = cur
                cur = piece_x()
                print("  校正%d need=%.1f -> piece_x=%.2f（目标 %.2f）"
                      % (it + 1, need, cur, target))
                if abs(target - cur) <= abs(target - prev_cur):
                    best_done, best_cur = done, cur
                else:                              # 越改越歪：退回上一步
                    print("  量化跳动使残差变大，退回上一位置")
                    for k in range(1, 9):
                        self._mouse(c, "mouseMoved",
                                    done - (done - best_done) * k / 8.0,
                                    sy, buttons=1)
                        time.sleep(0.012)
                    done, cur = best_done, best_cur
                    break
            print("落点 piece_x=%.2f（目标 %.2f）" % (cur, target))
            result.update({"final_piece_x": cur, "target_x": target,
                           "thumb_delta": done - sx})

            if dry:
                print("DRY：只拖动不松手，不发 verify（保持按下状态直接关标签页）")
                return 0, result

            # 5) 松手 -> 本会话 SDK 生成 collect 并自行提交 verify
            self._mouse(c, "mouseReleased", done, sy, buttons=0)

            if intercept_verify:
                print("已松手，截住 SDK 的 verify 请求（不发给服务端）...")
                paused = None
                for _ in range(40):
                    time.sleep(0.5)
                    self._drain(c, rounds=2, pause=0.15)
                    for e in c.events:
                        if e.get("method") == "Fetch.requestPaused":
                            paused = e["params"]
                            break
                    if paused:
                        break
                if not paused:
                    print("没截到 verify 请求")
                    return 2, result
                req = paused.get("request") or {}
                result["verify_url"] = req.get("url")
                result["verify_headers"] = req.get("headers")
                result["verify_body"] = req.get("postData")
                if getattr(self, "hook_js", None):
                    try:
                        result["hook"] = c.ev(
                            "window.__hook ? window.__hook() : null")
                    except Exception as exc:
                        result["hook_error"] = str(exc)[:200]
                try:
                    c.call("Fetch.failRequest", requestId=paused["requestId"],
                           errorReason="Aborted")
                except Exception as exc:
                    print("failRequest:", exc)
                try:
                    result["cookies"] = c.call("Network.getAllCookies").get("cookies", [])
                except Exception as exc:
                    result["cookies_error"] = str(exc)[:200]
                # 把整条会话里浏览器发过的请求都记下来：哪些请求我们没发过，
                # 一眼就能看出来（服务端有可能要求某些请求才认这次 sess）。
                req_urls = []
                for e in c.events:
                    if e.get("method") == "Network.requestWillBeSent":
                        u = (e["params"].get("request") or {}).get("url") or ""
                        if u and u not in req_urls:
                            req_urls.append(u)
                result["request_urls"] = req_urls
                kv = dict(urllib.parse.parse_qsl(req.get("postData") or "",
                                                 keep_blank_values=True))
                result["collect_len"] = len(kv.get("collect", ""))
                result["sdk_eks"] = kv.get("eks", "")
                result["sdk_tlg"] = kv.get("tlg", "")
                result["fields"] = sorted(kv)
                print("截到 verify：collect=%d tlg=%s 字段=%s"
                      % (len(kv.get("collect", "")), kv.get("tlg"),
                         ",".join(sorted(kv))))
                return 0, result

            print("已松手，等 SDK 提交 ...")
            for _ in range(40):
                time.sleep(0.5)
                self._drain(c, rounds=2, pause=0.15)
                vr, _q = self._net(c, "cap_union_new_verify")
                if vr or c.ev("window.__fmCb"):
                    break
            vr, vq = self._net(c, "cap_union_new_verify")
            cb = c.ev("window.__fmCb")
            result["callback"] = cb
            if vq:
                result["verify_req"] = vq[-1:]
                kv = dict(urllib.parse.parse_qsl(vq[-1]["postData"],
                                                 keep_blank_values=True))
                result["collect_len"] = len(kv.get("collect", ""))
                result["sdk_eks"] = kv.get("eks", "")
                result["sdk_tlg"] = kv.get("tlg", "")
                print("SDK collect=%d 字符  tlg=%s  eks=%s..."
                      % (len(kv.get("collect", "")), kv.get("tlg"),
                         kv.get("eks", "")[:16]))
            if not vr:
                print("没抓到 verify 响应；callback=%s" % str(cb)[:200])
                return 2, result
            body = vr[-1]["body"]
            result["verify_resp"] = vr[-1:]
            print("verify 响应：", body[:300])
            try:
                js = json.loads(body)
            except Exception:
                js = {}
            err = js.get("errorCode")
            ticket, randstr = js.get("ticket") or "", js.get("randstr") or ""
            result.update({"errorCode": err, "ticket_len": len(ticket),
                           "randstr": randstr})
            if err != "0" or not ticket:
                return 2, result

            # 6) 业务后端校验
            if submit_local:
                try:
                    lr = requests.post(LOCAL_VERIFY, json={
                        "ticket": ticket, "randstr": randstr, "platform": 1,
                        "business_id": 1, "scene_id": 1, "id": 0, "type": 1,
                        "lang": "zh-CN"},
                        headers={"Accept": "*/*", "Content-Type": "application/json",
                                 "Origin": "null", "lang": "zh-CN"},
                        timeout=15)
                    print("本地业务校验 HTTP %d %s"
                          % (lr.status_code, lr.text[:300]))
                    result.update({"local_http": lr.status_code,
                                   "local_response": lr.text[:1000]})
                except Exception as exc:
                    print("本地业务校验失败：", exc)
                    result["local_error"] = str(exc)[:300]
            return 0, result
        finally:
            try:
                c.ws.close()
            except Exception:
                pass
            self._close_target(tid)
            # 只关我们自己拉起来的实例
            if self.proc is not None:
                try:
                    self.proc.terminate()
                except Exception:
                    pass


# --------------------------------------------------------------------------- #
# 6. 命令行入口
# --------------------------------------------------------------------------- #
USAGE = """\
FastMoss 腾讯验证码（aid 195941100）单文件流程

  python fastmoss_flow.py               无浏览器（默认）：算缺口 -> 用本会话的
                                        tdc.js 在 Node 里出 collect -> **提交**
  python fastmoss_flow.py --dry         同上但不发 verify，只看中间结果
  python fastmoss_flow.py --browser     浏览器混合模式（Chrome + CDP 真拖动）
  python fastmoss_flow.py --static      纯 Python 静态常量路径（多半已过期）

  默认就是提交一条 verify（每次调用仅一条，无重试）；要不发就用 --dry。

公共选项：
  --recognizer zncc|captcha-recognizer|builtin   缺口识别引擎（默认 zncc）
  --events      在 collect 的 sd 里带一段模拟轨迹（真 collect 只有 {"od":"C"}，
                默认不带，仅排查用）
  --raw-tlg     tlg 用「未解码长度」（老 aid 的规则）
  --force-stale 静态模式下即使本次 eks 与 PROFILE 不同也照发

退出码：0 成功，2 服务端拒绝，1 初始化错误。
每次调用只对 cap_union_new_verify 提交一次，无重试。"""


def main():
    argv = sys.argv[1:]
    if "-h" in argv or "--help" in argv:
        print(USAGE)
        sys.exit(0)
    engine = "zncc"
    for i, a in enumerate(argv):
        if a == "--recognizer" and i + 1 < len(argv):
            engine = argv[i + 1]
        elif a.startswith("--recognizer="):
            engine = a.split("=", 1)[1]
    if engine not in ("zncc", "captcha-recognizer", "builtin"):
        raise SystemExit("--recognizer must be zncc / captcha-recognizer / "
                         "builtin")
    if "--no-impersonate" in argv:
        globals()["NO_IMPERSONATE"] = True

    if "--static" in argv or "--no-browser" in argv:
        # 纯 Python 路径：静态 PROFILE。tdc.js 每会话随机化后基本必然过期，
        # 留着用于离线组装 / 对拍 / 推导校验。默认也发一条（--dry 不发）；
        # 原来的 stale 闸门还在：PROFILE 与本次 build 不一致就直接中止。
        submit = "--dry" not in argv and "--dry-run" not in argv
        with_events = "--events" in argv
        if "--raw-tlg" in argv:
            globals()["TLG_DECODED"] = False
        code, result = FastMossCaptchaFlow(engine).run(submit, with_events)
        json.dump(result, open(OUT, "w"), indent=1)
        print("result ->", OUT)
        sys.exit(code)

    if "--browser" in argv:
        # 浏览器混合模式：Chrome + CDP 真拖动，由页面自己的 SDK 出 collect。
        dry = "--dry" in argv
        code, result = BrowserHybrid(engine).run(dry=dry)
        dst = OUT.replace(".json", "_dry.json") if dry else OUT
        json.dump(result, open(dst, "w"), ensure_ascii=False, indent=1)
        print("result ->", dst)
        sys.exit(code)

    # 默认：无浏览器模式。识图在 Python，collect 由「本会话的 tdc.js」在 Node 里算。
    # 默认就发一条 verify（每次调用一条，无重试）；要不发就 --dry。
    dry = "--dry" in argv or "--dry-run" in argv
    submit = not dry
    if "--raw-tlg" in argv:
        globals()["TLG_DECODED"] = False
    # 真 collect 的 sd 只有 {"od":"C"}，没有轨迹点；默认别塞轨迹
    with_events = "--events" in argv
    code, result = FastMossCaptchaFlow(engine).run_node(submit and not dry,
                                                        with_events)
    dst = OUT.replace(".json", "_dry.json") if dry else OUT
    json.dump(result, open(dst, "w"), ensure_ascii=False, indent=1)
    print("result ->", dst)
    sys.exit(code)


if __name__ == "__main__":
    main()
