# -*- coding: utf-8 -*-
"""One-shot per-build derivation for the TDC collect cipher.

Why this exists: tdc.js is re-randomised on every HTTP request, so the handler
permutation, bytecode, key table K, branch constants C and the segment split
all change per build.  Hardcoding them (as tdc_crypto.PROFILES does) only works
until the page reloads.  This script re-derives everything from the build the
page actually has loaded:

  1. Debugger.getScriptSource of the live tdc.js   (fetch_live_build.py)
  2. handler fingerprinting -> live->canonical opcode map
  3. bytecode extraction + reachability walk
  4. K candidates: every closure of the form `(7 <- X)` that writes
     `self[7][slot] = word(literal, off)` yields one array; all of them are
     tried, the live sample decides which one the cipher reads.
  5. C: read statically from the cipher body's branch chain
         push A; push 3; load s; and; ==; jz tA
         setimm B; push 3; load s; and; ==; jz tB
     branch tA pushes constant cA after its getidx, tB pushes cB, so
     C[A]=cA, C[B]=cB, all other entries 0 (the `else` path adds nothing).
  6. split: brute-force 8-byte-aligned segment boundaries, score plaintexts.
  7. verify: decrypt a live TDC.getData() sample, then rebuild its plaintext
     with tdc_collect.build_collect_v3 and require byte equality.

Usage:
    python derive_build.py [name] [--src path] [--no-fetch]
Writes ../js/live_src/profile_<name>.json
"""
import argparse
import base64
import hashlib
import json
import os
import re
import subprocess
import sys
import time
import urllib.parse

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import extract_bc
import map_opcodes
from disasm_tdc import OPERANDS, NAMES
import derive_key_table as dk

# canonical opcodes (see disasm_tdc.NAMES)
PUSH, GETIDX, LOAD, JMP, SETIMM, AND, EQ, JZ = 59, 9, 28, 33, 54, 55, 58, 63

HERE = os.path.dirname(os.path.abspath(__file__))
JS = os.path.normpath(os.path.join(HERE, "..", "js"))
SUM_CONST = 84941944608
REF_SRC = os.path.join(JS, "tdc.dec.js")


# ---------------------------------------------------------------- opcode map
def resolve_map(old, live):
    """Same resolution as translate_bc.load_map, but from in-memory handler
    lists so we never clobber the saved cur3 maps."""
    fa = [map_opcodes.fingerprint(x) for x in old]
    fb = [map_opcodes.fingerprint(x) for x in live]
    from collections import defaultdict
    idx_b = defaultdict(list)
    for j, f in enumerate(fb):
        idx_b[f].append(j)
    live2old, unresolved = {}, []
    for i, f in enumerate(fa):
        cand = idx_b.get(f, [])
        if len(cand) == 1:
            live2old[cand[0]] = i
        else:
            unresolved.append(i)

    def popvar(src):
        try:
            return src.split(".pop()")[0].split("{")[-1].split("(")[-1]
        except Exception:
            return None

    old2live = {v: k for k, v in live2old.items()}
    main_var = None
    for old_i in (64, 0):
        lj = old2live.get(old_i)
        if lj is not None:
            m = re.search(r"(\w+)\.length\s*=", live[lj])
            if m:
                main_var = m.group(1)
                break
    if main_var is None:
        for src in live:
            m = re.search(r"(\w+)\.length\s*=", src)
            if m:
                main_var = m.group(1)
                break
    if main_var is None:
        main_var = "E"
    cands = [j for j, src in enumerate(live)
             if ".pop()" in src and j not in live2old]
    if 5 in unresolved:
        for j in cands:
            if popvar(live[j]) == main_var:
                live2old[j] = 5
                break
    if 14 in unresolved:
        for j in cands:
            if j not in live2old and popvar(live[j]) != main_var:
                live2old[j] = 14
                break
    used = set(live2old.values())
    free_live = [j for j in range(len(live)) if j not in live2old]
    free_old = [i for i in unresolved if i not in used]
    for j, i in zip(free_live, free_old):
        live2old[j] = i
    return live2old


# ------------------------------------------------------------ K derivation
def derive_key_arrays(seen):
    """Return {pair_tuple: [w0..w3]} for every `(7 <- X)` writer array."""
    arrays = {}
    for pc in sorted(seen):
        op, ops, end, pairs = seen[pc]
        if op != dk.CLOSURE or not pairs:
            continue
        off, slot = dk.body_info(seen, ops[0])
        if off is None or slot is None:
            continue
        lit = dk.lit_at(seen, end)
        if not lit:
            continue
        tag = tuple(pairs)
        arrays.setdefault(tag, {})[slot] = dk.word(lit, off) & 0xFFFFFFFF
    out = {}
    for tag, slots in arrays.items():
        if len(slots) == 4:
            out[tag] = [slots[i] for i in range(4)]
    return out


# ------------------------------------------------------------ C derivation
def _next_pushed_after_getidx(seen, body_pcs, target):
    """In the branch starting at `target`, return the constant added after
    getidx, or 0 when the branch adds none."""
    started = False
    for i, pc in enumerate(body_pcs):
        if pc < target:
            continue
        started = True
        name, ops, _end, _pairs = seen[pc]
        if name == JMP:
            return None
        if name == GETIDX:
            if i + 1 < len(body_pcs):
                nn, no, _e, _p = seen[body_pcs[i + 1]]
                if nn == PUSH:
                    return no[0]
                if nn == 51:  # add
                    return 0
            return None
    return None if started else None


def derive_case(seen, f):
    pcs = [p for p in sorted(seen) if f <= p < f + 600]
    names = [seen[p][0] for p in pcs]
    for i in range(len(pcs) - 5):
        if not (names[i] == PUSH and names[i + 1] == PUSH
                and seen[pcs[i + 1]][1] == [3] and names[i + 2] == LOAD
                and names[i + 3] == AND and names[i + 4] == EQ
                and names[i + 5] == JZ):
            continue
        A = seen[pcs[i]][1][0]
        tA = seen[pcs[i + 5]][1][0]
        j = i + 6
        if j >= len(pcs) or names[j] != SETIMM:
            continue
        B = seen[pcs[j]][1][0]
        if not (j + 5 < len(pcs) and names[j + 1] == PUSH
                and seen[pcs[j + 1]][1] == [3] and names[j + 2] == LOAD
                and names[j + 3] == AND and names[j + 4] == EQ
                and names[j + 5] == JZ):
            continue
        tB = seen[pcs[j + 5]][1][0]
        cA = _next_pushed_after_getidx(seen, pcs, tA)
        cB = _next_pushed_after_getidx(seen, pcs, tB)
        if cA is None or cB is None:
            continue
        case = [0, 0, 0, 0]
        case[A] = cA
        case[B] = cB
        return case, {"A": A, "B": B, "cA": cA, "cB": cB}
    return None, None


DELTA = 2654435769                 # XTEA delta, also a build literal
BIG_LIT = re.compile(r"(?<![\w.$])(\d{9,10})(?![\w.$])")


def big_operands(seen):
    """{value: count} for 1e9..2^32-1 reachable VM operands, delta excluded."""
    vals = {}
    for (_op, ops, _e, _p) in seen.values():
        for v in ops:
            if isinstance(v, int) and 1_000_000_000 <= v <= 0xFFFFFFFF \
                    and v != DELTA:
                vals[v] = vals.get(v, 0) + 1
    return vals


def find_build_const(src, seen=None):
    """The one big constant every tdc.js build embeds besides the XTEA delta.

    Every layout carries this value in exactly one payload slot.  The cur2
    layout puts it at ``cd[0]`` and the docs called it ``seed``; later layouts
    put it near the end, where the earlier note called it ``event_ts`` because
    the number often looks like a 2020 Unix timestamp.  It is not a time: the
    28 saved builds (2026-10-24) all carry a value in 1.41e9..2.13e9
    (e.g. 0x7E62A880 = 2120394880 == year 2037).  It is stable across a
    page's calls and changes only when the build changes, while real
    timestamps change on every call.

    The served source has exactly one candidate decimal literal; require it to
    be reachable VM operand too (guards against a numeric string).  The
    operand scan alone is ambiguous: 1000000000 is a common VM constant (ftt
    loads it twice and as a hex literal, so the source regex does not see it).
    """
    vals = {}
    for m in BIG_LIT.finditer(src):
        v = int(m.group(1))
        if 1_000_000_000 <= v <= 0xFFFFFFFF:
            vals[v] = vals.get(v, 0) + 1
    vals.pop(DELTA, None)
    if len(vals) != 1:
        return None
    v = next(iter(vals))
    if seen is not None and v not in big_operands(seen):
        return None
    return v


def find_event_ts(v):
    """Legacy profile field: the build constant restricted to its old
    `1.5e9..1.7e9` window (it is NOT a timestamp; see ``find_build_const``)."""
    return [v] if v is not None and 1_500_000_000 <= v <= 1_700_000_000 else []


def verify_layout(col, tc, pts, datas, key, cv, split, times=None):
    """Layout-agnostic verification: two consecutive plaintexts give the
    dynamic token positions, every other token must stay byte-identical, and
    re-encryption must reproduce each sample's `data` string.

    ``times`` are the page clocks captured next to each sample; they let a
    timestamp token be found even when both samples landed in one second.
    """
    if len(pts) < 2:
        return None
    # a long event trace splits the events JSON at byte 24; normalize those
    # samples so the ordinary token layout applies, and keep the remainder
    splits = [col.split_events(p) for p in pts]
    norms = [x[0] if x else p for x, p in zip(splits, pts)]
    try:
        lay = col.layout_from_pair(norms[0], norms[1])
        dyn = lay["dynamic"]
        if dyn.get("now_sec") is None and times:
            for j, t in enumerate(lay["tokens"]):
                try:
                    v = int(t.strip())
                except ValueError:
                    continue
                if len(t.strip()) != 10:
                    continue
                if all(abs(v - int(tt)) <= 2 for tt in times):
                    dyn["now_sec"] = j
                    break
        col.refine_layout(lay, norms)
    except Exception:
        return None
    dyn = lay["dynamic"]
    if dyn["counter"] is None:
        return None                       # no call counter identified
    pads = {int(j) for j in (dyn.get("pads") or {})}
    static = [j for j in range(len(lay["tokens"]))
              if j not in dyn["positions"] and j not in pads]

    def insert_token(parts, idx):
        """Token that ends exactly at the event-remainder insertion point."""
        off = len(parts["prefix"])
        for j, t in enumerate(parts["tokens"]):
            if off + len(t) == idx:
                return j
            off += len(t) + 1
        return None
    for i, p in enumerate(norms):
        parts = col.payload_parts(p)
        if len(parts["tokens"]) != len(lay["tokens"]):
            return None
        if any(parts["tokens"][j] != lay["tokens"][j] for j in static):
            return None
        v = col.values_at(lay, p)
        # the event-trace prefix is written at call time and may differ
        # between samples, so each sample rebuilds with its own prefix
        try:
            if splits[i]:
                # payload_parts' prefix includes the '{"cd":[' marker; the
                # events string is just the 24-byte header slot + the remainder
                events = parts["prefix"][:-len('{"cd":[')] + splits[i][2]
                rb = col.build_from_layout(
                    lay, v.get("now_sec"), v.get("counter"),
                    events=events,
                    insert_after_token=insert_token(parts, splits[i][1]))
            else:
                rb = col.build_from_layout(
                    lay, v.get("now_sec"), v.get("counter"),
                    prefix=parts["prefix"])
        except Exception:
            return None            # candidate cannot express this sample
        if rb != pts[i] or tc.get_data(rb, key, cv, split) != datas[i]:
            return None
    if any(splits):
        lay["events_split_at"] = 24
        lay["events_insert_after_pad"] = True
    return lay


def find_cipher(seen):
    """The real cipher body contains the sum constant and has upvalues."""
    hits = []
    for pc in sorted(seen):
        op, ops, end, pairs = seen[pc]
        if op != dk.CLOSURE or not pairs:
            continue
        f = ops[0]
        body = [p for p in seen if f <= p < f + 500]
        if any(seen[p][0] == PUSH and seen[p][1] == [SUM_CONST] for p in body):
            hits.append((pc, f, tuple(pairs)))
    return hits


# --------------------------------------------------------------- decryption
def decrypt_raw(ct, key, case):
    import tdc_crypto as tc
    out = bytearray()
    for i in range(0, len(ct) - len(ct) % 8, 8):
        w0 = ct[i] | (ct[i + 1] << 8) | (ct[i + 2] << 16) | (ct[i + 3] << 24)
        w1 = ct[i + 4] | (ct[i + 5] << 8) | (ct[i + 6] << 16) | (ct[i + 7] << 24)
        v0, v1 = tc._block_decrypt(w0, w1, key, case)
        out += tc._w2b(v0) + tc._w2b(v1)
    return bytes(out)


def unrotate(raw, split):
    k = split - 24
    return raw[k:split] + raw[0:k] + raw[split:]


def plausible(pt):
    if not pt.startswith(b"[["):
        return False
    if b'{"cd":' not in pt[:80]:
        return False
    if b'"sd":' not in pt:
        return False
    printable = sum(1 for b in pt if 32 <= b < 127 or b in (9, 10, 13))
    return printable >= len(pt) * 0.9


def live_sample():
    from fit_cur3 import evaluate
    return evaluate("(function(){var d=TDC.getData();"
                    "return {d:d,now:Math.floor(Date.now()/1000)}})()")


# --------------------------------------------------------------------- main
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("name", nargs="?", default="live")
    ap.add_argument("--src", help="use this source file instead of fetching")
    ap.add_argument("--fresh", action="store_true",
                    help="sample a fresh tab instead of the current page "
                         "(call counter starts at 1, so counter-width "
                         "padding is provable)")
    ap.add_argument("--no-fetch", action="store_true")
    ap.add_argument("--samples", type=int, default=3,
                    help="live TDC.getData() calls to verify (default 3)")
    ap.add_argument("--from-json",
                    help="use TDC.getData() outputs saved in this probe file "
                         "(e.g. collect_env_probe.json) instead of sampling the page")
    args = ap.parse_args()

    meta = {}
    src_path = args.src
    if args.fresh:
        print("[1] opening a fresh tab and sampling it ...")
        import fresh_session
        info = fresh_session.collect(args.name)
        src_path, meta = info["src"], info["meta"]
        args.from_json = info["probe"]
    elif src_path is None:
        src_path = os.path.join(JS, "live_src", "tdc_%s.js" % args.name)
        if not args.no_fetch:
            print("[1] fetching page-loaded tdc.js ...")
            subprocess.check_call([sys.executable, "-I",
                                   os.path.join(HERE, "fetch_live_build.py"),
                                   args.name], cwd=HERE)
        meta_path = os.path.join(JS, "live_src", "tdc_%s.json" % args.name)
        if os.path.exists(meta_path):
            meta = json.load(open(meta_path))
    src = open(src_path, encoding="utf-8", errors="replace").read()

    print("[2] mapping opcodes against", os.path.basename(REF_SRC))
    old = map_opcodes.handlers(REF_SRC)
    live = map_opcodes.handlers(src_path)
    live2old = resolve_map(old, live)
    print("    handlers old=%d live=%d mapped=%d" % (len(old), len(live), len(live2old)))

    print("[3] extracting bytecode")
    bc = extract_bc.decode(extract_bc.find_arg(src))
    seen = dk.walk(bc, live2old)
    bad = sum(1 for v in seen.values() if v[0] is None or v[0] not in NAMES)
    print("    %d bytes, %d reachable instrs, %d unmapped" % (len(bc), len(seen), bad))

    from extract_eks import find_eks
    eks_hits = find_eks(src)
    print("[3b] eks constants:", [(n, len(v)) for n, v in eks_hits])

    arrays = derive_key_arrays(seen)
    print("[4] K candidates:")
    for tag, k in arrays.items():
        print("    pair%s K=%s" % (list(tag), [hex(x) for x in k]))

    hits = find_cipher(seen)
    print("[5] cipher closures:", [(pc, f, list(p)) for pc, f, p in hits])
    case = cinfo = chosen_pc = None
    for pc, f, pairs in hits:
        case, cinfo = derive_case(seen, f)
        if case:
            chosen_pc = pc
            print("    C=%s  (%s)  closure pc=%d" % (case, cinfo, pc))
            break
    if case is None:
        raise SystemExit("static C derivation failed")

    if args.from_json:
        probe = json.load(open(args.from_json, encoding="utf-8"))
        samples = probe["datas"]
        print("[6] samples from %s: %d" % (args.from_json, len(samples)))
    else:
        # At least 12 calls: any 10 consecutive call indices include one
        # that carries an extra digit, which is what reveals the counter
        # width padding.  The first gap crosses a second boundary so the
        # call timestamp (now_sec) also shows up as a token diff.
        n = max(args.samples, 12)
        print("[6] sampling live TDC.getData() x%d" % n)
        samples = []
        for k in range(n):
            if k == 1:
                time.sleep(1.1)
            samples.append(live_sample())
    got = samples[0]
    raw = base64.b64decode(urllib.parse.unquote(got["d"]))
    print("    data=%d chars raw=%d bytes" % (len(got["d"]), len(raw)))

    nz = [i for i, v in enumerate(case) if v]
    swapped = list(case)
    if len(nz) == 2:
        swapped[nz[0]], swapped[nz[1]] = case[nz[1]], case[nz[0]]
    tried = []
    for tag, key in arrays.items():
        for cname, cv in (("static", case), ("swapped", swapped)):
            for split in range(32, len(raw) + 1, 8):
                pt = decrypt_raw(unrotate(raw, split), key, cv)
                if plausible(pt):
                    # keep the key with its candidate: arrays has one key per
                    # upvalue pair, and the loop variable below must not leak
                    tried.append((tag, key, cname, cv, split, pt))
    if not tried:
        raise SystemExit("no candidate decrypted the live sample")

    print("[7] verification")
    import tdc_collect as col

    def _split_of(t):
        try:
            return col.split_from_plaintext(t[5])
        except Exception:
            return -1
    # prefer candidates whose brute-forced boundary matches the payload layout
    tried.sort(key=lambda t: t[4] != _split_of(t))

    import tdc_crypto as tc
    datas = [g["d"] for g in samples]
    times = [g.get("now") if g.get("now") is not None else g.get("after")
             for g in samples]
    if any(t is None for t in times):
        times = None
    for tag, key, cname, cv, split, pt in tried:
        line = "    pair%s C=%s split=%d len=%d" % (list(tag), cname, split, len(pt))
        split_pt = None          # only meaningful for the known cur3 template
        pts = [pt]
        for g in samples[1:]:
            raw2 = base64.b64decode(urllib.parse.unquote(g["d"]))
            pts.append(decrypt_raw(unrotate(raw2, split), key, cv))

        # ---- (a) the template builder knows this plaintext layout
        env, source, extra, env_drift, layout = None, None, 0, [], None
        known = False
        try:
            env0, now0, cnt0, _fields = col.parse_v3(pt)
            try:
                split_pt = col.split_from_plaintext(pt)
                line += " split(plaintext)=%d" % split_pt
            except Exception:
                pass
            ok = col.build_collect_v3(now0, cnt0) == pt
            source = "V3_ENV"
            if not ok:
                ok = col.build_collect_v3(now0, cnt0, env0) == pt
                env, source = env0, "extracted"
            known = ok
            if known:
                for g, pt2 in zip(samples[1:], pts[1:]):
                    try:
                        env2, now2, cnt2, _ = col.parse_v3(pt2)
                    except Exception:
                        continue
                    for k in ("location", "ua", "canvas_png", "screen_geom",
                              "webgl_renderer"):
                        if env2[k] != env0[k]:
                            env_drift.append(k)
                    rb2 = col.build_collect_v3(now2, cnt2, env)
                    if rb2 == pt2 and tc.get_data(rb2, key, cv, split) == g["d"]:
                        extra += 1
        except Exception as e:
            line += " known-layout-failed(%s)" % str(e)[:60]

        # ---- (b) unknown layout: tokens learned from two consecutive calls
        if not known:
            layout = verify_layout(col, tc, pts, datas, key, cv, split,
                                   times=times)
            if layout is not None:
                known, source = True, "layout"
                extra = len(pts) - 1

        print(line, "builder=%s(%s)" % (known, source or "-"),
              "extras=%d/%d" % (extra, len(pts) - 1),
              ("env-drift=%s" % sorted(set(env_drift))) if env_drift else "")
        if not known:
            continue

        bconst = find_build_const(src, seen)
        if layout and bconst is not None:
            toks = [t.strip() for t in (layout.get("tokens") or [])]
            if str(bconst) not in toks:
                print("    WARNING: build constant %d not in decrypted layout"
                      % bconst)
        prof = {
            "name": args.name,
            "sha256_16": (meta.get("sha256_16")
                          or hashlib.sha256(src.encode()).hexdigest()[:16]),
            "url": meta.get("url"),
            "key": [int(x) for x in key],
            "case": cv,
            "split": split,
            "split_from_plaintext": split_pt,
            "cipher_pc": chosen_pc,
            "kvariant": list(tag),
            "c_info": cinfo,
            "env_source": source,
            "env": env,
            "layout": layout,
            "build_const": bconst,
            "build_const_hex": ("0x%X" % bconst) if bconst is not None else None,
            "event_ts_static": find_event_ts(bconst),  # legacy subset of the above
            "eks_global": eks_hits[0][0] if eks_hits else None,
            "eks": eks_hits[0][1] if eks_hits else None,
            "samples_verified": 1 + extra,
            "verified": True,
        }
        out = os.path.join(JS, "live_src", "profile_%s.json" % args.name)
        json.dump(prof, open(out, "w"), indent=1)
        print("    PROFILE written:", out)
        print("    tdc_crypto.PROFILES[%r] = {key: %s, case: %s, split: %d}" % (
            args.name, [int(x) for x in key], cv, split))
        return

    # nothing verified: keep the evidence so the mismatch can be diffed later
    # (the page may also have swapped builds between fetch and sampling)
    fail = {
        "name": args.name,
        "sha256_16": meta.get("sha256_16"),
        "src": src_path,
        "datas": [g["d"] for g in samples],
        "times": [g.get("now") for g in samples],
        "candidates": [{"tag": list(tag), "key": [int(x) for x in key],
                        "C": cname, "split": split, "len": len(pt),
                        "plain": pt.decode("latin-1")}
                       for tag, key, cname, cv, split, pt in tried[:12]],
    }
    out = os.path.join(HERE, "derive_fail_%s.json" % args.name)
    json.dump(fail, open(out, "w"), indent=1)
    print("    failure evidence:", out)
    raise SystemExit("decrypted but the local builder did not reproduce the sample")


if __name__ == "__main__":
    main()
