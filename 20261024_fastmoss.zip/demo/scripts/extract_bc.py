# -*- coding: utf-8 -*-
"""Extract a tdc.js (deobfuscated) Chaos-VM bytecode array.

The VM is entered as

    __TENCENT_CHAOS_VM(0, function (B) {
        var Q = B[0], F = B[1], U = [], A = X(Q), W = F.shift(), E = F.shift(), k = 0;
        function w(){ for (; k === W; ) U.push(E), k++, W = F.shift(), E = F.shift(); }
        for (var I = 0; I < A.length; I++) { var V = A.charAt(I).charCodeAt(0); w(); U.push(V), k++; }
        return w(), U;
    }(["<base64>", [<skip,value,...>]]))

i.e. base64 -> byte string, then run-length re-insertion of the (position,
value) pairs.  Usage:  python extract_bc.py ../js/tdc_live_dec.js ../js/bytecode_live.json
"""
import base64
import json
import sys


def find_arg(s):
    import re
    m = re.search(r"__TENCENT_CHAOS_VM\(0,function\(\w+\)\{", s)
    if not m:
        raise SystemExit("VM entry not found")
    j = s.find("}(", m.end())
    if j < 0:
        raise SystemExit("payload not found")
    start = j + 1
    # balanced scan of the array literal, string aware
    depth = 0
    instr = None
    esc = False
    k = start
    while k < len(s):
        ch = s[k]
        if instr:
            if esc:
                esc = False
            elif ch == "\\":
                esc = True
            elif ch == instr:
                instr = None
        else:
            if ch in "\"'":
                instr = ch
            elif ch == "[":
                depth += 1
            elif ch == "]":
                depth -= 1
                if depth == 0:
                    return s[start:k + 1]
        k += 1
    raise SystemExit("unbalanced")


def decode(arg):
    # arg = ["<b64>",[ints]]
    # parse manually: first string literal, then the numbers array
    q = arg.find('"')
    q2 = arg.find('"', q + 1)
    b64 = arg[q + 1:q2]
    n0 = arg.find("[", q2)
    depth = 1
    n1 = n0 + 1
    while n1 < len(arg) and depth:
        if arg[n1] == "[":
            depth += 1
        elif arg[n1] == "]":
            depth -= 1
        n1 += 1
    n1 -= 1                      # index of the matching close bracket
    # values may be written as 1e9 etc.
    pairs = [int(float(x)) for x in arg[n0 + 1:n1].replace("\n", "").split(",") if x.strip()]
    data = base64.b64decode(b64)
    chars = [c for c in data]          # 0..255
    out = []
    it = iter(pairs)
    W = next(it, None)
    E = next(it, None)
    k = 0
    for v in chars:
        while k == W:
            out.append(E)
            k += 1
            W = next(it, None)
            E = next(it, None)
        out.append(v)
        k += 1
    while k == W:
        out.append(E)
        k += 1
        W = next(it, None)
        E = next(it, None)
    return out


def main():
    src = sys.argv[1] if len(sys.argv) > 1 else "../js/tdc_live_dec.js"
    dst = sys.argv[2] if len(sys.argv) > 2 else "../js/bytecode_live.json"
    s = open(src, encoding="utf-8", errors="replace").read()
    arg = find_arg(s)
    bc = decode(arg)
    json.dump(bc, open(dst, "w"))
    print("bytecode len", len(bc), "->", dst)
    print("head", bc[:40])


if __name__ == "__main__":
    main()
