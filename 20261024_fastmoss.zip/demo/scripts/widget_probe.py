# -*- coding: utf-8 -*-
"""Read-only probe of the demo page's captcha widget DOM (fresh tab).

Opens a private tab, clicks 立即体验, and dumps the rects/classes of the
elements that make up the slider widget.  It never drags and never submits
anything, so no verify request is produced.

Usage: python widget_probe.py
"""
import json
import os
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import instrument_eks_init as I  # noqa: E402

JS = r"""
(function(){
  function info(el){
    var r = el.getBoundingClientRect();
    return {tag: el.tagName, cls: (el.className||'').toString().slice(0,90),
            id: el.id||'', x: Math.round(r.x), y: Math.round(r.y),
            w: Math.round(r.width), h: Math.round(r.height),
            txt: (el.textContent||'').trim().slice(0,30)};
  }
  var out = {dpr: window.devicePixelRatio, iw: innerWidth, ih: innerHeight,
             scrollY: scrollY, url: location.href, list: []};
  var all = document.querySelectorAll('div,span,img,button,a');
  for (var i = 0; i < all.length; i++){
    var el = all[i];
    var c = (el.className||'').toString();
    if (/slider|captcha|drag|puzzle|jigsaw|verify|tcaptcha/i.test(c) ||
        /slider|captcha|drag/i.test(el.id||'')){
      var o = info(el);
      if (o.w > 0 && o.h > 0) out.list.push(o);
    }
  }
  out.n = out.list.length;
  return JSON.stringify(out);
})()
"""


def main():
    t = I.new_target()
    tid = t["id"]
    print("fresh target", tid)
    c = I.CDP(t["webSocketDebuggerUrl"])
    try:
        c.call("Runtime.enable")
        c.call("Page.enable")
        c.call("Network.enable")
        c.call("Page.navigate", url=I.URL)
        for _ in range(40):
            time.sleep(0.5)
            if c.ev("document.readyState", await_promise=False) == "complete":
                break
        print("click:", c.ev(
            "(function(){var b=[...document.querySelectorAll('a.tpm-btn')]"
            ".filter(function(e){return e.textContent.trim()==='立即体验';})[0];"
            "if(b){b.click();return 1}return 0})()", await_promise=False))
        for i in range(30):
            time.sleep(0.5)
            n = c.ev("document.querySelectorAll('.tencent-captcha-dy__slider-block').length",
                     await_promise=False)
            if n:
                break
        raw = c.ev(JS, await_promise=False)
        d = json.loads(raw)
        print("dpr", d["dpr"], "viewport", d["iw"], d["ih"], "scrollY",
              d["scrollY"])
        print("url", d["url"])
        for e in d["list"]:
            print("%-6s %-30s %-14s x=%4d y=%4d w=%4d h=%4d  %s" % (
                e["tag"], e["cls"][:30], e["id"][:14], e["x"], e["y"],
                e["w"], e["h"], e["txt"]))
        json.dump(d, open(os.path.join(HERE, "widget_probe.json"), "w"),
                  indent=1, ensure_ascii=False)
    finally:
        try:
            c.ws.close()
        except Exception:
            pass
        I.close_target(tid)


if __name__ == "__main__":
    main()
