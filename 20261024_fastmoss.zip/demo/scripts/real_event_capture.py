# -*- coding: utf-8 -*-
"""Capture a REAL event trace: the widget's own collect after a trusted drag.

Why: our generator writes [[dx,dy,dt],...] triples (~290 chars for a 30-point
drag) while a real widget drag adds ~630 chars to the plaintext.  To stop
guessing, this probe opens a private tab, records baseline collects, derives
the session's build from the tdc.js the tab actually loaded, then drags the
slider with trusted CDP mouse events and INTERCEPTS + ABORTS the widget's
verify request.  Nothing reaches the server, so no captcha attempt is
consumed.  All collects are decrypted offline and the exact event JSON is
saved for comparison.

Ordering matters: the widget closes itself if it is left idle too long, so the
drag happens FIRST and the (slow) build derivation runs afterwards, offline.

Usage: python scripts/real_event_capture.py
Writes scripts/real_event_capture.json
"""
import json
import os
import sys
import time
import urllib.parse

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, ROOT)
sys.path.insert(0, HERE)

import hashlib                                          # noqa: E402

import solve_flow as S                                  # noqa: E402
import tdc_collect                                      # noqa: E402

OUT = os.path.join(HERE, "real_event_capture.json")

GEO = r"""
(function(){
  function rect(el){ if(!el) return null;
    var r=el.getBoundingClientRect(); var cs=getComputedStyle(el);
    return {rect:[r.x,r.y,r.width,r.height], left:cs.left, top:cs.top,
            w:cs.width, h:cs.height, style:(el.getAttribute('style')||''),
            display:cs.display, visibility:cs.visibility, opacity:cs.opacity}; }
  var ws = document.querySelectorAll('.tencent-captcha-dy__warp');
  var best = null, bestArea = -1;
  for (var i = 0; i < ws.length; i++){
    var b = ws[i].getBoundingClientRect();
    var cs = getComputedStyle(ws[i]);
    if (b.width < 10 || b.height < 10 || cs.visibility === 'hidden') continue;
    if (b.right < 0 || b.bottom < 0 || b.left > innerWidth || b.top > innerHeight) continue;
    var a = b.width * b.height;
    if (a > bestArea){ bestArea = a; best = ws[i]; }
  }
  function pick(sel){ return best ? best.querySelector(sel) : null; }
  return {n_warps: ws.length,
          area: rect(pick('.tencent-captcha-dy__image-area')),
          bg:   rect(pick('.tencent-captcha-dy__verify-bg')),
          fg:   rect(pick('.tencent-captcha-dy__fg-item')),
          block:rect(pick('.tencent-captcha-dy__slider-block')),
          opera:rect(pick('.tencent-captcha-dy__opera-area')),
          iw: innerWidth, ih: innerHeight, dpr: devicePixelRatio};
})()
"""


def events_of(collect, prof):
    """Decrypt a collect and pull the raw event JSON out of the plaintext."""
    pt = S.decode_data(collect, prof)
    split = tdc_collect.split_events(pt)
    if split is None:
        return pt, None, None
    _norm, _idx, rem = split
    s = pt.decode("latin-1").rstrip("\x00")
    ev_padded = s[:24] + rem
    ev = ev_padded.rstrip(" ")
    try:
        parsed = json.loads(ev)
    except ValueError as e:
        parsed = {"__parse_error": str(e)}
    return pt, ev_padded, parsed


def main():
    S.load_profiles()
    t = S.new_target()
    tid = t["id"]
    print("fresh target", tid)
    c = S.CDP(t["webSocketDebuggerUrl"])
    result = {}
    try:
        # a background tab makes the widget park itself off-screen after a
        # few seconds (rect x ~= -10180); keep the tab foregrounded
        c.call("Page.bringToFront")
        if not S.open_widget(c):
            raise SystemExit("TDC did not load")
        cap = S.capture_session(c)
        data = cap["pre"]["data"]
        sess = cap["pre"].get("sess") or data.get("sess") or ""
        print("sess=%d tdc_src=%d bytes" % (len(sess), len(cap["tdc_src"])))
        # ---- geometry + baseline collect (both fast) --------------------
        geo = c.ev(GEO, await_promise=False)
        if geo and geo.get("block") and geo["block"]["rect"][0] > 0:
            x0 = geo["block"]["rect"][0] + geo["block"]["rect"][2] / 2.0
            y0 = geo["block"]["rect"][1] + geo["block"]["rect"][3] / 2.0
        else:
            # the widget parks itself off-screen when the tab loses focus;
            # TDC still records document-level pointer events, so a drag at
            # these coordinates produces a genuine trace either way
            print("widget not on screen; using fallback drag coordinates")
            x0, y0 = 500.0, 450.0
        base = c.ev("(function(){return {d:TDC.getData(true),"
                    "now:Math.floor(Date.now()/1000)}})()", await_promise=False)
        print("baseline: collect=%d decoded=%d" % (
            len(base["d"]), len(urllib.parse.unquote(base["d"]))))

        # ---- drag -------------------------------------------------------
        # No solve needed: the trace only depends on the pointer events TDC
        # records, not on the answer.  Interception is on so that if the
        # widget does fire its verify, the request is aborted unsent.
        c.call("Fetch.enable", patterns=[
            {"urlPattern": "*cap_union_new_verify*", "requestStage": "Request"}])

        d_css = 120.0

        def mouse(typ, x, y, buttons=0, click_count=0):
            c.call("Input.dispatchMouseEvent", type=typ, x=x, y=y,
                   button="left" if buttons else "none", buttons=buttons,
                   clickCount=click_count, pointerType="mouse")

        mouse("mouseMoved", x0 - 30, y0)
        time.sleep(0.09)
        mouse("mouseMoved", x0, y0)
        time.sleep(0.06)
        mouse("mousePressed", x0, y0, buttons=1, click_count=1)
        steps = 34
        t0 = time.time()
        for k in range(1, steps + 1):
            p = k / float(steps)
            e = 1 - (1 - p) ** 3
            mouse("mouseMoved", x0 + d_css * e,
                  y0 + (0.7 if k % 3 == 0 else 0.0), buttons=1)
            time.sleep(0.03)
        time.sleep(0.12)
        mouse("mouseReleased", x0 + d_css, y0, buttons=0, click_count=1)
        print("drag finished in %.2fs" % (time.time() - t0))

        paused = None
        deadline = time.time() + 10
        while time.time() < deadline:
            S.pump(c, 0.2)
            for ev in c.events:
                if ev.get("method") == "Fetch.requestPaused":
                    paused = ev["params"]
                    break
            if paused:
                break
        fields = {}
        collect = ""
        if not paused:
            print("no verify request fired (widget likely parked); "
                  "using our own TDC.getData() instead")
        else:
            fields = {k: v[0] for k, v in urllib.parse.parse_qs(
                paused["request"].get("postData") or "",
                keep_blank_values=True).items()}
            collect = fields.get("collect", "")
            print("widget verify intercepted: body=%d fields=%s" % (
                len(paused["request"].get("postData") or ""),
                {k: len(v) for k, v in fields.items()}))

        # read our own getData at the same moment, then abort immediately
        post = c.ev("(function(){return {d:TDC.getData(true),"
                    "now:Math.floor(Date.now()/1000)}})()",
                    await_promise=False)
        if paused:
            c.call("Fetch.failRequest", requestId=paused["requestId"],
                   errorReason="Aborted")
            print("verify request aborted (nothing sent)")

        # ---- derive this session's build offline -----------------------
        samples = S.take_samples(c, 2)
        sha = hashlib.sha256(cap["tdc_src"].encode()).hexdigest()[:16]
        print("build sha256_16", sha)
        prof = S.P.get(sha)
        if prof is None:
            name = S.derive_profile(sha, cap["tdc_src"], samples)
            print("derived profile:", name)
            prof = S.P.get(sha)
        if prof is None:
            raise SystemExit("build derivation failed; cannot decrypt")

        b_pt, b_ev, b_parsed = events_of(base["d"], prof)
        print("baseline: plaintext=%d events=%s" % (
            len(b_pt), "none" if b_ev is None else "%d chars" % len(b_ev)))
        print("baseline events raw:", (b_ev or "")[:800])

        w_pt, w_ev, w_parsed = events_of(collect, prof) if collect else \
            (b"", None, None)
        if collect:
            print("widget: collect=%d decoded=%d plaintext=%d" % (
                len(collect), len(urllib.parse.unquote(collect)), len(w_pt)))
            if w_ev is not None:
                print("widget events: %d chars, %d entries" % (
                    len(w_ev),
                    len(w_parsed) if isinstance(w_parsed, list) else -1))
                print("widget events raw:", w_ev[:1500])
        p_pt, p_ev, p_parsed = events_of(post["d"], prof)
        print("getData after drag: collect=%d plaintext=%d events=%s" % (
            len(post["d"]), len(p_pt),
            "none" if p_ev is None else "%d chars" % len(p_ev)))
        if p_ev:
            print("getData events raw:", p_ev[:1500])

        result.update({
            "paused": bool(paused), "sha": sha, "profile": prof["name"],
            "baseline": {"collect_len": len(base["d"]),
                         "plaintext": b_pt.decode("latin-1", "replace"),
                         "events": b_ev, "parsed": b_parsed},
            "widget": {"collect_len": len(collect),
                       "plaintext": w_pt.decode("latin-1", "replace"),
                       "events": w_ev, "parsed": w_parsed,
                       "tlg": fields.get("tlg"), "ans": fields.get("ans"),
                       "sess_matches": fields.get("sess") == sess},
            "getdata": {"collect_len": len(post["d"]),
                        "plaintext": p_pt.decode("latin-1", "replace"),
                        "events": p_ev, "parsed": p_parsed,
                        "same_as_widget": bool(collect) and post["d"] == collect},
            "drag_css": d_css,
        })
        json.dump(result, open(OUT, "w"), indent=1)
        print("wrote", OUT)
    finally:
        try:
            c.ws.close()
        except Exception:
            pass
        S.close_target(tid)


if __name__ == "__main__":
    main()
