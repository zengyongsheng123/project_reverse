# -*- coding: utf-8 -*-
"""在 Node 侧逐个「改一个环境值」出 collect，看哪一项会影响 mystery 四元组。

四元组 = 同一 build 里 node 和浏览器值不同的那四个 token（浏览器 1007/0/0/0，
node 0/22/3/40 那种）。这里只跑本地 Node，不发任何网络请求。

用法：python env_sweep.py <tdc.js 路径> [--idx 27,28,29,33]
"""
import json
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import build_diff as B

NODE = "node"
SWEEP = os.path.join(HERE, "node_tdc", "sweep.js")


def run(js, sets=None):
    args = [NODE, SWEEP, js, "--mode", "read" if sets is None else "probe"]
    if sets is not None:
        args += ["--set", json.dumps(sets)]
    p = subprocess.run(args, capture_output=True, text=True, encoding="utf-8",
                       errors="replace")
    try:
        return json.loads(p.stdout.strip().splitlines()[-1])
    except Exception:
        return {"ok": False, "err": (p.stdout or "")[-300:] + (p.stderr or "")[-300:]}


def toks(js, collect):
    pt, _ = B.decrypt(js, collect, "node")
    return [x.strip() for x in B.tokenize(pt)]


def main():
    js = sys.argv[1]
    idx = [int(x) for x in (sys.argv[sys.argv.index("--idx") + 1].split(",")
                            if "--idx" in sys.argv else ["27", "28", "29", "33"])]
    base = run(js)
    if not base.get("ok"):
        print("基线失败:", base)
        return 1
    bt = toks(js, base["d"])
    print("基线四元组:", [(i, bt[i]) for i in idx], "token 数", len(bt))

    reads = base.get("reads") or []
    cands = []
    for p in reads:
        if p.endswith((".addEventListener", ".removeEventListener", ".setInterval",
                       ".getItem", ".setItem", ".clear", ".key", ".removeItem",
                       ".createElement", ".appendChild", ".removeChild", ".btoa",
                       ".document", ".window", ".location", ".navigator",
                       ".screen", ".performance", ".localStorage", ".head",
                       ".documentElement", ".body", ".getCookie", ".href")):
            continue
        cands.append(p)
    # 再补几个嵌套值（插件/媒体查询/样式）
    cands += ["navigator.plugins.length", "navigator.plugins.0",
              "navigator.webdriver", "navigator.hardwareConcurrency",
              "navigator.cookieEnabled", "screen.orientation.type",
              "screen.orientation.angle"]

    for path in cands:
        cand_vals = [777001]
        for v in cand_vals:
            r = run(js, {path: v})
            if not r.get("ok") or not r.get("d"):
                print("%-40s 跳过（%s）" % (path, (r.get("err") or "空")[:40]))
                continue
            try:
                t = toks(js, r["d"])
            except SystemExit as e:
                print("%-40s 解密失败 %s" % (path, e))
                continue
            diff = [(i, bt[i], t[i] if i < len(t) else "<miss>")
                    for i in idx if i < len(t) and t[i] != bt[i]]
            print("%-40s %s" % (path, diff if diff else "-"))
    return 0


if __name__ == "__main__":
    sys.exit(main())
