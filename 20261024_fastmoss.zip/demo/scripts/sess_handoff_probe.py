# -*- coding: utf-8 -*-
"""决定性实验：浏览器只负责「产生 sess」，其余全走我们自己的链路。

已知（前几轮隔离实验）：
  * 浏览器 sess + 浏览器 collect + 浏览器其余  -> errorCode 0
  * 浏览器 sess + **Node** collect + 浏览器其余 -> errorCode 0（collect 没问题）
  * 我们自己的 sess + 我们的 collect            -> errorCode 12（怎么调都是 12）

我们自己那条 prehandle 请求：参数已逐字段对齐浏览器（fb/lang/subsid/userLanguage），
响应逐字段比对也完全一致（只有 sid/sess 不同），浏览器侧无 cookie、请求头是
我们的超集。所以「sess 的出身」只剩传输层（TLS/HTTP2 指纹）这一个变量。

本实验把 prehandle 交给真 Chrome 发，然后把 sess/tkid/tdc.js 源码/图片/pow_cfg
全部接过来，用纯 Python + Node 走完：
    取图 -> 识别 -> Node 出 collect/eks -> 算 PoW -> 一条 verify
  * 过  -> 我们的链路完全正确，12 的唯一原因就是 sess 出身（prehandle 的传输层）
  * 不过 -> 我们链路里还有错（首疑 ans），跟 sess 无关

浏览器端不拖动、不产生 verify。整脚本只发一条 verify（--dry 只走不发）。
输出 scripts/kcalib/sess_handoff_pre.json、fastmoss_flow_result_handoff.json

用法：python sess_handoff_probe.py [--dry]
"""
import json
import os
import sys
import time
import urllib.parse

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, ROOT)
sys.path.insert(0, HERE)

import fastmoss_flow as F

KD = os.path.join(HERE, "kcalib")


def grab_browser_session():
    """只让浏览器把 prehandle / tdc.js 跑完，拿回 sess/tkid/tdc.js 源码。"""
    hy = F.BrowserHybrid()
    hy._launch()
    t = hy._new_target()
    c = F._CDP(t["webSocketDebuggerUrl"])
    out = {}
    try:
        c.call("Runtime.enable")
        c.call("Page.enable")
        c.call("Network.enable")
        c.call("Debugger.enable")
        c.call("Page.navigate", url=hy.PAGE)
        time.sleep(1.5)
        c.ev(hy.LOAD % F.AID)
        for _ in range(80):
            time.sleep(0.5)
            if c.ev("typeof window.TDC") == "object":
                break
        time.sleep(2.0)
        hy._drain(c)
        resps, reqs = hy._net(c, "cap_union_prehandle")
        if not resps:
            raise RuntimeError("没截到 prehandle 响应")
        pre = hy._jsonp(resps[-1]["body"]) or {}
        tkid = ""
        if reqs:
            q = urllib.parse.parse_qs(
                urllib.parse.urlsplit(reqs[-1]["url"]).query)
            tkid = (q.get("tkid") or [""])[0]
        js, js_url = hy._tdc_source(c)
        out.update({"pre": pre, "tkid": tkid, "tdc_js": js or "",
                    "tdc_js_url": js_url or "",
                    "sess": pre.get("sess") or ""})
    finally:
        try:
            hy._close_target(t["id"])
        except Exception:
            pass
    return out


def main():
    dry = "--dry" in sys.argv
    cap = grab_browser_session()
    if not cap.get("tdc_js"):
        print("没拿到 tdc.js 源码")
        return 1
    pre = cap["pre"]
    data = pre.get("data") or {}
    dsi = data["dyn_show_info"]
    pow_cfg = data["comm_captcha_cfg"]["pow_cfg"]
    fg = [e for e in dsi["fg_elem_list"] if e.get("id") == 1][0]
    init_x, init_y = fg["init_pos"]
    print("接管：sess=%d tkid=%s init_pos=%s tdc.js=%d 字符"
          % (len(cap["sess"]), cap["tkid"], [init_x, init_y],
             len(cap["tdc_js"])))

    # 存留档（tdc.js 单独存，方便离线对拍）
    open(os.path.join(KD, "sess_handoff_tdc.js"), "w",
         encoding="utf-8").write(cap["tdc_js"])
    slim = {k: v for k, v in cap.items() if k != "tdc_js"}
    open(os.path.join(KD, "sess_handoff_pre.json"), "w",
         encoding="utf-8").write(json.dumps(slim, ensure_ascii=False, indent=1))

    s = F.FastMossCaptchaFlow.make_session()
    # 图片：URL 里自带 sess，浏览器也没 cookie
    open(F.BG, "wb").write(F.FastMossCaptchaFlow.get_image(
        s, dsi["bg_elem_cfg"]["img_url"], cap["tkid"]))
    open(F.SP, "wb").write(F.FastMossCaptchaFlow.get_image(
        s, dsi["sprite_url"], cap["tkid"]))
    print("图片：bg=%dB sprite=%dB" % (os.path.getsize(F.BG),
                                     os.path.getsize(F.SP)))

    ans = F.GapRecognizer("zncc").recognize(F.BG, F.SP, dsi)
    print("ans=%s conf=%s" % (ans["data"], ans["hole"].get("confidence")))

    nc = F.NodeCollector(events=False)
    collect, eks = nc.collect(cap["tdc_js"])
    tlg = len(urllib.parse.unquote(collect))
    print("collect=%d tlg=%d eks=%d" % (len(collect), tlg, len(eks or "")))

    pow_answer, pow_ms = F.FastMossCaptchaFlow.solve_pow(pow_cfg)
    ans_json = json.dumps([{"elem_id": 1, "type": "DynAnswerType_POS",
                            "data": ans["data"]}], separators=(",", ":"))
    body = {"collect": collect, "tlg": str(tlg), "eks": eks,
            "sess": cap["sess"], "ans": ans_json, "tkid": cap["tkid"],
            "pow_answer": pow_answer, "pow_calc_time": str(pow_ms)}

    if dry:
        print("DRY：不发包")
        return 0

    print("POST verify（本次运行唯一一条）")
    r = s.post(F.BASE + "/cap_union_new_verify",
               data=F.FastMossCaptchaFlow.encode_form(body),
               headers={"Accept": "application/json, text/javascript, "
                                   "*/*; q=0.01",
                        "Content-Type": "application/x-www-form-urlencoded; "
                                        "charset=UTF-8",
                        "Origin": "null", "Sec-Fetch-Dest": "empty",
                        "Sec-Fetch-Mode": "cors",
                        "Sec-Fetch-Site": "cross-site"}, timeout=20)
    print("HTTP", r.status_code, r.text[:300])
    try:
        js = r.json()
    except Exception:
        js = {}
    err = js.get("errorCode")
    print("errorCode=", err, "ticket_len=", len(js.get("ticket") or ""))
    out = os.path.join(ROOT, "fastmoss_flow_result_handoff.json")
    json.dump({"ans": ans["data"], "tkid": cap["tkid"],
               "sess_len": len(cap["sess"]), "collect_len": len(collect),
               "tlg": tlg, "pow_ms": pow_ms,
               "errorCode": err, "response": r.text[:2000]},
              open(out, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print("->", out)
    return 0 if err == "0" else 2


if __name__ == "__main__":
    sys.exit(main())
