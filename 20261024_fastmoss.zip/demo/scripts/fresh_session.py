# -*- coding: utf-8 -*-
"""Open a FRESH tab, grab the tdc.js build it loaded, and sample
TDC.getData() a dozen times.

Why a fresh tab: the per-page call counter starts at 1 there, so 12 calls
cover 1..12 and therefore cross the 1->2 *digit* boundary (9 -> 10).  That
boundary is what proves the counter-width padding rule
(``width = spaces + digits``); on a long-lived tab the counter can sit
anywhere (e.g. 200+) and 12 calls may never cross a power of ten.

The tab is private to this script (new target, closed at the end); it never
touches the page the user is working in.

Usage (normally through derive_build --fresh):
    python fresh_session.py NAME
Writes js/live_src/tdc_NAME.js/.json and scripts/fresh_probe_NAME.json
"""
import hashlib
import json
import os
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
JS = os.path.join(ROOT, "js")
sys.path.insert(0, HERE)

import instrument_eks_init as I

SAMPLES = 12
SLEEP_BEFORE = 1              # index of the first sample that waits >1 s


def _tdc_source(c):
    """Source of the tdc.js build that window.TDC.getData belongs to."""
    sids = {}
    for e in c.events:
        if e.get("method") == "Debugger.scriptParsed":
            p = e["params"]
            sids[p.get("url") or ""] = p["scriptId"]
    cands = [(u, sid) for u, sid in sids.items() if "tdc.js" in u]
    if not cands:
        return None, None
    picked = None
    try:
        r = c.call("Runtime.evaluate", expression="window.TDC && TDC.getData",
                   returnByValue=False)
        oid = r.get("result", {}).get("objectId")
        if oid:
            props = c.call("Runtime.getProperties", objectId=oid, ownProperties=False)
            for p in props.get("internalProperties", []):
                if p.get("name") == "[[FunctionLocation]]":
                    picked = p.get("value", {}).get("value", {}).get("scriptId")
                    break
    except Exception:
        pass
    by_sid = {sid: u for u, sid in cands}
    if picked in by_sid:
        return by_sid[picked], picked
    url, sid = cands[-1]
    return url, sid


def collect(name):
    """-> {"src", "meta", "probe"} after closing the fresh tab."""
    t = I.new_target()
    tid = t["id"]
    print("    fresh target", tid)
    c = I.CDP(t["webSocketDebuggerUrl"])
    try:
        c.call("Runtime.enable")
        c.call("Page.enable")
        c.call("Debugger.enable")
        c.call("Page.navigate", url=I.URL)
        tdc = "?"
        for _ in range(40):
            time.sleep(0.5)
            tdc = c.ev("typeof window.TDC", await_promise=False)
            if tdc == "object":
                break
        if tdc != "object":
            print("    clicking 立即体验 ...")
            c.ev("(function(){var b=[...document.querySelectorAll('a.tpm-btn')]"
                 ".filter(function(e){return e.textContent.trim()==='立即体验';})[0];"
                 "if(b){b.click();return 1}return 0})()", await_promise=False)
            for _ in range(60):
                time.sleep(0.5)
                tdc = c.ev("typeof window.TDC", await_promise=False)
                if tdc == "object":
                    break
        if tdc != "object":
            raise SystemExit("TDC never appeared in the fresh tab")

        url, sid = _tdc_source(c)
        if sid is None:
            raise SystemExit("no tdc.js script in the fresh tab")
        src = c.call("Debugger.getScriptSource", scriptId=sid).get("scriptSource", "")
        sha = hashlib.sha256(src.encode("utf-8", "surrogatepass")).hexdigest()[:16]
        os.makedirs(os.path.join(JS, "live_src"), exist_ok=True)
        src_path = os.path.join(JS, "live_src", "tdc_%s.js" % name)
        open(src_path, "w", encoding="utf-8").write(src)
        meta = {"url": url, "scriptId": sid, "len": len(src), "sha256_16": sha,
                "saved": src_path, "fresh": True}
        json.dump(meta, open(os.path.join(JS, "live_src", "tdc_%s.json" % name), "w"),
                  indent=1)
        print("    tdc.js %d chars sha %s" % (len(src), sha))

        samples = []
        for k in range(SAMPLES):
            if k == SLEEP_BEFORE:
                time.sleep(1.2)       # make the call timestamp change too
            before = c.ev("Math.floor(Date.now()/1000)", await_promise=False)
            d = c.ev("TDC.getData()", await_promise=False)
            after = c.ev("Math.floor(Date.now()/1000)", await_promise=False)
            samples.append({"d": d, "now": before, "after": after})
            print("    getData #%d chars=%s" % (k + 1, len(d or "")))
    finally:
        try:
            c.ws.close()
        except Exception:
            pass
        I.close_target(tid)

    probe_path = os.path.join(HERE, "fresh_probe_%s.json" % name)
    json.dump({"sha256_16": sha, "src": src_path, "datas": samples},
              open(probe_path, "w"), indent=1)
    print("    wrote", probe_path)
    return {"src": src_path, "meta": meta, "probe": probe_path}


if __name__ == "__main__":
    collect(sys.argv[1] if len(sys.argv) > 1 else "fresh")
