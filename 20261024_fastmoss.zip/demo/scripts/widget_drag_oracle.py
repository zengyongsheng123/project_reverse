# -*- coding: utf-8 -*-
"""Intercept (and never deliver) the widget's own verify request.

Opens a private tab, solves the challenge locally, then drags the slider to the
locally computed position with trusted CDP mouse events.  When the widget
fires `cap_union_new_verify`, the Fetch domain pauses the request; we read its
body (the widget's own `ans`, `collect`, `sess`, `pow_answer`, ...), then abort
it.  Nothing reaches the server, so this consumes no captcha attempt.

What it gives us:
  * the answer value the real client computes for the same puzzle,
  * the exact field set / headers the real client sends,
  * a collect that contains a genuine drag trace (compare with our no-drag one).

Usage: python widget_drag_oracle.py
Writes widget_drag_oracle.json (+ widget_drag_overlay.png)
"""
import base64
import json
import os
import re
import sys
import time
import urllib.parse

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import instrument_eks_init as I                       # noqa: E402
import slider_solver                                  # noqa: E402

OUT = os.path.join(HERE, "widget_drag_oracle.json")


def pump(c, secs):
    end = time.time() + secs
    while time.time() < end:
        c.ev("1", await_promise=False)
        time.sleep(0.1)


def capture(c):
    pre = None
    img = {}
    pre_req = {}
    img_req = {}
    for e in c.events:
        m = e.get("method")
        p = e.get("params", {})
        if m == "Network.requestWillBeSent":
            u = p.get("request", {}).get("url", "")
            if "cap_union_prehandle" in u:
                pre_req[p["requestId"]] = urllib.parse.parse_qs(
                    urllib.parse.urlparse(u).query)
            elif "cap_union_new_getcapbysig" in u:
                img_req[p["requestId"]] = urllib.parse.parse_qs(
                    urllib.parse.urlparse(u).query)
        elif m == "Network.responseReceived":
            u = p.get("response", {}).get("url", "")
            rid = p["requestId"]
            if "cap_union_prehandle" in u:
                pre = rid
            elif "cap_union_new_getcapbysig" in u:
                img[rid] = u
    return pre_req, pre, img_req, img


GEO = r"""
(function(){
  function rect(el, sel){ if(!el) return null;
    var r=el.getBoundingClientRect(); var cs=getComputedStyle(el);
    return {rect:[r.x,r.y,r.width,r.height], left:cs.left, top:cs.top,
            w:cs.width, h:cs.height, style:(el.getAttribute('style')||''),
            display:cs.display, visibility:cs.visibility, opacity:cs.opacity}; }
  // the demo page may keep hidden widgets parked off-screen: pick the one
  // whose warp actually intersects the viewport
  var ws = document.querySelectorAll('.tencent-captcha-dy__warp');
  var best = null, bestArea = -1;
  for (var i = 0; i < ws.length; i++){
    var b = ws[i].getBoundingClientRect();
    var cs = getComputedStyle(ws[i]);
    if (b.width < 10 || b.height < 10 || cs.visibility === 'hidden') continue;
    if (b.right < 0 || b.bottom < 0 || b.left > innerWidth || b.top > innerHeight) continue;
    var a = b.width * b.height;
    if (a > bestArea){ bestArea = a; best = ws[i]; }
  }
  function pick(sel){ return best ? best.querySelector(sel) : null; }
  return {n_warps: ws.length,
          area: rect(pick('.tencent-captcha-dy__image-area')),
          bg:   rect(pick('.tencent-captcha-dy__verify-bg')),
          fg:   rect(pick('.tencent-captcha-dy__fg-item')),
          block:rect(pick('.tencent-captcha-dy__slider-block')),
          opera:rect(pick('.tencent-captcha-dy__opera-area')),
          iw: innerWidth, ih: innerHeight, dpr: devicePixelRatio};
})()
"""


def main():
    t = I.new_target()
    tid = t["id"]
    print("fresh target", tid)
    c = I.CDP(t["webSocketDebuggerUrl"])
    result = {}
    try:
        c.call("Runtime.enable")
        c.call("Page.enable")
        c.call("Network.enable")
        c.call("Page.navigate", url=I.URL)
        for _ in range(40):
            time.sleep(0.5)
            if c.ev("document.readyState", await_promise=False) == "complete":
                break
        c.ev("(function(){var b=[...document.querySelectorAll('a.tpm-btn')]"
             ".filter(function(e){return e.textContent.trim()==='立即体验';})[0];"
             "if(b){b.click();return 1}return 0})()", await_promise=False)

        pre_req, pre_id, img_req, img_ids = {}, None, {}, {}
        bodies = {}
        deadline = time.time() + 40
        while time.time() < deadline:
            pump(c, 0.4)
            pre_req, pre_id, img_req, img_ids = capture(c)
            for rid in ([pre_id] if pre_id else []) + list(img_ids):
                if rid and rid not in bodies:
                    try:
                        bodies[rid] = c.call("Network.getResponseBody",
                                             requestId=rid)
                    except Exception:
                        pass
            if pre_id and len(img_ids) >= 2 and pre_id in bodies \
                    and all(r in bodies for r in img_ids):
                break
        if not pre_id:
            raise SystemExit("prehandle not captured")

        raw = bodies[pre_id]["body"]
        if bodies[pre_id].get("base64Encoded"):
            raw = base64.b64decode(raw).decode("utf-8", "replace")
        m = re.search(r"^[^(]*\((.*)\)\s*;?\s*$", raw.strip(), re.S)
        pre = json.loads(m.group(1) if m else raw)
        data = pre["data"]
        sess = pre.get("sess") or data.get("sess") or ""
        tkid = (pre_req.get(pre_id) or {}).get("tkid", [""])[0]
        dsi = data["dyn_show_info"]
        pow_cfg = data["comm_captcha_cfg"]["pow_cfg"]
        print("sess %d, tkid %s, pow %s" % (len(sess), tkid, pow_cfg["prefix"]))

        bg_path = os.path.join(HERE, "verify_bg.bin")
        sp_path = os.path.join(HERE, "verify_sprite.bin")
        for rid, u in img_ids.items():
            idx = (img_req.get(rid, {}).get("img_index") or ["?"])[0]
            b = bodies[rid]
            blob = (base64.b64decode(b["body"]) if b.get("base64Encoded")
                    else b["body"].encode("latin-1"))
            dst = bg_path if idx == "1" else (sp_path if idx == "0" else None)
            if dst:
                open(dst, "wb").write(blob)
        json.dump({"dsi": dsi, "pow_cfg": pow_cfg,
                   "tdc_path": data["comm_captcha_cfg"].get("tdc_path")},
                  open(os.path.join(HERE, "verify_capture.json"), "w"), indent=1)

        ans = slider_solver.answer_from_session(bg_path, sp_path, dsi)
        print("local ans:", ans["data"], ans["hole"])
        try:
            slider_solver.draw_overlay(bg_path, sp_path, dsi,
                                       os.path.join(HERE, "widget_drag_overlay.png"))
        except Exception as e:
            print("overlay failed:", e)

        # let the opening animation finish: the widget slides/scales in, and a
        # geometry read mid-transition reports off-screen rects
        geo = None
        for _ in range(40):
            time.sleep(0.4)
            g1 = c.ev(GEO, await_promise=False)
            time.sleep(0.4)
            g2 = c.ev(GEO, await_promise=False)
            if g1 and g2 and g1.get("block") and g2.get("block") \
                    and g1["block"]["rect"] == g2["block"]["rect"] \
                    and g1["fg"]["rect"] == g2["fg"]["rect"] \
                    and g2["block"]["rect"][0] > 0:
                geo = g2
                break
        print("geometry:", json.dumps(geo))
        if not geo or not geo.get("block") or not geo.get("area"):
            raise SystemExit("widget geometry missing / unstable")
        area = geo["area"]["rect"]
        block = geo["block"]["rect"]
        fg = geo["fg"]
        print("fg style:", fg["style"][:120])

        from PIL import Image
        bw = Image.open(bg_path).size[0]
        scale = area[2] / bw
        init_x, init_y = [e for e in dsi["fg_elem_list"] if e["id"] == 1][0]["init_pos"]
        fg_design = float(fg["left"].replace("px", "")) / scale
        print("bg width %d, scale %.5f, init_x %d, fg_left_design %.1f, ans_x %d"
              % (bw, scale, init_x, fg_design, ans["x"]))
        if abs(fg_design - init_x) > 3:
            raise SystemExit("piece is not at init_x (still animating?); abort")
        d_css = (ans["x"] - init_x) * scale
        print("drag %.2f css px" % d_css)

        c.call("Fetch.enable", patterns=[
            {"urlPattern": "*cap_union_new_verify*", "requestStage": "Request"}])

        x0 = block[0] + block[2] / 2.0
        y0 = block[1] + block[3] / 2.0
        print("drag from (%.1f, %.1f)" % (x0, y0))

        def mouse(typ, x, y, buttons=0, click_count=0):
            c.call("Input.dispatchMouseEvent", type=typ, x=x, y=y,
                   button="left" if buttons else "none", buttons=buttons,
                   clickCount=click_count, pointerType="mouse")

        mouse("mouseMoved", x0, y0)
        time.sleep(0.08)
        mouse("mousePressed", x0, y0, buttons=1, click_count=1)
        steps = 34
        t0 = time.time()
        for k in range(1, steps + 1):
            p = k / float(steps)
            e = 1 - (1 - p) ** 3
            mouse("mouseMoved", x0 + d_css * e,
                  y0 + (0.7 if k % 3 == 0 else 0.0), buttons=1)
            time.sleep(0.03)
        time.sleep(0.12)
        mouse("mouseReleased", x0 + d_css, y0, buttons=0, click_count=1)
        print("released after %.2fs" % (time.time() - t0))

        paused = None
        deadline = time.time() + 10
        while time.time() < deadline:
            pump(c, 0.2)
            for ev in c.events:
                if ev.get("method") == "Fetch.requestPaused":
                    paused = ev["params"]
                    break
            if paused:
                break
        if not paused:
            print("NO verify request observed")
            result["paused"] = False
            json.dump(result, open(OUT, "w"), indent=1)
            return

        req = paused["request"]
        post = req.get("postData") or ""
        body = urllib.parse.parse_qs(post, keep_blank_values=True)
        print("verify request intercepted, %d header(s), body %d chars"
              % (len(req.get("headers") or {}), len(post)))
        fields = {}
        for k, v in body.items():
            fields[k] = v[0] if v else ""
        print("field lengths:", {k: len(v) for k, v in fields.items()})
        print("widget ans:", fields.get("ans"))
        print("widget tlg:", fields.get("tlg"), " pow_answer:",
              fields.get("pow_answer", "")[:26])
        print("headers:", json.dumps(req.get("headers"), ensure_ascii=False))
        geo2 = c.ev(GEO, await_promise=False)
        print("fg after drag:", geo2["fg"]["style"][:140])
        print("block after drag:", geo2["block"]["style"][:140])

        result = {
            "paused": True,
            "local_ans": ans["data"],
            "widget_ans": fields.get("ans"),
            "widget_sess_matches": fields.get("sess") == sess,
            "widget_fields": {k: (v if len(v) < 60 else "len=%d" % len(v))
                              for k, v in fields.items()},
            "tlg": fields.get("tlg"),
            "pow_answer": fields.get("pow_answer"),
            "headers": req.get("headers"),
            "collect": fields.get("collect"),
            "collect_len": len(fields.get("collect", "")),
            "decoded_len": len(urllib.parse.unquote(fields.get("collect", ""))),
            "sess_len": len(sess),
            "local_hole": ans["hole"],
            "drag_css": d_css,
            "scale": scale,
            "fg_style_after": geo2["fg"]["style"][:400],
            "block_style_after": geo2["block"]["style"][:200],
        }
        json.dump(result, open(OUT, "w"), indent=1)
        c.call("Fetch.failRequest", requestId=paused["requestId"],
               errorReason="Aborted")
        print("request aborted (not sent)")
    finally:
        try:
            c.ws.close()
        except Exception:
            pass
        I.close_target(tid)


if __name__ == "__main__":
    main()
