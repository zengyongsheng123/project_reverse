# -*- coding: utf-8 -*-
"""Derive the opcode-number mapping between two tdc.js builds.

Each build embeds the Chaos-VM handler array in a randomised order, so the
numeric opcodes in the bytecode are permuted per build.  The handler bodies are
structurally identical apart from renamed identifiers, so fingerprinting them
(normalise identifiers, keep operators/constants) yields the permutation.

Usage: python map_opcodes.py ../js/tdc.dec.js ../js/tdc_live_dec.js
"""
import json
import re
import sys

KEYWORDS = {
    "function", "return", "var", "if", "else", "for", "while", "do", "new", "this",
    "typeof", "instanceof", "in", "of", "try", "catch", "finally", "throw", "delete",
    "void", "null", "undefined", "true", "false", "switch", "case", "default", "break",
    "continue", "yield", "await", "class", "extends", "super", "const", "let", "arguments",
}

TOKEN = re.compile(r"\s+|//[^\n]*|/\*.*?\*/|(\d+\.?\d*(?:e[+-]?\d+)?)|([A-Za-z_$][\w$]*)|(.)", re.S)


def split_top(arr):
    parts, depth, cur, instr, esc = [], 0, [], None, False
    for ch in arr[1:-1]:
        if instr:
            cur.append(ch)
            if esc:
                esc = False
            elif ch == "\\":
                esc = True
            elif ch == instr:
                instr = None
        else:
            if ch in "\"'":
                instr = ch
                cur.append(ch)
            elif ch in "([{":
                depth += 1
                cur.append(ch)
            elif ch in ")]}":
                depth -= 1
                cur.append(ch)
            elif ch == "," and depth == 0:
                parts.append("".join(cur))
                cur = []
            else:
                cur.append(ch)
    parts.append("".join(cur))
    return parts


def balanced(s, start):
    depth, instr, esc, i = 0, None, False, start
    while i < len(s):
        ch = s[i]
        if instr:
            if esc:
                esc = False
            elif ch == "\\":
                esc = True
            elif ch == instr:
                instr = None
        else:
            if ch in "\"'":
                instr = ch
            elif ch in "[({":
                depth += 1
            elif ch in "])}":
                depth -= 1
                if depth == 0:
                    return s[start:i + 1]
        i += 1
    raise ValueError("unbalanced")


def handlers(path):
    s = open(path, encoding="utf-8", errors="replace").read()
    m = re.search(r"for\(var (\w+)=\[\s*,?\s*function", s)
    if not m:
        raise SystemExit("handler array not found in " + path)
    arr = balanced(s, s.index("[", m.start()))
    return split_top(arr)


def fingerprint(src):
    out = []
    prev_dot = False
    for m in TOKEN.finditer(src):
        num, ident, other = m.group(1), m.group(2), m.group(3)
        if num is not None:
            out.append(num)
            prev_dot = False
        elif ident is not None:
            if prev_dot or ident in KEYWORDS:
                out.append(ident)
            else:
                out.append("I")
            prev_dot = False
        elif other is not None:
            out.append(other)
            prev_dot = other == "."
    return "".join(out)


def main():
    a_path = sys.argv[1] if len(sys.argv) > 1 else "../js/tdc.dec.js"
    b_path = sys.argv[2] if len(sys.argv) > 2 else "../js/tdc_live_dec.js"
    A = handlers(a_path)
    B = handlers(b_path)
    print("handlers", len(A), len(B))
    fa = [fingerprint(x) for x in A]
    fb = [fingerprint(x) for x in B]
    from collections import defaultdict
    idx_b = defaultdict(list)
    for j, f in enumerate(fb):
        idx_b[f].append(j)
    mapping = {}
    ambiguous = []
    for i, f in enumerate(fa):
        cand = idx_b.get(f, [])
        if len(cand) == 1:
            mapping[i] = cand[0]
        elif len(cand) == 0:
            mapping[i] = None
        else:
            ambiguous.append((i, cand))
            mapping[i] = cand
    missing = [i for i, v in mapping.items() if v is None]
    print("uniquely matched", sum(1 for v in mapping.values() if isinstance(v, int)))
    print("missing", missing)
    print("ambiguous", ambiguous)
    # print fingerprints of unmatched/ambiguous for inspection
    for i in missing:
        print("  old", i, ascii(A[i])[:160])
    for i, cand in ambiguous:
        print("  amb old", i, ascii(A[i])[:120], "->", cand, [ascii(B[j])[:80] for j in cand])
    json.dump({str(k): v for k, v in mapping.items()}, open("../js/opmap.json", "w"), indent=1)
    # also dump handler sources for review
    json.dump({"old": A, "live": B}, open("../js/handlers.json", "w"), indent=1)


if __name__ == "__main__":
    main()
