# -*- coding: utf-8 -*-
"""Read-only: list the scripts/resources the captcha widget loads.

Opens a private tab, opens the demo captcha, and prints resource URLs (plus
inline script sizes) so the widget's own JS can be fetched and searched for
the verify error-code handling.  No drag, no submission.

Usage: python script_probe.py
"""
import json
import os
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import instrument_eks_init as I  # noqa: E402

JS = r"""
(function(){
  var res = performance.getEntriesByType('resource').map(function(e){
    return {n: e.name, t: e.initiatorType, s: e.transferSize};
  });
  var scripts = [].map.call(document.scripts, function(s){
    return {src: s.src || '', len: (s.text||'').length,
            type: s.type || ''};
  });
  var frames = [];
  for (var i=0;i<frames.length;i++){ try { frames.push(frames[i].location.href); } catch(e){ frames.push('x'); } }
  return JSON.stringify({res: res, scripts: scripts, frames: frames,
                         url: location.href});
})()
"""


def main():
    t = I.new_target()
    tid = t["id"]
    c = I.CDP(t["webSocketDebuggerUrl"])
    try:
        c.call("Runtime.enable")
        c.call("Page.enable")
        c.call("Page.navigate", url=I.URL)
        for _ in range(40):
            time.sleep(0.5)
            if c.ev("document.readyState", await_promise=False) == "complete":
                break
        c.ev("(function(){var b=[...document.querySelectorAll('a.tpm-btn')]"
             ".filter(function(e){return e.textContent.trim()==='立即体验';})[0];"
             "if(b){b.click();return 1}return 0})()", await_promise=False)
        for _ in range(20):
            time.sleep(0.5)
            if c.ev("document.querySelectorAll('.tencent-captcha-dy__fg-item').length",
                    await_promise=False):
                break
        time.sleep(1.0)
        d = json.loads(c.ev(JS, await_promise=False))
        print("url", d["url"])
        print("frames", d["frames"])
        print("--- resources (%d)" % len(d["res"]))
        for r in d["res"]:
            print("%-10s %8s %s" % (r["t"], r["s"], r["n"][:150]))
        print("--- inline scripts")
        for s in d["scripts"]:
            if not s["src"]:
                print("inline len=%d type=%s" % (s["len"], s["type"]))
        json.dump(d, open(os.path.join(HERE, "script_probe.json"), "w"),
                  indent=1, ensure_ascii=False)
    finally:
        try:
            c.ws.close()
        except Exception:
            pass
        I.close_target(tid)


if __name__ == "__main__":
    main()
