# -*- coding: utf-8 -*-
"""诊断：背景图里的两个拼图形状，到底哪个是缺口。

只读本地已保存的 bg/sprite，不发任何网络请求。
"""
import json
import os
import sys

import numpy as np
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)


def comps(mask, min_area=200):
    """粗粒度连通域（4 邻域，迭代式）。"""
    h, w = mask.shape
    seen = np.zeros_like(mask, dtype=bool)
    out = []
    ys, xs = np.nonzero(mask)
    for sy, sx in zip(ys, xs):
        if seen[sy, sx]:
            continue
        stack = [(sy, sx)]
        seen[sy, sx] = True
        pts = []
        while stack:
            y, x = stack.pop()
            pts.append((y, x))
            for dy, dx in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                ny, nx = y + dy, x + dx
                if 0 <= ny < h and 0 <= nx < w and mask[ny, nx] \
                        and not seen[ny, nx]:
                    seen[ny, nx] = True
                    stack.append((ny, nx))
        if len(pts) >= min_area:
            a = np.array(pts)
            out.append({"n": len(pts),
                        "y0": int(a[:, 0].min()), "y1": int(a[:, 0].max()),
                        "x0": int(a[:, 1].min()), "x1": int(a[:, 1].max()),
                        "cy": float(a[:, 0].mean()), "cx": float(a[:, 1].mean())})
    out.sort(key=lambda d: -d["n"])
    return out


def main():
    bg = np.array(Image.open(os.path.join(ROOT, "fastmoss_bg.png")).convert("RGB"))
    sp = np.array(Image.open(os.path.join(ROOT, "fastmoss_sprite.png")).convert("RGBA"))
    print("bg", bg.shape, "sprite", sp.shape)

    # 拼图块：sprite_pos [140,490] size 120x120
    sx, sy, w, h = 140, 490, 120, 120
    crop = sp[sy:sy + h, sx:sx + w]
    pm = crop[:, :, 3] > 128
    ys, xs = np.nonzero(pm)
    ox, oy = int(xs.min()), int(ys.min())
    pw, ph = int(xs.max()) - ox + 1, int(ys.max()) - oy + 1
    print("piece mask bbox in crop: ox=%d oy=%d w=%d h=%d area=%d"
          % (ox, oy, pw, ph, pm.sum()))

    # 形状轮廓：按行打印 mask 宽度，看凸起（knob）在哪一侧
    def profile(m):
        rows = [np.nonzero(m[y])[0] for y in range(m.shape[0])]
        return [(y, (int(r.min()), int(r.max())) if len(r) else None)
                for y, r in enumerate(rows)]

    print("piece rows (y, xmin,xmax) 每 6 行:")
    for y, r in profile(pm):
        if y % 6 == 0:
            print("   ", y, r)

    # 背景：白色描边 -> 连通域
    lum = bg.mean(axis=2)
    white = (bg[:, :, 0] > 225) & (bg[:, :, 1] > 225) & (bg[:, :, 2] > 225)
    print("\nwhite pixels:", int(white.sum()))
    cs = comps(white, min_area=120)
    print("white components (top 12):")
    for c in cs[:12]:
        print("   n=%5d x[%3d..%3d] y[%3d..%3d] c=(%.0f,%.0f)"
              % (c["n"], c["x0"], c["x1"], c["y0"], c["y1"], c["cx"], c["cy"]))

    # 暗色（缺口通常被压暗）
    dark = lum < 60
    print("\ndark pixels:", int(dark.sum()))
    ds = comps(dark, min_area=400)
    print("dark components (top 8):")
    for c in ds[:8]:
        print("   n=%5d x[%3d..%3d] y[%3d..%3d]"
              % (c["n"], c["x0"], c["x1"], c["y0"], c["y1"]))

    # 两个候选：分别取窗口，与拼图块做归一化相关性（亮度归一）
    piece_rgb = crop[:, :, :3].astype(np.float32)
    pmask3 = pm
    cands = [("left", 270, 110), ("right", 550, 110)]
    for name, cx, cy in cands:
        for sc in (1.0, 0.9, 0.833, 0.8125):
            bw, bh = int(round(pw * sc)), int(round(ph * sc))
            if cy + bh > bg.shape[0] or cx + bw > bg.shape[1]:
                continue
            win = bg[cy:cy + bh, cx:cx + bw].astype(np.float32)
            m = np.array(Image.fromarray((pmask3 * 255).astype(np.uint8))
                         .resize((bw, bh), Image.NEAREST)) > 128
            pr = np.array(Image.fromarray(piece_rgb.astype(np.uint8))
                          .resize((bw, bh), Image.BILINEAR)).astype(np.float32)
            if m.sum() < 50:
                continue
            a = pr[m]
            b = win[m]
            a = a - a.mean()
            b = b - b.mean()
            den = (np.sqrt((a * a).sum()) * np.sqrt((b * b).sum())) or 1
            corr = float((a * b).sum() / den)
            print("cand %-5s sc=%.4f win=(%d,%d,%d,%d) corr=%.4f"
                  % (name, sc, cx, cy, cx + bw, cy + bh, corr))


if __name__ == "__main__":
    main()
