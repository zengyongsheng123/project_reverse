# -*- coding: utf-8 -*-
"""浏览器侧「改一个东西，看 collect 里**哪些字段**跟着动」。

和 browser_bitmap_probe.py 的区别：那个只盯能力位图（1007），这个把整条明文
按 token 对照，任何变动的下标都打出来。目的是把 Node 侧和浏览器不一致的那两个
数（22 / 40）定位到具体来源 —— 浏览器里它们是 0，那就看看把什么改掉会让 0 变非 0。

一次会话里做完所有探针；每次都 kill -> getData -> 还原。只读，不发 verify。

用法：python browser_field_probe.py
"""
import json
import os
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
sys.path.insert(0, ROOT)

import fastmoss_flow as F
import token_probe as T
import counter_probe as C
import quartet_probe as Q

SETUP = r"""
window.__saved = window.__saved || {};
window.__kill = function(path) {
  try {
    var parts = path.split('.');
    var obj = window;
    for (var i = 0; i < parts.length - 1; i++) { obj = obj[parts[i]]; if (!obj) return 'noobj'; }
    var key = parts[parts.length - 1];
    if (!(key in obj)) return 'absent';
    window.__saved[path] = { had: true, val: obj[key] };
    try { delete obj[key]; } catch (e) { try { obj[key] = undefined; } catch (e2) { return 'ro'; } }
    return ('undefined' === typeof obj[key]) ? 'killed' : 'stuck';
  } catch (e) { return 'err:' + e.message; }
};
window.__revive = function(path) {
  try {
    var rec = window.__saved[path]; if (!rec) return 'none';
    var parts = path.split('.'); var obj = window;
    for (var i = 0; i < parts.length - 1; i++) { obj = obj[parts[i]]; if (!obj) return 'noobj'; }
    obj[parts[parts.length - 1]] = rec.val; return 'ok';
  } catch (e) { return 'err:' + e.message; }
};
window.__set = function(path, expr, literal) {
  try {
    var parts = path.split('.'); var obj = window;
    for (var i = 0; i < parts.length - 1; i++) { obj = obj[parts[i]]; if (!obj) return 'noobj'; }
    var key = parts[parts.length - 1];
    window.__saved['set:' + path] = { had: (key in obj), val: obj[key] };
    try {
      Object.defineProperty(obj, key, { configurable: true, enumerable: true,
        get: function () { return literal; }, set: function () {} });
    } catch (e) { obj[key] = literal; }
    return 'ok';
  } catch (e) { return 'err:' + e.message; }
};
window.__unset = function(path) {
  try {
    var rec = window.__saved['set:' + path]; if (!rec) return 'none';
    var parts = path.split('.'); var obj = window;
    for (var i = 0; i < parts.length - 1; i++) obj = obj[parts[i]];
    var key = parts[parts.length - 1];
    delete obj[key];
    if (rec.had) obj[key] = rec.val;
    return 'ok';
  } catch (e) { return 'err:' + e.message; }
};
"""

# 探针：(标签, 动作 JS, 撤回 JS)
PROBES = [
    ("kill customElements", "__kill('customElements')", "__revive('customElements')"),
    ("kill CSS", "__kill('CSS')", "__revive('CSS')"),
    ("kill matchMedia", "__kill('matchMedia')", "__revive('matchMedia')"),
    ("kill getComputedStyle", "__kill('getComputedStyle')", "__revive('getComputedStyle')"),
    ("kill IntersectionObserver", "__kill('IntersectionObserver')", "__revive('IntersectionObserver')"),
    ("kill MutationObserver", "__kill('MutationObserver')", "__revive('MutationObserver')"),
    ("kill ResizeObserver", "__kill('ResizeObserver')", "__revive('ResizeObserver')"),
    ("kill Worker", "__kill('Worker')", "__revive('Worker')"),
    ("kill WebSocket", "__kill('WebSocket')", "__revive('WebSocket')"),
    ("kill XMLHttpRequest", "__kill('XMLHttpRequest')", "__revive('XMLHttpRequest')"),
    ("kill fetch", "__kill('fetch')", "__revive('fetch')"),
    ("kill localStorage", "__kill('localStorage')", "__revive('localStorage')"),
    ("kill sessionStorage", "__kill('sessionStorage')", "__revive('sessionStorage')"),
    ("kill indexedDB", "__kill('indexedDB')", "__revive('indexedDB')"),
    ("kill performance", "__kill('performance')", "__revive('performance')"),
    ("kill crypto", "__kill('crypto')", "__revive('crypto')"),
    ("kill history", "__kill('history')", "__revive('history')"),
    ("kill Notification", "__kill('Notification')", "__revive('Notification')"),
    ("kill AudioContext", "__kill('AudioContext')", "__revive('AudioContext')"),
    ("kill MediaSource", "__kill('MediaSource')", "__revive('MediaSource')"),
    ("kill RTCPeerConnection", "__kill('RTCPeerConnection')", "__revive('RTCPeerConnection')"),
    ("kill chrome", "__kill('chrome')", "__revive('chrome')"),
    ("kill devicePixelRatio", "__kill('devicePixelRatio')", "__revive('devicePixelRatio')"),
    ("kill visualViewport", "__kill('visualViewport')", "__revive('visualViewport')"),
    ("webdriver=true", "__set('navigator.webdriver', '', true)", "__unset('navigator.webdriver')"),
    ("hardwareConcurrency=2", "__set('navigator.hardwareConcurrency', '', 2)",
     "__unset('navigator.hardwareConcurrency')"),
    ("plugins empty", "__set('navigator.plugins', '', [])", "__unset('navigator.plugins')"),
    ("languages en", "__set('navigator.languages', '', ['en-US', 'en'])",
     "__unset('navigator.languages')"),
    ("platform Linux", "__set('navigator.platform', '', 'Linux x86_64')",
     "__unset('navigator.platform')"),
    ("vendor Apple", "__set('navigator.vendor', '', 'Apple Computer, Inc.')",
     "__unset('navigator.vendor')"),
    ("innerWidth 1280", "__set('innerWidth', '', 1280)", "__unset('innerWidth')"),
    ("screen.width 1366", "__set('screen.width', '', 1366)", "__unset('screen.width')"),
    ("ua HeadlessChrome", "__set('navigator.userAgent', '', navigator.userAgent.replace('Chrome/', 'HeadlessChrome/'))",
     "__unset('navigator.userAgent')"),
    ("isSecureContext true", "__set('isSecureContext', '', true)", "__unset('isSecureContext')"),
]


def main():
    hy = F.BrowserHybrid()
    hy._launch()
    t = hy._new_target()
    c = F._CDP(t["webSocketDebuggerUrl"])
    try:
        for m in ("Runtime.enable", "Page.enable", "Network.enable", "Debugger.enable"):
            c.call(m)
        c.call("Page.navigate", url=hy.PAGE)
        time.sleep(1.5)
        c.ev(hy.LOAD % F.AID)
        for _ in range(80):
            time.sleep(0.5)
            if c.ev("typeof window.TDC") == "object":
                break
        for _ in range(60):
            time.sleep(0.5)
            if c.ev("!!document.querySelector('.tencent-captcha-dy__slider-block')"):
                break
        time.sleep(1.0)
        hy._drain(c)
        js = C.get_tdc_source(c)
        tdc_path = os.path.join(HERE, ".field_tdc.js")
        open(tdc_path, "w", encoding="utf-8").write(js)
        c.ev(SETUP)

        first = c.ev("TDC.getData()")
        prm = T.params(tdc_path, first)

        def toks():
            d = c.ev("TDC.getData()")
            try:
                pt = T.decrypt(d, prm)
            except Exception:
                return None
            return [x[2] for x in Q.tokenize_spans(pt)]

        base = toks()
        if base is None:
            print("基线解不开")
            return 1
        print("基线 %d 个 token" % len(base))
        out = open(os.path.join(HERE, "kcalib", "field_%d.txt" % int(time.time())),
                   "w", encoding="utf-8")

        def log(line):
            print(line)
            out.write(line + "\n")
            out.flush()

        def diff(a, b):
            if b is None or len(a) != len(b):
                return "长度变了（%s -> %s）" % (
                    len(a) if a else "?", len(b) if b else "?")
            d = []
            for i in range(len(a)):
                if a[i] != b[i]:
                    d.append("%d:%s->%s" % (i, a[i][:16], b[i][:16]))
            return "; ".join(d)

        for label, do, undo in PROBES:
            r = c.ev(do)
            t2 = toks()
            c.ev(undo)
            d = diff(base, t2)
            log("%-26s %-8s %s" % (label, str(r)[:8], d if d else "不变"))
        out.close()
        return 0
    finally:
        try:
            c.ws.close()
        except Exception:
            pass
        hy._close_target(t["id"])
        if hy.proc is not None:
            try:
                hy.proc.terminate()
            except Exception:
                pass


if __name__ == "__main__":
    sys.exit(main())
