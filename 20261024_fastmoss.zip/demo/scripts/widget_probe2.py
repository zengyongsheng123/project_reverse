# -*- coding: utf-8 -*-
"""Read-only probe #2: computed styles / inline styles of the captcha widget.

Reads how the piece and slider are positioned (design px vs css px, transforms)
so the drag distance can be mapped correctly.  No drag, no submission.

Usage: python widget_probe2.py
"""
import json
import os
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import instrument_eks_init as I  # noqa: E402

JS = r"""
(function(){
  function pick(sel){ return document.querySelector(sel); }
  function st(el){
    if (!el) return null;
    var cs = getComputedStyle(el);
    var r = el.getBoundingClientRect();
    return {cls: (el.className||'').toString().slice(0,60),
            tag: el.tagName,
            style: (el.getAttribute('style')||'').slice(0,300),
            left: cs.left, top: cs.top, width: cs.width, height: cs.height,
            transform: cs.transform, transformOrigin: cs.transformOrigin,
            position: cs.position, zIndex: cs.zIndex,
            rect: [Math.round(r.x), Math.round(r.y), Math.round(r.width), Math.round(r.height)],
            nw: el.naturalWidth||0, nh: el.naturalHeight||0,
            src: (el.getAttribute('src')||'').slice(0,120)};
  }
  var out = {dpr: devicePixelRatio, iw: innerWidth, ih: innerHeight};
  out.transform = st(pick('.tencent-captcha__transform'));
  out.content   = st(pick('.tencent-captcha-dy__content'));
  out.warp      = st(pick('.tencent-captcha-dy__warp'));
  out.imageArea = st(pick('.tencent-captcha-dy__image-area'));
  out.bgImg     = st(pick('.tencent-captcha-dy__bg-placeholder, .tencent-captcha-dy__bg'));
  out.verifyBg  = st(pick('.tencent-captcha-dy__verify-bg'));
  out.fg        = st(pick('.tencent-captcha-dy__fg-item'));
  out.fgParent  = st(pick('.tencent-captcha-dy__fg-item') ? pick('.tencent-captcha-dy__fg-item').parentNode : null);
  out.opera     = st(pick('.tencent-captcha-dy__opera-area'));
  out.slider    = st(pick('.tencent-captcha-dy__verify-slider'));
  out.block     = st(pick('.tencent-captcha-dy__slider-block'));
  out.imgs = [];
  var ims = document.querySelectorAll('.tencent-captcha-dy__warp img');
  for (var i=0;i<ims.length;i++) out.imgs.push(st(ims[i]));
  out.desc = [];
  var all = document.querySelectorAll('.tencent-captcha-dy__warp *');
  for (var j=0;j<all.length && j<80;j++){
    var e = all[j];
    if (e.children.length === 0 || (e.getAttribute('style')||'').indexOf('translate') >= 0)
      out.desc.push(st(e));
  }
  return JSON.stringify(out);
})()
"""


def main():
    t = I.new_target()
    tid = t["id"]
    c = I.CDP(t["webSocketDebuggerUrl"])
    try:
        c.call("Runtime.enable")
        c.call("Page.enable")
        c.call("Page.navigate", url=I.URL)
        for _ in range(40):
            time.sleep(0.5)
            if c.ev("document.readyState", await_promise=False) == "complete":
                break
        c.ev("(function(){var b=[...document.querySelectorAll('a.tpm-btn')]"
             ".filter(function(e){return e.textContent.trim()==='立即体验';})[0];"
             "if(b){b.click();return 1}return 0})()", await_promise=False)
        for _ in range(30):
            time.sleep(0.5)
            if c.ev("document.querySelectorAll('.tencent-captcha-dy__fg-item').length",
                    await_promise=False):
                break
        d = json.loads(c.ev(JS, await_promise=False))
        json.dump(d, open(os.path.join(HERE, "widget_probe2.json"), "w"),
                  indent=1, ensure_ascii=False)
        for k in ("transform", "content", "warp", "imageArea", "bgImg",
                  "verifyBg", "fg", "fgParent", "opera", "slider", "block"):
            v = d.get(k)
            if not v:
                print(k, None)
                continue
            print("%-9s %-22s rect=%s style=%s" % (k, v["cls"][:22], v["rect"],
                                                  v["style"][:180]))
            print("          pos=%s left=%s top=%s w=%s h=%s tf=%s" % (
                v["position"], v["left"], v["top"], v["width"], v["height"],
                v["transform"][:60]))
        print("--- imgs")
        for v in d["imgs"]:
            print("  %-22s rect=%s nat=%dx%d src=%s" % (v["cls"][:22], v["rect"],
                                                       v["nw"], v["nh"], v["src"][:60]))
        print("--- positioned descendants")
        for v in d["desc"][:40]:
            print("  %-24s rect=%s style=%s" % (v["cls"][:24], v["rect"],
                                                v["style"][:140]))
    finally:
        try:
            c.ws.close()
        except Exception:
            pass
        I.close_target(tid)


if __name__ == "__main__":
    main()
