# -*- coding: utf-8 -*-
"""ONE-shot oracle check: submit a verify request for a captcha session that
this script's own fresh tab created.

What is ours vs the browser's:
  * prehandle (sess / tkid / pow_cfg / images) comes from the fresh tab we open;
  * collect + eks are read from that tab's TDC (their byte-level reproduction is
    already proven by derive_build.py, so reusing them here keeps the oracle
    focused on ans / pow / protocol);
  * ans is computed locally by slider_solver.py from the session images;
  * the drag trajectory fed to TDC.setData is generated locally;
  * pow_answer / pow_calc_time are computed locally; the time is the real
    measured solve time (the widget on this page reports a real 2-digit
    value, e.g. 57 ms, not a simulated band).

Limits (explicit user authorization, 2026-10-24):
  * exactly ONE POST per invocation, no retry loop;
  * only the public demo aid 192962660 on cloud.tencent.com;
  * the tab is private to this script and closed afterwards.

Usage:
    python verify_once.py            # dry run: capture + solve, no POST
    python verify_once.py --yes      # actually POST once
"""
import base64
import hashlib
import json
import os
import random
import re
import sys
import time
import urllib.parse

import requests

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import instrument_eks_init as I                       # noqa: E402
import slider_solver                                  # noqa: E402
from probe import BASE, UA                            # noqa: E402

OUT = os.path.join(HERE, "verify_once_result.json")


def pump(c, secs):
    """Let CDP deliver queued events for a while."""
    end = time.time() + secs
    while time.time() < end:
        c.ev("1", await_promise=False)
        time.sleep(0.15)


def make_trajectory(init_x, init_y, target_x, target_y,
                    duration_ms=1500, n=30):
    """Ease-in-out cubic move from init to the answer, {elapsed_ms: "x,y"}.

    This is the shape TDC.setData expects for a slider interaction (verified
    live with setdata_probe.py: it adds the trace to the collect).  ±1 px
    jitter in the middle segment mirrors human movement.
    """
    pts = {}
    for i in range(n):
        p = i / float(n - 1)
        e = 4 * p ** 3 if p < 0.5 else 1 - ((-2 * p + 2) ** 3) / 2.0
        x = int(init_x + (target_x - init_x) * e)
        y = int(init_y + (target_y - init_y) * e)
        if 0.1 < p < 0.9:
            x += random.choice((-1, 0, 1))
            y += random.choice((-1, 0, 1))
        pts[int(p * duration_ms)] = "%d,%d" % (x, y)
    pts[duration_ms] = "%d,%d" % (target_x, target_y)
    return pts


def capture(c):
    pre = None
    img = {}
    pre_req = {}
    img_req = {}
    bodies = {}
    for e in c.events:
        m = e.get("method")
        p = e.get("params", {})
        if m == "Network.requestWillBeSent":
            u = p.get("request", {}).get("url", "")
            if "cap_union_prehandle" in u:
                pre_req[p["requestId"]] = urllib.parse.parse_qs(
                    urllib.parse.urlparse(u).query)
            elif "cap_union_new_getcapbysig" in u:
                img_req[p["requestId"]] = urllib.parse.parse_qs(
                    urllib.parse.urlparse(u).query)
        elif m == "Network.responseReceived":
            u = p.get("response", {}).get("url", "")
            rid = p["requestId"]
            if "cap_union_prehandle" in u:
                pre = rid
            elif "cap_union_new_getcapbysig" in u:
                img[rid] = u
    return pre_req, pre, img_req, img


def main():
    submit = "--yes" in sys.argv
    t = I.new_target()
    tid = t["id"]
    print("fresh target", tid)
    c = I.CDP(t["webSocketDebuggerUrl"])
    result = {}
    try:
        c.call("Runtime.enable")
        c.call("Page.enable")
        c.call("Network.enable")
        c.call("Page.navigate", url=I.URL)
        for _ in range(40):
            time.sleep(0.5)
            if c.ev("document.readyState", await_promise=False) == "complete":
                break
        c.ev("(function(){var b=[...document.querySelectorAll('a.tpm-btn')]"
             ".filter(function(e){return e.textContent.trim()==='立即体验';})[0];"
             "if(b){b.click();return 1}return 0})()", await_promise=False)

        pre_req, pre_id, img_req, img_ids = {}, None, {}, {}
        deadline = time.time() + 40
        bodies = {}
        while time.time() < deadline:
            pump(c, 0.5)
            pre_req, pre_id, img_req, img_ids = capture(c)
            # fetch bodies as soon as they appear (CDP may evict them)
            for rid in ([pre_id] if pre_id else []) + list(img_ids):
                if rid and rid not in bodies:
                    try:
                        bodies[rid] = c.call("Network.getResponseBody",
                                             requestId=rid)
                    except Exception:
                        pass
            if pre_id and len(img_ids) >= 2 and pre_id in bodies \
                    and all(r in bodies for r in img_ids):
                break
        if not pre_id:
            raise SystemExit("prehandle response not captured")

        raw = bodies[pre_id]["body"]
        if bodies[pre_id].get("base64Encoded"):
            raw = base64.b64decode(raw).decode("utf-8", "replace")
        m = re.search(r"^[^(]*\((.*)\)\s*;?\s*$", raw.strip(), re.S)
        pre = json.loads(m.group(1) if m else raw)
        data = pre["data"]
        sess = pre.get("sess") or data.get("sess") or ""
        if not sess:
            print("prehandle keys:", list(pre), "data keys:", list(data))
            raise SystemExit("sess not found")
        tkid = (pre_req.get(pre_id) or {}).get("tkid", [""])[0]
        if not tkid:
            raise SystemExit("tkid not found in prehandle request url")
        dsi = data["dyn_show_info"]
        pow_cfg = data["comm_captcha_cfg"]["pow_cfg"]
        print("sess %d chars, tkid %s, pow_cfg %s" %
              (len(sess), tkid, pow_cfg))
        print("tdc_path:", data["comm_captcha_cfg"].get("tdc_path"))
        fg1 = [e for e in dsi["fg_elem_list"] if e.get("id") == 1][0]
        print("init_pos", fg1.get("init_pos"), "sprite_pos",
              fg1.get("sprite_pos"), "size_2d", fg1.get("size_2d"))
        json.dump({"dsi": dsi, "pow_cfg": pow_cfg,
                   "tdc_path": data["comm_captcha_cfg"].get("tdc_path")},
                  open(os.path.join(HERE, "verify_capture.json"), "w"), indent=1)

        # images: favicon indices may differ; keep whatever the page fetched
        bg_path = os.path.join(HERE, "verify_bg.bin")
        sp_path = os.path.join(HERE, "verify_sprite.bin")
        for rid, u in img_ids.items():
            q = img_req.get(rid, {})
            idx = (q.get("img_index") or ["?"])[0]
            b = bodies[rid]
            blob = (base64.b64decode(b["body"]) if b.get("base64Encoded")
                    else b["body"].encode("latin-1"))
            dst = bg_path if idx == "1" else (sp_path if idx == "0" else None)
            if dst:
                open(dst, "wb").write(blob)
            print("image img_index=%s -> %s bytes" % (idx, len(blob)))
        for p in (bg_path, sp_path):
            if not os.path.exists(p):
                raise SystemExit("missing image %s" % p)

        for _ in range(40):
            time.sleep(0.3)
            if c.ev("typeof window.TDC==='object'", await_promise=False):
                break

        ans = slider_solver.answer_from_session(bg_path, sp_path, dsi)
        print("ans:", ans["data"], "piece_offset", ans["piece_offset"],
              "hole", ans["hole"], "y_check_ok", ans["y_check_ok"])
        try:
            slider_solver.draw_overlay(bg_path, sp_path, dsi,
                                       os.path.join(HERE, "verify_overlay.png"))
        except Exception as e:
            print("overlay failed:", e)

        # feed the locally generated trajectory to TDC; the real widget does
        # the same (verified: TDC.setData adds the trace to the collect)
        init_x, init_y = ans["init_pos"]
        traj = make_trajectory(init_x, init_y, ans["x"], ans["y"])
        tr = c.ev("(function(){try{var d=%s;TDC.setData(d);return 'ok'}"
                  "catch(e){return 'ERR '+e}})()" % json.dumps(traj),
                  await_promise=False)
        print("TDC.setData:", tr, "(%d points)" % len(traj))

        collect = c.ev("TDC.getData(true)", await_promise=False)
        eks = c.ev("TDC.getInfo().info", await_promise=False)
        if not collect or not eks:
            raise SystemExit("TDC collect/eks not available")
        # the real client sends the RAW collect length (captured from its own
        # verify request), not the decoded one
        tlg = len(collect)
        print("collect %d chars (decoded %d), eks %d chars" %
              (len(collect), len(urllib.parse.unquote(collect)), len(eks)))

        # the TDC instance must belong to THIS prehandle session, otherwise the
        # server would decrypt with another build's keys
        app_data = urllib.parse.parse_qs(
            urllib.parse.urlparse(data["comm_captcha_cfg"]["tdc_path"]).query
        ).get("app_data", [""])[0]
        tdc_apps = [urllib.parse.parse_qs(
            urllib.parse.urlparse(e["params"]["request"]["url"]).query
        ).get("app_data", [""])[0]
            for e in c.events
            if e.get("method") == "Network.requestWillBeSent"
            and "/tdc.js" in e["params"]["request"].get("url", "")]
        print("session app_data", app_data, "tdc.js app_data", tdc_apps)
        if app_data and tdc_apps and app_data not in tdc_apps:
            raise SystemExit("TDC build is for a different app_data; aborting")
        if not tdc_apps:
            print("WARNING: no tdc.js request observed; continuing")

        ans_json = json.dumps([{"elem_id": 1, "type": "DynAnswerType_POS",
                                "data": ans["data"]}], separators=(",", ":"))
        prefix, target = pow_cfg["prefix"], pow_cfg["md5"]
        t0 = time.time()
        n = 0
        while hashlib.md5((prefix + str(n)).encode()).hexdigest() != target:
            n += 1
        pow_ms = max(1, int((time.time() - t0) * 1000))
        pow_answer = prefix + str(n)
        # the widget on this page reports its real solve time (captured: a
        # 2-digit value), so no simulation is needed
        print("pow_answer", pow_answer, "in", pow_ms, "ms")

        body = {
            "collect": collect, "tlg": str(tlg), "eks": eks, "sess": sess,
            "ans": ans_json, "tkid": tkid,
            "pow_answer": pow_answer, "pow_calc_time": str(pow_ms),
        }
        result = {"sess_len": len(sess), "tkid": tkid, "tlg": tlg,
                  "ans": ans_json, "pow_answer": pow_answer,
                  "pow_calc_time": pow_ms,
                  "collect_len": len(collect),
                  "collect_decoded_len": len(urllib.parse.unquote(collect)),
                  "traj_points": len(traj), "setdata": tr,
                  "eks_len": len(eks), "init_pos": fg1.get("init_pos"),
                  "hole": ans["hole"], "method": ans["hole"].get("method", "mask")}
        if not submit:
            print("DRY RUN: not posting. Re-run with --yes to submit once.")
            json.dump(result, open(OUT, "w"), indent=1)
            return

        # cookies from the browser (the session ticket may be bound to them)
        S = requests.Session()
        S.headers.update({
            "User-Agent": UA, "Accept": "*/*",
            "Origin": "https://cloud.tencent.com",
            "Referer": "https://cloud.tencent.com/product/captcha",
        })
        try:
            for ck in c.call("Storage.getCookies").get("cookies", []):
                dom = (ck.get("domain") or "").lstrip(".")
                if "qcloud.com" in dom:
                    S.cookies.set(ck["name"], ck["value"], domain=dom,
                                  path=ck.get("path", "/"))
        except Exception as e:
            print("cookie copy failed:", e)

        r = S.post(BASE + "/cap_union_new_verify", data=body, timeout=15)
        print("HTTP", r.status_code)
        print(r.text[:1500])
        result.update({"http": r.status_code, "response": r.text[:4000]})
        json.dump(result, open(OUT, "w"), indent=1)
    finally:
        try:
            c.ws.close()
        except Exception:
            pass
        I.close_target(tid)


if __name__ == "__main__":
    main()
