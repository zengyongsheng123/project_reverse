# -*- coding: utf-8 -*-
"""把「浏览器那条会话的 prehandle 请求参数」和我们自己发的逐字段对照。

之前已经证明：Node 出的 collect 放进浏览器会话能过（errorCode 0），放进我们自己
的会话就是 12。collect 内容、轨迹、appid、header 全排除了，那就只剩「会话本身」。
prehandle 是唯一决定 sess 的那条请求 —— 参数差一个字，服务端给这个 sess 的
风险档位就可能不同。

本脚本只做测量：用 CDP 打开页面、让 SDK 自己发 prehandle、拖完截住 verify
（failRequest，不发给服务端），把请求参数留档后对照。不发任何 verify。

用法：python prehandle_param_cmp.py
"""
import json
import os
import sys
import urllib.parse

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))
sys.path.insert(0, HERE)

import fastmoss_flow as F

OUT = os.path.join(HERE, "kcalib", "browser_session.json")


def ours():
    """复刻 prehandle() 里的参数字典。"""
    F.FastMossCaptchaFlow.prehandle  # 只为确保类已定义
    import base64
    import random
    tkid = "0"
    cb = "_aq_1"
    return {
        "aid": F.AID, "protocol": "https", "accver": "1",
        "showtype": "popup",
        "ua": base64.b64encode(F.UA.encode()).decode(),
        "noheader": "1", "fb": "1", "aged": "0", "enableAged": "0",
        "enableDarkMode": "0", "grayscale": "1", "clientype": "2",
        "cap_cd": "", "uid": "", "lang": "zh-cn",
        "entry_url": F.ENTRY_URL, "elder_captcha": "0",
        "js": "/tgJCap.2f0b2c65.js", "login_appid": "",
        "wb": "1", "tkid": tkid, "subsid": "1", "callback": cb, "sess": "",
    }


def main():
    hy = F.BrowserHybrid()
    code, res = hy.run(intercept_verify=True)
    if not res.get("verify_body"):
        print("没截到 verify：", str(res)[:300])
    keep = {k: v for k, v in res.items() if k != "tdc_js"}
    with open(OUT, "w", encoding="utf-8") as fh:
        json.dump(keep, fh, ensure_ascii=False, indent=1)
    print("浏览器会话留档 ->", OUT, "(code=%s)" % code)

    urls = res.get("request_urls") or []
    pre_url = next((u for u in urls if "cap_union_prehandle" in u), "")
    if not pre_url:
        print("没记到 prehandle URL")
        return 1
    bq = urllib.parse.parse_qs(urllib.parse.urlsplit(pre_url).query,
                               keep_blank_values=True)
    bq = {k: v[0] for k, v in bq.items()}
    oq = ours()
    print("\n== 只浏览器有 ==")
    for k in sorted(set(bq) - set(oq)):
        print("  %-16s %r" % (k, bq[k][:120]))
    print("== 只我们有 ==")
    for k in sorted(set(oq) - set(bq)):
        print("  %-16s %r" % (k, oq[k][:120]))
    print("== 值不同 ==")
    for k in sorted(set(bq) & set(oq)):
        b, o = bq[k], oq[k]
        if k in ("tkid", "callback", "ua"):
            continue
        if b != o:
            print("  %-16s brow=%r ours=%r" % (k, b[:100], o[:100]))
    print("\n== 两边都有的（略过逐字比对）==")
    print("  " + " ".join(sorted(set(bq) & set(oq))))

    # tdc.js 那条也照一下
    tdc = next((u for u in urls if "tdc.js" in u), "")
    print("\n浏览器 tdc.js URL:", tdc[:220])
    print("浏览器 cookies(qcloud):", [(c.get("name"), (c.get("domain") or ""))
                                      for c in (res.get("cookies") or [])
                                      if "qcloud" in (c.get("domain") or "")
                                      or "gtimg" in (c.get("domain") or "")])
    print("verify 请求头 keys:", sorted((res.get("verify_headers") or {})))
    return 0


if __name__ == "__main__":
    sys.exit(main())
