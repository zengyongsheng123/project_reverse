# -*- coding: utf-8 -*-
"""在浏览器里 hook 序列化相关的入口（JSON.stringify / join / fromCharCode），
看看 tdc.js 拼 collect 明文时有没有暴露出「哪个内部状态变量对应哪个 cd 槽位」。

只读环境：只调 TDC.getData()，不发任何 verify 请求。

用法：python browser_serialize_probe.py
"""
import os
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
sys.path.insert(0, ROOT)

import fastmoss_flow as F

PRE = r"""
(function(){
  window.__log = [];
  function note(kind, info) {
    if (window.__log.length < 200) window.__log.push([kind, String(info).slice(0, 4000)]);
  }
  var js = JSON.stringify;
  JSON.stringify = function(v) {
    try {
      if (v && typeof v === 'object') {
        var keys = Object.keys(v);
        if (keys.indexOf('cd') >= 0 || keys.indexOf('sd') >= 0) {
          note('JSON.stringify', keys.join(',') + ' => ' + js.call(JSON, v));
        }
      }
    } catch (e) {}
    return js.apply(JSON, arguments);
  };
  var join = Array.prototype.join;
  Array.prototype.join = function(sep) {
    try {
      if (this && this.length === 38) note('join38', js.call(JSON, this));
    } catch (e) {}
    return join.apply(this, arguments);
  };
  var fcc = String.fromCharCode;
  String.fromCharCode = function() { return fcc.apply(String, arguments); };
})();
"""


def main():
    hy = F.BrowserHybrid()
    hy._launch()
    t = hy._new_target()
    c = F._CDP(t["webSocketDebuggerUrl"])
    try:
        for m in ("Runtime.enable", "Page.enable", "Network.enable"):
            c.call(m)
        c.call("Page.addScriptToEvaluateOnNewDocument", source=PRE)
        c.call("Page.navigate", url=hy.PAGE)
        time.sleep(1.5)
        c.ev(hy.LOAD % F.AID)
        for _ in range(80):
            time.sleep(0.5)
            if c.ev("typeof window.TDC") == "object":
                break
        for _ in range(60):
            time.sleep(0.5)
            if c.ev("!!document.querySelector('.tencent-captcha-dy__slider-block')"):
                break
        time.sleep(1.0)
        d = c.ev("TDC.getData()")
        print("collect %d" % len(d))
        print(c.ev("JSON.stringify(window.__log)")[:3000])
    finally:
        try:
            c.ws.close()
        except Exception:
            pass
        hy._close_target(t["id"])
        if hy.proc is not None:
            try:
                hy.proc.terminate()
            except Exception:
                pass


if __name__ == "__main__":
    main()
