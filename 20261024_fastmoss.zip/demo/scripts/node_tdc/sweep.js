// 在 Node 垫片里做「环境读取扫描」：
//   1) --mode read  : 记录 tdc.js 在加载+getData 期间读了垫片上的哪些属性
//   2) --mode probe : 按 --set '{"navigator.plugins.length":987654}' 改一个值，出 collect
// 每次都用全新的 vm 上下文，互不污染。不发任何网络请求。
//
// 用法：
//   node sweep.js <tdc.js> --mode read
//   node sweep.js <tdc.js> --mode probe --set '{"path":987654}'
'use strict';
const fs = require('fs');
const vm = require('vm');
const { install } = require('./shim.js');

const argv = process.argv.slice(2);
const jsPath = argv[0];
const mode = (() => { const i = argv.indexOf('--mode'); return i > 0 ? argv[i + 1] : 'read'; })();
const setSpec = (() => {
  const i = argv.indexOf('--set');
  if (i < 0) return {};
  try { return JSON.parse(argv[i + 1] || '{}'); } catch (e) { return {}; }
})();
const pauses = (() => { const i = argv.indexOf('--pause'); return i > 0 ? Number(argv[i + 1]) : 0; })();
const src = fs.readFileSync(jsPath, 'utf8');

const TARGETS = [
  'window', 'navigator', 'navigator.plugins', 'navigator.userAgentData',
  'navigator.connection', 'navigator.storage', 'navigator.permissions',
  'screen', 'screen.orientation', 'document', 'document.documentElement',
  'document.body', 'location', 'history', 'performance', 'performance.memory',
  'localStorage', 'sessionStorage', 'visualViewport',
];

function resolvePath(win, path) {
  const parts = path.split('.');
  let obj = parts[0] === 'window' ? win : win;
  if (parts[0] === 'window') parts.shift();
  for (let i = 0; i < parts.length - 1; i++) {
    if (obj == null) return null;
    obj = obj[parts[i]];
  }
  if (obj == null) return null;
  const last = parts[parts.length - 1];
  if (!(last in obj)) return null;
  return { parent: obj, key: last };
}

function installReadTrace(win, reads) {
  for (const path of TARGETS) {
    if (path === 'window') { traceObj(win, 'window', reads); continue; }
    const r = resolvePath(win, path);
    if (r) traceObj(r.parent[r.key], path, reads);
  }
}

function traceObj(obj, label, reads) {
  if (!obj || (typeof obj !== 'object' && typeof obj !== 'function')) return;
  for (const key of Object.keys(obj)) {
    let val;
    try { val = obj[key]; } catch (e) { continue; }
    try {
      Object.defineProperty(obj, key, {
        configurable: true, enumerable: true,
        get() { reads.add(label + '.' + key); return val; },
        set(v) { val = v; },
      });
    } catch (e) { /* 不可配就不管 */ }
  }
}

function applySet(win, notes) {
  for (const path of Object.keys(setSpec)) {
    const r = resolvePath(win, path);
    if (!r) { notes.push('miss:' + path); continue; }
    let val = setSpec[path];
    if (val === '__undefined') val = undefined;
    try {
      Object.defineProperty(r.parent, r.key, {
        configurable: true, enumerable: true, writable: true, value: val,
      });
    } catch (e) { notes.push('err:' + path + ':' + e.message); }
  }
}

const caps = (() => {
  const i = argv.indexOf('--caps');
  return i < 0 ? [] : String(argv[i + 1] || '').split(',').filter(Boolean);
})();

// --js2 <code>：tdc.js 加载前执行的一段代码，作用域里有 win（沙箱全局）。
// 用来临时改 canvas/GL 之类的垫片行为，看 collect 里哪个 token 会跟着动。
const js2 = (() => { const i = argv.indexOf('--js2'); return i > 0 ? String(argv[i + 1] || '') : ''; })();

// 浏览器有、垫片没有的全局名：挂成「读了就记一笔、值仍是 undefined」的 getter。
// tdc.js 若用 typeof/in 探测这些能力，就能看出它到底查了什么。
const WATCH_GLOBALS = [
  'IntersectionObserver', 'ResizeObserver', 'MutationObserver', 'PerformanceObserver',
  'ReportingObserver', 'Element', 'HTMLElement', 'HTMLCanvasElement', 'HTMLImageElement',
  'HTMLVideoElement', 'HTMLAudioElement', 'Audio', 'AudioContext', 'OfflineAudioContext',
  'webkitAudioContext', 'WebGLRenderingContext', 'WebGL2RenderingContext', 'GPU',
  'Worker', 'SharedWorker', 'ServiceWorker', 'OffscreenCanvas', 'BroadcastChannel',
  'MessageChannel', 'RTCPeerConnection', 'webkitRTCPeerConnection', 'WebSocket',
  'XMLHttpRequest', 'fetch', 'Notification', 'PushManager', 'PaymentRequest',
  'PublicKeyCredential', 'Bluetooth', 'USB', 'Serial', 'HID', 'NFC', 'WakeLock',
  'IdleDetector', 'Gamepad', 'Geolocation', 'MediaDevices', 'MediaRecorder',
  'ImageCapture', 'SpeechRecognition', 'webkitSpeechRecognition',
  'SpeechSynthesisUtterance', 'ApplicationCache', 'InstallTrigger', 'opr', 'MSStream',
  'callPhantom', '_phantom', '__nightmare', 'domAutomation',
  'domAutomationController', 'Buffer', 'process', 'require', 'module', 'exports',
  'global', 'structuredClone', 'queueMicrotask', 'requestIdleCallback',
  'requestAnimationFrame', 'getComputedStyle', 'matchMedia', 'indexedDB',
  'webkitIndexedDB', 'openDatabase', 'caches', 'CSS', 'customElements',
  'HTMLDialogElement', 'ShadowRoot', 'devicePixelRatio', 'screenLeft', 'screenTop',
  'scrollX', 'scrollY', 'pageXOffset', 'pageYOffset', 'outerWidth', 'outerHeight',
  'visualViewport', 'languages', 'external', 'frames', 'length', 'top', 'parent',
  'self', 'opener', 'closed', 'name', 'status', 'defaultStatus', 'event',
];
const WATCH_NAV = [
  'mediaDevices', 'gpu', 'usb', 'bluetooth', 'serial', 'hid', 'credentials',
  'mediaSession', 'storage', 'serviceWorker', 'wakeLock', 'keyboard', 'locks',
  'deviceMemory', 'maxTouchPoints', 'pdfViewerEnabled', 'webdriver', 'doNotTrack',
  'vendorSub', 'productSub', 'oscpu', 'buildID', 'cpuClass', 'devicePixelRatio',
  'getBattery', 'getGamepads', 'sendBeacon', 'registerProtocolHandler',
  'requestMIDIAccess', 'share', 'canShare', 'clipboard',
];
const WATCH_DOC = [
  'fonts', 'pointerLockElement', 'fullscreenElement', 'fullscreenEnabled',
  'visibilityState', 'webdriver', 'msHidden', 'webkitHidden', 'all',
  'activeElement', 'adoptedStyleSheets', 'styleSheets', 'scripts',
  'compatMode', 'designMode', 'dir', 'domain', 'implementation', 'images',
  'lastModified', 'links', 'locationbar', 'menubar', 'plugins', 'scrollingElement',
  'timeline', 'webkitFullscreenElement', 'webkitIsFullScreen', 'xmlVersion',
  'createRange', 'exitPointerLock', 'exitFullscreen', 'execCommand',
  'elementFromPoint', 'elementsFromPoint', 'queryCommandSupported',
];

function watch(win, target, list, label, reads) {
  for (const name of list) {
    if (target === win && name in win) continue;
    if (target !== win && name in target) continue;
    try {
      Object.defineProperty(target, name, {
        configurable: true, enumerable: false,
        get() { reads.add(label + '.' + name + ' (=undefined)'); return undefined; },
      });
    } catch (e) { /* ignore */ }
  }
}

async function main() {
  const win = install({ caps });
  if (js2) {
    try { new Function('win', js2)(win); } catch (e) { console.log(JSON.stringify({ ok: false, err: 'js2:' + e.message })); return; }
  }
  const reads = new Set();
  if (mode === 'read') installReadTrace(win, reads);
  if (argv.includes('--watch-missing')) {
    watch(win, win, WATCH_GLOBALS, 'window', reads);
    watch(win, win.navigator, WATCH_NAV, 'navigator', reads);
    watch(win, win.document, WATCH_DOC, 'document', reads);
  }
  const notes = [];
  if (mode === 'probe') applySet(win, notes);
  const ctx = vm.createContext(win);
  vm.runInContext(src, ctx, { filename: 'tdc.js', timeout: 20000 });
  if (pauses) await new Promise((r) => setTimeout(r, pauses));
  const TDC = ctx.TDC || win.TDC;
  if (!TDC) { console.log(JSON.stringify({ ok: false, err: 'no TDC' })); return; }
  let d = '';
  let err = null;
  try { d = TDC.getData(); } catch (e) { err = String(e).slice(0, 200); }
  // --js2 里可以定义 win.__dump()，这里在 getData 之后把它取回来（调试用）
  let dump;
  try { if (typeof win.__dump === 'function') dump = String(win.__dump()); } catch (e) { dump = 'dump:' + e.message; }
  console.log(JSON.stringify({
    ok: true, d, err, notes, dump,
    reads: mode === 'read' ? [...reads].sort() : undefined,
    qlog: win.document && win.document.__qlog,
  }));
}

main().catch((e) => console.log(JSON.stringify({ ok: false, err: String(e && e.stack || e).slice(0, 500) })));
