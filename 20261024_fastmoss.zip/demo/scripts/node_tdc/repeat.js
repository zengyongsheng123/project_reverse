// 同一个 Node 会话里连续调 N 次 TDC.getData()，把 N 条 collect 都打出来。
// 用来判断 collect 里哪些 token 是**会话内计数器**（每调一次 +1），哪些是环境指纹。
//
// 用法：node repeat.js <tdc.js> [次数]
'use strict';
const fs = require('fs');
const vm = require('vm');
const { install } = require('./shim.js');

const argv = process.argv.slice(2);
const jsPath = argv[0];
const n = Number(argv[1] || 3);
const capSpec = (() => { const i = argv.indexOf('--caps'); return i < 0 ? [] : String(argv[i + 1] || '').split(',').filter(Boolean); })();

const win = install({ caps: capSpec });
const ctx = vm.createContext(win);
vm.runInContext(fs.readFileSync(jsPath, 'utf8'), ctx, { filename: 'tdc.js', timeout: 20000 });
const TDC = ctx.TDC || win.TDC;
const out = [];
for (let i = 0; i < n; i++) out.push(TDC.getData());
console.log(JSON.stringify({ ok: true, ds: out }));
