// 极简 DOM 垫片：只为让 tdc.js 能在 Node 里初始化并产出 collect。
// 目标不是伪装成浏览器，而是「不依赖浏览器进程」——指纹字段全部由这里给，
// 需要时可以用参数覆盖。
'use strict';
const zlib = require('zlib');

// ---- 最小 PNG 编码器（只为让 canvas.toDataURL() 返回一张真实尺寸的图）---- //
const CRC_TABLE = (() => {
  const t = new Int32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1;
    t[n] = c;
  }
  return t;
})();

function crc32(buf) {
  let c = 0xFFFFFFFF;
  for (let i = 0; i < buf.length; i++) c = CRC_TABLE[(c ^ buf[i]) & 0xFF] ^ (c >>> 8);
  return (c ^ 0xFFFFFFFF) >>> 0;
}

function chunk(type, data) {
  const len = Buffer.alloc(4);
  len.writeUInt32BE(data.length, 0);
  const td = Buffer.concat([Buffer.from(type, 'latin1'), data]);
  const crc = Buffer.alloc(4);
  crc.writeUInt32BE(crc32(td), 0);
  return Buffer.concat([len, td, crc]);
}

function pngEncode(w, h, rgba) {
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(w, 0);
  ihdr.writeUInt32BE(h, 4);
  ihdr[8] = 8; ihdr[9] = 6;                 // 8bit RGBA
  ihdr[10] = 0; ihdr[11] = 0; ihdr[12] = 0;
  const raw = Buffer.alloc((w * 4 + 1) * h);
  for (let y = 0; y < h; y++) {
    raw[y * (w * 4 + 1)] = 0;               // filter: none
    rgba.copy(raw, y * (w * 4 + 1) + 1, y * w * 4, (y + 1) * w * 4);
  }
  return Buffer.concat([
    Buffer.from([0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A]),
    chunk('IHDR', ihdr),
    chunk('IDAT', zlib.deflateSync(raw, { level: 6 })),
    chunk('IEND', Buffer.alloc(0)),
  ]);
}

/** 画一张「像浏览器画布指纹」的图：渐变底 + 圆弧 + 文字块。确定性的。 */
function canvasPng(w, h) {
  const buf = Buffer.alloc(w * h * 4);
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const i = (y * w + x) * 4;
      const g = (x * 255 / Math.max(1, w - 1)) | 0;
      buf[i] = (200 - ((y * 40 / h) | 0)) & 255;
      buf[i + 1] = g & 255;
      buf[i + 2] = (90 + ((x * y) & 63)) & 255;
      buf[i + 3] = 255;
    }
  }
  const paint = (cx, cy, r, rgb) => {
    for (let y = Math.max(0, cy - r); y < Math.min(h, cy + r); y++) {
      for (let x = Math.max(0, cx - r); x < Math.min(w, cx + r); x++) {
        const dx = x - cx, dy = y - cy;
        if (dx * dx + dy * dy <= r * r) {
          const i = (y * w + x) * 4;
          buf[i] = rgb[0]; buf[i + 1] = rgb[1]; buf[i + 2] = rgb[2];
        }
      }
    }
  };
  paint((w * 0.15) | 0, (h * 0.4) | 0, 22, [30, 120, 200]);
  paint((w * 0.42) | 0, (h * 0.65) | 0, 15, [220, 60, 40]);
  // 文字块：用竖条近似字形的覆盖率，够做指纹
  const textY = (h * 0.5) | 0;
  for (let k = 0; k < 26; k++) {
    const x0 = 40 + k * 12;
    if (x0 + 7 >= w) break;
    for (let y = textY; y < textY + 22 && y < h; y++) {
      for (let x = x0; x < x0 + 7; x++) {
        const i = (y * w + x) * 4;
        buf[i] = 20; buf[i + 1] = 20; buf[i + 2] = 20;
      }
    }
  }
  return pngEncode(w, h, buf);
}

function makeCtx2d(w, h) {
  const px = () => new Uint8ClampedArray(w * h * 4);
  return {
    canvas: null,
    fillStyle: '#000', strokeStyle: '#000', lineWidth: 1, font: '10px sans-serif',
    globalAlpha: 1, globalCompositeOperation: 'source-over', textBaseline: 'alphabetic',
    shadowBlur: 0, shadowColor: '#000',
    fillRect() {}, clearRect() {}, strokeRect() {}, beginPath() {}, closePath() {},
    moveTo() {}, lineTo() {}, arc() {}, rect() {}, fill() {}, stroke() {}, clip() {},
    fillText() {}, strokeText() {},
    // 宽度跟字体绑定：不同 font-family 量出来的宽度要不一样，否则「字体探测」
    // 会把每个候选字体都判成同一个，风险位里就会多记一笔。
    measureText(t) {
      const f = String(this.font || '');
      let h = 0;
      for (let i = 0; i < f.length; i++) h = (h * 31 + f.charCodeAt(i)) >>> 0;
      return { width: (t || '').length * 6.2 + (h % 13) * 0.37 };
    },
    save() {}, restore() {}, translate() {}, rotate() {}, scale() {}, setTransform() {},
    drawImage() {}, createLinearGradient() { return { addColorStop() {} }; },
    createRadialGradient() { return { addColorStop() {} }; },
    putImageData() {},
    getImageData(x, y, iw, ih) {
      const d = px();
      for (let i = 0; i < d.length; i += 4) {
        // 稳定的伪噪声（确定性），够做 canvas 指纹
        const t = (i * 2654435761) >>> 0;
        d[i] = t & 255; d[i + 1] = (t >> 8) & 255;
        d[i + 2] = (t >> 16) & 255; d[i + 3] = 255;
      }
      return { width: iw, height: ih, data: d };
    },
    getLineDash() { return []; }, setLineDash() {},
  };
}

function makeCtxWebGL(w, h) {
  const PARAMS = {
    7936: 'WebKit', 7937: 'WebKit WebGL', 7938: 'WebGL 1.0 (OpenGL ES 2.0 Chromium)',
    35724: 'WebGL GLSL ES 1.0 (OpenGL ES GLSL ES 1.0 Chromium)',
    37445: 'Google Inc. (NVIDIA)',
    37446: 'ANGLE (NVIDIA, NVIDIA GeForce RTX 3060 (0x00002503) Direct3D11 vs_5_0 ps_5_0, D3D11)',
  };
  return {
    canvas: null, drawingBufferWidth: w, drawingBufferHeight: h,
    VENDOR: 7936, RENDERER: 7937, VERSION: 7938, SHADING_LANGUAGE_VERSION: 35724,
    UNMASKED_VENDOR_WEBGL: 37445, UNMASKED_RENDERER_WEBGL: 37446,
    getParameter(p) { return PARAMS[p] !== undefined ? PARAMS[p] : 0; },
    getExtension(n) {
      if (/debug_renderer_info/i.test(n)) return { UNMASKED_VENDOR_WEBGL: 37445, UNMASKED_RENDERER_WEBGL: 37446 };
      return null;
    },
    getSupportedExtensions() { return ['WEBGL_debug_renderer_info']; },
    getShaderPrecisionFormat() { return { precision: 23, rangeMin: 127, rangeMax: 127 }; },
    createBuffer() { return {}; }, bindBuffer() {}, bufferData() {},
    createTexture() { return {}; }, bindTexture() {}, texImage2D() {}, texParameteri() {},
    createProgram() { return {}; }, createShader() { return {}; }, shaderSource() {},
    compileShader() {}, attachShader() {}, linkProgram() {}, useProgram() {},
    getShaderParameter() { return true; }, getProgramParameter() { return true; },
    getAttribLocation() { return 0; }, getUniformLocation() { return {}; },
    viewport() {}, clearColor() {}, clear() {}, drawArrays() {}, drawElements() {},
    readPixels() {}, enable() {}, disable() {}, depthFunc() {}, blendFunc() {},
  };
}

function makeCanvas() {
  const c = {
    width: 300, height: 150, style: {},
    getContext(kind) {
      const w = c.width, h = c.height;
      if (kind === '2d') {
        if (!c.__2d) { c.__2d = makeCtx2d(w, h); c.__2d.canvas = c; }
        return c.__2d;
      }
      if (/webgl/i.test(kind)) {
        if (!c.__gl) { c.__gl = makeCtxWebGL(w, h); c.__gl.canvas = c; }
        return c.__gl;
      }
      return null;
    },
    toDataURL() {
      // 真尺寸的 PNG（tdc.js 会按 canvas 尺寸做画布指纹）
      const w2 = Math.max(1, c.width | 0);
      const h2 = Math.max(1, c.height | 0);
      if (!c.__png || c.__pngKey !== w2 + 'x' + h2) {
        c.__png = canvasPng(w2, h2);
        c.__pngKey = w2 + 'x' + h2;
      }
      return 'data:image/png;base64,' + c.__png.toString('base64');
    },
    addEventListener() {}, removeEventListener() {},
  };
  c.__2d = null; c.__gl = null;
  return c;
}

// ---- 事件系统：tdc.js 靠 document/window 上的鼠标事件记轨迹 ------------- //
const LISTENERS = new WeakMap();
// WeakMap 不可遍历，另记一份「谁挂了什么监听」，排查轨迹为什么没记下来时用
const LIS_LOG = [];

function addL(target, type, fn) {
  if (typeof fn !== 'function') return;
  if (LIS_LOG.length < 500) LIS_LOG.push([target, type]);
  let m = LISTENERS.get(target);
  if (!m) { m = new Map(); LISTENERS.set(target, m); }
  const a = m.get(type) || [];
  if (!a.includes(fn)) a.push(fn);
  m.set(type, a);
}

function removeL(target, type, fn) {
  const m = LISTENERS.get(target);
  if (!m) return;
  const a = m.get(type);
  if (!a) return;
  const i = a.indexOf(fn);
  if (i >= 0) a.splice(i, 1);
}

function makeEvent(type, props) {
  const e = Object.assign({
    type, bubbles: true, cancelable: true, defaultPrevented: false,
    isTrusted: true, timeStamp: Date.now(), target: null, srcElement: null,
    currentTarget: null, button: 0, buttons: 0, which: 0, detail: 1,
    clientX: 0, clientY: 0, pageX: 0, pageY: 0, screenX: 0, screenY: 0,
    offsetX: 0, offsetY: 0, movementX: 0, movementY: 0,
    pointerId: 1, pointerType: 'mouse', isPrimary: true, pressure: 0.5,
    preventDefault() { this.defaultPrevented = true; },
    stopPropagation() {}, stopImmediatePropagation() {},
    composedPath() { return []; },
  }, props || {});
  e.pageX = e.pageX || e.clientX;
  e.pageY = e.pageY || e.clientY;
  return e;
}

function fire(target, ev) {
  ev.currentTarget = target;
  if (!ev.target) ev.target = target;
  const m = LISTENERS.get(target);
  if (m) {
    for (const fn of (m.get(ev.type) || []).slice()) {
      try { fn.call(target, ev); } catch (e) { /* 监听器自己报错不管 */ }
    }
  }
  const on = target['on' + ev.type];
  if (typeof on === 'function') {
    try { on.call(target, ev); } catch (e) { /* ignore */ }
  }
}

// 本进程建过的所有元素。浏览器里 getElementById 查的是整棵文档树，不管挂在哪层；
// tdc 探测用的 firsth/firstp/secondh/secondp/bar 都是它自己用 innerHTML 造出来的，
// 垫片里必须真的能把它们建出来、找得到，那一位能力位才亮得起来。
const REG = [];
const VOID_TAGS = { img: 1, br: 1, hr: 1, input: 1, meta: 1, link: 1, source: 1 };

// 极简 HTML 解析（只够 tdc 那几段探针用的）：建元素、认 id/class、认嵌套。
// 文本内容丢掉 —— 需要颜色看的是 computed style，不是文字。
function parseHTML(html) {
  const s = String(html == null ? '' : html);
  const stack = [{ el: null, kids: [] }];
  const TAG = /<(\/?)([a-zA-Z][\w:-]*)([^<>]*?)(\/?)>/g;
  const ATTR = /([\w:-]+)\s*=\s*("([^"]*)"|'([^']*)'|([^\s"'>`]+))/g;
  let m;
  while ((m = TAG.exec(s)) !== null) {
    const tag = m[2].toLowerCase();
    if (m[1] === '/') {
      for (let i = stack.length - 1; i > 0; i--) {
        if (stack[i].el && stack[i].el.tagName.toLowerCase() === tag) { stack.length = i; break; }
      }
      continue;
    }
    const el = makeEl(tag);
    let a;
    ATTR.lastIndex = 0;
    while ((a = ATTR.exec(m[3] || '')) !== null) {
      const key = a[1];
      const val = a[3] !== undefined ? a[3] : (a[4] !== undefined ? a[4] : a[5]);
      if (key === 'class') el.className = val;
      else el[key] = val;
    }
    const cur = stack[stack.length - 1];
    cur.kids.push(el);
    el.parentNode = cur.el;
    if (m[4] !== '/' && !VOID_TAGS[tag]) stack.push({ el: el, kids: el.children });
  }
  return stack[0].kids;
}

function makeEl(tag) {
  const el = {
    tagName: String(tag || 'div').toUpperCase(), nodeName: String(tag || 'div').toUpperCase(),
    id: '', className: '', style: {}, children: [], childNodes: [],
    innerHTML: '', innerText: '', textContent: '', value: '', type: '',
    offsetWidth: 0, offsetHeight: 0, clientWidth: 0, clientHeight: 0,
    scrollWidth: 0, scrollHeight: 0,
    parentNode: null, ownerDocument: null, dataset: {},
    appendChild(c) { this.children.push(c); return c; },
    removeChild(c) { return c; }, insertBefore(c) { this.children.push(c); return c; },
    setAttribute(k, v) { this[k] = v; }, getAttribute(k) { return this[k] === undefined ? null : this[k]; },
    removeAttribute() {}, hasAttribute() { return false; },
    addEventListener(t, f) { addL(this, t, f); },
    removeEventListener(t, f) { removeL(this, t, f); },
    dispatchEvent(ev) { fire(this, ev); return !ev.defaultPrevented; },
    getBoundingClientRect() { return { left: 0, top: 0, right: 300, bottom: 150, width: 300, height: 150, x: 0, y: 0 }; },
    getContext(kind) { return makeCanvas().getContext(kind); },
    querySelector() { return null; }, querySelectorAll() { return []; },
    focus() {}, blur() {}, click() {}, cloneNode() { return makeEl(tag); },
  };
  // innerHTML：解析成真实子元素（tdc 靠它造探针元素）
  let _html = '';
  Object.defineProperty(el, 'innerHTML', {
    configurable: true, enumerable: true,
    get() { return _html; },
    set(v) {
      _html = String(v == null ? '' : v);
      el.children.length = 0;
      const kids = parseHTML(_html);
      for (let i = 0; i < kids.length; i++) el.children.push(kids[i]);
      el.childNodes = el.children;
    },
  });
  if (String(tag).toLowerCase() === 'canvas') Object.assign(el, makeCanvas());
  REG.push(el);
  return el;
}

function findById(el, id) {
  if (!el) return null;
  if (el.id === id) return el;
  const kids = el.children || [];
  for (let i = 0; i < kids.length; i++) {
    const hit = findById(kids[i], id);
    if (hit) return hit;
  }
  return null;
}

function install(opts) {
  opts = opts || {};
  REG.length = 0;            // 每次 install 都是一个新页面，元素登记表清空
  LIS_LOG.length = 0;
  const mock = opts.mock || {};
  const store = Object.create(null);
  const storage = {
    getItem(k) { return k in store ? store[k] : null; },
    setItem(k, v) { store[k] = String(v); },
    removeItem(k) { delete store[k]; },
    clear() { for (const k in store) delete store[k]; },
    key(i) { return Object.keys(store)[i] || null; },
    get length() { return Object.keys(store).length; },
  };

  const docEl = makeEl('html');
  const body = makeEl('body');
  // 验证码弹层：浏览器里 #tCaptchaDyMainWrap 量出来是 360x363（不是视口 929x883）。
  // tdc.js 会把这个元素的尺寸记进 collect，垫片之前返回 0 尺寸的 div，于是 tdc 退回到
  // 视口尺寸，collect 里就出现了 [929,883] 而浏览器是 [360,363]。
  const captchaWrap = makeEl('div');
  captchaWrap.id = 'tCaptchaDyMainWrap';
  captchaWrap.className = 'tencent-captcha-dy__warp';
  captchaWrap.offsetWidth = 360; captchaWrap.offsetHeight = 363;
  captchaWrap.clientWidth = 360; captchaWrap.clientHeight = 363;
  captchaWrap.scrollWidth = 360; captchaWrap.scrollHeight = 363;
  captchaWrap.getBoundingClientRect = () => ({ left: 0, top: 0, right: 360, bottom: 363,
                                               width: 360, height: 363, x: 0, y: 0 });
  // tdc.js 实际量的是 #tCaptchaDyContent（浏览器里它和 wrap 一样是 360x363）
  const captchaContent = makeEl('div');
  captchaContent.id = 'tCaptchaDyContent';
  captchaContent.className = 'tencent-captcha-dy__content-wrap';
  captchaContent.offsetWidth = 360; captchaContent.offsetHeight = 363;
  captchaContent.clientWidth = 360; captchaContent.clientHeight = 363;
  captchaContent.scrollWidth = 360; captchaContent.scrollHeight = 363;
  captchaContent.getBoundingClientRect = captchaWrap.getBoundingClientRect;
  captchaContent.appendChild(captchaWrap);
  const captchaRoot = makeEl('div');
  captchaRoot.id = 'tc';
  // 按类名查：在登记表里按 class token 匹配（弹层本身、innerHTML 造出来的探针元素都在里面）
  function tagList(cls) {
    const want = String(cls || '');
    if (!want) return [];
    const out = [];
    for (let i = 0; i < REG.length; i++) {
      const c = REG[i].className;
      if (c && String(c).split(/\s+/).indexOf(want) >= 0) out.push(REG[i]);
    }
    return out;
  }
  docEl.appendChild(body);
  // 视口尺寸：tdc.js 会读 documentElement 的 client 尺寸
  docEl.clientWidth = 929; docEl.clientHeight = 883;
  docEl.offsetWidth = 929; docEl.offsetHeight = 883;
  docEl.scrollWidth = 929; docEl.scrollHeight = 883;
  body.clientWidth = 929; body.clientHeight = 883;
  body.offsetWidth = 929; body.offsetHeight = 883;

  // DOM 查询记录：排查「tdc 到底按什么选择器找元素」时用（run.js 里读 document.__qlog）
  const qlog = { ids: [], sel: [], cls: [], tag: [] };

  const mk = (t) => makeEl(t);
  function findAll(id) {
    for (let i = 0; i < REG.length; i++) if (REG[i].id === id) return REG[i];
    return null;
  }

  const document = {
    createElement: (t) => mk(t),
    createElementNS: (ns, t) => mk(t),
    documentElement: docEl,
    body, head: makeEl('head'),
    cookie: '',
    readyState: 'complete',
    hidden: false, visibilityState: 'visible',
    referrer: '',
    title: 'captcha',
    currentScript: null,     // tdc.js 可能从自己的 script.src 里取 build 参数
    getElementById(id) {
      if (id === 'tCaptchaDyMainWrap') return captchaWrap;
      if (id === 'tCaptchaDyContent') return captchaContent;
      if (id === 'tc') return captchaRoot;
      // tdc.js 会自己造 firsth/firstp/secondh/secondp/bar 这几个探针元素挂到 body 上，
      // 再 getElementById 取回来读 computed style。所以这里要真的按树找。
      const hit = findById(body, id) || findById(captchaWrap, id) ||
                  findById(captchaContent, id) || findAll(id);
      if (hit) return hit;
      qlog.ids.push(String(id));
      return null;
    },
    __els: REG,
    querySelector(s) { qlog.sel.push(String(s)); return null; },
    querySelectorAll(s) { qlog.sel.push(String(s)); return []; },
    getElementsByClassName(c) { qlog.cls.push(String(c)); return tagList(c); },
    addEventListener(t, f) { addL(this, t, f); },
    removeEventListener(t, f) { removeL(this, t, f); },
    dispatchEvent(ev) { fire(this, ev); return !ev.defaultPrevented; },
    getElementsByTagName(t) { qlog.tag.push(String(t)); return t === 'head' ? [makeEl('head')] : []; },
    __qlog: qlog,
    hasFocus() { return true; },
    createTextNode(t) { return { nodeValue: String(t) }; },
  };

  const nav = {
    userAgent: opts.ua || 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36',
    appVersion: '5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36',
    appName: 'Netscape', appCodeName: 'Mozilla', product: 'Gecko', vendor: 'Google Inc.',
    platform: 'Win32', language: 'zh-CN', languages: ['zh-CN', 'zh'],
    hardwareConcurrency: 8, deviceMemory: 8, maxTouchPoints: 0,
    cookieEnabled: true, onLine: true, doNotTrack: null,
    plugins: new Array(5).fill({ name: 'Chrome PDF Plugin' }),
    mimeTypes: new Array(2).fill({ type: 'application/pdf' }),
    webdriver: false,
    sendBeacon() { return true; },
  };

  const screen = {
    width: 1920, height: 1080, availWidth: 1920, availHeight: 1032,
    colorDepth: 32, pixelDepth: 32, availLeft: 0, availTop: 0, orientation: { type: 'landscape-primary', angle: 0 },
  };

  const location = {
    href: opts.href || 'file:///D:/20261024_fastmoss/captcha-test.html',
    protocol: 'file:', host: '', hostname: '', port: '', pathname: '/D:/20261024_fastmoss/captcha-test.html',
    search: '', hash: '', origin: 'null',
    toString() { return this.href; }, reload() {}, replace() {}, assign() {},
  };

  const win = {
    document, navigator: nav, screen, location,
    innerWidth: 929, innerHeight: 883, outerWidth: 945, outerHeight: 1012,
    devicePixelRatio: 1, screenX: 957, screenY: 47, screenLeft: 957,
    screenTop: 47, scrollX: 0, scrollY: 0,
    pageXOffset: 0, pageYOffset: 0,
    name: '', closed: false, isSecureContext: false,
    performance: { now: () => Number(process.hrtime.bigint() / 1000n) / 1000, timeOrigin: 0,
                   getEntriesByType: () => [], getEntriesByName: () => [], mark() {}, measure() {} },
    localStorage: storage, sessionStorage: storage,
    addEventListener(t, f) { addL(this, t, f); },
    removeEventListener(t, f) { removeL(this, t, f); },
    dispatchEvent(ev) { fire(this, ev); return !ev.defaultPrevented; },
    getComputedStyle(el) {
      // tdc.js 会建几个带 id 的元素（firsth/firstp/secondh/secondp/bar），给它们设
      // 颜色再读回来，用来判断「这个环境到底有没有真的 CSS 引擎」。浏览器里实测值如下；
      // 垫片以前一律返回 ''，这里就被判成「没有 CSS」。
      const COLORS = { firsth: 'rgb(0, 128, 0)', firstp: 'rgb(255, 0, 0)',
                       secondh: 'rgb(230, 232, 238)', secondp: 'rgb(0, 0, 255)',
                       bar: 'rgb(255, 0, 0)' };
      const id = (el && (el.id || el.className)) || '';
      const color = COLORS[id] || '';
      return { getPropertyValue(p) { return p === 'color' ? color : ''; },
               get color() { return color; }, length: 0 };
    },
    matchMedia(q) {
      // 浏览器实测：dark=false, light=true, reduce=false, no-preference=true
      const s = String(q || '').replace(/\s+/g, ' ').trim();
      let matches = false;
      if (s.indexOf('prefers-color-scheme') >= 0) matches = /light/.test(s);
      else if (s.indexOf('prefers-reduced-motion') >= 0) matches = /no-preference/.test(s);
      return { matches, media: q, onchange: null,
               addListener() {}, removeListener() {},
               addEventListener() {}, removeEventListener() {} };
    },
    requestAnimationFrame(cb) { return setTimeout(() => cb(Date.now()), 16); },
    cancelAnimationFrame(id) { clearTimeout(id); },
    setTimeout, clearTimeout, setInterval, clearInterval,
    atob: (s) => Buffer.from(String(s), 'base64').toString('binary'),
    btoa: (s) => Buffer.from(String(s), 'binary').toString('base64'),
    alert() {}, confirm() { return true; }, prompt() { return null; },
    open() { return null; }, close() {}, focus() {}, blur() {}, postMessage() {},
    XMLHttpRequest: function () { throw new Error('XHR disabled in shim'); },
    Image: function () { return makeEl('img'); },
    Worker: undefined,
    top: null, self: null, parent: null, frames: null,
    chrome: { runtime: {} },
    AudioContext: undefined,
  };
  win.top = win; win.self = win; win.parent = win; win.frames = win; win.window = win;
  win.globalThis = win;
  // 调试用：看看 tdc.js 到底把事件监听挂在谁身上（轨迹三元组是靠这些监听记的）
  win.__listenDump = function () {
    const out = [];
    for (const [tgt, type] of LIS_LOG) {
      const label = tgt === win ? 'window' : (tgt === document ? 'document'
        : (tgt && tgt.id ? '#' + tgt.id : ((tgt && tgt.tagName) || '?')));
      out.push([label, type]);
    }
    return out;
  };

  // 可选能力桩：tdc.js 会探测这些 API 是否存在，缺了会记一个风险位
  const CAPS = {
    audio: () => {
      win.AudioContext = function () {
        return { sampleRate: 48000, destination: {}, createOscillator: () => ({ connect() {}, start() {}, frequency: {} }), createAnalyser: () => ({ connect() {}, getByteFrequencyData() {} }), createGain: () => ({ connect() {}, gain: {} }) };
      };
      win.webkitAudioContext = win.AudioContext;
      win.OfflineAudioContext = win.AudioContext;
    },
    idb: () => { win.indexedDB = { open() { return {}; } }; },
    speech: () => { win.speechSynthesis = { getVoices() { return []; } }; },
    permissions: () => { nav.permissions = { query() { return { state: 'prompt' }; } }; },
    connection: () => { nav.connection = { effectiveType: '4g', rtt: 50, downlink: 10, saveData: false }; },
    battery: () => { nav.getBattery = () => ({ charging: true, level: 1 }); },
    notification: () => { win.Notification = function () {}; win.Notification.permission = 'default'; },
    websocket: () => { win.WebSocket = function () {}; },
    perfmem: () => { win.performance.memory = { usedJSHeapSize: 12345678, totalJSHeapSize: 23456789, jsHeapSizeLimit: 2172649472 }; },
    fonts: () => { document.fonts = { check() { return true; }, ready: { then() {} } }; },
    media: () => { nav.mediaDevices = { enumerateDevices: () => Promise.resolve([]) }; },
    webdriver_false: () => { nav.webdriver = false; },
    css: () => {
      // tdc.js 会探测 window.CSS（浏览器一定有）
      win.CSS = { supports: () => true, escape: (s) => String(s) };
    },
    rtc: () => {
      // tdc.js 会探测 RTCPeerConnection；_phantom/callPhantom/domAutomation
      // 这几个自动化标记则必须保持 undefined（真浏览器就是 undefined）。
      const RTC = function () { this.createDataChannel = () => ({}); this.close = () => {}; };
      RTC.prototype.createOffer = () => Promise.resolve({ type: 'offer', sdp: '' });
      RTC.prototype.setLocalDescription = () => Promise.resolve();
      win.RTCPeerConnection = RTC;
      win.webkitRTCPeerConnection = RTC;
    },
    plugins_obj: () => {
      nav.plugins = { length: 5, item() { return null; }, namedItem() { return null; }, refresh() {} };
      nav.mimeTypes = { length: 2, item() { return null; }, namedItem() { return null; } };
    },
    crypto: () => {
      // vm 上下文里没有 Node 的 globalThis.crypto，tdc.js 拿不到就退回 Math.random
      try { win.crypto = globalThis.crypto; } catch (e) { /* ignore */ }
      if (win.crypto && !win.crypto.getRandomValues) {
        win.crypto = { getRandomValues(a) { for (let i = 0; i < a.length; i++) a[i] = (Math.random() * 256) | 0; return a; } };
      }
      win.msCrypto = win.crypto;
    },
    timeorigin: () => {
      const base = Date.now() - (opts.warmup || 3000);
      win.performance.timeOrigin = base;
      win.performance.timing = {
        navigationStart: base, fetchStart: base + 3, domainLookupStart: base + 4,
        domainLookupEnd: base + 9, connectStart: base + 9, connectEnd: base + 41,
        requestStart: base + 42, responseStart: base + 96, responseEnd: base + 118,
        domLoading: base + 121, domInteractive: base + 421, domContentLoadedEventStart: base + 421,
        domContentLoadedEventEnd: base + 438, domComplete: base + 802,
        loadEventStart: base + 802, loadEventEnd: base + 806,
      };
    },
    chromeobj: () => {
      win.chrome = {
        runtime: {}, app: { isInstalled: false },
        loadTimes: () => ({ requestTime: 0, startLoadTime: 0, commitLoadTime: 0, finishLoadTime: 0, firstPaintTime: 0, firstPaintAfterLoadTime: 0, navigationType: 'Other', wasFetchedViaSpdy: true, wasNpnNegotiated: true, npnNegotiatedProtocol: 'h2', wasAlternateProtocolAvailable: false, connectionInfo: 'h2' }),
        csi: () => ({ startE: 0, onloadT: 0, pageT: 0, tran: 15 }),
      };
    },
    uadata: () => {
      nav.userAgentData = {
        brands: [{ brand: 'Not:A-Brand', version: '8' }, { brand: 'Chromium', version: '146' }, { brand: 'Google Chrome', version: '146' }],
        mobile: false, platform: 'Windows',
        getHighEntropyValues: () => Promise.resolve({ platform: 'Windows', platformVersion: '15.0.0', architecture: 'x86', bitness: '64', model: '', uaFullVersion: '146.0.0.0' }),
      };
    },
    plugins_named: () => {
      const mk = (name, filename) => ({ name, filename, description: '', length: 1 });
      const list = [mk('PDF Viewer', 'internal-pdf-viewer'), mk('Chrome PDF Viewer', 'internal-pdf-viewer'),
                    mk('Chromium PDF Viewer', 'internal-pdf-viewer'), mk('Microsoft Edge PDF Viewer', 'internal-pdf-viewer'),
                    mk('WebKit built-in PDF', 'internal-pdf-viewer')];
      nav.plugins = { length: list.length, item: (i) => list[i] || null,
                      namedItem: (n) => list.find((p) => p.name === n) || null, refresh() {} };
      nav.mimeTypes = { length: 2, item: (i) => (i < 2 ? { type: 'application/pdf' } : null),
                        namedItem: () => ({ type: 'application/pdf' }) };
    },
    orientation: () => { win.screen.orientation = { type: 'landscape-primary', angle: 0, addEventListener() {}, removeEventListener() {} }; },
    idle: () => { win.requestIdleCallback = (cb) => setTimeout(() => cb({ didTimeout: false, timeRemaining: () => 50 }), 1); win.cancelIdleCallback = (id) => clearTimeout(id); },
  };
  for (const name of (opts.caps || [])) {
    if (CAPS[name]) CAPS[name]();
  }
  win.document.location = location;
  win.document.URL = location.href;
  win.document.documentURI = location.href;
  win.document.characterSet = 'UTF-8';
  win.document.charset = 'UTF-8';
  win.document.inputEncoding = 'UTF-8';

  // 模拟拖动：tdc.js 通过 document/window 上的鼠标/指针事件记轨迹。
  // 单步调用，让 run.js 用真实间隔驱动（dt 才是真的）。
  win.__dragStep = function (kind, x, y, buttons) {
    // tdc.js 的轨迹三元组只在 #tCaptchaDyContent 上挂着 touchmove/mousemove
    // （listeners.js 实测），所以这个节点必须收得到事件，否则 collect 里一条轨迹都没有。
    const targets = [captchaContent, captchaWrap, document, win, docEl, body];
    const emit = (type) => {
      const px = win.__lastDragX, py = win.__lastDragY;
      const mx = (typeof px === 'number' && typeof x === 'number') ? x - px : 0;
      const my = (typeof py === 'number' && typeof y === 'number') ? y - py : 0;
      win.__lastDragX = x; win.__lastDragY = y;
      for (const t of targets) {
        fire(t, makeEvent(type, {
          clientX: x, clientY: y, screenX: x, screenY: y,
          pageX: x, pageY: y, offsetX: x, offsetY: y,
          movementX: mx, movementY: my,
          buttons: buttons, button: 0,
          touches: [{ clientX: x, clientY: y, pageX: x, pageY: y,
                      screenX: x, screenY: y, identifier: 1 }],
          changedTouches: [{ clientX: x, clientY: y, pageX: x, pageY: y,
                             screenX: x, screenY: y, identifier: 1 }],
          target: t, srcElement: t, timeStamp: Date.now(),
        }));
      }
    };
    if (kind === 'down') {
      // tdc 记轨迹用的是 clientX/clientY 的差值，起点默认在 (0,0)。所以按下前先
      // 在滑块旁边发一次 hover（真人放下手之前鼠标就在那块），第一条三元组就是
      // 「走过去」的小位移，而不是几百像素的绝对坐标。
      const hx = x - (8 + Math.random() * 30);
      const hy = y - (2 + Math.random() * 14);
      win.__lastDragX = hx; win.__lastDragY = hy;
      // 这条 hover 事件必须和 emit() 带一样多的坐标字段：tdc 记轨迹读的是
      // offsetX/offsetY（实测少了这两个字段时，第一条三元组会记成 [0,0,dt]，
      // 而真浏览器的第一条是鼠标当时的绝对位置，比如 [41,25,4036]）。
      for (const t of targets) {
        fire(t, makeEvent('pointermove', {
          clientX: hx, clientY: hy, screenX: hx, screenY: hy,
          pageX: hx, pageY: hy, offsetX: hx, offsetY: hy,
          movementX: hx, movementY: hy, buttons: 0, button: 0,
          touches: [{ clientX: hx, clientY: hy, pageX: hx, pageY: hy,
                      screenX: hx, screenY: hy, identifier: 1 }],
          changedTouches: [],
          target: t, srcElement: t, timeStamp: Date.now() }));
        fire(t, makeEvent('mousemove', {
          clientX: hx, clientY: hy, screenX: hx, screenY: hy,
          pageX: hx, pageY: hy, offsetX: hx, offsetY: hy,
          movementX: hx, movementY: hy, buttons: 0, button: 0,
          target: t, srcElement: t, timeStamp: Date.now() }));
      }
      emit('pointerdown'); emit('mousedown');
    }
    else if (kind === 'move') { emit('pointermove'); emit('mousemove'); }
    else { emit('pointerup'); emit('mouseup'); }
    return x;
  };

  // 一次性发完（不带真实间隔，排查用）
  win.__drag = function (pts) {
    if (!pts || !pts.length) return 0;
    win.__dragStep('down', pts[0][0], pts[0][1], 1);
    for (let i = 1; i < pts.length; i++) {
      win.__dragStep('move', pts[i][0], pts[i][1], 1);
    }
    const n = pts[pts.length - 1];
    win.__dragStep('up', n[0], n[1], 0);
    return pts.length;
  };

  // 探针用：按 key 覆盖 shim 里的任意取值（只覆盖已存在的 key）
  for (const k of Object.keys(mock)) {
    for (const tgt of [win, nav, screen, document, location, docEl, body]) {
      if (tgt && Object.prototype.hasOwnProperty.call(tgt, k)) tgt[k] = mock[k];
    }
  }

  // Node 22 自带只读的 globalThis.navigator，必须用 defineProperty 覆盖
  const globals = {
    window: win, self: win, document, navigator: nav, screen, location,
    localStorage: storage, sessionStorage: storage,
    atob: win.atob, btoa: win.btoa,
    performance: win.performance,
    getComputedStyle: win.getComputedStyle,
    matchMedia: win.matchMedia,
    requestAnimationFrame: win.requestAnimationFrame,
    cancelAnimationFrame: win.cancelAnimationFrame,
    innerWidth: win.innerWidth, innerHeight: win.innerHeight,
    outerWidth: win.outerWidth, outerHeight: win.outerHeight,
    devicePixelRatio: 1, screenX: 957, screenY: 47, scrollX: 0, scrollY: 0,
    Image: win.Image, chrome: win.chrome,
  };
  if (win.crypto) globals.crypto = win.crypto;
  if (win.requestIdleCallback) globals.requestIdleCallback = win.requestIdleCallback;
  for (const k of Object.keys(globals)) {
    try {
      Object.defineProperty(globalThis, k, {
        value: globals[k], writable: true, configurable: true, enumerable: true,
      });
    } catch (e) { /* 只读就跳过 */ }
  }
  return win;
}

module.exports = { install, makeEl, makeCanvas };
