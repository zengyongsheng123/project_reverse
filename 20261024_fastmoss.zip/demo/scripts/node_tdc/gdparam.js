// 浏览器里 SDK 调的是 TDC.getData(true)（带一个参数），这里对比带参/不带参出的 collect。
//
// 用法：node gdparam.js <tdc.js>
'use strict';
const fs = require('fs');
const vm = require('vm');
const { install } = require('./shim.js');

const jsPath = process.argv[2];
const win = install({ warmup: 1500 });
const ctx = vm.createContext(win);
vm.runInContext(fs.readFileSync(jsPath, 'utf8'), ctx, { filename: 'tdc.js', timeout: 20000 });
const TDC = ctx.TDC || win.TDC;
if (typeof TDC.setData === 'function') {
  try { TDC.setData({ ft: '6f_7Pf__H' }); } catch (e) { /* ignore */ }
}
const out = {};
try { out.argTrue = TDC.getData(true); } catch (e) { out.errTrue = String(e).slice(0, 200); }
try { out.noArg = TDC.getData(); } catch (e) { out.errNoArg = String(e).slice(0, 200); }
console.log(JSON.stringify({ ok: true, ...out }));
