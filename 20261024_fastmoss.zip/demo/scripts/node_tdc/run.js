// 用垫片加载某个 build 的 tdc.js，调 TDC.getData() 取 collect（不发任何网络请求）。
//
// 用法：node run.js <tdc.js 路径> [--calls N] [--events]
// 输出：最后一行是 JSON {"ok":true,"datas":[...],"info":{...}} 或 {"ok":false,"err":...}
'use strict';
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const argv = process.argv.slice(2);
const jsPath = argv[0];
if (!jsPath) { console.log(JSON.stringify({ ok: false, err: 'no js path' })); process.exit(0); }
const calls = (() => { const i = argv.indexOf('--calls'); return i > 0 ? Number(argv[i + 1] || 1) : 1; })();
const wantEvents = argv.includes('--events');
function argPair(name, def) {
  const i = argv.indexOf(name);
  if (i < 0) return def;
  const parts = String(argv[i + 1] || '').split(',');
  return [Number(parts[0]), Number(parts[1])];
}
const from = argPair('--from', [50, 58]);     // init_pos（图像坐标）
const to = argPair('--to', [250, 58]);        // 答案 ans

const mock = (() => {
  const i = argv.indexOf('--mock');
  if (i < 0) return {};
  try { return JSON.parse(argv[i + 1] || '{}'); } catch (e) { return {}; }
})();

const caps = (() => {
  const i = argv.indexOf('--caps');
  return i < 0 ? [] : String(argv[i + 1] || '').split(',').filter(Boolean);
})();

// 探针用：往 window 上补任意全局（垫片没有的那些），值是 JSON 里的字面量。
// 用来二分「哪个缺失的全局让 tdc 记了风险位」。
const extra = (() => {
  const i = argv.indexOf('--extra');
  if (i < 0) return {};
  try { return JSON.parse(argv[i + 1] || '{}'); } catch (e) { return {}; }
})();

// 探针用：预置 localStorage/sessionStorage（浏览器里 tdc 会往里写 itoken 等）。
const preseed = (() => {
  const i = argv.indexOf('--ls');
  if (i < 0) return {};
  try { return JSON.parse(argv[i + 1] || '{}'); } catch (e) { return {}; }
})();

const warmupMs = (() => {
  const i = argv.indexOf('--warmup');
  return i > 0 ? Number(argv[i + 1] || 0) : 0;
})();

const { install } = require('./shim.js');
const win = install({ mock, caps, warmup: warmupMs });
for (const k of Object.keys(extra)) win[k] = extra[k];
for (const k of Object.keys(preseed)) win.localStorage.setItem(k, String(preseed[k]));

const src = fs.readFileSync(jsPath, 'utf8');
const traceMissing = argv.includes('--trace-missing');
const missing = [];
if (traceMissing) {
  // 只包 navigator / screen / document：记录被读但垫片里没有的属性名
  const wrap = (obj, label) => new Proxy(obj, {
    get(t, k, r) {
      if (typeof k === 'string' && !(k in t) && missing.length < 400) {
        missing.push(label + '.' + k);
      }
      return t[k];
    },
  });
  win.navigator = wrap(win.navigator, 'navigator');
  win.screen = wrap(win.screen, 'screen');
  win.document = wrap(win.document, 'document');
}
const ctx = vm.createContext(win);
// 垫片里的全局已经在 win 上（install 同时写了 globalThis），这里补 setTimeout 等
vm.runInContext(src, ctx, { filename: path.basename(jsPath), timeout: 20000 });

function out(o) { console.log(JSON.stringify(o)); }
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/** 按真实间隔把拖动事件喂给 tdc.js（这样轨迹里的 dt 不是 0）。
 *
 * 间隔做成 0.65x~1.45x 的抖动：真人拖拽每帧耗时不会是一条直线，
 * 固定 9ms 那种节奏本身就是机器人特征。
 */
async function doDrag(pts, gapMs) {
  if (!pts || !pts.length) return 0;
  win.__dragStep('down', pts[0][0], pts[0][1], 1);
  for (let i = 1; i < pts.length; i++) {
    const jitter = 0.65 + Math.random() * 0.8;
    await sleep(Math.max(4, Math.round(gapMs * jitter)));
    win.__dragStep('move', pts[i][0], pts[i][1], 1);
  }
  await sleep(Math.round(gapMs * (1.2 + Math.random())));
  const n = pts[pts.length - 1];
  win.__dragStep('up', n[0], n[1], 0);
  return pts.length;
}

const dragGap = (() => {
  const i = argv.indexOf('--drag-gap');
  return i > 0 ? Number(argv[i + 1] || 9) : 9;
})();

// 页面「已经开了一会儿」：tdc.js 记录的是相对加载时刻的毫秒数，
// 刚启动就 getData（~20ms）在真浏览器里不可能——真人拖滑块至少一两秒。
const warmup = (() => {
  const i = argv.indexOf('--warmup');
  return i > 0 ? Number(argv[i + 1] || 0) : 0;
})();

(async () => {
  try {
    const TDC = ctx.TDC || (win.TDC);
    if (!TDC) { out({ ok: false, err: 'no TDC after load' }); return; }
    const info = (() => { try { return TDC.getInfo ? TDC.getInfo() : null; } catch (e) { return String(e); } })();

    if (warmup > 0) await sleep(warmup);

    const dragArg = (() => {
      const i = argv.indexOf('--drag');
      if (i < 0) return null;
      try { return JSON.parse(argv[i + 1] || 'null'); } catch (e) { return null; }
    })();
    if (dragArg && typeof win.__dragStep === 'function') {
      await doDrag(dragArg, dragGap);
    }

    const sdArg = (() => {
      const i = argv.indexOf('--sd');
      return i < 0 ? null : argv[i + 1];
    })();
    if (sdArg && typeof TDC.setData === 'function') {
      try { TDC.setData(JSON.parse(sdArg)); } catch (e) { /* 格式不对就不塞 */ }
    }

    if (wantEvents && typeof TDC.setData === 'function') {
      const t = {};
      const dist = to[0] - from[0], dur = 760;
      for (let ms = 0; ms <= dur; ms += 10) {
        const p = ms / dur;
        // 先快后慢、末端回正：和真实拖动形状一致
        const e = p < 0.85 ? (1 - Math.pow(1 - p / 0.85, 3)) * 1.02 : 1 + 0.02 * (1 - (p - 0.85) / 0.15);
        t[ms] = Math.round(from[0] + dist * e) + ',' +
                Math.round(from[1] + Math.sin(p * 3) * 1.5);
      }
      try { TDC.setData(t); } catch (e) { /* 老版本可能没有 setData */ }
    }

    const datas = [];
    for (let i = 0; i < calls; i++) {
      const d = TDC.getData();
      if (typeof d !== 'string') { out({ ok: false, err: 'getData returned ' + typeof d, info }); return; }
      datas.push({ d, now: Math.floor(Date.now() / 1000) });
    }
    const infoText = info && typeof info === 'object' ? (info.info || '') : '';
    out({ ok: true, datas, info: { len: infoText.length, text: infoText,
                                   missing: traceMissing ? [...new Set(missing)] : [] } });
  } catch (e) {
    out({ ok: false, err: String(e && e.stack || e).slice(0, 800) });
  }
})();
