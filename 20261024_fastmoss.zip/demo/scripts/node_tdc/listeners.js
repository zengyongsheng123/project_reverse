// 加载 tdc.js 后，把「谁身上挂了哪些事件监听」打出来。
// 轨迹三元组是 tdc 从指针事件里记的，先得知道它监听在哪个节点上。
//
// 用法：node listeners.js <tdc.js>
'use strict';
const fs = require('fs');
const vm = require('vm');
const { install } = require('./shim.js');

const jsPath = process.argv[2];
const win = install({ warmup: 1500 });
const ctx = vm.createContext(win);
vm.runInContext(fs.readFileSync(jsPath, 'utf8'), ctx, { filename: 'tdc.js', timeout: 20000 });
const before = win.__listenDump();
const TDC = ctx.TDC || win.TDC;
const mid = win.__listenDump();
if (typeof TDC.setData === 'function') { try { TDC.setData({ ft: '6f_7Pf__H' }); } catch (e) {} }
const afterSet = win.__listenDump();
try { TDC.getData(true); } catch (e) {}
const afterGet = win.__listenDump();
console.log(JSON.stringify({
  ok: true, before: mid, afterSet, afterGet,
  delta: { setData: afterSet.length - mid.length, getData: afterGet.length - afterSet.length },
}, null, 0));
