# -*- coding: utf-8 -*-
"""受控实验：浏览器真会话里，把 collect 换成「同一份 tdc.js 在 Node 里算出的」那条，
其余（sess / tkid / eks / ans / pow / 头）全部沿用浏览器真值，再发一条 verify。

为什么这么做
------------
之前四条实验已经确定：
  * 浏览器真 collect + Python 发 -> errorCode 0（transport 没问题）；
  * 同一个 build 下，Node 与浏览器的明文只差 canvas / GPU 串 / 两个随机数 /
    时间戳 / 两个 mystery flag / mask，而 mask 和 flag 单独改都还是 0。
所以现在只剩一个问题没被隔离：**「Node 算出来的 collect 本身」到底能不能过**。
这个脚本把除 collect 以外的一切都钉死在浏览器真值上 —— 过了说明 Node 的 collect
没问题、问题在我们自己那条 prehandle 会话；没过说明问题就在 collect 内容里。

每次运行只发一条 verify（--dry 不发）。

用法：python node_collect_probe.py [--dry]
"""
import os
import sys
import urllib.parse

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))
sys.path.insert(0, HERE)

import fastmoss_flow as F

SKIP_HEADERS = {"content-length", "host", "connection", "accept-encoding"}


def main():
    dry = "--dry" in sys.argv

    hy = F.BrowserHybrid()
    code, res = hy.run(intercept_verify=True)
    body = res.get("verify_body") or ""
    js = res.get("tdc_js") or ""
    if not body:
        print("没截到 verify：", str(res)[:400])
        return 1
    if not js:
        print("没拿到本页 tdc.js 源码")
        return 1

    kv = dict(urllib.parse.parse_qsl(body, keep_blank_values=True))
    bcollect = kv["collect"]
    print("浏览器 collect %d 字符 tlg=%s ans=%s"
          % (len(bcollect), kv.get("tlg"), kv.get("ans")))

    nc = F.NodeCollector(events=False)
    ncollect, n_eks = nc.collect(js)
    ntlg = len(urllib.parse.unquote(ncollect))
    print("Node     collect %d 字符 tlg=%d eks=%d"
          % (len(ncollect), ntlg, len(n_eks or "")))

    # 关键核对：SDK 自己发的 eks 到底是不是这份 js 里那个 window 全局？
    # 如果不等，说明 Node 的 getInfo() 给错了（或者我们抓错了全局），
    # 那 Node 路径送出去的 eks 就是错的 —— 这是一个从未验证过的变量。
    bek = kv.get("eks", "")
    print("eks 相同(browser vs node)? %s" % (bek == n_eks))
    if bek != n_eks:
        import base64 as _b64
        globs = F.FastMossCaptchaFlow.EKS_PAT.findall(js)
        print("  js 里 248 字全局: %s" % [(n, v[:12]) for n, v in globs])
        print("  browser eks[:16]=%r node eks[:16]=%r"
              % (bek[:16], (n_eks or "")[:16]))
        for n, v in globs:
            print("  %s: ==browser %s / ==node %s"
                  % (n, v == bek, v == n_eks))
    open(os.path.join(HERE, "kcalib", "probe_js.js"), "w",
         encoding="utf-8").write(js)

    # 只换 collect / tlg，别的一律不动（eks 仍是浏览器的，避免一次改两个变量）
    body2 = body.replace("collect=" + urllib.parse.quote(bcollect, safe=""),
                         "collect=" + ncollect)
    body2 = body2.replace("tlg=" + str(kv.get("tlg")), "tlg=" + str(ntlg))
    kv2 = dict(urllib.parse.parse_qsl(body2, keep_blank_values=True))
    print("换后 body：collect=%d tlg=%s eks=%s sess=%s"
          % (len(kv2.get("collect", "")), kv2.get("tlg"),
             len(kv2.get("eks", "")), len(kv2.get("sess", ""))))
    if kv2.get("collect") == bcollect:
        print("警告：collect 没换成功")
        return 1
    out = os.path.join(HERE, "kcalib", "node_collect_body.txt")
    open(out, "w", encoding="utf-8").write(body2)
    print("换后 body ->", out)

    if dry:
        print("DRY：不发包")
        return 0

    hdr = {}
    for k, v in (res.get("verify_headers") or {}).items():
        if k.lower() not in SKIP_HEADERS:
            hdr[k] = v
    cookies = [c for c in (res.get("cookies") or [])
               if "qcloud.com" in (c.get("domain") or "")]
    if cookies:
        hdr["Cookie"] = "; ".join("%s=%s" % (c["name"], c["value"])
                                  for c in cookies)
    url = res.get("verify_url") or (F.BASE + "/cap_union_new_verify")

    from curl_cffi import requests as creq
    s = creq.Session(impersonate="chrome")
    r = s.post(url, data=body2.encode("utf-8"), headers=hdr, timeout=20)
    print("curl_cffi:", r.status_code, r.text[:400])
    try:
        j = r.json()
        print("errorCode=", j.get("errorCode"),
              "ticket_len=", len(j.get("ticket") or ""))
    except Exception as exc:
        print("非 JSON:", exc)
    return 0


if __name__ == "__main__":
    sys.exit(main())
