# -*- coding: utf-8 -*-
"""把「Node 出的 collect」和「浏览器真 collect」逐字段对比（不提交）。

用法：python node_diff.py [--node .node_tdc_work/tdc_session.js]
                          [--collect .node_tdc_work/collect.txt]
                          [--truth 1792896616]
除了打印 Node 侧明文，还会把两边 cd 里的 token 按值类型配对，指出哪些字段
一眼就能被服务端看出不是浏览器（canvas/WebGL/screen 之类）。
"""
import argparse
import base64
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
sys.path.insert(0, ROOT)

import kcalib

CLOUD = os.path.join(HERE, "kcalib")


def decrypt_js(js_path, collect):
    info = kcalib.analyse(js_path, collect)
    if not info["hits"]:
        return None
    h = info["hits"][0]
    # analyse 里剥掉了 pt，重新解一遍拿明文
    hits = kcalib.try_decrypt(
        base64.b64decode(__import__("urllib.parse", fromlist=["x"]).unquote(collect)),
        [(tuple(h["tag"]), _key_of(info, h))], [h["case"]])
    return hits[0]["pt"] if hits else None


def _key_of(info, hit):
    tag = tuple(hit["tag"])
    for k, v in info["keys"]:
        if tuple(tuple(x) for x in k) == tag:
            return [int(x, 16) for x in v]
    raise SystemExit("找不到 key 数组 %s" % (tag,))


def load_truth(ts):
    t = json.load(open(os.path.join(CLOUD, "truth.json")))
    for k, v in t.items():
        if k.endswith(ts):
            return v
    raise SystemExit("truth.json 里没有 %s" % ts)


def browser_plain(ts):
    p = os.path.join(CLOUD, "%s.pt" % ts)
    return open(p, "rb").read()


def cd_of(pt):
    s = pt.decode("latin-1")
    i = s.find('{"cd":[')
    j = s.find('],"sd"')
    if j < 0:
        j = s.rfind(']}') - 1
    return json.loads(s[i:j + 1])["cd"]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--node", default=os.path.join(ROOT, ".node_tdc_work",
                                                   "tdc_session.js"))
    ap.add_argument("--collect", default=os.path.join(ROOT, ".node_tdc_work",
                                                      "collect.txt"))
    ap.add_argument("--truth", default="1792896616")
    args = ap.parse_args()

    node_pt = decrypt_js(args.node, open(args.collect).read())
    if node_pt is None:
        raise SystemExit("Node collect 解不开")
    print("=== Node 明文 ===")
    print(node_pt.decode("latin-1"))
    print()

    bpt = browser_plain(args.truth)
    print("=== 浏览器明文（%s）===" % args.truth)
    print(bpt.decode("latin-1"))
    print()

    a, b = cd_of(node_pt), cd_of(bpt)
    print("token 数：node=%d browser=%d" % (len(a), len(b)))
    print("按类型计数：")
    for name, f in (("int", lambda x: isinstance(x, int)),
                    ("str", lambda x: isinstance(x, str)),
                    ("list", lambda x: isinstance(x, list))):
        print("  %-4s node=%d browser=%d"
              % (name, sum(1 for x in a if f(x)), sum(1 for x in b if f(x))))
    print("\n字符串 token 对照（按出现顺序）:")
    sa = [x for x in a if isinstance(x, str)]
    sb = [x for x in b if isinstance(x, str)]
    for i in range(max(len(sa), len(sb))):
        x = sa[i] if i < len(sa) else ""
        y = sb[i] if i < len(sb) else ""
        mark = "  " if x == y else "!!"
        print("%s %-46r | %-46r" % (mark, x[:46], y[:46]))


if __name__ == "__main__":
    main()
