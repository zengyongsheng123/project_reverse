# -*- coding: utf-8 -*-
"""Translate a live build's bytecode into the canonical (reference build)
opcode space, using the handler-order permutation in ../js/opmap.json.

Usage: python translate_bc.py ../js/bytecode_live.json ../js/bytecode_live_canon.json
"""
import json
import re
import sys
from disasm_tdc import OPERANDS, NAMES


def load_map(path_map="../js/opmap.json", path_handlers="../js/handlers.json"):
    raw = json.load(open(path_map))
    handlers = json.load(open(path_handlers))
    old = handlers["old"]
    live = handlers["live"]
    live2old = {}
    unresolved = []
    for k, v in raw.items():
        i = int(k)
        if isinstance(v, list):
            unresolved.append(i)
        else:
            live2old[v] = i
    # ambiguous pop-style handlers: disambiguate by the VM variable they pop.
    # drop (old 5) pops the value stack; tpop (old 14) pops the try stack.
    # The value-stack variable differs per build, so find it dynamically: it
    # is the variable pushed by the handler mapped from old 0
    # (`V.push([V.pop(), V.pop()].reverse())`).
    def popvar(src):
        try:
            return src.split(".pop()")[0].split("{")[-1].split("(")[-1]
        except Exception:
            return None

    # The main value stack is the variable assigned `.length` by the handler
    # mapped from old 64 (`function(){V.length=w[k++]}` in the reference
    # build, `function(){g.length=y[C++]}` live).  Do not assume the old->live
    # mapping is positional: in newer builds handler slots are permuted too.
    old2live = {v: k for k, v in live2old.items()}
    main_var = None
    for old_i in (64, 0):
        lj = old2live.get(old_i)
        if lj is not None:
            m = re.search(r"(\w+)\.length\s*=", live[lj])
            if m:
                main_var = m.group(1)
                break
    if main_var is None:
        for src in live:
            m = re.search(r"(\w+)\.length\s*=", src)
            if m:
                main_var = m.group(1)
                break
    if main_var is None:
        main_var = "E"
    def candlist(old_i):
        v = raw.get(str(old_i))
        return list(v) if isinstance(v, list) else []

    cands = candlist(5) + [j for j in candlist(14) if j not in candlist(5)]
    if not cands:
        cands = [j for j, src in enumerate(live)
                 if ".pop()" in src and j not in live2old]
    if 5 in unresolved:
        for j in cands:
            if popvar(live[j]) == main_var:
                live2old[j] = 5
                break
    if 14 in unresolved:
        for j in cands:
            if j not in live2old and popvar(live[j]) != main_var:
                live2old[j] = 14
                break
    # remaining unresolved are empty (unused) slots: map arbitrarily
    used_old = set(live2old.values())
    free_live = [j for j in range(len(live)) if j not in live2old]
    free_old = [i for i in unresolved if i not in used_old]
    for j, i in zip(free_live, free_old):
        live2old[j] = i
    return live2old


def translate(bc, live2old):
    out = []
    n = len(bc)
    pc = 0
    stats = {}
    while pc < n:
        op_live = bc[pc]
        if op_live not in live2old:
            raise SystemExit("unmapped opcode %r at pc %d" % (op_live, pc))
        op = live2old[op_live]
        stats[op] = stats.get(op, 0) + 1
        out.append(op)
        cnt = OPERANDS.get(op)
        if cnt is None:
            raise SystemExit("invalid canonical opcode %d (live %d) at pc %d" % (op, op_live, pc))
        if cnt == -1:  # closure
            f = bc[pc + 1]
            nup = bc[pc + 2]
            narg = bc[pc + 3]
            out.extend(bc[pc + 1:pc + 4 + 2 * nup + narg])
            pc += 4 + 2 * nup + narg
        else:
            out.extend(bc[pc + 1:pc + 1 + cnt])
            pc += 1 + cnt
    return out, stats


def main():
    src = sys.argv[1] if len(sys.argv) > 1 else "../js/bytecode_live.json"
    dst = sys.argv[2] if len(sys.argv) > 2 else "../js/bytecode_live_canon.json"
    bc = json.load(open(src))
    live2old = load_map()
    out, stats = translate(bc, live2old)
    json.dump(out, open(dst, "w"))
    print("translated", len(bc), "->", len(out), "instrs", sum(stats.values()), "->", dst)
    ref = json.load(open("../js/bytecode.json"))
    n = min(len(out), len(ref))
    same = sum(1 for i in range(n) if out[i] == ref[i])
    print("positional equality vs reference build: %d/%d (%.1f%%)" % (same, n, 100.0 * same / max(1, n)))


if __name__ == "__main__":
    main()
