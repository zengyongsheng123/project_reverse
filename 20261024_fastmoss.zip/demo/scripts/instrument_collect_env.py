# -*- coding: utf-8 -*-
"""Instrument a FRESH tab to trace where the session-stable collect fields
come from (`rand_id`, `t_load`, `t_state`, `event_ts`) plus `now_sec`.

Hooks installed before ANY page script runs:
    Math.random        -> value + caller stack
    Date.now           -> value + caller stack
    performance.now    -> value + caller stack
    new Date(...)      -> getTime()

Then the page is opened, TDC initialises, and TDC.getData() is called twice.
The payloads are decrypted locally with the matching build profile (by sha)
so the numbers can be compared with the hook log.

It never touches the page the user is working in.

Usage: python instrument_collect_env.py
Writes collect_env_probe.json and js/live_src/tdc_env_<sha>.js/.json
"""
import base64
import hashlib
import json
import os
import sys
import time
import urllib.parse

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import instrument_eks_init as I

HERE = os.path.dirname(os.path.abspath(__file__))
JS = os.path.normpath(os.path.join(HERE, "..", "js"))

HOOK = r"""
(function(){
  var L = {rnd: [], rnd_n: 0, now: [], now_n: 0, perf: [], date_new: []};
  window.__ENVLOG = L;
  function st(){
    try { return String(new Error().stack).split('\n').slice(1, 6).join(' | ').slice(0, 300); }
    catch(e){ return ''; }
  }
  function keep(arr, rec){ if (arr.length < 2000) arr.push(rec); }
  var ornd = Math.random;
  Math.random = function(){
    var v = ornd.apply(Math, arguments);
    L.rnd_n++;
    if (L.rnd_n <= 400) keep(L.rnd, [L.rnd_n, v, st()]);
    return v;
  };
  var onow = Date.now;
  var dnow = function(){
    var v = onow();
    L.now_n++;
    if (L.now_n <= 400) keep(L.now, [v, st()]);
    return v;
  };
  Date.now = dnow;
  var operf = performance.now.bind(performance);
  performance.now = function(){
    var v = operf();
    if (L.perf.length < 400) keep(L.perf, [v, st()]);
    return v;
  };
  try {
    var OD = Date;
    var WD = function(){
      var n = arguments.length;
      var r = n ? new (Function.prototype.bind.apply(OD, [null].concat([].slice.call(arguments))))() : new OD();
      if (L.date_new.length < 400) keep(L.date_new, [r.getTime(), n, st()]);
      return r;
    };
    WD.prototype = OD.prototype;
    WD.now = dnow;                 // keep the wrapped clock visible
    WD.parse = OD.parse;
    WD.UTC = OD.UTC;
    window.Date = WD;
  } catch(e){}
})();
"""


def scripts_by_url(c):
    out = {}
    for e in c.events:
        if e.get("method") == "Debugger.scriptParsed":
            p = e["params"]
            out[p.get("url") or ""] = p["scriptId"]
    return out


def main():
    t = I.new_target()
    tid = t["id"]
    print("fresh target", tid)
    c = I.CDP(t["webSocketDebuggerUrl"])
    try:
        c.call("Runtime.enable")
        c.call("Page.enable")
        c.call("Debugger.enable")
        c.call("Page.addScriptToEvaluateOnNewDocument", source=HOOK)
        c.call("Page.navigate", url=I.URL)
        tdc = "?"
        for _ in range(40):
            time.sleep(0.5)
            tdc = c.ev("typeof window.TDC", await_promise=False)
            if tdc == "object":
                break
        if tdc != "object":
            print("clicking 立即体验 ...")
            c.ev("(function(){var b=[...document.querySelectorAll('a.tpm-btn')]"
                 ".filter(function(e){return e.textContent.trim()==='立即体验';})[0];"
                 "if(b){b.click();return 1}return 0})()", await_promise=False)
            for _ in range(60):
                time.sleep(0.5)
                tdc = c.ev("typeof window.TDC", await_promise=False)
                if tdc == "object":
                    break
        print("TDC:", tdc)
        if tdc != "object":
            raise SystemExit("TDC never appeared")

        # grab the build source that this page loaded
        sids = scripts_by_url(c)
        cand = [sid for u, sid in sids.items() if "tdc.js" in u]
        src = c.call("Debugger.getScriptSource", scriptId=cand[-1])["scriptSource"] if cand else ""
        sha = hashlib.sha256(src.encode()).hexdigest()[:16]
        print("tdc.js:", len(src), "chars sha256_16", sha)
        os.makedirs(os.path.join(JS, "live_src"), exist_ok=True)
        src_path = os.path.join(JS, "live_src", "tdc_env_%s.js" % sha)
        if src:
            open(src_path, "w", encoding="utf-8").write(src)
        json.dump({"sha256_16": sha, "url": [u for u in sids if "tdc.js" in u][-1:]},
                  open(os.path.join(JS, "live_src", "tdc_env_%s.json" % sha), "w"),
                  indent=1)

        # phase marker: anything logged after this point happened during getData
        c.ev("window.__PHASE='getData'; window.__MARK={r:L.rnd_n,n:L.now_n}", await_promise=False)
        datas = []
        for k in range(2):
            if k:
                # >1 s apart so the call timestamp token actually changes
                time.sleep(1.2)
            before = c.ev("Math.floor(Date.now()/1000)", await_promise=False)
            d = c.ev("TDC.getData()", await_promise=False)
            after = c.ev("Math.floor(Date.now()/1000)", await_promise=False)
            datas.append({"d": d, "before": before, "after": after})
            print("getData #%d: chars=%s t=%s..%s"
                  % (k + 1, len(d or ""), before, after))
        log = json.loads(c.ev("JSON.stringify(window.__ENVLOG)", await_promise=False))
        mark = c.ev("JSON.stringify(window.__MARK)", await_promise=False)
        import json as _j
        storage = c.ev(
            "(function(){var o={};try{o.TDC_itoken=localStorage.getItem('TDC_itoken');"
            "o.keys=[];for(var i=0;i<localStorage.length;i++){var k=localStorage.key(i);"
            "var v=localStorage.getItem(k)||'';if(/^\\\\d+:\\\\d+$/.test(v))"
            "o.keys.push([k,v]);}}catch(e){}return JSON.stringify(o)})()",
            await_promise=False)
        storage = _j.loads(storage) if storage else {}
    finally:
        try:
            c.ws.close()
        except Exception:
            pass
        I.close_target(tid)

    out = {"sha256_16": sha, "src": src_path, "datas": datas, "log": log,
           "mark": json.loads(mark) if mark else None, "storage": storage}
    json.dump(out, open(os.path.join(HERE, "collect_env_probe.json"), "w"), indent=1)
    print("Math.random calls:", log["rnd_n"], "Date.now calls:", log["now_n"],
          "new Date:", len(log["date_new"]), "performance.now:", len(log["perf"]))

    # decrypt the payloads locally with a profile whose sha matches this build
    prof_paths = []
    for fn in sorted(os.listdir(os.path.join(JS, "live_src"))):
        if fn.startswith("profile_") and fn.endswith(".json"):
            prof_paths.append(os.path.join(JS, "live_src", fn))
    prof = None
    for p in prof_paths:
        d = json.load(open(p))
        if d.get("sha256_16") == sha and d.get("verified"):
            prof = d
            break
    if prof is None:
        print("no matching profile for this build - plaintext not decrypted")
        print("(run: python derive_build.py envprobe --no-fetch --src %s, then re-run)"
              % src_path)
        return
    import tdc_crypto as tc
    print("using profile", prof["name"])
    out["plaintexts"] = []
    for item in datas:
        pt = tc.decode_data(item["d"], prof["key"], prof["case"], prof["split"])
        out["plaintexts"].append(pt.decode("latin-1"))
        print("plaintext:", pt.decode("latin-1").encode("unicode_escape").decode("ascii")[:400])
    json.dump(out, open(os.path.join(HERE, "collect_env_probe.json"), "w"), indent=1)
    print("wrote collect_env_probe.json")


if __name__ == "__main__":
    main()
