# -*- coding: utf-8 -*-
"""Extract the per-build constant that the collect payload carries once.

Every tdc.js build embeds exactly one 32-bit literal besides the XTEA delta
2654435769.  The payload puts that value in exactly one slot:

* cur2 layout: ``cd[0]`` -- the docs called it ``seed``;
* later layouts: near the end -- the docs called it ``event_ts``.

Those names are historical.  It is not a timestamp: observed values span
1.41e9..2.13e9 (2120394880 = 0x7E62A880 would be year 2037), it stays fixed
across a page's calls, and 11 different builds each carry their own value in
the payload while the real time fields change on every call.  Like ``eks`` it is a
server-side per-build constant, so pure Python extracts it from the loaded
build instead of computing it.

Usage:
    python extract_build_const.py ../js/live_src/tdc_cur11.js
    python extract_build_const.py ../js/live_src/tdc_cur11.js \
                                   ../js/live_src/profile_cur11.json
    python extract_build_const.py --live   # fetch the current page's build
    python extract_build_const.py --all    # scan saved builds + profiles
"""
import glob
import json
import os
import re
import sys

DELTA = 2654435769
HERE = os.path.dirname(os.path.abspath(__file__))
JS = os.path.join(os.path.dirname(HERE), "js", "live_src")

PAT = re.compile(r"(?<![\w.$])(\d{9,10})(?![\w.$])")


def find_build_const(src):
    """Return {value: occurrences} for 1e9..2^32-1 literals minus the delta."""
    vals = {}
    for m in PAT.finditer(src):
        v = int(m.group(1))
        if 1_000_000_000 <= v <= 0xFFFFFFFF:
            vals[v] = vals.get(v, 0) + 1
    vals.pop(DELTA, None)
    return vals


def one(src):
    vals = find_build_const(src)
    if len(vals) != 1:
        return None, vals
    return next(iter(vals)), vals


def locate(profile_path, value):
    """Where the value sits in a derived layout (token index), if recorded."""
    d = json.load(open(profile_path))
    toks = (d.get("layout") or {}).get("tokens") or []
    idx = [i for i, t in enumerate(toks) if t.strip() == str(value)]
    return idx, toks


def main():
    args = [a for a in sys.argv[1:] if not a.startswith("-")]
    if "--all" in sys.argv:
        bad = 0
        for path in sorted(glob.glob(os.path.join(JS, "tdc_*.js"))):
            name = os.path.basename(path)[4:-3]
            v, vals = one(open(path, encoding="utf-8", errors="replace").read())
            line = "%-28s %s" % (name, vals)
            prof = os.path.join(JS, "profile_%s.json" % name)
            if v is not None and os.path.exists(prof):
                idx, toks = locate(prof, v)
                if toks:
                    line += "  token_idx=%s %s" % (
                        idx, "OK" if idx else "MISMATCH")
                    if not idx:
                        bad += 1
                else:
                    line += "  (template profile, no layout)"
            elif v is None:
                bad += 1
            print(line)
        print("\nproblems:", bad)
        return

    if "--live" in sys.argv:
        sys.path.insert(0, HERE)
        from extract_eks import live_source
        src, _info = live_source()
        print("live source: %d chars" % len(src))
        prof = None
    else:
        path = args[0] if args else os.path.join(JS, "tdc_cur11.js")
        src = open(path, encoding="utf-8", errors="replace").read()
        print("source:", path, len(src), "chars")
        prof = args[1] if len(args) > 1 else None

    v, vals = one(src)
    print("big literals besides delta:", vals)
    if v is None:
        raise SystemExit("expected exactly one 1e9..2^32-1 literal")
    print("build constant:", v, "= 0x%X" % v)
    if prof and os.path.exists(prof):
        idx, _ = locate(prof, v)
        print("layout token index in %s: %s" % (os.path.basename(prof), idx))
        print("matches profile:", bool(idx))


if __name__ == "__main__":
    main()
