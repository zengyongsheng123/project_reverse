# -*- coding: utf-8 -*-
"""找出 collect 里「能力位图」token 的每一位对应哪个浏览器 API。

已知：同一 build 下 Node 与浏览器差在四元组上；其中浏览器 1007 / Node 0 的那一位
是**能力位图**（加上 window.CSS 会让它 0 -> 2，即 bit1）。
这里逐个补一个浏览器 API，看位图哪一位翻起来、以及另外三个检测字段会不会归零。

纯本地：只跑 Node 垫片，不发任何网络请求。

用法：python bit_sweep.py <tdc.js> --idx 27,28,29,33
"""
import json
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import build_diff as B

SWEEP = os.path.join(HERE, "node_tdc", "sweep.js")

# 每个候选：名字 -> 注入到沙箱全局的 JS 片段
CANDS = {
    "CSS": "win.CSS={supports:function(){return true;},escape:function(s){return String(s);}};",
    "IntersectionObserver": "win.IntersectionObserver=function(){this.observe=function(){};this.disconnect=function(){};};",
    "ResizeObserver": "win.ResizeObserver=function(){this.observe=function(){};this.disconnect=function(){};};",
    "MutationObserver": "win.MutationObserver=function(){this.observe=function(){};this.disconnect=function(){};this.takeRecords=function(){return [];};};",
    "PerformanceObserver": "win.PerformanceObserver=function(){this.observe=function(){};this.disconnect=function(){};};",
    "Worker": "win.Worker=function(){this.postMessage=function(){};this.terminate=function(){};this.addEventListener=function(){};};",
    "OffscreenCanvas": "win.OffscreenCanvas=function(w,h){this.width=w;this.height=h;this.getContext=function(){return null;};};",
    "WebSocket": "win.WebSocket=function(){this.send=function(){};this.close=function(){};this.addEventListener=function(){};};",
    "XMLHttpRequest": "win.XMLHttpRequest=function(){this.open=function(){};this.send=function(){};this.setRequestHeader=function(){};this.addEventListener=function(){};};",
    "indexedDB": "win.indexedDB={open:function(){return {};}};",
    "Notification": "win.Notification=function(){}; win.Notification.permission='default'; win.Notification.requestPermission=function(){return Promise.resolve('default');};",
    "AudioContext": "win.AudioContext=function(){this.sampleRate=48000;this.destination={};this.createOscillator=function(){return {connect:function(){},start:function(){},frequency:{}};};};",
    "OfflineAudioContext": "win.OfflineAudioContext=function(){this.startRendering=function(){return Promise.resolve({});};};",
    "speechSynthesis": "win.speechSynthesis={getVoices:function(){return [];},speak:function(){},cancel:function(){}};",
    "fonts": "win.document.fonts={check:function(){return true;},ready:Promise.resolve(),size:5,forEach:function(){}};",
    "subtle": "win.crypto=win.crypto||{}; win.crypto.subtle={digest:function(){return Promise.resolve(new ArrayBuffer(16));}};",
    "mediaDevices": "win.navigator.mediaDevices={enumerateDevices:function(){return Promise.resolve([]);},getUserMedia:function(){return Promise.resolve({});}};",
    "serviceWorker": "win.navigator.serviceWorker={register:function(){return Promise.resolve({});},ready:Promise.resolve({}),controller:null};",
    "permissions": "win.navigator.permissions={query:function(){return Promise.resolve({state:'prompt',onchange:null});}};",
    "storage": "win.navigator.storage={estimate:function(){return Promise.resolve({quota:1,usage:0});},persist:function(){return Promise.resolve(true);}};",
    "geolocation": "win.navigator.geolocation={getCurrentPosition:function(){},watchPosition:function(){return 1;},clearWatch:function(){}};",
    "getBattery": "win.navigator.getBattery=function(){return Promise.resolve({charging:true,level:1});};",
    "sendBeacon": "win.navigator.sendBeacon=function(){return true;};",
    "history": "win.history={length:2,pushState:function(){},replaceState:function(){},back:function(){},state:null,scrollRestoration:'auto'};",
    "matchMedia": "win.matchMedia=function(q){return {matches:false,media:q,onchange:null,addListener:function(){},removeListener:function(){},addEventListener:function(){},removeEventListener:function(){}};};",
    "rAF": "win.requestAnimationFrame=function(cb){return setTimeout(function(){cb(Date.now());},16);}; win.cancelAnimationFrame=function(id){clearTimeout(id);};",
    "requestIdleCallback": "win.requestIdleCallback=function(cb){return setTimeout(function(){cb({didTimeout:false,timeRemaining:function(){return 50;}});},1);};",
    "structuredClone": "win.structuredClone=function(o){return JSON.parse(JSON.stringify(o));};",
    "customElements": "win.customElements={define:function(){},get:function(){return undefined;},whenDefined:function(){return Promise.resolve();}};",
    "MessageChannel": "win.MessageChannel=function(){this.port1={postMessage:function(){},addEventListener:function(){}};this.port2=this.port1;};",
    "BroadcastChannel": "win.BroadcastChannel=function(){this.postMessage=function(){};this.close=function(){};};",
    "EventSource": "win.EventSource=function(){this.close=function(){};this.addEventListener=function(){};};",
    "ReadableStream": "win.ReadableStream=function(){};",
    "AbortController": "win.AbortController=function(){this.abort=function(){};this.signal={};};",
    "Element": "win.Element=function(){}; win.Element.prototype.animate=function(){return {cancel:function(){},finished:Promise.resolve()};}; win.Element.prototype.attachShadow=function(){return {appendChild:function(){}};};",
    "dialog": "win.HTMLDialogElement=function(){};",
    "video": "win.HTMLVideoElement=function(){}; win.HTMLImageElement=function(){}; win.HTMLAudioElement=function(){}; win.Image=function(){return win.document.createElement('img');}; win.HTMLCanvasElement=function(){};",
    "canvas_toBlob": "var oc=win.document.createElement; win.document.createElement=function(t){var e=oc(t); if(String(t).toLowerCase()==='canvas'&&!e.toBlob){e.toBlob=function(cb){setTimeout(function(){cb(null);},0);};if(!e.__ad){e.__ad=1;var ga=e.addEventListener;e.addEventListener=function(n,f){if(n==='webglcontextlost'||n==='webglcontextrestored')return;return ga.call(e,n,f);};}} return e;};",
    "chrome": "win.chrome={runtime:{},app:{isInstalled:false},loadTimes:function(){return {requestTime:0,startLoadTime:0,commitLoadTime:0,finishLoadTime:0,firstPaintTime:0,firstPaintAfterLoadTime:0,navigationType:'Other',wasFetchedViaSpdy:true,wasNpnNegotiated:true,npnNegotiatedProtocol:'h2',wasAlternateProtocolAvailable:false,connectionInfo:'h2'};},csi:function(){return {startE:0,onloadT:0,pageT:0,tran:15};}};",
    "deviceMemory": "win.navigator.deviceMemory=8;",
    "maxTouchPoints": "win.navigator.maxTouchPoints=0;",
    "pdfViewer": "win.navigator.pdfViewerEnabled=true;",
    "uadata": "win.navigator.userAgentData={brands:[{brand:'Not:A-Brand',version:'8'},{brand:'Chromium',version:'146'},{brand:'Google Chrome',version:'146'}],mobile:false,platform:'Windows',getHighEntropyValues:function(){return Promise.resolve({platform:'Windows',platformVersion:'15.0.0',architecture:'x86',bitness:'64',uaFullVersion:'146.0.0.0'});}};",
    "perfmem": "win.performance.memory={usedJSHeapSize:12345678,totalJSHeapSize:23456789,jsHeapSizeLimit:2172649472};",
    "perfentries": "win.performance.getEntries=function(){return [];}; win.performance.getEntriesByType=function(){return [];}; win.performance.now=win.performance.now.bind(win.performance);",
    "visualViewport": "win.visualViewport={width:929,height:883,offsetLeft:0,offsetTop:0,scale:1,addEventListener:function(){},removeEventListener:function(){}};",
    "screenOrientation": "win.screen.orientation={type:'landscape-primary',angle:0,addEventListener:function(){},removeEventListener:function(){}};",
    "connection": "win.navigator.connection={effectiveType:'4g',rtt:50,downlink:10,saveData:false,addEventListener:function(){}};",
    "languages": "win.navigator.languages=['zh-CN','zh'];",
    "Intl": "win.Intl=Intl;",
    "MutationObserver2": "win.MutationObserver=win.MutationObserver||function(){this.observe=function(){};};",
}


def run(js, code=None):
    args = ["node", SWEEP, js, "--mode", "probe"]
    if code:
        args += ["--js2", code]
    p = subprocess.run(args, capture_output=True, text=True, encoding="utf-8",
                       errors="replace")
    try:
        o = json.loads(p.stdout.strip().splitlines()[-1])
    except Exception:
        return None, p.stdout[-200:]
    if not o.get("ok"):
        return None, o.get("err")
    pt, _ = B.decrypt(js, o["d"], "node")
    return [x.strip() for x in B.tokenize(pt)], None


def main():
    js = sys.argv[1]
    idx = ([int(x) for x in sys.argv[sys.argv.index("--idx") + 1].split(",")]
           if "--idx" in sys.argv else [27, 28, 29, 33])
    base, err = run(js)
    if base is None:
        print("基线失败", err)
        return 1
    print("基线", [(i, base[i]) for i in idx])
    for name, code in CANDS.items():
        t, err = run(js, code)
        if t is None:
            print("%-20s 失败 %s" % (name, str(err)[:60]))
            continue
        quad = [(i, base[i], t[i]) for i in idx if t[i] != base[i]]
        other = [(i, base[i][:14], t[i][:14]) for i in range(len(base))
                 if t[i] != base[i] and i not in idx and i not in (6, 7, 22, 24)]
        if quad or other:
            print("%-20s 四元组 %s 其他 %s" % (name, quad, other[:4]))
        else:
            print("%-20s -" % name)
    return 0


if __name__ == "__main__":
    sys.exit(main())
