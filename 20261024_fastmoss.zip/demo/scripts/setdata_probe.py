# -*- coding: utf-8 -*-
"""Read-only: does this build's TDC accept `setData` slider data, and how does
it change the collect payload?

Opens a private tab, opens the captcha, then:
  1. reads a baseline collect (no trajectory),
  2. feeds a synthetic trajectory through TDC.setData (same shape the real
     widget uses: {elapsed_ms: "x,y"}) and reads again,
  3. compares raw/decoded lengths.
No verify request is made, so no attempt is consumed.

Usage: python setdata_probe.py
"""
import json
import os
import sys
import time
import urllib.parse

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import instrument_eks_init as I  # noqa: E402


def main():
    t = I.new_target()
    tid = t["id"]
    c = I.CDP(t["webSocketDebuggerUrl"])
    out = {}
    try:
        c.call("Runtime.enable")
        c.call("Page.enable")
        c.call("Page.navigate", url=I.URL)
        for _ in range(40):
            time.sleep(0.5)
            if c.ev("document.readyState", await_promise=False) == "complete":
                break
        c.ev("(function(){var b=[...document.querySelectorAll('a.tpm-btn')]"
             ".filter(function(e){return e.textContent.trim()==='立即体验';})[0];"
             "if(b){b.click();return 1}return 0})()", await_promise=False)
        for _ in range(60):
            time.sleep(0.5)
            if c.ev("typeof window.TDC==='object'", await_promise=False):
                break
        api = c.ev("(function(){var o=[];for(var k in TDC){o.push(k+':'+typeof TDC[k])}"
                   "return o.join(',')})()", await_promise=False)
        print("TDC API:", api)
        print("setData:", c.ev("typeof TDC.setData", await_promise=False),
              "getData:", c.ev("typeof TDC.getData", await_promise=False))

        a = c.ev("TDC.getData(true)", await_promise=False)
        print("baseline collect raw %d decoded %d" % (
            len(a), len(urllib.parse.unquote(a))))

        # synthetic ease-in-out trajectory, element coordinates (design px)
        init_x, init_y = 50, 215
        target_x, target_y = 347, 215
        n = 40
        dur = 1200
        traj = {}
        for i in range(n):
            p = i / float(n - 1)
            e = 4 * p ** 3 if p < 0.5 else 1 - ((-2 * p + 2) ** 3) / 2.0
            x = int(init_x + (target_x - init_x) * e)
            y = int(init_y + (target_y - init_y) * e)
            traj[int(p * dur)] = "%d,%d" % (x, y)
        traj[dur] = "%d,%d" % (target_x, target_y)
        expr = ("(function(){try{var d=%s;TDC.setData(d);return 'ok'}"
                "catch(e){return 'ERR '+e}})()" % json.dumps(traj))
        r = c.ev(expr, await_promise=False)
        print("setData ->", r)
        b = c.ev("TDC.getData(true)", await_promise=False)
        print("after setData raw %d decoded %d (delta %+d)" % (
            len(b), len(urllib.parse.unquote(b)),
            len(b) - len(a)))
        c_ = c.ev("TDC.getData(true)", await_promise=False)
        print("next collect raw %d decoded %d (delta vs baseline %+d)" % (
            len(c_), len(urllib.parse.unquote(c_)), len(c_) - len(a)))
        out = {"api": api, "a": len(a), "b": len(b), "c": len(c_),
               "a_dec": len(urllib.parse.unquote(a)),
               "b_dec": len(urllib.parse.unquote(b)),
               "c_dec": len(urllib.parse.unquote(c_)),
               "setdata": r, "traj_points": len(traj)}
        json.dump(out, open(os.path.join(HERE, "setdata_probe.json"), "w"),
                  indent=1)
    finally:
        try:
            c.ws.close()
        except Exception:
            pass
        I.close_target(tid)


if __name__ == "__main__":
    main()
