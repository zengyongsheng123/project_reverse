# -*- coding: utf-8 -*-
"""Derive the live build's module key tables from its bytecode.

Each key module is a small closure built as

    closure <body> ... ; emptystr 'LIT' ; push 8 ; callm 2 ; setelem

and the body computes

    acc |= ((lit.charCodeAt(i) - off) << (8*i))     i = 0..3

with `off` baked into the body as `push A; sub` (off = A) or
`push 0; push B; sub; sub` (off = -B), then stores into self[7][slot]
via `push1 7; push <slot>; mkpair; load 6; setelem`.

Usage: python derive_keys.py old|live
"""
import json
import sys
from collections import deque

from disasm_tdc import OPERANDS, NAMES
from translate_bc import load_map

PUSH, PUSH1, SUB, MKPAIR, LOAD, SETELEM = 59, 35, 43, 34, 28, 38
EMPTYSTR, APPENDCHR, CLOSURE, CALLP = 46, 65, 52, 25


def walk(bc, live2old):
    n = len(bc)
    seen = {}
    q = deque([0])
    while q:
        pc = q.popleft()
        if not isinstance(pc, int) or pc in seen or pc < 0 or pc >= n:
            continue
        op = live2old.get(bc[pc])
        if op is None or OPERANDS.get(op) is None:
            continue
        cnt = OPERANDS[op]
        if cnt == -1:
            f, nup, narg = bc[pc + 1], bc[pc + 2], bc[pc + 3]
            end = pc + 4 + 2 * nup + narg
            seen[pc] = (op, [f, nup, narg], end)
            q.append(f)
            q.append(end)
            continue
        ops = bc[pc + 1:pc + 1 + cnt]
        end = pc + 1 + cnt
        seen[pc] = (op, ops, end)
        if op == 33:
            q.append(ops[0])
            continue
        q.append(end)
        if op in (63, 16):
            q.append(ops[0])
    return seen


def load(kind):
    if kind == "old":
        return json.load(open("../js/bytecode.json")), {i: i for i in range(200)}
    path = sys.argv[2] if len(sys.argv) > 2 else "../js/bytecode_live.json"
    return json.load(open(path)), load_map()


def lit_at(seen, start_pc):
    """Return the literal built by an emptystr/appendchr run following start_pc."""
    pc = start_pc
    for _ in range(6):
        rec = seen.get(pc)
        if rec is None:
            return None
        if rec[0] == EMPTYSTR:
            s = ""
            cur = rec[2]
            while True:
                nx = seen.get(cur)
                if not nx or nx[0] != APPENDCHR:
                    break
                s += chr(nx[1][0] & 0xFFFF)
                cur = nx[2]
            return s
        pc = rec[2]
    return None


def body_info(seen, f):
    """Extract (offset, slot) from a builder body starting at pc f."""
    recs = [(pc, seen[pc]) for pc in sorted(seen) if f <= pc <= f + 200]
    offset = None
    slot = None
    for i, (pc, (op, ops, end)) in enumerate(recs):
        if op == CALLP and ops == [1]:
            # read the next few instructions along fallthrough
            tail = []
            cur = end
            for _ in range(4):
                r = seen.get(cur)
                if not r:
                    break
                tail.append(r)
                cur = r[2]
            if len(tail) >= 4 and tail[0][0] == PUSH and tail[1][0] == PUSH \
                    and tail[2][0] == SUB and tail[3][0] == SUB:
                offset = -tail[1][1][0]          # c - (0 - B) = c + B
            elif len(tail) >= 2 and tail[0][0] == PUSH and tail[1][0] == SUB:
                offset = tail[0][1][0]           # c - A
        if op == SETELEM and i >= 4:
            p = recs[i - 4:i + 1]
            if p[0][1][0] == PUSH1 and p[0][1][1] == [7] and p[1][1][0] == PUSH \
                    and p[2][1][0] == MKPAIR and p[3][1][0] == LOAD:
                slot = p[1][1][1][0]
    return offset, slot


def word(s, off):
    """OR_i ((charCodeAt(i) - off) << 8*i), JS 32-bit semantics."""
    acc = 0
    for i in range(min(4, len(s))):
        v = (ord(s[i]) - off) << (8 * i)
        acc = (acc | v) & 0xFFFFFFFF
    return acc


def main():
    kind = sys.argv[1] if len(sys.argv) > 1 else "live"
    bc, m = load(kind)
    seen = walk(bc, m)
    mods = []
    for pc in sorted(seen):
        op, ops, end = seen[pc]
        if op != CLOSURE:
            continue
        f = ops[0]
        off, slot = body_info(seen, f)
        if off is None or slot is None:
            continue
        lit = lit_at(seen, end)
        mods.append((pc, f, off, slot, lit))
    for pc, f, off, slot, lit in mods:
        w = word(lit, off) if lit else None
        print("call@%5d body@%5d off=%-4d slot=%s lit=%r word=%s"
              % (pc, f, off, slot, lit,
                 ("0x%08x" % w) if w is not None else "-"))
    # assemble arrays
    arrs = {}
    for pc, f, off, slot, lit in mods:
        if not lit:
            continue
        arrs.setdefault(slot, []).append((pc, word(lit, off)))
    for slot in sorted(arrs):
        print("slot %d:" % slot, ["0x%08x" % v for _, v in arrs[slot]])
    try:
        cand = json.load(open("../js/live_key_candidates.json"))
        print("candidates:", cand)
    except Exception as e:
        print("no candidates:", e)


if __name__ == "__main__":
    main()
