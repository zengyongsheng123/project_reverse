# -*- coding: utf-8 -*-
"""定位 collect 明文里那个「风险位掩码」token：逐组打开能力桩，看它归零没有。

用一个已有的 build_diff 目录（tdc.js + browser.pt + browser.txt），所以不用
再开浏览器；纯本地。

用法：python cap_probe.py [diff 目录]
"""
import json
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
sys.path.insert(0, ROOT)

import fastmoss_flow as F
import token_probe as T

CAPS = ["audio", "idb", "speech", "permissions", "connection", "battery",
        "notification", "websocket", "perfmem", "fonts", "media",
        "webdriver_false", "plugins_obj"]


def run(js_path, caps):
    cmd = [F.NODE_BIN, os.path.join(F.NODE_ASSETS, "run.js"), js_path,
           "--calls", "1", "--caps", ",".join(caps)]
    r = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8",
                       errors="replace", timeout=180)
    lines = [l for l in (r.stdout or "").strip().splitlines() if l.startswith("{")]
    if not lines:
        raise SystemExit("node 无输出: %s" % (r.stderr or "")[:300])
    out = json.loads(lines[-1])
    if not out.get("ok"):
        raise SystemExit("node 失败: %s" % out.get("err"))
    return out["datas"][0]["d"]


def main():
    d = sys.argv[1] if len(sys.argv) > 1 else os.path.join(
        HERE, "kcalib", sorted(x for x in os.listdir(os.path.join(HERE, "kcalib"))
                               if x.startswith("diff_"))[-1])
    jsp = os.path.join(d, "tdc.js")
    bt = T.tokenize(open(os.path.join(d, "browser.pt"), "rb").read())
    prm = T.params(jsp, open(os.path.join(d, "browser.txt")).read())
    print("browser token 09 = %r" % bt[9].strip())

    cases = [("none", [])] + [(c, [c]) for c in CAPS] + [("all", CAPS)]
    for name, caps in cases:
        pt = T.decrypt(run(jsp, caps), prm)
        tk = T.tokenize(pt)
        print("%-16s token09=%-5s token19=%-12s token34=%s"
              % (name, tk[9].strip(), tk[19].strip(), tk[34].strip()))


if __name__ == "__main__":
    main()
