# -*- coding: utf-8 -*-
"""混合解算：Python 算缺口答案，浏览器本会话的 SDK 出 collect。

为什么必须混合
--------------
tdc.js 每个会话重新随机化（K 数组 / C 常量 / VM 字节码 / eks 全变），
所以「静态常量算出来的 collect」服务端解不开 —— 这是 errorCode 12
（验证失败）的根因。collect 只能由**本会话自己的 JS 运行时**生成。

流程
----
1. 浏览器弹验证码，Network 域抓 prehandle（sess / init_pos / 图片 URL）
2. Python 下载本会话的背景图和拼图块，ZNCC 内容匹配定位缺口
3. 用 CDP 真实鼠标事件拖滑块，闭环读 fg-item 的 transform 校正到目标
4. 松开 -> SDK 自己带着真实事件出 collect 并 POST cap_union_new_verify
5. 抓 verify 的请求体（= 服务端认可的 collect 长什么样）与响应 errorCode

用法
----
    python hybrid_solve.py            # 完整：拖到位后松手，让 SDK 提交
    python hybrid_solve.py --dry      # 只拖动不松手，测几何，不发 verify

规则：一次调用最多产生一条 verify（SDK 自己发的那条）。
"""
import argparse
import base64
import json
import os
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
sys.path.insert(0, ROOT)

import fastmoss_probe as P
import fastmoss_flow as F

BG = os.path.join(ROOT, "hybrid_bg.png")
SP = os.path.join(ROOT, "hybrid_sprite.png")

GEO = r"""
(function(){
  var img = document.querySelector('.tencent-captcha-dy__image-area');
  var bg  = document.querySelector('.tencent-captcha-dy__verify-bg-img');
  var fg  = document.querySelector('.tencent-captcha-dy__fg-item');
  var th  = document.querySelector('.tencent-captcha-dy__slider-block');
  if (!img || !fg || !th) return null;
  var ri = img.getBoundingClientRect();
  var rf = fg.getBoundingClientRect();
  var rt = th.getBoundingClientRect();
  var rb = bg ? bg.getBoundingClientRect() : null;
  return {
    img:   [ri.left, ri.top, ri.width, ri.height],
    fg:    [rf.left, rf.top, rf.width, rf.height],
    thumb: [rt.left, rt.top, rt.width, rt.height],
    bgBox: rb ? [rb.left, rb.top, rb.width, rb.height] : null,
    fgTf:  getComputedStyle(fg).transform,
    scaleX: bg ? (parseFloat(getComputedStyle(bg).backgroundSize) /
                  (fg.offsetWidth || 1)) : null
  };
})()
"""


def drain(c, rounds=6, pause=0.2):
    for _ in range(rounds):
        c.call("Runtime.evaluate", expression="1")
        time.sleep(pause)


def parse_jsonp(text):
    t = (text or "").strip()
    i, j = t.find("("), t.rfind(")")
    if i < 0 or j <= i:
        return None
    try:
        return json.loads(t[i + 1:j])
    except Exception:
        return None


def pick(c, needle):
    """(response 体列表, 请求体列表)"""
    resps, reqs = [], []
    for e in c.events:
        m = e.get("method")
        p = e.get("params") or {}
        if m == "Network.requestWillBeSent":
            if needle in (p.get("request") or {}).get("url", ""):
                reqs.append({"url": p["request"]["url"],
                             "postData": p["request"].get("postData", "")})
        elif m == "Network.responseReceived":
            if needle in (p.get("response") or {}).get("url", ""):
                try:
                    b = c.call("Network.getResponseBody",
                               requestId=p["requestId"]).get("body", "")
                except Exception as exc:
                    b = "ERR %s" % exc
                resps.append({"url": p["response"]["url"],
                              "status": p["response"].get("status"),
                              "body": b[:200000]})
    return resps, reqs


def mouse(c, kind, x, y, buttons=0):
    p = {"type": kind, "x": x, "y": y, "button": "left",
         "clickCount": 1, "buttons": buttons, "pointerType": "mouse"}
    c.call("Input.dispatchMouseEvent", **p)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dry", action="store_true", help="只拖动，不松手，不发 verify")
    ap.add_argument("--engine", default="zncc")
    args = ap.parse_args()

    proc = P.launch()
    t = P.new_target()
    tid = t["id"]
    c = P.CDP(t["webSocketDebuggerUrl"])
    result = {"dry": args.dry}
    try:
        c.call("Runtime.enable")
        c.call("Page.enable")
        c.call("Network.enable")
        c.call("Page.navigate", url=P.PAGE)
        time.sleep(1.5)
        print("show:", c.ev(P.LOAD))
        for _ in range(80):
            time.sleep(0.5)
            if c.ev("typeof window.TDC") == "object":
                break
        for _ in range(60):
            time.sleep(0.5)
            if c.ev("!!document.querySelector('.tencent-captcha-dy__slider-block')"):
                break
        time.sleep(1.0)
        drain(c)

        resps, _ = pick(c, "cap_union_prehandle")
        pre = None
        for r in reversed(resps):
            pre = parse_jsonp(r["body"])
            if pre:
                break
        if not pre:
            raise SystemExit("prehandle not captured")
        d = pre.get("data") or {}
        dsi = d["dyn_show_info"]
        fg_cfg = [e for e in dsi["fg_elem_list"] if e.get("id") == 1][0]
        init_x, init_y = fg_cfg["init_pos"]
        print("sess=%d init_pos=%s" % (len(pre.get("sess") or ""), [init_x, init_y]))

        # 下载本会话的图片
        def url_of(path):
            return path if path.startswith("http") else F.BASE + path
        import requests
        hdr = {"User-Agent": F.UA, "Referer": P.PAGE,
               "Accept": "image/avif,image/webp,image/png,*/*"}
        for path, dst in ((dsi["bg_elem_cfg"]["img_url"], BG),
                          (dsi["sprite_url"], SP)):
            r = requests.get(url_of(path), headers=hdr, timeout=20)
            r.raise_for_status()
            open(dst, "wb").write(r.content)
            print("  image %s %d B" % (os.path.basename(dst), len(r.content)))

        # Python 算缺口
        rec = F.GapRecognizer(args.engine)
        ans = rec.recognize(BG, SP, dsi)
        print("ans = %s  engine=%s conf=%s peak=%s" % (
            ans["data"], ans.get("engine"), ans["hole"].get("confidence"),
            ans["hole"].get("global_peak")))
        result["ans"] = ans["data"]
        result["ans_meta"] = ans["hole"]

        # 几何
        g = c.ev(GEO)
        if not g:
            raise SystemExit("popup geometry not found")
        img_l, img_t, img_w, img_h = g["img"]
        th_l, th_t, th_w, th_h = g["thumb"]
        fg_l, fg_t, fg_w, fg_h = g["fg"]
        piece_natural_w = 120.0                      # 拼图块图片宽（已确认）
        scale = fg_w / piece_natural_w
        print("geometry: image-area=%s thumb=%s fg=%s scale=%.5f"
              % (g["img"], g["thumb"], g["fg"], scale))
        result["geometry"] = {"img": g["img"], "thumb": g["thumb"],
                              "fg": g["fg"], "scale": scale}

        def piece_x():
            gg = c.ev(GEO)
            return (gg["fg"][0] - img_l) / scale

        x0 = piece_x()
        print("piece image x before drag = %.2f (init_x=%d)" % (x0, init_x))

        sx, sy = th_l + th_w / 2.0, th_t + th_h / 2.0
        mouse(c, "mousePressed", sx, sy, buttons=1)
        time.sleep(0.05)

        # 闭环：拖到 ans_x
        target = float(ans["x"])
        done = sx
        cur = x0
        for it in range(4):
            need = (target - cur) * scale        # 需要的显示位移
            if abs(need) < 0.6:
                break
            step_n = 12
            for k in range(1, step_n + 1):
                mouse(c, "mouseMoved", sx + done - sx + need * k / step_n,
                      sy + (1.0 if k % 3 else 0.0), buttons=1)
                time.sleep(0.012)
            done += need
            time.sleep(0.08)
            cur = piece_x()
            print("  iter%d need=%.1f -> piece x=%.2f (target %.2f)"
                  % (it + 1, need, cur, target))

        g2 = c.ev(GEO)
        print("final fg box=%s tf=%s" % (g2["fg"], g2["fgTf"]))
        result["final_piece_x"] = cur
        result["target_x"] = target
        result["thumb_delta"] = done - sx

        if args.dry:
            print("DRY: 不松手、不发 verify。把浏览器的鼠标留在按下状态，直接关标签页。")
            json.dump(result, open(os.path.join(HERE, "hybrid_solve.json"), "w"),
                      ensure_ascii=False, indent=1)
            return

        # 松手 -> SDK 出 collect 并自行提交 verify
        mouse(c, "mouseReleased", done, sy, buttons=0)
        print("released; waiting for SDK verify ...")
        for _ in range(40):
            time.sleep(0.5)
            drain(c, rounds=2, pause=0.15)
            vr, vq = pick(c, "cap_union_new_verify")
            if vr or c.ev("window.__fmCb"):
                break
        vr, vq = pick(c, "cap_union_new_verify")
        cb = c.ev("window.__fmCb")
        print("callback:", json.dumps(cb, ensure_ascii=False)[:300] if cb else None)
        if vq:
            print("verify request body keys:", sorted(
                [k.split("=")[0] for k in vq[-1]["postData"].split("&")]))
        if vr:
            print("verify response:", vr[-1]["body"][:400])
        result.update({"verify_req": vq[-1:] if vq else [],
                       "verify_resp": vr[-1:] if vr else [],
                       "callback": cb})
        json.dump(result, open(os.path.join(HERE, "hybrid_solve.json"), "w"),
                  ensure_ascii=False, indent=1)
        print("saved scripts/hybrid_solve.json")
    finally:
        try:
            c.ws.close()
        except Exception:
            pass
        P.close_target(tid)
        if proc is not None:
            try:
                proc.terminate()
            except Exception:
                pass


if __name__ == "__main__":
    main()
