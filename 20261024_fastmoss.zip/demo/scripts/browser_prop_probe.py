# -*- coding: utf-8 -*-
"""在真浏览器里改单个环境字段，看 collect 明文里哪个 token 跟着变。

反向探针：token_probe.py 是「改垫片 -> 看 token」，这里是「改真浏览器 ->
看 token」。目的是把 Node 侧对不上的几个 token（17/23/35/36）确定到具体字段。
只读环境 + 本地 getData，不发任何 verify 请求。

用法：python browser_prop_probe.py
"""
import json
import os
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
sys.path.insert(0, ROOT)

import fastmoss_flow as F
import token_probe as T
import counter_probe as C

# (标签, 设置表达式, 还原表达式, 期望出现在 token 里的值)
CASES = [
    ("outerHeight", "window.__d('outerHeight',4321)", "window.__u('outerHeight')", "4321"),
    ("outerWidth", "window.__d('outerWidth',4322)", "window.__u('outerWidth')", "4322"),
    ("innerWidth", "window.__d('innerWidth',4323)", "window.__u('innerWidth')", "4323"),
    ("innerHeight", "window.__d('innerHeight',4324)", "window.__u('innerHeight')", "4324"),
    ("devicePixelRatio", "window.__d('devicePixelRatio',4325)", "window.__u('devicePixelRatio')", "4325"),
    ("screenX", "window.__d('screenX',4326)", "window.__u('screenX')", "4326"),
    ("screenY", "window.__d('screenY',4327)", "window.__u('screenY')", "4327"),
    ("scrollX", "window.__d('scrollX',4328)", "window.__u('scrollX')", "4328"),
    ("screen.width", "window.__d2(screen,'width',4329)", "window.__u2(screen,'width')", "4329"),
    ("screen.height", "window.__d2(screen,'height',4330)", "window.__u2(screen,'height')", "4330"),
    ("screen.availWidth", "window.__d2(screen,'availWidth',4331)", "window.__u2(screen,'availWidth')", "4331"),
    ("screen.availHeight", "window.__d2(screen,'availHeight',4332)", "window.__u2(screen,'availHeight')", "4332"),
    ("screen.availTop", "window.__d2(screen,'availTop',4333)", "window.__u2(screen,'availTop')", "4333"),
    ("screen.colorDepth", "window.__d2(screen,'colorDepth',4334)", "window.__u2(screen,'colorDepth')", "4334"),
    ("nav.hardwareConcurrency", "window.__d2(navigator,'hardwareConcurrency',4335)",
     "window.__u2(navigator,'hardwareConcurrency')", "4335"),
    ("nav.deviceMemory", "window.__d2(navigator,'deviceMemory',4336)", "window.__u2(navigator,'deviceMemory')", "4336"),
    ("nav.maxTouchPoints", "window.__d2(navigator,'maxTouchPoints',4337)", "window.__u2(navigator,'maxTouchPoints')", "4337"),
    ("nav.webdriver", "window.__d2(navigator,'webdriver',true)", "window.__u2(navigator,'webdriver')", "None"),
    ("docEl.clientHeight", "window.__d2(document.documentElement,'clientHeight',4338)",
     "window.__u2(document.documentElement,'clientHeight')", "4338"),
    ("docEl.offsetHeight", "window.__d2(document.documentElement,'offsetHeight',4339)",
     "window.__u2(document.documentElement,'offsetHeight')", "4339"),
    ("docEl.scrollHeight", "window.__d2(document.documentElement,'scrollHeight',4340)",
     "window.__u2(document.documentElement,'scrollHeight')", "4340"),
    ("body.clientHeight", "window.__d2(document.body,'clientHeight',4341)",
     "window.__u2(document.body,'clientHeight')", "4341"),
    ("history.length", "window.__d2(history,'length',4342)", "window.__u2(history,'length')", "4342"),
]

# 第二轮：token 30（浏览器 1007 / Node 0）的候选来源。数值类的都往 44xx 走。
CASES2 = [
    ("nav.plugins.length", "window.__d2(navigator.plugins,'length',4401)",
     "window.__u2(navigator.plugins,'length')", "4401"),
    ("nav.mimeTypes.length", "window.__d2(navigator.mimeTypes,'length',4402)",
     "window.__u2(navigator.mimeTypes,'length')", "4402"),
    ("nav.languages", "window.__d2(navigator,'languages',['xx'])", "window.__u2(navigator,'languages')", "xx"),
    ("nav.language", "window.__d2(navigator,'language','xx')", "window.__u2(navigator,'language')", "xx"),
    ("nav.onLine", "window.__d2(navigator,'onLine',false)", "window.__u2(navigator,'onLine')", "None"),
    ("nav.cookieEnabled", "window.__d2(navigator,'cookieEnabled',false)",
     "window.__u2(navigator,'cookieEnabled')", "None"),
    ("nav.doNotTrack", "window.__d2(navigator,'doNotTrack','1')", "window.__u2(navigator,'doNotTrack')", "1"),
    ("nav.platform", "window.__d2(navigator,'platform','XX')", "window.__u2(navigator,'platform')", "XX"),
    ("nav.vendor", "window.__d2(navigator,'vendor','XX')", "window.__u2(navigator,'vendor')", "XX"),
    ("nav.userAgentData", "window.__d2(navigator,'userAgentData',null)",
     "window.__u2(navigator,'userAgentData')", "None"),
    ("nav.connection.rtt", "window.__d2(navigator.connection,'rtt',4403)",
     "window.__u2(navigator.connection,'rtt')", "4403"),
    ("doc.hidden", "window.__d2(document,'hidden',true)", "window.__u2(document,'hidden')", "None"),
    ("doc.visibilityState", "window.__d2(document,'visibilityState','hidden')",
     "window.__u2(document,'visibilityState')", "hidden"),
    ("doc.cookie", "window.__d2(document,'cookie','a=4404')", "window.__u2(document,'cookie')", "4404"),
    ("doc.title", "window.__d2(document,'title','XX')", "window.__u2(document,'title')", "XX"),
    ("doc.characterSet", "window.__d2(document,'characterSet','XX')",
     "window.__u2(document,'characterSet')", "XX"),
    ("win.name", "window.__d('name','XX')", "window.__u('name')", "XX"),
    ("win.screenTop", "window.__d('screenTop',4405)", "window.__u('screenTop')", "4405"),
    ("screen.pixelDepth", "window.__d2(screen,'pixelDepth',4406)", "window.__u2(screen,'pixelDepth')", "4406"),
    ("screen.availLeft", "window.__d2(screen,'availLeft',4407)", "window.__u2(screen,'availLeft')", "4407"),
    ("body.offsetHeight", "window.__d2(document.body,'offsetHeight',4408)",
     "window.__u2(document.body,'offsetHeight')", "4408"),
    ("body.scrollHeight", "window.__d2(document.body,'scrollHeight',4409)",
     "window.__u2(document.body,'scrollHeight')", "4409"),
    ("docEl.scrollWidth", "window.__d2(document.documentElement,'scrollWidth',4410)",
     "window.__u2(document.documentElement,'scrollWidth')", "4410"),
    ("docEl.offsetWidth", "window.__d2(document.documentElement,'offsetWidth',4411)",
     "window.__u2(document.documentElement,'offsetWidth')", "4411"),
    ("body.offsetWidth", "window.__d2(document.body,'offsetWidth',4412)",
     "window.__u2(document.body,'offsetWidth')", "4412"),
    ("body.clientWidth", "window.__d2(document.body,'clientWidth',4413)",
     "window.__u2(document.body,'clientWidth')", "4413"),
]

HELPERS = r"""
window.__saved = window.__saved || [];
window.__d = function(k, v){
  var d = Object.getOwnPropertyDescriptor(window, k);
  window.__saved.push([k, d]);
  Object.defineProperty(window, k, {get: function(){ return v; }, configurable: true});
};
window.__u = function(k){
  for (var i = window.__saved.length - 1; i >= 0; i--) {
    if (window.__saved[i][0] === k) {
      var d = window.__saved[i][1];
      delete window[k];
      if (d) Object.defineProperty(window, k, d);
      window.__saved.splice(i, 1);
      return;
    }
  }
};
window.__saved2 = window.__saved2 || [];
window.__d2 = function(o, k, v){
  var d = Object.getOwnPropertyDescriptor(o, k);
  window.__saved2.push([o, k, d]);
  try { Object.defineProperty(o, k, {get: function(){ return v; }, configurable: true}); }
  catch (e) { return 'ERR'; }
  return 'OK';
};
window.__u2 = function(o, k){
  for (var i = window.__saved2.length - 1; i >= 0; i--) {
    if (window.__saved2[i][0] === o && window.__saved2[i][1] === k) {
      var d = window.__saved2[i][2];
      try { delete o[k]; } catch (e) {}
      if (d) { try { Object.defineProperty(o, k, d); } catch (e) {} }
      window.__saved2.splice(i, 1);
      return;
    }
  }
};
"""


def main():
    hy = F.BrowserHybrid()
    hy._launch()
    t = hy._new_target()
    c = F._CDP(t["webSocketDebuggerUrl"])
    out = os.path.join(HERE, "kcalib", "pp_%d" % int(time.time()))
    os.makedirs(out, exist_ok=True)
    try:
        for m in ("Runtime.enable", "Page.enable", "Network.enable", "Debugger.enable"):
            c.call(m)
        c.call("Page.navigate", url=hy.PAGE)
        time.sleep(1.5)
        c.ev(hy.LOAD % F.AID)
        for _ in range(80):
            time.sleep(0.5)
            if c.ev("typeof window.TDC") == "object":
                break
        for _ in range(60):
            time.sleep(0.5)
            if c.ev("!!document.querySelector('.tencent-captcha-dy__slider-block')"):
                break
        time.sleep(1.2)
        hy._drain(c)
        js = C.get_tdc_source(c)
        if js:
            open(os.path.join(out, "tdc.js"), "w", encoding="utf-8").write(js)
        c.ev(HELPERS)

        def shot(name):
            d = c.ev("TDC.getData()")
            open(os.path.join(out, name + ".txt"), "w").write(d)
            return d

        base = shot("base")
        prm = T.params(os.path.join(out, "tdc.js"), base)
        print("params split=%d" % prm["split"])

        def toks(d):
            return [x.strip() for x in T.tokenize(T.decrypt(d, prm))]

        bt = toks(base)
        print("base %d token" % len(bt))
        for i, v in enumerate(bt):
            print("  %02d %r" % (i, v[:40]))
        open(os.path.join(out, "base.pt"), "wb").write(T.decrypt(base, prm))

        cases = CASES2 if (len(sys.argv) > 1 and sys.argv[1] == "2") else CASES
        for label, setter, restorer, want in cases:
            r = c.ev(setter)
            if isinstance(r, dict) and r.get("__exc"):
                print("%-24s setter 失败 %s" % (label, str(r)[:80]))
                c.ev(restorer)
                continue
            time.sleep(0.15)
            try:
                t2 = toks(shot("m_" + label.replace(".", "_")))
            except SystemExit as exc:
                print("%-24s 解密失败 %s" % (label, exc))
                c.ev(restorer)
                continue
            c.ev(restorer)
            time.sleep(0.1)
            diff = [(i, bt[i][:24], t2[i][:24]) for i in range(min(len(bt), len(t2)))
                    if bt[i] != t2[i]]
            same = [i for i in range(min(len(bt), len(t2)))
                    if bt[i] != t2[i] and (want in t2[i] if want != "None" else False)]
            print("%-24s %s%s" % (label, diff,
                                  "  <= 命中 %s" % want if same else ""))
        print("产出 ->", out)
    finally:
        try:
            c.ws.close()
        except Exception:
            pass
        hy._close_target(t["id"])
        if hy.proc is not None:
            try:
                hy.proc.terminate()
            except Exception:
                pass


if __name__ == "__main__":
    main()
