# -*- coding: utf-8 -*-
"""混合方案的侦察步：在真实浏览器里弹验证码，抓本会话的 prehandle 与弹窗几何。

目的：collect 必须由「本会话自己的 tdc.js」生成才可能被服务端认可
（tdc.js 每次请求重新随机化，静态 PROFILE 必然过期）。所以混合方案是
    Python 算答案  +  浏览器本会话的 SDK 出 collect  ——> 合并提交
本脚本只做侦察，不发 verify：
    1) 打开测试台，以 AID 弹验证码
    2) Network 域抓 cap_union_prehandle 响应体（sid / init_pos / 图片 URL）
    3) dump 弹窗里所有 tencent-captcha 元素的盒模型，找滑块把手
    4) 存 screenshot + JSON

用法：python hybrid_recon.py
产出：scripts/hybrid_recon.json、scripts/hybrid_prehandle.json、
      fastmoss_popup3.png
"""
import base64
import json
import os
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)

import fastmoss_probe as P

DUMP = r"""
(function(){
  var out = {nodes: [], imgs: [], html: document.documentElement.outerHTML.length};
  var all = document.querySelectorAll('[class*="tencent-captcha"],[id*="tcaptcha"],[id*="tCaptcha"]');
  for (var i = 0; i < all.length; i++) {
    var el = all[i], r = el.getBoundingClientRect();
    if (r.width < 1 && r.height < 1) continue;
    var cs = getComputedStyle(el);
    out.nodes.push({
      tag: el.tagName, cls: String(el.className).slice(0, 90), id: el.id,
      box: [Math.round(r.left), Math.round(r.top), Math.round(r.width), Math.round(r.height)],
      bg: (cs.backgroundImage || 'none').slice(0, 120),
      pos: cs.backgroundPosition, size: cs.backgroundSize,
      tf: (cs.transform || 'none').slice(0, 60),
      cur: cs.cursor, op: cs.opacity, z: cs.zIndex
    });
  }
  return out;
})()
"""


def drain(c, rounds=8, pause=0.25):
    """借一次无害调用把已到达的 CDP 事件收进 c.events。"""
    for _ in range(rounds):
        c.call("Runtime.evaluate", expression="1")
        time.sleep(pause)


def grab_responses(c, needle):
    """从 c.events 里挑出 URL 含 needle 的响应体。"""
    out = []
    for e in c.events:
        if e.get("method") != "Network.responseReceived":
            continue
        p = e["params"]
        url = p["response"].get("url", "")
        if needle not in url:
            continue
        try:
            body = c.call("Network.getResponseBody", requestId=p["requestId"])
        except Exception as exc:
            body = {"err": str(exc)[:120]}
        out.append({"url": url, "status": p["response"].get("status"),
                    "mime": p["response"].get("mimeType"),
                    "body": body.get("body", "")[:200000]})
    return out


def parse_jsonp(text):
    """prehandle 是 JSONP：_aq_xxxx({...})。"""
    t = text.strip()
    i, j = t.find("("), t.rfind(")")
    if i < 0 or j <= i:
        return None
    try:
        return json.loads(t[i + 1:j])
    except Exception:
        return None


def main():
    proc = P.launch()
    t = P.new_target()
    tid = t["id"]
    c = P.CDP(t["webSocketDebuggerUrl"])
    out = {}
    try:
        c.call("Runtime.enable")
        c.call("Page.enable")
        c.call("Network.enable")
        c.call("Page.navigate", url=P.PAGE)
        time.sleep(1.5)

        print("show:", c.ev(P.LOAD))
        for _ in range(80):
            time.sleep(0.5)
            if c.ev("typeof window.TDC") == "object":
                break
        # 等弹窗元素出现
        n = 0
        for _ in range(60):
            time.sleep(0.5)
            n = c.ev("document.querySelectorAll('[class*=\"tencent-captcha\"]')"
                     ".length") or 0
            if n:
                break
        print("captcha nodes:", n)
        time.sleep(1.0)
        drain(c)

        pres = grab_responses(c, "cap_union_prehandle")
        print("prehandle responses captured:", len(pres))
        pre = None
        for r in reversed(pres):
            pre = parse_jsonp(r["body"])
            if pre:
                break
        if pre:
            json.dump(pre, open(os.path.join(HERE, "hybrid_prehandle.json"), "w"),
                      ensure_ascii=False, indent=1)
            d = pre.get("data") or {}
            dsi = d.get("dyn_show_info") or {}
            fg = [e for e in dsi.get("fg_elem_list", []) if e.get("id") == 1]
            print("  sess len:", len(pre.get("sess") or ""))
            print("  init_pos:", fg[0].get("init_pos") if fg else None)
            print("  bg url:", (dsi.get("bg_elem_cfg") or {}).get("img_url"))
            print("  sprite:", (dsi.get("sprite_url") or "")[:80])
            print("  tdc_path:", ((d.get("comm_captcha_cfg") or {})
                                   .get("tdc_path") or "")[:70])
        else:
            print("  !! prehandle body not captured")

        dump = c.ev(DUMP)
        out["dom"] = dump
        for nd in (dump or {}).get("nodes", []):
            print("  %-6s %-52s %-16s box=%-20s bg=%s pos=%s size=%s tf=%s cur=%s"
                  % (nd["tag"], (nd["cls"] or "")[:52], nd["id"][:16],
                     nd["box"], (nd["bg"] or "")[:40], nd["pos"], nd["size"],
                     (nd["tf"] or "")[:20], nd["cur"]))

        ver = grab_responses(c, "cap_union_new_verify")
        print("verify responses (should be 0):", len(ver))
        out["prehandle_captured"] = bool(pre)
        out["verify_count"] = len(ver)

        shot = c.call("Page.captureScreenshot", format="png")
        b = base64.b64decode(shot["data"])
        open(os.path.join(ROOT, "fastmoss_popup3.png"), "wb").write(b)
        print("screenshot fastmoss_popup3.png", len(b), "B")
        json.dump(out, open(os.path.join(HERE, "hybrid_recon.json"), "w"),
                  ensure_ascii=False, indent=1)
    finally:
        try:
            c.ws.close()
        except Exception:
            pass
        P.close_target(tid)
        if proc is not None:
            try:
                proc.terminate()
            except Exception:
                pass


if __name__ == "__main__":
    main()
