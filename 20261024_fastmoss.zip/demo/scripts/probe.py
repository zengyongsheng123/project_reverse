# -*- coding: utf-8 -*-
"""Probe: pure-python prehandle + image fetch. Prints parsed config."""
import json, re, base64, random, time, sys
import requests

UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36"
BASE = "https://turing.captcha.qcloud.com"
R = requests.Session()
R.headers.update({
    "User-Agent": UA,
    "Accept": "*/*",
    "Referer": "https://cloud.tencent.com/",
    "sec-ch-ua": '"Chromium";v="146", "Not-A.Brand";v="24", "Google Chrome";v="146"',
    "sec-ch-ua-mobile": "?0",
    "sec-ch-ua-platform": '"Windows"',
})

AID = "192962660"

def prehandle(tkid=None):
    tkid = tkid or str(int(time.time() * 1000) % 1000000000)
    cb = "_aq_%d" % random.randint(10000, 99999)
    params = {
        "aid": AID, "protocol": "https", "accver": "1", "showtype": "popup",
        "ua": base64.b64encode(UA.encode()).decode(),
        "noheader": "1", "fb": "1", "aged": "0", "enableAged": "0",
        "enableDarkMode": "0", "grayscale": "1", "clientype": "2",
        "cap_cd": "", "uid": "", "lang": "zh-cn",
        "entry_url": "https://cloud.tencent.com/product/captcha",
        "elder_captcha": "0", "js": "/tgJCap.2f0b2c65.js", "login_appid": "",
        "wb": "2", "tkid": tkid, "subsid": "1", "callback": cb, "sess": "",
    }
    r = R.get(BASE + "/cap_union_prehandle", params=params, timeout=10)
    m = re.search(r"^%s\((.*)\)$" % re.escape(cb), r.text, re.S)
    data = json.loads(m.group(1))
    return tkid, data

def get_img(path, tkid):
    r = R.get(BASE + path, timeout=10)
    return r.content

if __name__ == "__main__":
    tkid, d = prehandle()
    print("tkid", tkid, "state", d.get("state"))
    print(json.dumps(d, ensure_ascii=False, indent=1)[:4000])
    dinfo = d["data"]["dyn_show_info"]
    bg = get_img(dinfo["bg_elem_cfg"]["img_url"] + "&tkid=" + tkid, tkid)
    sp = get_img(dinfo["sprite_url"] + "&tkid=" + tkid, tkid)
    open("img_bg.bin", "wb").write(bg)
    open("img_sprite.bin", "wb").write(sp)
    print("bg bytes", len(bg), "sprite bytes", len(sp))
    from PIL import Image
    import io
    for n, b in (("bg", bg), ("sprite", sp)):
        im = Image.open(io.BytesIO(b))
        print(n, im.size, im.mode)
        im.save("img_%s.png" % n)
    json.dump({"tkid": tkid, "resp": d}, open("prehandle.json", "w"), ensure_ascii=False)
