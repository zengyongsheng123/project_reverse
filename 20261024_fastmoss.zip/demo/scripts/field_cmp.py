# -*- coding: utf-8 -*-
"""比较 Node 与浏览器两条 collect 明文的「非轨迹字段」集合。

轨迹三元组 [dx,dy,dt] 会被替换成 TRIPLE，其余按顶层逗号切开做集合比对。
用来发现 Node 路径是不是少了/多了字段（服务端按字段取值，少一个就会异常）。

用法：python field_cmp.py <node_tdc.js> <node_collect.txt> <browser_plaintext.txt>
"""
import difflib
import re
import sys

HERE = __import__("os").path.dirname(__file__)
sys.path.insert(0, HERE)

import build_diff as B

js_path, node_collect, brow_pt = sys.argv[1:4]
node_pt, _ = B.decrypt(js_path, open(node_collect).read().strip(), "node")
node_pt = node_pt.decode("latin-1")
brow_pt = open(brow_pt, "r", encoding="latin-1").read().strip()

TRIPLE = re.compile(r"\[\s*-?\d+\s*,\s*-?\d+\s*,\s*\d+\s*\]")


def fields(s):
    """截取 {"cd":[ 到 "sd": 之间的内容，把轨迹三元组折叠掉，再按顶层逗号切。"""
    i = s.find('{"cd":[')
    j = s.find('"sd":')
    s2 = TRIPLE.sub("TRIPLE", s[i + 8:j] if i >= 0 and j > i else s)
    toks, depth, cur, instr, esc = [], 0, "", False, False
    for ch in s2:
        if instr:
            cur += ch
            if esc:
                esc = False
            elif ch == "\\":
                esc = True
            elif ch == '"':
                instr = False
            continue
        if ch == '"':
            instr = True
            cur += ch
            continue
        if ch in "([{":
            depth += 1
        if ch in ")]}":
            # 明文里的括号是故意不平衡的（服务端不用 JSON 解析），
            # 所以深度夹在 0 以上，否则后面所有逗号都切不开。
            depth = max(0, depth - 1)
        if ch == "," and depth == 0:
            toks.append(cur.strip())
            cur = ""
        else:
            cur += ch
    toks.append(cur.strip())
    return [t for t in toks]


tn, tb = fields(node_pt), fields(brow_pt)
print("node fields %d / browser fields %d" % (len(tn), len(tb)))
print("-- node --")
for t in tn:
    print("| %s" % t[:100])
print("-- diff (browser vs node, sorted) --")
for line in difflib.unified_diff(sorted(tb), sorted(tn), "browser", "node",
                                 lineterm="", n=0):
    print("| %s" % line[:110])
