# -*- coding: utf-8 -*-
"""同一份 tdc.js，分别在浏览器和 Node 里出 collect，逐字段比对（不提交）。

这是定位「Node 出的 collect 和浏览器差在哪」的专用工具：同 build 的字段
顺序是固定的，所以可以按下标一一对照。浏览器只用来 TDC.getData()，不会
触发任何 verify 请求。

用法：python build_diff.py
产出：scripts/kcalib/diff_<ts>/tdc.js、browser.txt、node.txt、diff.txt
"""
import json
import os
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
sys.path.insert(0, ROOT)

import fastmoss_flow as F
import kcalib


def tokenize(pt):
    """把明文里的 "cd" 数组拆成 token 文本（容忍无值的空 token）。"""
    s = pt.decode("latin-1")
    i = s.find('{"cd":[')
    if i < 0:
        return []
    j = i + len('{"cd":[')
    depth, in_str, esc, start, out = 0, False, False, j, []
    while j < len(s):
        ch = s[j]
        if in_str:
            if esc:
                esc = False
            elif ch == "\\":
                esc = True
            elif ch == '"':
                in_str = False
        else:
            if ch == '"':
                in_str = True
            elif ch in "[{(":
                depth += 1
            elif ch in "]}":
                if depth == 0:
                    out.append(s[start:j])
                    return out
                depth -= 1
            elif ch == ",":
                if depth == 0:
                    out.append(s[start:j])
                    start = j + 1
        j += 1
    return out


def decrypt(js_path, collect, want="node"):
    info = kcalib.analyse(js_path, collect)
    if not info["hits"]:
        raise SystemExit("%s collect 解不开" % want)
    h = info["hits"][0]
    tag = tuple(tuple(x) for x in h["tag"])
    key = None
    for k, v in info["keys"]:
        if tuple(tuple(x) for x in k) == tag:
            key = [int(x, 16) for x in v]
    raw = __import__("base64").b64decode(
        __import__("urllib.parse", fromlist=["x"]).unquote(collect))
    hits = kcalib.try_decrypt(raw, [(tag, key)], [h["case"]])
    if not hits:
        raise SystemExit("%s collect 二次解密失败" % want)
    return hits[0]["pt"], h


def main():
    tag = "diff_%d" % int(time.time())
    outdir = os.path.join(HERE, "kcalib", tag)
    os.makedirs(outdir, exist_ok=True)

    print("== 浏览器：打开验证码，取本 build 的 tdc.js 和真 collect（不提交）")
    js, bcollect, _pre = kcalib.collect_session()
    jsp = os.path.join(outdir, "tdc.js")
    open(jsp, "w", encoding="utf-8").write(js)
    open(os.path.join(outdir, "browser.txt"), "w").write(bcollect)
    print("   tdc.js %d 字符，浏览器 collect %d 字符" % (len(js), len(bcollect)))

    print("== Node：同一份 tdc.js 出 collect")
    nc = F.NodeCollector(events=False)
    ncollect, eks = nc.collect(js)
    open(os.path.join(outdir, "node.txt"), "w").write(ncollect)
    print("   Node collect %d 字符，eks %d 字符" % (len(ncollect), len(eks)))

    bpt, bh = decrypt(jsp, bcollect, "browser")
    npt, nh = decrypt(jsp, ncollect, "node")
    open(os.path.join(outdir, "browser.pt"), "wb").write(bpt)
    open(os.path.join(outdir, "node.pt"), "wb").write(npt)

    tb, tn = tokenize(bpt), tokenize(npt)
    lines = []
    print("\n== 对照（browser=%d token，node=%d token）" % (len(tb), len(tn)))
    lines.append("browser=%d token, node=%d token" % (len(tb), len(tn)))
    for i in range(max(len(tb), len(tn))):
        a = tb[i] if i < len(tb) else "<missing>"
        x = tn[i] if i < len(tn) else "<missing>"
        same = a.strip() == x.strip()
        mark = "  " if same else "!!"
        line = "%s %02d %-46r | %r" % (mark, i, a[:46], x[:46])
        print(line)
        lines.append(line)
    print("\n不一致 token：%d / %d"
          % (sum(1 for i in range(max(len(tb), len(tn)))
                 if (tb[i] if i < len(tb) else "").strip()
                 != (tn[i] if i < len(tn) else "").strip()),
             max(len(tb), len(tn))))
    print("sd 尾部：browser=%r node=%r"
          % (bpt.decode("latin-1")[-60:], npt.decode("latin-1")[-60:]))
    open(os.path.join(outdir, "diff.txt"), "w",
         encoding="utf-8").write("\n".join(lines))
    print("产出 ->", outdir)


if __name__ == "__main__":
    main()
