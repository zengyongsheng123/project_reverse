# -*- coding: utf-8 -*-
"""Capture one full cipher pass from the LIVE page, same build:

  * every trampoline invoked with a single 2-number array argument
    -> pre-mutation [w0,w1], the array objectId, and (later) its
       post-mutation value
  * the register-file upvalue (key array) at the first such hit
  * the final TDC.getData() payload

Everything is read-only instrumentation on the user's own browser.

Usage: python capture_full.py [name]
Writes capture_full_<name>.json
"""
import http.client
import json
import sys
import time

import websocket

PORT = 9222
NAME = sys.argv[1] if len(sys.argv) > 1 else "a"


def targets():
    c = http.client.HTTPConnection("127.0.0.1", PORT, timeout=5)
    c.request("GET", "/json")
    return json.loads(c.getresponse().read())


class CDP:
    def __init__(self, url):
        self.ws = websocket.create_connection(url, timeout=180, suppress_origin=True)
        self.i = 0
        self.events = []
        self.auto_resume = False

    def send(self, method, **p):
        self.i += 1
        self.ws.send(json.dumps({"id": self.i, "method": method, "params": p}))
        return self.i

    def recv(self, timeout):
        self.ws.settimeout(timeout)
        return json.loads(self.ws.recv())

    def call(self, method, timeout=60, **p):
        mid = self.send(method, **p)
        end = time.time() + timeout
        while True:
            m = self.recv(max(0.5, end - time.time()))
            if m.get("id") == mid:
                if "error" in m:
                    raise RuntimeError("%s -> %s" % (method, m["error"]))
                return m.get("result", {})
            if "method" in m:
                self.events.append(m)
                if m["method"] == "Debugger.paused" and self.auto_resume:
                    self.i += 1
                    self.ws.send(json.dumps(
                        {"id": self.i, "method": "Debugger.resume", "params": {}}))

    def ev(self, expr, timeout=120):
        r = self.call("Runtime.evaluate", expression=expr, returnByValue=True,
                      awaitPromise=True, timeout=timeout)
        if r.get("exceptionDetails"):
            return {"__exc": str(r["exceptionDetails"])[:300]}
        return r.get("result", {}).get("value")


PROBE = r"""
(function(AR){
  try{
    var sh=[];
    for(var i=0;i<AR.length && i<4;i++){
      var v=AR[i], t=typeof v;
      if(v&&t==='object'&&typeof v.length==='number'){
        var e=[];for(var j=0;j<Math.min(v.length,4);j++)e.push(typeof v[j]==='number'?(v[j]>>>0):(v[j]===undefined?'u':typeof v[j]));
        sh.push('['+e.join(',')+']len'+v.length);
      } else if(t==='number') sh.push(String(v>>>0));
      else if(t==='string') sh.push('s:'+v.slice(0,12));
      else sh.push(t);
    }
    var o={sh:'n'+AR.length+':'+sh.join('|')};
    if(AR.length===1 && AR[0] && typeof AR[0]==='object' && AR[0].length===2 &&
       typeof AR[0][0]==='number' && typeof AR[0][1]==='number')
      o.ps=JSON.stringify([AR[0][0]>>>0, AR[0][1]>>>0]), o.a=AR[0];
    return o;
  }catch(e){ return {sh:'ERR:'+String(e).slice(0,80)}; }
})(arguments)
"""

DEEP = r"""
function(){
  var v=this, out={tag:Object.prototype.toString.call(v)};
  if(typeof v.length==='number'){
    out.len=v.length; out.e=[];
    for(var i=0;i<Math.min(v.length,16);i++){
      var x=v[i];
      if(typeof x==='number') out.e.push(x>>>0);
      else if(x&&typeof x==='object'&&typeof x.length==='number'){
        var q=[];for(var j=0;j<Math.min(x.length,8);j++){var y=x[j];
          q.push(typeof y==='number'?(y>>>0):(y===undefined?'u':typeof y))}
        out.e.push({len:x.length,e:q});
      } else out.e.push(x===undefined?'u':typeof x);
    }
  }
  return JSON.stringify(out);
}
"""


def dump_scopes(c, cf):
    scopes = []
    for sc in cf.get("scopeChain", []):
        if sc.get("type") not in ("closure", "local", "block"):
            continue
        oid = (sc.get("object") or {}).get("objectId")
        if not oid:
            continue
        try:
            props = c.call("Runtime.getProperties", objectId=oid, ownProperties=True)
        except Exception as e:
            scopes.append({"type": sc.get("type"), "err": str(e)[:80]})
            continue
        vars_ = {}
        for p in props.get("result", []):
            name = p.get("name")
            val = p.get("value") or {}
            if not name or name in ("this",):
                continue
            if val.get("type") == "number":
                vars_[name] = {"n": val.get("value")}
            elif val.get("type") == "object" and val.get("objectId"):
                try:
                    r = c.call("Runtime.callFunctionOn", objectId=val["objectId"],
                               functionDeclaration=DEEP, returnByValue=True)
                    vars_[name] = json.loads(r.get("result", {}).get("value") or "{}")
                except Exception as e:
                    vars_[name] = {"err": str(e)[:60]}
        scopes.append({"type": sc.get("type"), "vars": vars_})
    return scopes


def find_key(scopes):
    keys = []
    for sc in scopes:
        for name, d in (sc.get("vars") or {}).items():
            if not isinstance(d, dict) or d.get("len") != 8:
                continue
            e = d.get("e") or []
            if len(e) > 7 and isinstance(e[7], dict):
                inner = e[7].get("e") or []
                if len(inner) >= 1 and isinstance(inner[0], dict):
                    arr = inner[0].get("e") or []
                    if len(arr) == 4 and all(isinstance(x, int) for x in arr):
                        keys.append({"var": name, "key": arr})
    return keys


def main():
    pg = [t for t in targets() if t.get("type") == "page"][0]
    c = CDP(pg["webSocketDebuggerUrl"])
    c.call("Runtime.enable")
    c.auto_resume = True
    c.call("Debugger.enable")
    time.sleep(0.3)

    proto = c.call("Runtime.evaluate", expression="Function.prototype")["result"]["objectId"]
    objs = c.call("Runtime.queryObjects", prototypeObjectId=proto)["objects"]["objectId"]
    finder = ("function(){var out=[];for(var i=0;i<this.length;i++){try{"
              "if(Function.prototype.toString.call(this[i]).indexOf('__TENCENT_CHAOS_VM')>=0)"
              "out.push(this[i])}catch(e){}}return out}")
    r = c.call("Runtime.callFunctionOn", objectId=objs, functionDeclaration=finder,
               returnByValue=False)
    props = c.call("Runtime.getProperties", objectId=r["result"]["objectId"], ownProperties=True)
    fns = [p["value"]["objectId"] for p in props.get("result", [])
           if p.get("name", "").isdigit() and (p.get("value") or {}).get("objectId")]
    print("trampolines:", len(fns))

    bp_map = {}
    for oid in fns:
        try:
            bid = c.call("Debugger.setBreakpointOnFunctionCall", objectId=oid).get("breakpointId")
            bp_map[bid] = oid
        except RuntimeError as e:
            if "already exists" not in str(e):
                raise
    print("breakpoints:", len(bp_map))

    c.auto_resume = False
    print("reset:", c.ev("(function(){try{window.__probe.fcc4=[];return 1}catch(e){return 0}})()"))
    mid = c.send("Runtime.evaluate", expression="(function(){return TDC.getData()})()",
                 returnByValue=True, awaitPromise=True)
    hits, arrays, keyrec = [], [], None
    probes, hitcount = {}, {}
    shape_count = {}
    npauses = 0
    done = None

    def next_pause(timeout=1.0):
        # pauses that arrived while a generic call() was waiting are queued
        # in c.events; replay them first or the page stays suspended.
        for k, e in enumerate(c.events):
            if e.get("method") == "Debugger.paused":
                return c.events.pop(k)
        while True:
            m = c.recv(timeout)
            if m.get("method") == "Debugger.paused":
                return m
            if m.get("id") == mid:
                return m
            c.events.append(m)

    end = time.time() + 300
    while time.time() < end:
        try:
            m = next_pause()
        except Exception:
            continue
        if m.get("id") == mid:
            done = m
            break
        if m.get("method") != "Debugger.paused":
            continue
        npauses += 1
        params = m["params"]
        cf = params["callFrames"][0]
        bids = params.get("hitBreakpoints") or []
        bid = bids[0] if bids else "?"
        rec = None
        probes[bid] = probes.get(bid, 0) + 1
        try:
            rr = c.call("Debugger.evaluateOnCallFrame", callFrameId=cf["callFrameId"],
                        expression=PROBE, returnByValue=False, silent=True)
            obj = rr.get("result") or {}
            if obj.get("objectId"):
                pr = c.call("Runtime.getProperties", objectId=obj["objectId"],
                            ownProperties=True)
                vals = {p.get("name"): p.get("value") for p in pr.get("result", [])}
                sh = (vals.get("sh") or {}).get("value")
                if isinstance(sh, str):
                    shape_count[sh] = shape_count.get(sh, 0) + 1
                ps = (vals.get("ps") or {}).get("value")
                arr_oid = (vals.get("a") or {}).get("objectId")
                if isinstance(ps, str) and arr_oid:
                    pv = json.loads(ps)
                    if len(pv) == 2:
                        rec = {"pre": pv, "oid": arr_oid}
        except Exception:
            pass
        if rec:
            hitcount[bid] = hitcount.get(bid, 0) + 1
            rec["bp"] = bid
            rec["i"] = len(hits)
            hits.append(rec)
            arrays.append(rec["oid"])
            if keyrec is None:
                sc = dump_scopes(c, cf)
                keyrec = {"scopes": sc, "keys": find_key(sc),
                          "fn": cf.get("functionName")}
                print("KEYREC keys:", keyrec["keys"])
        c.call("Debugger.resume")
    print("pauses:", npauses, "hits:", len(hits), "done:", bool(done))
    data = None
    if done:
        data = (((done.get("result") or {}).get("result") or {}).get("value"))
    print("data len:", len(data) if data else None)

    # post-mutation reads
    post = []
    for oid in arrays:
        try:
            r = c.call("Runtime.callFunctionOn", objectId=oid, returnByValue=True,
                       functionDeclaration="function(){return [this[0]>>>0,this[1]>>>0,this.length]}")
            post.append((r.get("result") or {}).get("value"))
        except Exception as e:
            post.append({"err": str(e)[:60]})
    fcc = c.ev("(function(){var D=window.__probe;return D?D.fcc4:null})()")
    out = {"data": data, "hits": hits, "post": post, "fcc": fcc,
           "keyrec": keyrec, "counts": {"pauses": npauses, "hits": len(hits)},
           "hitcount": hitcount, "shapes": shape_count}
    fn = "capture_full_%s.json" % NAME
    json.dump(out, open(fn, "w"), ensure_ascii=False)
    print("wrote", fn, "fcc:", len(fcc) if fcc else 0)

    for b in list(bp_map):
        try:
            c.call("Debugger.removeBreakpoint", breakpointId=b)
        except Exception:
            pass


if __name__ == "__main__":
    main()
