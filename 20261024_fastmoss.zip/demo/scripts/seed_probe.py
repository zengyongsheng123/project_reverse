# -*- coding: utf-8 -*-
"""Where does the per-page `seed` token in the collect plaintext come from?

`seed` is a random-looking 32-bit value, constant for a page (e.g. cur2
2120394880, user page 1961369642, another build 1950354050).  This script
opens its own fresh tab with Math.random / crypto.getRandomValues / Date.now /
performance.now hooks installed BEFORE navigation, opens the captcha modal,
samples getData() twice and saves both the samples and the hook log.

Run derive_build.py offline on the result, decrypt a sample, and match the
static numeric token against the hook values.

It never touches the user's tab.

Usage: python seed_probe.py [name]
Writes js/live_src/tdc_<name>.js/.json and scripts/fresh_probe_<name>.json
(the probe file also carries a "hooks" object).
"""
import hashlib
import json
import os
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
JS = os.path.join(ROOT, "js")
sys.path.insert(0, HERE)

import instrument_eks_init as I
import fresh_session as F

HOOK = r"""
(function(){
  var L = {mr: [], gr: [], dn: [], pn: [], wk: [], blob: [], uuid: []};
  window.__SEEDLOG = L;
  try {
    var OW = window.Worker;
    window.Worker = function(u, o){
      try { L.wk.push({u: String(u).slice(0, 300), t: typeof u}); } catch(e){}
      return new OW(u, o);
    };
    window.Worker.prototype = OW.prototype;
  } catch(e){}
  try {
    var ocu = URL.createObjectURL;
    URL.createObjectURL = function(b){
      var u = ocu.call(URL, b);
      try {
        L.blob.push({u: u, size: b.size, type: b.type});
        if (L.blob.length <= 5 && b.size < 2e6) {
          b.text().then(function(t){ (window.__SEEDBLOBS = window.__SEEDBLOBS || {})[u] = t; });
        }
      } catch(e){}
      return u;
    };
  } catch(e){}
  try {
    var oru = crypto.randomUUID.bind(crypto);
    crypto.randomUUID = function(){
      var v = oru();
      if (L.uuid.length < 50) L.uuid.push(v);
      return v;
    };
  } catch(e){}
  var omr = Math.random;
  Math.random = function(){
    var v = omr.call(Math);
    if (L.mr.length < 600) L.mr.push(v);
    return v;
  };
  try {
    var ogr = crypto.getRandomValues.bind(crypto);
    crypto.getRandomValues = function(a){
      var r = ogr(a);
      try { if (L.gr.length < 100) L.gr.push({n: a.length,
              v: Array.prototype.slice.call(a, 0, 8)}); } catch(e){}
      return r;
    };
  } catch(e){}
  var odn = Date.now;
  Date.now = function(){
    var v = odn();
    if (L.dn.length < 300) L.dn.push(v);
    return v;
  };
  var opn = performance.now.bind(performance);
  performance.now = function(){
    var v = opn();
    if (L.pn.length < 300) L.pn.push(v);
    return v;
  };
})();
"""


def collect(name):
    t = I.new_target()
    tid = t["id"]
    print("    fresh target", tid)
    c = I.CDP(t["webSocketDebuggerUrl"])
    try:
        c.call("Runtime.enable")
        c.call("Page.enable")
        c.call("Debugger.enable")
        c.call("Page.addScriptToEvaluateOnNewDocument", source=HOOK)
        c.call("Page.navigate", url=I.URL)
        tdc = "?"
        for _ in range(40):
            time.sleep(0.5)
            tdc = c.ev("typeof window.TDC", await_promise=False)
            if tdc == "object":
                break
        if tdc != "object":
            c.ev("(function(){var b=[...document.querySelectorAll('a.tpm-btn')]"
                 ".filter(function(e){return e.textContent.trim()==='立即体验';})[0];"
                 "if(b){b.click();return 1}return 0})()", await_promise=False)
            for _ in range(60):
                time.sleep(0.5)
                tdc = c.ev("typeof window.TDC", await_promise=False)
                if tdc == "object":
                    break
        if tdc != "object":
            raise SystemExit("TDC never appeared")

        url, sid = F._tdc_source(c)
        if sid is None:
            raise SystemExit("no tdc.js script")
        src = c.call("Debugger.getScriptSource", scriptId=sid).get("scriptSource", "")
        sha = hashlib.sha256(src.encode("utf-8", "surrogatepass")).hexdigest()[:16]
        os.makedirs(os.path.join(JS, "live_src"), exist_ok=True)
        src_path = os.path.join(JS, "live_src", "tdc_%s.js" % name)
        open(src_path, "w", encoding="utf-8").write(src)
        json.dump({"url": url, "scriptId": sid, "len": len(src),
                   "sha256_16": sha, "saved": src_path},
                  open(os.path.join(JS, "live_src", "tdc_%s.json" % name), "w"),
                  indent=1)
        print("    tdc.js %d chars sha %s" % (len(src), sha))

        samples = []
        for k in range(2):
            if k == 1:
                time.sleep(1.2)
            before = c.ev("Math.floor(Date.now()/1000)", await_promise=False)
            d = c.ev("TDC.getData()", await_promise=False)
            after = c.ev("Math.floor(Date.now()/1000)", await_promise=False)
            samples.append({"d": d, "now": before, "after": after})
            print("    getData #%d chars=%s" % (k + 1, len(d or "")))
        hooks = json.loads(c.ev("JSON.stringify(window.__SEEDLOG)",
                                await_promise=False) or "{}")
        hooks["blobs"] = json.loads(
            c.ev("JSON.stringify(window.__SEEDBLOBS||{})", await_promise=False) or "{}")
    finally:
        try:
            c.ws.close()
        except Exception:
            pass
        I.close_target(tid)

    probe = os.path.join(HERE, "fresh_probe_%s.json" % name)
    json.dump({"sha256_16": sha, "src": src_path, "datas": samples,
               "hooks": hooks}, open(probe, "w"), indent=1)
    print("    wrote", probe, "| random()=%d getRandomValues()=%d"
          % (len(hooks.get("mr", [])), len(hooks.get("gr", []))))
    return {"src": src_path, "probe": probe, "sha": sha}


if __name__ == "__main__":
    collect(sys.argv[1] if len(sys.argv) > 1 else "seed")
