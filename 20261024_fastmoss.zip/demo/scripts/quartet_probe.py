# -*- coding: utf-8 -*-
"""受控实验：拿浏览器真 collect，只把「Node 和浏览器不一致的那几个字段」改成
Node 的值，再重新加密发出去 —— 看服务端是不是就因为这几个字段拒。

为什么这么设计：
  transport_probe.py 已经证明「浏览器真 collect 由 Python 发」能过传输层（errorCode 50 =
  答案不对，不是 12）。所以现在唯一没量化的就是 collect 里的内容差异。与其去猜每个
  token 的语义，不如把差异本身当成变量：只改差异、别的一律不动，一条包看结论。

改哪些：Node 与浏览器同一 build 下明文不同的 token 里，属于「mystery 四元组」和
「验证码容器尺寸」的那些（浏览器 1007/0/0/0 + [360,363] → Node 的 0/22/3/40 + [929,883]）。
env hash / 时间戳 / 答案图这些本来就该随会话变，不动。

每次运行只发一条 verify。

用法：python quartet_probe.py [--dry-run]
"""
import base64
import json
import os
import sys
import urllib.parse

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
sys.path.insert(0, ROOT)

import fastmoss_flow as F
import token_probe as T
import build_diff as B

SKIP_HEADERS = {"content-length", "host", "connection", "accept-encoding"}
CD_HEAD = '{"cd":['


def cd_spans(pt):
    """切出 cd 数组里每个元素的 [start, end) 字节区间（token 文本原样）。

    要点：浏览器那条明文里拖动三元组会**插到 cd 中间**，形如
        ...,"<img>",   ,[1,-1,14],[...],...,[1,1,12]]   ,1792900276,0,...
    这里 `[1,1,12]]` 是两个 `]` 连着：第一个把该三元组收到 depth 1，第二个
    才落到 depth 0。所以不能见到 depth 0 的 `]` 就当数组结束 —— 要往后跳过空白看
    下一个字符：是 ',' 或 ']' 就说明只是拼接块的边界，继续切；否则才是 cd 结束。
    """
    s = pt.decode("latin-1")
    cd = s.find(CD_HEAD)
    if cd < 0:
        raise SystemExit("明文里没有 cd 数组")
    j = cd + len(CD_HEAD)
    depth, in_str, esc, start = 0, False, False, j
    spans = []
    while j < len(s):
        ch = s[j]
        if in_str:
            if esc:
                esc = False
            elif ch == "\\":
                esc = True
            elif ch == '"':
                in_str = False
        else:
            if ch == '"':
                in_str = True
            elif ch in "[{(":
                depth += 1
            elif ch in "]}":
                if depth > 0:
                    depth -= 1
                    if depth == 0:            # 内嵌块闭合 = 一个 token 结束
                        spans.append((start, j + 1))
                        # trail 块的拼接处后面可能紧跟逗号，也可能直接接下一段
                        k = j + 1
                        while k < len(s) and s[k] in " \t\r\n":
                            k += 1
                        start = k + 1 if (k < len(s) and s[k] == ",") else j + 1
                        j = k if start > j + 1 else j
                else:                          # depth==0 的 ']'
                    # 结尾特征是紧跟（隔空格/逗号）出现 "sd"；trail 拼接块后面接的是
                    # 下一个 token。只看后面几十个字节就够区分。
                    if '"sd"' in s[j:j + 60]:
                        spans.append((start, j))
                        break
                    spans.append((start, j + 1))
                    k = j + 1
                    while k < len(s) and s[k] in " \t\r\n":
                        k += 1
                    start = k + 1 if (k < len(s) and s[k] == ",") else k
                    j = k if start == k + 1 else k - 1
            elif ch == "," and depth == 0:
                spans.append((start, j))
                start = j + 1
        j += 1
    else:
        raise SystemExit("cd 数组没闭合")
    return s, spans


def patch_cd(pt, patches):
    """按 token 下标替换文本；长度变了就在 "sd" 前面的空白里补齐（明文必须是 8 的倍数）。"""
    s, spans = cd_spans(pt)
    out = s
    for idx in sorted(patches, reverse=True):
        a, b = spans[idx]
        out = out[:a] + patches[idx] + out[b:]
    pad = (-len(out)) % 8
    if pad:
        i = out.find('"sd"')
        if i < 0:
            raise SystemExit("找不到补位用的空白区")
        # 往前退到连续空白里插
        k = i
        while k > 0 and out[k - 1] == " ":
            k -= 1
        out = out[:k] + " " * pad + out[k:]
    return out.encode("latin-1")


def tokenize_spans(pt):
    s, spans = cd_spans(pt)
    return [(a, b, s[a:b].strip()) for a, b in spans]


def main():
    dry = "--dry-run" in sys.argv
    hy = F.BrowserHybrid()
    code, res = hy.run(intercept_verify=True)
    body = res.get("verify_body") or ""
    if not body:
        print("没截到 verify：", json.dumps(
            {k: v for k, v in res.items() if k != "cookies"}, ensure_ascii=False)[:500])
        return 1
    # 必须用本页真正加载的那份 tdc.js：prehandle 里另外给的 tdc_path 是另一次
    # 会话的 build，密钥对不上，collect 直接解不开。
    js = res.get("tdc_js") or ""
    if not js:
        print("没拿到本页 tdc.js 源码（Debugger 没抓到）")
        return 1
    jsp = os.path.join(HERE, ".quartet_tdc.js")
    open(jsp, "w", encoding="utf-8").write(js)
    print("tdc.js %d 字符" % len(js))

    kv = dict(urllib.parse.parse_qsl(body, keep_blank_values=True))
    bcollect = kv["collect"]
    print("浏览器 collect %d 字符 tlg=%s" % (len(bcollect), kv.get("tlg")))

    # 同一 build 在 Node 侧出 collect；两份都解开，按下标对照
    nc = F.NodeCollector(events=False)
    ncollect, n_eks = nc.collect(js)
    print("Node collect %d 字符 eks=%d" % (len(ncollect), len(n_eks)))

    # 密钥候选跟 collect 自身走（一个 build 里有多个 K 候选，选中哪个由内容决定），
    # 所以两条 collect 各自解各自的。
    prm_b = T.params(jsp, bcollect)
    prm_n = T.params(jsp, ncollect)
    print("浏览器明文参数 split=%d case=%s" % (prm_b["split"], prm_b["case"]))
    print("Node   明文参数 split=%d case=%s" % (prm_n["split"], prm_n["case"]))
    bpt = T.decrypt(bcollect, prm_b)
    try:
        npt = T.decrypt(ncollect, prm_n)
    except SystemExit:
        # token_probe 的接受条件要求明文头部就是 [[1,1,12]]；有的 build 把
        # 空格/顺序排得不一样，这里退回 build_diff 的解析器。
        npt = B.decrypt(jsp, ncollect, "node")
        print("Node 明文用 build_diff 解析器解出")
    open(os.path.join(HERE, "kcalib", "last_browser.pt"), "wb").write(bpt)
    open(os.path.join(HERE, "kcalib", "last_node.pt"), "wb").write(npt)
    btoks = tokenize_spans(bpt)                 # 浏览器：带 trail 块的下标/区间
    ntoks = [x.strip() for x in T.tokenize(npt)]  # Node：没有 trail，按普通 token 切
    bt = [t[2] for t in btoks]
    print("浏览器 token %d 个（含 trail 块），Node token %d 个" % (len(bt), len(ntoks)))
    cipher = F.TDCCipher(prm_b)

    # 回环自检：明文原样加密回去必须和浏览器那条一模一样
    rt = base64.b64decode(urllib.parse.unquote(cipher.get_data(bpt)))
    ob = base64.b64decode(urllib.parse.unquote(bcollect))
    print("回环一致：%s（%d 字节）" % (rt == ob, len(ob)))

    QUARTET_NODE = {"3", "22", "40"}
    # 浏览器明文里多出来的是拖动三元组（[dx,dy,t]）、一个多余的 ']'，Node 侧没有。
    # 先把这些摘掉再配对，否则多对多的 replace 块会把四元组里最后一个 0->40 配丢。
    import re
    import difflib
    TRAIL = re.compile(r"^\[-?\d+,-?\d+,-?\d+\]$")

    def clean(toks):
        keep = [i for i, t in enumerate(toks) if not TRAIL.match(t) and t != "]"]
        return [toks[i] for i in keep], keep

    cb, kb = clean(bt)
    cn, kn = clean(ntoks)
    print("去 trail 后：浏览器 %d 个, Node %d 个" % (len(cb), len(cn)))
    sm = difflib.SequenceMatcher(None, cb, cn, autojunk=False)
    pairs = []
    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        if tag == "equal":
            pairs += list(zip(kb[i1:i2], kn[j1:j2]))
            continue
        print("  %-7s 浏览器[%d:%d]=%r  Node[%d:%d]=%r"
              % (tag, i1, i2, [x[:24] for x in cb[i1:i2]], j1, j2,
                 [x[:24] for x in cn[j1:j2]]))
        if (i2 - i1) == (j2 - j1):
            pairs += list(zip([kb[i] for i in range(i1, i2)],
                              [kn[j] for j in range(j1, j2)]))
    control = "--control" in sys.argv
    # --only mask|trio|container：只改其中一类，用来把「到底哪个字段触发 12」拆开。
    # 一次运行仍然只发一条包。
    only = None
    if "--only" in sys.argv:
        only = sys.argv[sys.argv.index("--only") + 1]
    patches = {}
    now = int(__import__("time").time())
    for bi, ni in pairs:
        a, x = bt[bi], ntoks[ni]
        if control:
            # 对照组：只把一个时间戳 +1 秒。用来确认「改明文再重新加密」这件事本身
            # 不会引起 12（即服务端没有对明文的完整性校验）。
            if a.isdigit() and len(a) == 10 and abs(int(a) - now) < 600:
                patches[bi] = str(int(a) + 1)
                print("  对照组选中时间戳 %02d %s -> %s" % (bi, a, patches[bi]))
                break
            continue
        if not a.isdigit() and not a.startswith("["):
            continue
        if a == "1007":
            kind = "mask"
        elif a == "0" and x in QUARTET_NODE:
            kind = "trio"
        elif a == "[360,363]":
            kind = "container"
        else:
            # 浏览器值 == Node 值的不动；值不同但不属于上面三类，只是打印出来备查
            if a != x:
                print("  未归类差异 %02d %r vs %r" % (bi, a, x))
            continue
        if only and kind != only:
            continue
        patches[bi] = x
        print("  选中[%s] %02d %r -> %r" % (kind, bi, a, x))
    print("\n要改的下标：", sorted(patches),
          "->", [patches[k] for k in sorted(patches)])
    if not patches:
        print("没找到要改的字段")
        return 1

    new_pt = patch_cd(bpt, patches)
    new_collect = cipher.get_data(new_pt)
    back = T.decrypt(new_collect, prm_b)
    bt3 = [t[2] for t in tokenize_spans(back)]
    print("改后还能解开：%s；token 数 %d；改动已生效：%s"
          % (back[:12] == bpt[:12], len(bt3),
             all(bt3[i] == patches[i] for i in patches)))
    new_tlg = len(urllib.parse.unquote(new_collect))

    body2 = body
    body2 = body2.replace("collect=" + urllib.parse.quote(bcollect, safe=""),
                          "collect=" + new_collect)
    body2 = body2.replace("tlg=" + str(kv.get("tlg")),
                          "tlg=" + str(new_tlg))
    kv2 = dict(urllib.parse.parse_qsl(body2, keep_blank_values=True))
    print("改后 body：collect=%d tlg=%s" % (len(kv2.get("collect", "")),
                                          kv2.get("tlg")))
    if kv2.get("collect") == bcollect:
        print("警告：body 里的 collect 没换成功")

    out = os.path.join(HERE, "kcalib", "quartet_body.txt")
    open(out, "w", encoding="utf-8").write(body2)
    print("改后 body ->", out)
    if dry:
        print("DRY：不发包")
        return 0

    hdr = {}
    for k, v in (res.get("verify_headers") or {}).items():
        if k.lower() not in SKIP_HEADERS:
            hdr[k] = v
    cookies = [c for c in (res.get("cookies") or [])
               if "qcloud.com" in (c.get("domain") or "")]
    if cookies:
        hdr["Cookie"] = "; ".join("%s=%s" % (c["name"], c["value"])
                                  for c in cookies)
    url = res.get("verify_url") or (F.BASE + "/cap_union_new_verify")

    from curl_cffi import requests as creq
    s = creq.Session(impersonate="chrome")
    r = s.post(url, data=body2.encode("utf-8"), headers=hdr, timeout=20)
    print("curl_cffi:", r.status_code, r.text[:400])
    try:
        j = r.json()
        print("errorCode=", j.get("errorCode"),
              "ticket_len=", len(j.get("ticket") or ""))
    except Exception as exc:
        print("非 JSON:", exc)
    return 0


if __name__ == "__main__":
    sys.exit(main())
