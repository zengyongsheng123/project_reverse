# -*- coding: utf-8 -*-
"""把浏览器在「弹窗刚出现」这段时间里发过的每条请求的**完整请求头 + 响应头**
留档（prehandle / tdc.js / getcapbysig），和我们自己发的逐字段对照。

为什么要看请求头：响应体已经逐字段对过，两边 prehandle 的响应除了 sid/sess
之外完全一样 —— 说明服务端给了同一档配置。那 server 在 prehandle 上还能看
到的就只剩请求本身（头 / Cookie / TLS）。一次只查一项，先把头查干净。

只打开页面不拖动 -> 不会产生 verify，不发任何提交。
输出：scripts/kcalib/browser_headers.json

用法：python browser_req_headers.py
"""
import json
import os
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))
sys.path.insert(0, HERE)

import fastmoss_flow as F

KD = os.path.join(HERE, "kcalib")
WANT = ("cap_union_prehandle", "tdc.js", "getcapbysig", "TJCaptcha.js",
        "tgJCap", "dy-jy3")


def main():
    hy = F.BrowserHybrid()
    hy._launch()
    t = hy._new_target()
    c = F._CDP(t["webSocketDebuggerUrl"])
    out = {}
    try:
        c.call("Runtime.enable")
        c.call("Page.enable")
        c.call("Network.enable")
        c.call("Page.navigate", url=hy.PAGE)
        time.sleep(1.5)
        c.ev(hy.LOAD % F.AID)
        for _ in range(80):
            time.sleep(0.5)
            if c.ev("typeof window.TDC") == "object":
                break
        time.sleep(2.0)
        hy._drain(c)
        for e in c.events:
            m = e.get("method")
            p = e.get("params") or {}
            if m == "Network.requestWillBeSent":
                u = (p.get("request") or {}).get("url") or ""
                if any(w in u for w in WANT):
                    out[u] = {"request_headers": p["request"].get("headers"),
                              "method": p["request"].get("method")}
            elif m == "Network.responseReceived":
                u = (p.get("response") or {}).get("url") or ""
                if u in out:
                    out[u]["status"] = p["response"].get("status")
                    out[u]["response_headers"] = p["response"].get("headers")
        try:
            out["__cookies__"] = [{"name": x.get("name"),
                                   "domain": x.get("domain"),
                                   "value": (x.get("value") or "")[:40]}
                                  for x in c.call("Network.getAllCookies")
                                  .get("cookies", [])]
        except Exception as exc:
            out["__cookies__"] = str(exc)[:200]
    finally:
        try:
            hy._close_target(t["id"])
        except Exception:
            pass
    open(os.path.join(KD, "browser_headers.json"), "w",
         encoding="utf-8").write(json.dumps(out, ensure_ascii=False, indent=1))
    print("->", os.path.join(KD, "browser_headers.json"))
    for u, v in out.items():
        if u.startswith("__"):
            continue
        print("\n== %s  [%s]" % (u[:110], v.get("status")))
        for k, val in sorted((v.get("request_headers") or {}).items()):
            print("   > %-24s %s" % (k, str(val)[:80]))
        for k, val in sorted((v.get("response_headers") or {}).items()):
            if k.lower() in ("set-cookie", "content-type", "cache-control"):
                print("   < %-24s %s" % (k, str(val)[:100]))
    print("\ncookies:", out.get("__cookies__"))


if __name__ == "__main__":
    sys.exit(main())
