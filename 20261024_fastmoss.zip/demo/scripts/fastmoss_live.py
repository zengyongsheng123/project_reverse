# -*- coding: utf-8 -*-
"""按「本次会话自己的 tdc.js」现推 collect 常量（不发 verify）。

2026-10-25 的结论：FastMoss 这个 aid 的 tdc.js 是**每个会话重新随机化**的
（同一个 app_data 之外，每次 prehandle 拿到的 tdc.js 里 K 数组、C 常量、
VM 字节码、eks 全都不一样；只有 XTEA 骨架/n 轮数不变）。所以静态 PROFILE
必然对不上服务端——这就是三次提交都返回 errorCode 12 的原因。

本脚本的产出：一套可直接塞进 fastmoss_flow.PROFILE 的常量
    key / case / cipher_pc / kvariant / eks / build_const / split
其中 split 由明文里的 "[]", 位置推出（tdc_collect.split_from_plaintext）。

用法：python fastmoss_live.py [--save path]
"""
import argparse
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
sys.path.insert(0, ROOT)

import derive_build as D
import extract_bc
import map_opcodes
import derive_key_table as dk
import tdc_collect as col
import fastmoss_flow as F


def fingerprint_js(js_text):
    """把 tdc.js 落到临时文件（map_opcodes.handlers 只吃路径）。"""
    d = os.path.join(ROOT, "js", "live_src")
    os.makedirs(d, exist_ok=True)
    p = os.path.join(d, "tdc_session_tmp.js")
    with open(p, "w", encoding="utf-8") as fh:
        fh.write(js_text)
    return p


def derive(src_path):
    old = map_opcodes.handlers(D.REF_SRC)
    live = map_opcodes.handlers(src_path)
    m = D.resolve_map(old, live)
    src = open(src_path, encoding="utf-8", errors="replace").read()
    bc = extract_bc.decode(extract_bc.find_arg(src))
    seen = dk.walk(bc, m)

    arrays = D.derive_key_arrays(seen)
    hits = D.find_cipher(seen)
    if not hits:
        raise SystemExit("no cipher closure found")
    pc, f, pairs = hits[0]                       # 约定：取第一个闭包
    case, _info = D.derive_case(seen, f)
    if not case:
        raise SystemExit("no case constants")

    # key 数组的选择规则：cipher 闭包的 upvalue 是 (depth, src)，其中 src 是
    # key 数组所在的源寄存器。key/诱饵两个数组只在第一元（depth）上不同，
    # 所以必须按 src 匹配，而不是按整个 pair 相等。
    # 旧 build 里 cipher 恰好也是 (7,8)，整 pair 相等因此蒙对了。
    src_reg = pairs[-1][1] if pairs else None
    key = None
    cand = [tag for tag in arrays if tag and tag[-1][1] == src_reg]
    if len(cand) > 1:                            # 同源多个：优先第一元最小的
        cand.sort(key=lambda t: t[-1][0])
    if cand:
        key = arrays[cand[0]]
        print("  key 数组取自 %s（cipher upvalue %s, src=%s）"
              % (cand[0], pairs, src_reg))

    from extract_eks import find_eks
    eks_hits = find_eks(src)
    bconst = D.find_build_const(src, seen)
    return {"key": [int(x) for x in key], "case": case, "pairs": list(pairs),
            "cipher_pc": pc, "closures": [(h[0], list(h[2])) for h in hits],
            "eks": eks_hits[0][1] if eks_hits else None,
            "eks_global": eks_hits[0][0] if eks_hits else None,
            "build_const": bconst, "bc_len": len(bc),
            "unmapped": sum(1 for v in m.values() if v is None)}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--save", default=None)
    args = ap.parse_args()

    s = F.FastMossCaptchaFlow.make_session()
    tkid, pre = F.FastMossCaptchaFlow.prehandle(s)
    data = pre.get("data") or {}
    if not pre.get("sess"):
        raise SystemExit("prehandle failed: %s" % json.dumps(pre)[:300])
    path = data["comm_captcha_cfg"]["tdc_path"]
    js = s.get(F.BASE + path, timeout=20).text
    print("session app_data =", path.split("app_data=")[1].split("&")[0])
    print("tdc.js %d chars" % len(js))

    prof = derive(fingerprint_js(js))
    split = col.split_from_plaintext(
        F.CollectBuilder(F.PROFILE).build_plaintext(1790000000, counter=1))
    prof["split"] = split
    prof["build_const"] = prof["build_const"]

    print("key       =", [hex(x) for x in prof["key"]])
    print("case      =", prof["case"])
    print("pairs     =", prof["pairs"], "cipher_pc =", prof["cipher_pc"])
    print("closures  =", prof["closures"])
    print("split     =", split, "(plaintext-derived)")
    print("eks       =", (prof["eks"] or "")[:32], "...")
    print("bconst    =", prof["build_const"])
    print("bc_len    =", prof["bc_len"], "unmapped =", prof["unmapped"])
    print("vs probe  : key %s | case %s | eks %s"
          % (prof["key"] == F.PROFILE["key"], prof["case"] == F.PROFILE["case"],
             prof["eks"] == F.PROFILE["eks"]))

    # 自检：用本次常量加密再解密，明文必须原样回来
    lay = dict(F.PROFILE)
    lay.update({"key": prof["key"], "case": prof["case"],
                "split": split})
    b = F.CollectBuilder(lay)
    pt = b.build_plaintext(1790000000, counter=1)
    enc, _ = b.make_collect(1790000000, counter=1)
    back = b.cipher.decode_data(enc)
    print("roundtrip =", back[:len(pt)] == pt, "plausible =",
          D.plausible(pt[:len(pt)] + b"\x00" * (-len(pt) % 8)))

    if args.save:
        json.dump(prof, open(args.save, "w"), indent=1)
        print("saved ->", args.save)


if __name__ == "__main__":
    main()
