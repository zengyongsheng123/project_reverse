# -*- coding: utf-8 -*-
"""Read-only live check: call TDC.getData() twice through CDP (no breakpoints,
no page reload), decrypt both payloads with the pure-Python implementation and
compare each one against tdc_collect.build_collect().

Usage: python live_check.py
"""
import http.client
import json
import os
import re
import sys
import time

import websocket

PORT = 9222
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
import tdc_collect                                     # noqa: E402
import tdc_crypto                                      # noqa: E402


def targets():
    c = http.client.HTTPConnection("127.0.0.1", PORT, timeout=5)
    c.request("GET", "/json")
    return json.loads(c.getresponse().read())


class CDP:
    def __init__(self, url):
        self.ws = websocket.create_connection(url, timeout=120, suppress_origin=True)
        self.i = 0

    def call(self, method, **p):
        self.i += 1
        mid = self.i
        self.ws.send(json.dumps({"id": mid, "method": method, "params": p}))
        end = time.time() + 90
        while True:
            self.ws.settimeout(max(0.5, end - time.time()))
            m = json.loads(self.ws.recv())
            if m.get("id") == mid:
                if "error" in m:
                    raise RuntimeError("%s -> %s" % (method, m["error"]))
                return m.get("result", {})


def get_data(cdp):
    r = cdp.call("Runtime.evaluate", expression="TDC.getData()",
                 returnByValue=True, awaitPromise=True)
    if r.get("exceptionDetails"):
        raise RuntimeError(str(r["exceptionDetails"])[:300])
    return r["result"]["value"]


def parse(pt):
    s = pt.decode("latin-1")
    return {
        "now_sec": int(re.search(r'rand=\d+",(\d+),', s).group(1)),
        "counter": int(re.search(r",(\d+),1920\]", s).group(1)),
        "raw": s,
    }


def main():
    pg = [t for t in targets() if t.get("type") == "page"][0]
    cdp = CDP(pg["webSocketDebuggerUrl"])
    cdp.call("Runtime.enable")
    for k in (1, 2):
        data = get_data(cdp)
        raw = tdc_crypto.decode_data(data)
        f = parse(raw)
        back = tdc_crypto.get_data(raw)
        rebuilt = tdc_collect.build_collect(f["now_sec"], f["counter"])
        print("call %d: len(pt)=%d now=%d counter=%d  decrypt->reencrypt=%s  rebuild=%s"
              % (k, len(raw), f["now_sec"], f["counter"], back == data, rebuilt == raw))
        if rebuilt != raw:
            for i in range(min(len(raw), len(rebuilt))):
                if raw[i] != rebuilt[i]:
                    print("  first diff @%d ref=%r got=%r"
                          % (i, raw[i - 30:i + 30], rebuilt[i - 30:i + 30]))
                    break
        time.sleep(0.4)


if __name__ == "__main__":
    main()
