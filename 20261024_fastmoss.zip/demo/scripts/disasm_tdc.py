# -*- coding: utf-8 -*-
"""Extract the Chaos-VM opcode table and disassemble bytecode regions.

Usage:
    python disasm_tdc.py                # dump the opcode table
    python disasm_tdc.py 9400 9460      # show bytecode[9400:9460] with context
"""
import sys, json, re

SRC = "../js/tdc.dec.js"
BC = "../js/bytecode.json"


def balanced(s, start):
    depth = 0
    i = start
    instr = None
    esc = False
    while i < len(s):
        ch = s[i]
        if instr:
            if esc:
                esc = False
            elif ch == "\\":
                esc = True
            elif ch == instr:
                instr = None
        else:
            if ch in "\"'":
                instr = ch
            elif ch == "[":
                depth += 1
            elif ch == "]":
                depth -= 1
                if depth == 0:
                    return s[start:i + 1]
        i += 1
    raise ValueError("unbalanced")


def split_top(arr):
    parts = []
    depth = 0
    cur = []
    instr = None
    esc = False
    for ch in arr[1:-1]:
        if instr:
            cur.append(ch)
            if esc:
                esc = False
            elif ch == "\\":
                esc = True
            elif ch == instr:
                instr = None
        else:
            if ch in "\"'":
                instr = ch
                cur.append(ch)
            elif ch in "([{":
                depth += 1
                cur.append(ch)
            elif ch in ")]}":
                depth -= 1
                cur.append(ch)
            elif ch == "," and depth == 0:
                parts.append("".join(cur))
                cur = []
            else:
                cur.append(ch)
    parts.append("".join(cur))
    return parts


def get_handlers():
    s = open(SRC, encoding="utf-8", errors="replace").read()
    a = s.find("for(var A=[")
    start = s.find("[", a)
    arr = balanced(s, start)
    return [p.strip() for p in split_top(arr)]


# operand count per opcode (None = invalid / unused slot)
# 52 is variable (3 + 2*B + Q)
OPERANDS = {
    0: 0, 1: 0, 2: 0, 3: 0, 4: 0, 5: 0, 6: 1, 7: 0, 8: 0, 9: 0,
    10: 1, 12: 0, 14: 0, 16: 2, 18: 0, 19: 0, 20: 0, 21: 1, 22: 0,
    24: 0, 25: 1, 26: 0, 27: 1, 28: 1, 29: 0, 30: 0, 31: 0, 33: 1,
    34: 0, 35: 1, 36: 0, 37: 0, 38: 0, 39: 1, 40: 0, 41: 0, 43: 0,
    45: 0, 46: 0, 47: 0, 48: 0, 50: 0, 51: 0, 52: -1, 54: 1, 55: 0,
    56: 0, 57: 0, 58: 0, 59: 1, 60: 0, 62: 0, 63: 1, 64: 1, 65: 1,
    66: 0, 67: 0, 68: 0,
}

NAMES = {
    0: "swap2", 1: "iter", 2: "or", 3: "shl", 4: "shr", 5: "drop",
    6: "store", 7: "deref0", 8: "seq===", 9: "getidx", 10: "callm",
    12: "dup", 14: "tpop", 16: "try", 18: "ret", 19: "clrF",
    20: "mod", 21: "local", 22: "keys", 24: "null", 25: "callp",
    26: "undef", 27: "new", 28: "load", 29: "typeof", 30: "not",
    31: "setprop", 33: "jmp", 34: "mkpair", 35: "push1", 36: ">=",
    37: "xor", 38: "setelem", 39: "call0", 40: "ushr", 41: "in",
    43: "sub", 45: "del", 46: "emptystr", 47: "mkpair2", 48: "halt",
    50: "mul", 51: "add", 52: "closure", 54: "setimm", 55: "and",
    56: "pushI", 57: "div", 58: "==", 59: "push", 60: "throw",
    62: ">", 63: "jz", 64: "setlen", 65: "appendchr", 66: "true",
    67: "false", 68: "host",
}


def disasm(bc, lo, hi, verbose=True):
    """Linear sweep from 0; print instructions whose pc is in [lo,hi)."""
    pc = 0
    out = []
    n = len(bc)
    while pc < hi and pc < n:
        op = bc[pc]
        start = pc
        pc += 1
        if op == 52:
            pc += 3  # funcpc, nup, narg (then variable)
            if pc <= n:
                nup = bc[start + 2]
                narg = bc[start + 3]
                pc += 2 * nup + narg
        elif op in OPERANDS:
            pc += OPERANDS[op]
        else:
            if verbose and lo <= start < hi:
                out.append((start, op, ["<invalid>"]))
            continue
        if verbose and start >= lo - 40 and start < hi:
            ops = bc[start + 1:pc]
            out.append((start, op, ops))
    return out


def main():
    hs = get_handlers()
    if len(sys.argv) == 1:
        print("n opcodes", len(hs))
        for k, p in enumerate(hs):
            print("%3d %s" % (k, p[:220].replace("\n", " ")))
        return
    lo, hi = int(sys.argv[1]), int(sys.argv[2])
    bc = json.load(open(BC, encoding="utf-8"))
    print("bytecode len", len(bc))
    for start, op, ops in disasm(bc, lo, hi):
        print("%6d  %-10s %s" % (start, NAMES.get(op, "op%d" % op),
                                 " ".join(str(x) for x in ops)))


if __name__ == "__main__":
    main()
