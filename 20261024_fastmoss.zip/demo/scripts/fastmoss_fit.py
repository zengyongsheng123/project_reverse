# -*- coding: utf-8 -*-
"""FastMoss build 的 (K, C, split) 组合穷举。

derive_build.py 只试第一个能推出 C 的 cipher 闭包；本 build 有两个闭包，
第一个是诱饵。这里把「每个闭包 × 每个 K 数组 × C 原序/交换 × split」全试，
再用全部样本（含 setData 事件样本）逐个用 derive_build.verify_layout 裁决。

用法：python fastmoss_fit.py [--src path] [--probe path]
成功时写 ../js/live_src/profile_fastmoss.json 并打印常量。
"""
import argparse
import base64
import hashlib
import json
import os
import sys
import urllib.parse

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
sys.path.insert(0, ROOT)

import derive_build as D
import extract_bc
import map_opcodes
import derive_key_table as dk
import tdc_collect as col
import tdc_crypto as tc
from disasm_tdc import NAMES


def load(src_path):
    src = open(src_path, encoding="utf-8", errors="replace").read()
    old = map_opcodes.handlers(D.REF_SRC)
    live = map_opcodes.handlers(src_path)
    live2old = D.resolve_map(old, live)
    bc = extract_bc.decode(extract_bc.find_arg(src))
    seen = dk.walk(bc, live2old)
    bad = sum(1 for v in seen.values() if v[0] is None or v[0] not in NAMES)
    print("bytecode %d B, reachable %d, unmapped %d" % (len(bc), len(seen), bad))
    return src, seen


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--src", default=os.path.join(ROOT, "js", "live_src",
                                                  "tdc_fastmoss.js"))
    ap.add_argument("--probe", default=os.path.join(HERE,
                                                    "fastmoss_probe.json"))
    args = ap.parse_args()

    src, seen = load(args.src)
    arrays = D.derive_key_arrays(seen)
    print("K arrays:")
    for tag, k in arrays.items():
        print("   %s -> %s" % (list(tag), [hex(x) for x in k]))

    hits = D.find_cipher(seen)
    print("cipher closures:", [(pc, f, list(p)) for pc, f, p in hits])
    options = []
    for pc, f, pairs in hits:
        case, cinfo = D.derive_case(seen, f)
        print("   closure pc=%d f=%d pairs=%s C=%s cinfo=%s"
              % (pc, f, list(pairs), case, cinfo))
        if case:
            options.append((pc, pairs, case, cinfo))
    if not options:
        raise SystemExit("no derivable C")

    probe = json.load(open(args.probe, encoding="utf-8"))
    all_samples = probe["datas"]
    # FastMoss 这个 build 的拖动轨迹写在 "sd" 对象里（不是 demo 的 cd 三元组），
    # 带事件的样本不能套普通 token 布局；先用不带事件的样本定布局，事件单独处理。
    samples = [g for g in all_samples if not g.get("events")]
    ev_samples = [g for g in all_samples if g.get("events")]
    print("samples: %d normal, %d event" % (len(samples), len(ev_samples)))
    datas = [g["d"] for g in samples]
    times = [g.get("now") for g in samples]
    if any(t is None for t in times):
        times = None
    raw0 = base64.b64decode(urllib.parse.unquote(datas[0]))
    print("samples=%d first raw=%d B" % (len(samples), len(raw0)))

    # 所有候选解密，plausible 的进入验证
    tried = []
    for pc, pairs, case, cinfo in options:
        nz = [i for i, v in enumerate(case) if v]
        swapped = list(case)
        if len(nz) == 2:
            swapped[nz[0]], swapped[nz[1]] = case[nz[1]], case[nz[0]]
        for tag, key in arrays.items():
            for cname, cv in (("static", case), ("swapped", swapped)):
                for split in range(32, len(raw0) + 1, 8):
                    pt = D.decrypt_raw(D.unrotate(raw0, split), key, cv)
                    if D.plausible(pt):
                        tried.append((pc, tag, key, cname, cv, split, pt))
    print("plausible candidates: %d" % len(tried))

    winners = []
    for pc, tag, key, cname, cv, split, pt in tried:
        pts = [pt]
        for g in samples[1:]:
            raw = base64.b64decode(urllib.parse.unquote(g["d"]))
            pts.append(D.decrypt_raw(D.unrotate(raw, split), key, cv))
        lay = D.verify_layout(col, tc, pts, datas, key, cv, split, times=times)
        line = ("  pc=%d pair%s C=%s split=%d -> layout=%s"
                % (pc, list(tag), cname, split, "OK" if lay else "no"))
        print(line)
        if lay is not None:
            winners.append((pc, tag, key, cname, cv, split, lay))

    if not winners:
        raise SystemExit("no combination reproduced all samples")
    pc, tag, key, cname, cv, split, lay = winners[0]
    print("\nWINNER pc=%d pair=%s C=%s split=%d" % (pc, list(tag), cname, split))
    print("key =", [int(x) for x in key])
    print("case =", cv)
    print("layout dynamic =", lay.get("dynamic"))
    print("layout tokens =", len(lay["tokens"]))

    # 事件样本分析：确认事件只落在 "sd" 里，且 cd 段与非事件样本同构
    ev_fmt = None
    if ev_samples:
        ev = ev_samples[0]
        raw = base64.b64decode(urllib.parse.unquote(ev["d"]))
        ev_pt = D.decrypt_raw(D.unrotate(raw, split), key, cv)
        i = ev_pt.find(b'"sd":')
        head = ev_pt[:i]
        # 与非事件样本比 cd 段（counter 不同，只允许 dynamic 位置不同）
        probe_pt = D.decrypt_raw(
            D.unrotate(base64.b64decode(urllib.parse.unquote(datas[0])), split),
            key, cv)
        j = probe_pt.find(b'"sd":')
        ev_fmt = {"sd_head": ev_pt[i:i + 90].decode("latin-1"),
                  "space_before_sd": len(head) - len(head.rstrip(b" "))}
        print("event sd:", repr(ev_pt[i:i + 90]))
        print("event space-before-sd:", ev_fmt["space_before_sd"],
              "normal:", len(probe_pt[:j]) - len(probe_pt[:j].rstrip(b" ")))

    # eks / build const
    from extract_eks import find_eks
    eks_hits = find_eks(src)
    bconst = D.find_build_const(src, seen)
    prof = {
        "name": "fastmoss",
        "sha256_16": hashlib.sha256(
            src.encode("utf-8", "surrogatepass")).hexdigest()[:16],
        "key": [int(x) for x in key], "case": cv, "split": split,
        "cipher_pc": pc, "kvariant": list(tag),
        "c_info": {"chosen": cname, "derived": [list(o[2]) for o in options]},
        "env_source": "layout", "layout": lay,
        "build_const": bconst,
        "build_const_hex": ("0x%X" % bconst) if bconst is not None else None,
        "eks_global": eks_hits[0][0] if eks_hits else None,
        "eks": eks_hits[0][1] if eks_hits else None,
        "samples_verified": len(samples), "verified": True,
    }
    out = os.path.join(ROOT, "js", "live_src", "profile_fastmoss.json")
    json.dump(prof, open(out, "w"), indent=1)
    print("PROFILE written:", out)


if __name__ == "__main__":
    main()
