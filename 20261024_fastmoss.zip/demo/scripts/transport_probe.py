# -*- coding: utf-8 -*-
"""把「collect 内容」和「传输层」拆开：用浏览器生成真 collect，但请求改由 Python 发。

做法：浏览器照常拖到位，松手后 SDK 会发 cap_union_new_verify —— 用 CDP 的
Fetch 域把它截住（不发给服务端），拿到完整 body / headers / cookie，
再由 Python（curl_cffi，Chrome 指纹）发一条一模一样的请求。

结果解读：
  errorCode=0  -> Python 传输层没问题，Node 侧输在 collect 内容上
  errorCode!=0 -> 传输层（TLS/HTTP2/头顺序）本身就被卡，光换 collect 没用

每次运行只发一条 verify（浏览器那条已被截断，服务端只会收到 Python 这条）。

用法：python transport_probe.py [--requests]   # --requests 用 requests 发（对照）
"""
import json
import os
import sys
import urllib.parse

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
sys.path.insert(0, ROOT)

import fastmoss_flow as F

SKIP_HEADERS = {"content-length", "host", "connection", "accept-encoding"}


def main():
    use_requests = "--requests" in sys.argv
    hy = F.BrowserHybrid()
    code, res = hy.run(intercept_verify=True)
    body = res.get("verify_body") or ""
    if not body:
        print("没拿到 body，退出：", json.dumps(
            {k: v for k, v in res.items() if k != "cookies"}, ensure_ascii=False)[:600])
        return 1
    out = os.path.join(HERE, "kcalib", "verify_capture.json")
    json.dump({"body": body, "headers": res.get("verify_headers"),
               "cookies": res.get("cookies")}, open(out, "w", encoding="utf-8"),
              ensure_ascii=False)
    print("已存 ->", out)

    hdr = {}
    for k, v in (res.get("verify_headers") or {}).items():
        if k.lower() in SKIP_HEADERS:
            continue
        hdr[k] = v
    cookies = [c for c in (res.get("cookies") or [])
               if "qcloud.com" in (c.get("domain") or "")]
    if cookies:
        hdr["Cookie"] = "; ".join("%s=%s" % (c["name"], c["value"])
                                  for c in cookies)
    print("headers:", json.dumps(hdr, ensure_ascii=False)[:500])

    url = res.get("verify_url") or (F.BASE + "/cap_union_new_verify")
    if use_requests:
        import requests
        s = requests.Session()
        r = s.post(url, data=body.encode("utf-8"), headers=hdr, timeout=20)
        print("requests:", r.status_code, r.text[:400])
    else:
        from curl_cffi import requests as creq
        s = creq.Session(impersonate="chrome")
        r = s.post(url, data=body.encode("utf-8"), headers=hdr, timeout=20)
        print("curl_cffi:", r.status_code, r.text[:400])
    try:
        js = r.json()
        print("errorCode=", js.get("errorCode"), "ticket_len=", len(js.get("ticket") or ""))
    except Exception as exc:
        print("非 JSON:", exc)
    return 0


if __name__ == "__main__":
    sys.exit(main())
