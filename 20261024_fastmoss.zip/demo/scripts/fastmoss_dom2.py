# -*- coding: utf-8 -*-
"""第二版 DOM 探针：把票证弹窗里每个带图/带位移的元素都列出来。

要回答：拼图块（sprite 背景的 div）在哪、缺口在背景图的什么位置、
拖动时位移作用在谁身上（drag 的 x 与 ans 的坐标系怎么对应）。

用法：python fastmoss_dom2.py
产出：fastmoss_popup2.png（放大截图）、scripts/fastmoss_dom2.json
"""
import base64
import json
import os
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)

import fastmoss_probe as P

DUMP = r"""
(function(){
  var out = {nodes: [], wrapHtml: '', dpr: window.devicePixelRatio,
             imgs: []};
  var wrap = document.getElementById('tCaptchaDyMainWrap');
  if (wrap) out.wrapHtml = wrap.outerHTML.length;
  function rec(el, depth){
    var cs = getComputedStyle(el);
    var r = el.getBoundingClientRect();
    var bg = cs.backgroundImage || '';
    var tf = cs.transform || 'none';
    var pos = cs.backgroundPosition;
    var size = cs.backgroundSize;
    var hasImg = bg && bg !== 'none';
    var moved = tf && tf !== 'none';
    if ((hasImg || moved) && r.width > 1) {
      out.nodes.push({d: depth, tag: el.tagName, cls: String(el.className).slice(0,60),
        id: el.id, bg: bg.slice(0, 70), pos: pos, size: size, tf: tf,
        box: [Math.round(r.left), Math.round(r.top),
              Math.round(r.width), Math.round(r.height)],
        nat: el.tagName === 'IMG' ? [el.naturalWidth, el.naturalHeight] : null,
        z: cs.zIndex, op: cs.opacity});
    }
    if (depth < 7) {
      for (var i = 0; i < el.children.length; i++) rec(el.children[i], depth+1);
    }
  }
  if (wrap) rec(wrap, 0);
  var im = document.querySelectorAll('img');
  for (var i = 0; i < im.length; i++) {
    var r = im[i].getBoundingClientRect();
    if (r.width > 30) out.imgs.push({cls: String(im[i].className).slice(0,60),
      nat: [im[i].naturalWidth, im[i].naturalHeight],
      box: [Math.round(r.left), Math.round(r.top),
            Math.round(r.width), Math.round(r.height)]});
  }
  return out;
})()
"""


def main():
    proc = P.launch()
    t = P.new_target()
    tid = t["id"]
    c = P.CDP(t["webSocketDebuggerUrl"])
    try:
        c.call("Runtime.enable")
        c.call("Page.enable")
        c.call("Page.navigate", url=P.PAGE)
        time.sleep(1.5)
        print("show:", c.ev(P.LOAD))
        for _ in range(80):
            time.sleep(0.5)
            if c.ev("typeof window.TDC") == "object":
                break
        time.sleep(1.0)
        d = c.ev(DUMP)
        if not d:
            print("no dump")
            return
        print("wrap html len:", d["wrapHtml"], "dpr", d["dpr"])
        print("--- imgs")
        for i in d["imgs"]:
            print("   %-55s nat=%s box=%s" % (i["cls"], i["nat"], i["box"]))
        print("--- nodes (bg / transform)")
        for n in d["nodes"]:
            print("   " * 0 + "d%d %-6s %-46s box=%-22s pos=%-12s size=%-12s tf=%s bg=%s"
                  % (n["d"], n["tag"], n["cls"], n["box"], n["pos"], n["size"],
                     (n["tf"] or "")[:34], (n["bg"] or "")[:46]))
        shot = c.call("Page.captureScreenshot", format="png")
        b = base64.b64decode(shot["data"])
        open(os.path.join(ROOT, "fastmoss_popup2.png"), "wb").write(b)
        print("screenshot saved", len(b))
        json.dump(d, open(os.path.join(HERE, "fastmoss_dom2.json"), "w"),
                  ensure_ascii=False, indent=1)
    finally:
        try:
            c.ws.close()
        except Exception:
            pass
        P.close_target(tid)
        if proc is not None:
            try:
                proc.terminate()
            except Exception:
                pass


if __name__ == "__main__":
    main()
