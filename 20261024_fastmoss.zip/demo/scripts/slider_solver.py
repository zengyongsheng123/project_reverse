# -*- coding: utf-8 -*-
"""Pure-python slider (jigsaw) captcha solver.

Works on the two images returned by TCaptcha `cap_union_new_getcapbysig`:
  * img_index=0 -> sprite sheet (contains the puzzle piece, RGBA)
  * img_index=1 -> background photo (RGB)

Geometry comes from `cap_union_prehandle` -> resp.data.dyn_show_info:
  fg_elem_list[id==1].sprite_pos / size_2d / init_pos  (the draggable piece)

The answer submitted to /cap_union_new_verify is
    [{"elem_id":1,"type":"DynAnswerType_POS","data":"X,Y"}]
where X/Y are the *element box* coordinates design pixels (tgJCap: pos/rate).
The element box includes transparent padding, so
    X = hole_left_in_bg - piece_content_offset_x
    Y = init_pos[1]            (movement is x-only: move_factor [1,0])

No third-party services, no OpenCV - numpy + Pillow only.
"""
from collections import deque

import numpy as np
from PIL import Image


# --------------------------------------------------------------------------- #
# piece extraction
# --------------------------------------------------------------------------- #
def load_rgba(path):
    return np.array(Image.open(path).convert("RGBA"))


def load_gray_rgb(path):
    im = Image.open(path).convert("RGB")
    return np.array(im), np.array(im.convert("L")).astype(np.float32)


def piece_from_sprite(sprite_rgba, box, alpha_thr=128):
    """box = (x, y, w, h) of the piece inside the sprite sheet.

    Returns (mask[bool HxW], (off_x, off_y, w, h)) where off is the opaque
    content bbox inside the box - this is the offset the answer must compensate.
    """
    x, y, w, h = box
    crop = sprite_rgba[y:y + h, x:x + w]
    mask = crop[:, :, 3] > alpha_thr
    ys, xs = np.nonzero(mask)
    if len(xs) == 0:
        raise ValueError("empty piece mask")
    return mask, (int(xs.min()), int(ys.min()), int(xs.max() - xs.min() + 1), int(ys.max() - ys.min() + 1))


# --------------------------------------------------------------------------- #
# hole detection
# --------------------------------------------------------------------------- #
def _components(mask, min_area):
    h, w = mask.shape
    seen = mask.copy()
    out = []
    ys, xs = np.nonzero(mask)
    for sy, sx in zip(ys, xs):
        if not seen[sy, sx]:
            continue
        q = deque([(sy, sx)])
        seen[sy, sx] = False
        n = 0
        minx = maxx = sx
        miny = maxy = sy
        pix = []
        while q:
            y, x = q.popleft()
            n += 1
            pix.append((y, x))
            if x < minx: minx = x
            if x > maxx: maxx = x
            if y < miny: miny = y
            if y > maxy: maxy = y
            for dy, dx in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                ny, nx = y + dy, x + dx
                if 0 <= ny < h and 0 <= nx < w and seen[ny, nx]:
                    seen[ny, nx] = False
                    q.append((ny, nx))
        if n >= min_area:
            out.append({"area": n, "bbox": (minx, miny, maxx - minx + 1, maxy - miny + 1), "pix": pix})
    return out


def _hole_mask(bg_rgb, bg_lum):
    """Pixels that look like the hole overlay.

    TCaptcha paints the hole as a *desaturated, mid-dark* copy of the photo:
    measured on a session, hole pixels sit at luminance ~85-95 with
    max-min channel spread <= 10, while the photo's own shadows are either
    much darker or clearly tinted (saturation 20-60).
    """
    a = bg_rgb.astype(np.int16)
    sat = (a.max(2) - a.min(2)).astype(np.float32)
    return (bg_lum >= 40) & (bg_lum <= 140) & (sat <= 22)


def _iou(a_mask, a_off, b_mask, b_off, shift=(0, 0)):
    """IoU of two masks placed at offsets (x,y) inside a common canvas."""
    ax0, ay0 = a_off
    bx0, by0 = b_off[0] + shift[0], b_off[1] + shift[1]
    x0 = min(ax0, bx0); y0 = min(ay0, by0)
    x1 = max(ax0 + a_mask.shape[1], bx0 + b_mask.shape[1])
    y1 = max(ay0 + a_mask.shape[0], by0 + b_mask.shape[0])
    A = np.zeros((y1 - y0, x1 - x0), bool)
    B = np.zeros_like(A)
    A[ay0 - y0:ay0 - y0 + a_mask.shape[0], ax0 - x0:ax0 - x0 + a_mask.shape[1]] = a_mask
    B[by0 - y0:by0 - y0 + b_mask.shape[0], bx0 - x0:bx0 - x0 + b_mask.shape[1]] = b_mask
    inter = (A & B).sum()
    union = (A | B).sum()
    return inter / union if union else 0.0


def find_hole(bg_rgb, bg_lum, piece_mask, piece_bbox, expected_y=None):
    """Return the hole's content origin in background pixels + debug info.

    `expected_y` is the exact hole top from the session metadata
    (init_pos[1] + piece content offset).  The hole mask is the same shape as
    the piece mask but is eroded by the anti-aliased rim, so its bounding box
    sits a couple of pixels inside the true silhouette.  We measure that
    erosion on the (known) vertical axis and apply the same correction
    horizontally - that makes the x estimate self-calibrating.
    """
    pw, ph = piece_bbox[2], piece_bbox[3]
    mask = _hole_mask(bg_rgb, bg_lum)
    min_area = int(piece_mask.sum() * 0.35)
    comps = _components(mask, min_area)

    # shape of the piece restricted to its opaque bbox
    pm = piece_mask[piece_bbox[1]:piece_bbox[1] + ph, piece_bbox[0]:piece_bbox[0] + pw]

    cands = []
    for c in comps:
        cx, cy, cw, ch = c["bbox"]
        if not (0.6 * pw <= cw <= 1.45 * pw and 0.55 * ph <= ch <= 1.6 * ph):
            continue
        # component mask inside its own bbox
        cm = np.zeros((ch, cw), bool)
        for y, x in c["pix"]:
            cm[y - cy, x - cx] = True
        best = (0.0, 0, 0)
        for dy in range(-4, 5):
            for dx in range(-4, 5):
                score = _iou(pm, (0, 0), cm, (dx, dy))
                if score > best[0]:
                    best = (score, dx, dy)
        cands.append((best[0], cx + best[1], cy + best[2], c["area"], cw, ch, cx, cy))

    if not cands:
        return None
    cands.sort(reverse=True)
    iou, hx, hy, area, cw, ch, bx, by = cands[0]
    corr = None
    if expected_y is not None:
        corr = int(by - expected_y)
        if -1 <= corr <= 6:          # sane erosion -> calibrate x with it
            hx = bx - corr
            hy = int(expected_y)
        else:
            corr = None
    return {"hole_x": int(hx), "hole_y": int(hy), "iou": round(float(iou), 3),
            "comp_w": int(cw), "comp_h": int(ch), "n_comps": len(comps),
            "edge_corr": corr, "comp_bbox": [int(bx), int(by)],
            "margin": round(float(cands[0][0] - cands[1][0]), 3) if len(cands) > 1 else None,
            "cands": [(round(float(s), 3), int(x), int(y)) for s, x, y, *_ in cands[:5]]}


def match_piece(bg_rgb, sprite_rgba, fg, expected_y=None):
    """Template-match the piece's opaque content against the background.

    Fallback for sessions whose hole is rendered as a plain *darkened* copy of
    the photo (2026-10-24 variant) instead of the desaturated mid-gray overlay
    `_hole_mask` expects.  The piece content and the hole are the same pixels
    up to a brightness factor, so a global scale per x position is enough:

        residual(x) = mean |bg[y0:y0+ph, x:x+pw] - k * piece|

    Absolute residual is not enough (a flat sky matches any patch after the
    brightness factor absorbs the difference); the score is therefore the
    zero-mean normalised correlation of luminance inside the eroded opaque
    core, which only peaks where the *texture* lines up.  y is searched in a
    small window around `expected_y`; only x enters the answer.
    Returns a dict shaped like find_hole (hole_x = content origin, i.e.
    subtract off_x for the answer).
    """
    sx, sy = fg["sprite_pos"]
    w, h = fg["size_2d"]
    init_x, init_y = fg["init_pos"]
    crop = sprite_rgba[sy:sy + h, sx:sx + w]
    mask = crop[:, :, 3] > 128
    if not mask.any():
        raise ValueError("empty piece mask")
    ys, xs = np.nonzero(mask)
    ox, oy = int(xs.min()), int(ys.min())
    pw, ph = int(xs.max() - ox + 1), int(ys.max() - oy + 1)
    piece = crop[oy:oy + ph, ox:ox + pw, :3].astype(np.float32)
    pl = piece.mean(2)
    core = mask[oy:oy + ph, ox:ox + pw].copy()
    for _ in range(3):
        core = (core & np.roll(core, 1, 0) & np.roll(core, -1, 0)
                & np.roll(core, 1, 1) & np.roll(core, -1, 1))
    if core.sum() < 50:
        core = mask[oy:oy + ph, ox:ox + pw].copy()

    y0 = int(expected_y if expected_y is not None else init_y + oy)
    H, W = bg_rgb.shape[:2]
    bgl = bg_rgb.astype(np.float32)
    bg_l = bgl.mean(2)
    a = piece[core]
    pa = pl[core]
    pa0 = pa - pa.mean()
    dena = float(np.sqrt((pa0 * pa0).sum())) + 1e-9
    scores = []
    for y in range(max(0, y0 - 6), min(H - ph, y0 + 6) + 1):
        for x in range(0, W - pw + 1):
            patch = bgl[y:y + ph, x:x + pw]
            p = bg_l[y:y + ph, x:x + pw][core]
            p0 = p - p.mean()
            ncc = float((pa0 * p0).sum() /
                        (dena * (float(np.sqrt((p0 * p0).sum())) + 1e-9)))
            b = patch[core]
            k = float((a * b).sum() / ((a * a).sum() + 1e-6))
            resid = float(np.abs(b - a * k).mean())
            scores.append((ncc, -resid, x, y, k, resid))
    scores.sort(reverse=True)
    # the hole is always rendered darker than the photo (k ~0.25-0.6); a bright
    # patch can still correlate because sky gradients repeat, so prefer k<0.8
    dark = [s for s in scores if s[4] < 0.8]
    pool = dark if dark else scores
    ncc, _neg, best_x, best_y, k, resid = pool[0]
    around = [s for s in pool if abs(s[2] - best_x) > pw // 2]
    second = around[0][0] if around else None
    return {"hole_x": int(best_x), "hole_y": int(y0),
            "iou": round(float(ncc), 3),
            "comp_w": pw, "comp_h": ph, "n_comps": None,
            "edge_corr": None, "comp_bbox": [int(best_x), int(best_y)],
            "margin": round(ncc - second, 3) if second is not None else None,
            "k": round(float(k), 3), "resid": round(resid, 2),
            "method": "template"}


# --------------------------------------------------------------------------- #
# answer
# --------------------------------------------------------------------------- #
def answer_from_session(bg_path, sprite_path, dyn_show_info):
    fg = [e for e in dyn_show_info["fg_elem_list"] if e.get("id") == 1][0]
    sx, sy = fg["sprite_pos"]
    w, h = fg["size_2d"]
    init_x, init_y = fg["init_pos"]

    sprite = load_rgba(sprite_path)
    piece_mask, (off_x, off_y, pw, ph) = piece_from_sprite(sprite, (sx, sy, w, h))
    bg_rgb, bg_lum = load_gray_rgb(bg_path)
    hole = find_hole(bg_rgb, bg_lum, piece_mask, (off_x, off_y, pw, ph),
                     expected_y=init_y + off_y)
    if hole is None or hole.get("iou", 0) < 0.5:
        alt = match_piece(bg_rgb, sprite, fg, expected_y=init_y + off_y)
        if hole is None or alt["iou"] >= 0.5:
            hole = alt
    ans_x = hole["hole_x"] - off_x
    # sanity: y never changes, so the detected hole MUST sit at init_pos[1]+off_y
    dy_check = hole["hole_y"] - (init_y + off_y)
    return {"x": int(ans_x), "y": int(init_y), "data": "%d,%d" % (ans_x, init_y),
            "piece_offset": (off_x, off_y), "piece_size": (pw, ph), "hole": hole,
            "init_pos": [init_x, init_y], "y_check": int(dy_check),
            "y_check_ok": abs(dy_check) <= 4}


def draw_overlay(bg_path, sprite_path, dsi, out_path):
    """Save the bg with the solved piece box drawn on it (visual check)."""
    from PIL import ImageDraw
    res = answer_from_session(bg_path, sprite_path, dsi)
    im = Image.open(bg_path).convert("RGB")
    d = ImageDraw.Draw(im)
    fg = [e for e in dsi["fg_elem_list"] if e.get("id") == 1][0]
    w, h = fg["size_2d"]
    hx = res["x"] + res["piece_offset"][0]
    hy = res["hole"]["hole_y"]
    d.rectangle([hx, hy, hx + w - 1, hy + h - 1], outline=(255, 0, 0), width=1)
    sx, sy = fg["sprite_pos"]
    pw, ph = res["piece_size"]
    d.rectangle([sx + res["piece_offset"][0], sy + res["piece_offset"][1],
                 sx + res["piece_offset"][0] + pw - 1, sy + res["piece_offset"][1] + ph - 1],
                outline=(0, 255, 0), width=1)
    im.save(out_path)
    return res


if __name__ == "__main__":
    import json, sys, os
    bg = sys.argv[1] if len(sys.argv) > 1 else "../img_bg.png"
    sprite = sys.argv[2] if len(sys.argv) > 2 else "../img_sprite.png"
    resp_path = sys.argv[3] if len(sys.argv) > 3 else "../prehandle.json"
    resp = json.load(open(resp_path, encoding="utf-8", errors="replace"))
    dsi = resp["resp"]["data"]["dyn_show_info"] if "resp" in resp else resp["data"]["dyn_show_info"]
    print(json.dumps(answer_from_session(bg, sprite, dsi), indent=1))
    out = os.path.join(os.path.dirname(os.path.abspath(bg)), "solved_overlay.png")
    print("overlay ->", out)
    draw_overlay(bg, sprite, dsi, out)
