# -*- coding: utf-8 -*-
"""Reachability walk over a live build's bytecode with per-build opcode mapping.

Linear sweeps desync on unreachable bytes, so this follows entry points only
(pc 0, jump targets, closure bodies, try targets, fallthrough).  If every
reached opcode maps to a canonical handler with a known operand count, the
opcode permutation is validated.

Usage: python walk_live.py ../js/bytecode_live.json
"""
import json
import sys
from collections import deque
from disasm_tdc import OPERANDS, NAMES

sys.path.insert(0, ".")
from translate_bc import load_map

BC = "../js/bytecode_live.json"


def walk(bc, live2old):
    n = len(bc)
    seen = {}
    closures = []
    bad = []
    q = deque([0])
    while q:
        pc = q.popleft()
        if not isinstance(pc, int) or pc in seen or pc < 0 or pc >= n:
            continue
        op_live = bc[pc]
        if op_live not in live2old:
            bad.append((pc, op_live, "unmapped"))
            continue
        op = live2old[op_live]
        cnt = OPERANDS.get(op)
        if cnt is None:
            bad.append((pc, op_live, "canonical %d has no handler" % op))
            continue
        start = pc
        pc += 1
        if cnt == -1:  # closure: func, nup, narg, 2*nup pairs, narg argslots
            f = bc[start + 1]
            nup = bc[start + 2]
            narg = bc[start + 3]
            seen[start] = (op_live, op, [f, nup, narg], start + 4 + 2 * nup + narg)
            closures.append(f)
            q.append(f)
            q.append(start + 4 + 2 * nup + narg)
            continue
        ops = [bc[pc + i] for i in range(cnt)]
        end = pc + cnt
        seen[start] = (op_live, op, ops, end)
        if op == 33:                # jmp: no fallthrough
            q.append(ops[0])
            continue
        q.append(end)
        if op == 63:                # jz: fallthrough + target
            q.append(ops[0])
        elif op == 16:              # try: [catch pc, stack len]
            q.append(ops[0])
    return seen, closures, bad


def main():
    bc = json.load(open(sys.argv[1] if len(sys.argv) > 1 else BC))
    live2old = load_map()
    seen, closures, bad = walk(bc, live2old)
    from collections import Counter
    print("reachable instrs", len(seen), "closures", len(closures), "bad", len(bad))
    for b in bad[:20]:
        print("  bad", b)
    names = Counter(NAMES.get(v[1], "op%d" % v[1]) for v in seen.values())
    print("opcode histogram (canonical):", names.most_common(20))
    # closure count and entry pcs
    print("closure entry pcs", sorted(set(closures))[:10], "...")
    json.dump({"instrs": {str(k): v for k, v in seen.items()}, "closures": closures},
              open("../js/live_walk.json", "w"))


if __name__ == "__main__":
    main()
