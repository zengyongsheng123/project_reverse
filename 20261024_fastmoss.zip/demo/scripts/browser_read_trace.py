# -*- coding: utf-8 -*-
"""在页面加载前把 window/navigator/screen/document 的属性读操作全记录下来，
然后找「读出来等于 1007」的那一次 —— 定位 collect 里那个 Node 侧为 0 的字段。

只读环境，不发 verify 请求。

用法：python browser_read_trace.py [要找的值，默认 1007]
"""
import json
import os
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
sys.path.insert(0, ROOT)

import fastmoss_flow as F

PRE = r"""
(function(){
  window.__hits = [];
  window.__num = [];
  var N = 0;
  function note(label, key, v) {
    N++;
    if (v === 1007 || v === '1007') {
      if (window.__hits.length < 50) window.__hits.push([label, key, String(v), new Error().stack]);
    }
  }
  function wrapProto(proto, label) {
    if (!proto) return;
    Object.getOwnPropertyNames(proto).forEach(function(k){
      var d = Object.getOwnPropertyDescriptor(proto, k);
      if (!d || !d.get || !d.configurable) return;
      var g = d.get;
      try {
        Object.defineProperty(proto, k, {
          get: function(){ var v = g.call(this); note(label, k, v); return v; },
          set: d.set, configurable: true, enumerable: d.enumerable,
        });
      } catch (e) {}
    });
  }
  wrapProto(window.Window && Window.prototype, 'window');
  wrapProto(window.Navigator && Navigator.prototype, 'navigator');
  wrapProto(window.Screen && Screen.prototype, 'screen');
  wrapProto(window.Document && Document.prototype, 'document');
  wrapProto(window.HTMLElement && HTMLElement.prototype, 'element');
  wrapProto(window.HTMLCanvasElement && HTMLCanvasElement.prototype, 'canvas');
  wrapProto(window.Performance && Performance.prototype, 'performance');
  wrapProto(window.NavigatorUserAgentData && NavigatorUAData && NavigatorUAData.prototype, 'uadata');
  wrapProto(window.Storage && Storage.prototype, 'storage');
})();
"""


def main():
    want = sys.argv[1] if len(sys.argv) > 1 else "1007"
    hy = F.BrowserHybrid()
    hy._launch()
    t = hy._new_target()
    c = F._CDP(t["webSocketDebuggerUrl"])
    try:
        for m in ("Runtime.enable", "Page.enable", "Network.enable"):
            c.call(m)
        c.call("Page.addScriptToEvaluateOnNewDocument", source=PRE.replace("1007", want))
        c.call("Page.navigate", url=hy.PAGE)
        time.sleep(1.5)
        c.ev(hy.LOAD % F.AID)
        for _ in range(80):
            time.sleep(0.5)
            if c.ev("typeof window.TDC") == "object":
                break
        for _ in range(60):
            time.sleep(0.5)
            if c.ev("!!document.querySelector('.tencent-captcha-dy__slider-block')"):
                break
        time.sleep(1.0)
        d = c.ev("TDC.getData()")
        print("collect %d" % len(d))
        hits = c.ev("JSON.stringify(window.__hits)")
        print("hits:", hits)
        # 再兜一层：把 window/navigator/screen/document 上所有值为目标的属性列出来
        print(c.ev(r"""(function(){
          var out=[];
          function scan(o,label){ for (var k in o){ try { if (o[k] === %s) out.push(label+'.'+k); } catch(e){} } }
          scan(window,'window'); scan(navigator,'navigator');
          scan(screen,'screen'); scan(document,'document');
          return JSON.stringify(out.slice(0,40));
        })()""" % want))
    finally:
        try:
            c.ws.close()
        except Exception:
            pass
        hy._close_target(t["id"])
        if hy.proc is not None:
            try:
                hy.proc.terminate()
            except Exception:
                pass


if __name__ == "__main__":
    main()
