# -*- coding: utf-8 -*-
"""把浏览器里 tdc.js 真正跑的那个执行上下文（captcha iframe）的环境值全量导出来。

目的：collect 明文里 token 18/27/36 在 Node 侧是 0/22/40、浏览器侧是 1007/0/0，
需要知道 1007 到底是哪个字段，才能把垫片对齐。只读本地/浏览器环境，
不发任何 verify 请求。

用法：python browser_env_dump.py [输出json]
"""
import json
import os
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
sys.path.insert(0, ROOT)

import fastmoss_flow as F

DIMS = r"""
(function(){
  var out = {};
  function put(k, f){ try { out[k] = f(); } catch (e) { out[k] = '<err>'; } }
  put('href', function(){ return location.href; });
  put('origin', function(){ return location.origin; });
  put('top_is_self', function(){ return window.top === window; });
  put('frameElement', function(){
    var fe = window.frameElement;
    if (!fe) return null;
    var r = fe.getBoundingClientRect();
    return {cw: fe.clientWidth, ch: fe.clientHeight, ow: fe.offsetWidth,
            oh: fe.offsetHeight, rw: r.width, rh: r.height};
  });
  put('topInner', function(){ return [window.top.innerWidth, window.top.innerHeight]; });
  put('topOuter', function(){ return [window.top.outerWidth, window.top.outerHeight]; });
  put('topDocEl', function(){
    var d = window.top.document.documentElement;
    return [d.clientWidth, d.clientHeight, d.offsetWidth, d.offsetHeight,
            d.scrollWidth, d.scrollHeight];
  });
  put('inner', function(){ return [innerWidth, innerHeight]; });
  put('outer', function(){ return [outerWidth, outerHeight]; });
  put('screenXY', function(){ return [screenX, screenY, screenLeft, screenTop]; });
  put('screen', function(){ return [screen.width, screen.height, screen.availWidth,
    screen.availHeight, screen.availTop, screen.availLeft, screen.colorDepth,
    screen.pixelDepth]; });
  put('dpr', function(){ return devicePixelRatio; });
  put('docEl', function(){
    var d = document.documentElement;
    return [d.clientWidth, d.clientHeight, d.offsetWidth, d.offsetHeight,
            d.scrollWidth, d.scrollHeight];
  });
  put('body', function(){
    var b = document.body;
    if (!b) return null;
    var r = b.getBoundingClientRect();
    return [b.clientWidth, b.clientHeight, b.offsetWidth, b.offsetHeight,
            b.scrollWidth, b.scrollHeight, r.width, r.height];
  });
  put('historyLen', function(){ return history.length; });
  put('scroll', function(){ return [scrollX, scrollY, pageXOffset, pageYOffset]; });
  put('nav', function(){ return {hc: navigator.hardwareConcurrency,
    dm: navigator.deviceMemory, mtp: navigator.maxTouchPoints,
    pl: navigator.platform, lang: navigator.language}; });
  put('winName', function(){ return String(window.name); });
  put('winLen', function(){ return window.length; });
  put('tdcType', function(){ return typeof window.TDC; });
  return JSON.stringify(out);
})()
"""


def main():
    hy = F.BrowserHybrid()
    hy._launch()
    t = hy._new_target()
    c = F._CDP(t["webSocketDebuggerUrl"])
    try:
        for m in ("Runtime.enable", "Page.enable", "Network.enable"):
            c.call(m)
        c.call("Page.navigate", url=hy.PAGE)
        time.sleep(1.5)
        c.ev(hy.LOAD % F.AID)
        for _ in range(80):
            time.sleep(0.5)
            if c.ev("typeof window.TDC") == "object":
                break
        for _ in range(60):
            time.sleep(0.5)
            if c.ev("!!document.querySelector('.tencent-captcha-dy__slider-block')"):
                break
        time.sleep(1.0)

        ft = c.call("Page.getFrameTree")
        print("== frames ==")
        stack = [ft["frameTree"]]
        while stack:
            f = stack.pop()
            fr = f["frame"]
            print("%-10s %-40s %s" % (fr["id"][:10], (fr.get("url") or "")[:60],
                                      fr.get("name") or ""))
            stack.extend(f.get("childFrames") or [])

        ctxs = {}
        for e in c.events:
            if e.get("method") == "Runtime.executionContextCreated":
                ctx = e["params"]["context"]
                ctxs[ctx["id"]] = ctx
        print("\n== contexts ==")
        for cid, ctx in sorted(ctxs.items()):
            aux = ctx.get("auxData") or {}
            print("%3d %-28s %-12s %s" % (cid, (ctx.get("origin") or "")[:28],
                                          (ctx.get("name") or "")[:12],
                                          json.dumps(aux)[:80]))

        hits = []
        print("\n== dims ==")
        for cid, ctx in sorted(ctxs.items()):
            try:
                r = c.call("Runtime.evaluate", expression=DIMS, returnByValue=True,
                           contextId=cid, timeout=20)
            except Exception as exc:
                print(cid, "eval err", exc)
                continue
            v = (r.get("result") or {}).get("value")
            if not v:
                continue
            try:
                d = json.loads(v)
            except Exception:
                continue
            print("\n--- ctx %d %s" % (cid, (ctx.get("origin") or "")[:40]))
            for k in sorted(d):
                print("  %-12s %s" % (k, json.dumps(d[k], ensure_ascii=False)[:120]))
            if d.get("tdcType") == "object":
                hits.append((cid, d))
        if not hits:
            print("\n!! 没找到带 TDC 的上下文")
        out = sys.argv[1] if len(sys.argv) > 1 else os.path.join(
            HERE, "kcalib", "env_%d.json" % int(time.time()))
        json.dump([{cid: d} for cid, d in hits], open(out, "w", encoding="utf-8"),
                  ensure_ascii=False, indent=1)
        print("\n产出 ->", out)
    finally:
        try:
            c.ws.close()
        except Exception:
            pass
        hy._close_target(t["id"])
        if hy.proc is not None:
            try:
                hy.proc.terminate()
            except Exception:
                pass


if __name__ == "__main__":
    main()
