# -*- coding: utf-8 -*-
"""看在浏览器里，collect 的「计数 token」到底在数什么（不松手、不提交）。

步骤：加载验证码 -> getData() 两次 -> 只发 mousemove -> 按下并移动（不松手）
-> 各取一次 collect，解密后逐 token 对照。

产出：scripts/kcalib/cnt_<ts>/
"""
import json
import os
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
sys.path.insert(0, ROOT)

import fastmoss_flow as F
import token_probe as T


def get_tdc_source(c):
    sid = None
    for e in c.events:
        if e.get("method") == "Debugger.scriptParsed":
            if "tdc.js" in (e["params"].get("url") or ""):
                sid = e["params"]["scriptId"]
    return None if sid is None else c.call(
        "Debugger.getScriptSource", scriptId=sid)["scriptSource"]


def main():
    out = os.path.join(HERE, "kcalib", "cnt_%d" % int(time.time()))
    os.makedirs(out, exist_ok=True)
    hy = F.BrowserHybrid()
    hy._launch()
    t = hy._new_target()
    c = F._CDP(t["webSocketDebuggerUrl"])
    shots = []
    try:
        for m in ("Runtime.enable", "Page.enable", "Network.enable",
                  "Debugger.enable"):
            c.call(m)
        c.call("Page.navigate", url=hy.PAGE)
        time.sleep(1.5)
        c.ev(hy.LOAD % F.AID)
        for _ in range(80):
            time.sleep(0.5)
            if c.ev("typeof window.TDC") == "object":
                break
        for _ in range(60):
            time.sleep(0.5)
            if c.ev("!!document.querySelector('.tencent-captcha-dy__slider-block')"):
                break
        time.sleep(1.0)
        hy._drain(c)
        js = get_tdc_source(c)
        if js:
            open(os.path.join(out, "tdc.js"), "w", encoding="utf-8").write(js)

        def shot(name):
            d = c.ev("TDC.getData()")
            open(os.path.join(out, name + ".txt"), "w").write(d)
            shots.append((name, d))
            print("%-10s collect=%d" % (name, len(d)))

        shot("a")
        shot("b")

        g = c.ev(hy.GEO)
        th_l, th_t, th_w, th_h = g["thumb"]
        sx, sy = th_l + th_w / 2.0, th_t + th_h / 2.0
        for k in range(5):                       # 只移动，不按
            hy._mouse(c, "mouseMoved", sx + 6 * k, sy + 2, buttons=0)
            time.sleep(0.02)
        time.sleep(0.2)
        shot("c")

        hy._mouse(c, "mousePressed", sx, sy, buttons=1)
        time.sleep(0.05)
        for k in range(1, 11):                   # 按下后移动，不松手
            hy._mouse(c, "mouseMoved", sx + 12 * k, sy, buttons=1)
            time.sleep(0.02)
        time.sleep(0.2)
        shot("d")

        prm = T.params(os.path.join(out, "tdc.js"), shots[0][1])
        print("split=%d" % prm["split"])
        toks = {}
        for name, d in shots:
            try:
                pt = T.decrypt(d, prm)
            except SystemExit as exc:
                print(name, "解密失败:", exc)
                continue
            open(os.path.join(out, name + ".pt"), "wb").write(pt)
            toks[name] = [x.strip() for x in T.tokenize(pt)]
        names = [n for n in ("a", "b", "c", "d") if n in toks]
        base = toks[names[0]]
        print("\n变化：")
        for i in range(len(base)):
            vals = [toks[n][i] if i < len(toks[n]) else "<none>" for n in names]
            if len(set(vals)) > 1:
                print("  token %02d: %s" % (i, " -> ".join(v[:24] for v in vals)))
        for n in names:
            s = open(os.path.join(out, n + ".pt"), "rb").read().decode("latin-1")
            print("%s sd: %s" % (n, s[s.find('"sd"'):][:160]))
        print("产出 ->", out)
    finally:
        try:
            c.ws.close()
        except Exception:
            pass
        hy._close_target(t["id"])
        if hy.proc is not None:
            try:
                hy.proc.terminate()
            except Exception:
                pass


if __name__ == "__main__":
    main()
