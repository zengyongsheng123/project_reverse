# -*- coding: utf-8 -*-
"""Save the tdc.js build that the page currently has loaded.

CDP's Debugger.getScriptSource returns the *decompressed* source, i.e. exactly
the build whose K/C the running TDC instance uses.  (Re-fetching tdc.js over
HTTP gives a different build and is useless for key derivation.)

Usage: python fetch_live_build.py [name]
Writes ../js/live_src/tdc_<name>.js and ../js/live_src/tdc_<name>.json
"""
import hashlib
import http.client
import json
import os
import re
import sys
import time

import websocket

PORT = 9222
NAME = sys.argv[1] if len(sys.argv) > 1 else "cur3"
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "js", "live_src")


def targets():
    c = http.client.HTTPConnection("127.0.0.1", PORT, timeout=5)
    c.request("GET", "/json")
    return json.loads(c.getresponse().read())


class CDP:
    def __init__(self, url):
        self.ws = websocket.create_connection(url, timeout=120, suppress_origin=True)
        self.i = 0
        self.events = []

    def send(self, method, **p):
        self.i += 1
        self.ws.send(json.dumps({"id": self.i, "method": method, "params": p}))
        return self.i

    def recv(self, timeout):
        self.ws.settimeout(timeout)
        return json.loads(self.ws.recv())

    def call(self, method, timeout=60, **p):
        mid = self.send(method, **p)
        end = time.time() + timeout
        while True:
            m = self.recv(max(0.5, end - time.time()))
            if m.get("id") == mid:
                if "error" in m:
                    raise RuntimeError("%s -> %s" % (method, m["error"]))
                return m.get("result", {})
            if "method" in m:
                self.events.append(m)


def main():
    pg = [t for t in targets() if t.get("type") == "page"][0]
    c = CDP(pg["webSocketDebuggerUrl"])
    c.call("Runtime.enable")
    c.call("Debugger.enable")
    time.sleep(1.0)
    # scriptParsed events arrive during enable (replay) and/or just after it
    for _ in range(10):
        try:
            m = c.recv(0.5)
            if "method" in m:
                c.events.append(m)
        except Exception:
            break
    scripts = {}
    for e in c.events:
        if e.get("method") == "Debugger.scriptParsed":
            p = e["params"]
            scripts[p["url"]] = p["scriptId"]
    # The page can hold SEVERAL tdc.js builds (one per 立即体验 session) and
    # window.TDC only belongs to one of them.  Ask V8 which script the
    # currently reachable TDC.getData function lives in.
    cands = [(u, sid) for u, sid in scripts.items() if "tdc.js" in u]
    if not cands:
        print("no tdc.js script found; urls:")
        for u in list(scripts)[:40]:
            print("  ", u[:120])
        raise SystemExit(1)
    picked = None
    try:
        r = c.call("Runtime.evaluate", expression="window.TDC && TDC.getData",
                   returnByValue=False)
        oid = r.get("result", {}).get("objectId")
        if oid:
            props = c.call("Runtime.getProperties", objectId=oid, ownProperties=False)
            for p in props.get("internalProperties", []):
                if p.get("name") == "[[FunctionLocation]]":
                    picked = p.get("value", {}).get("value", {}).get("scriptId")
                    break
    except Exception as e:
        print("FunctionLocation probe failed:", e)
    by_sid = {sid: u for u, sid in cands}
    if picked in by_sid:
        url, sid = by_sid[picked], picked
        print("TDC.getData lives in", sid, url[:90])
    else:
        url, sid = cands[-1]        # fallback: most recently parsed build
        print("FunctionLocation unavailable; using newest tdc.js", sid)
    print("script:", url, "id", sid)
    src = c.call("Debugger.getScriptSource", scriptId=sid).get("scriptSource", "")
    os.makedirs(OUT, exist_ok=True)
    path = os.path.join(OUT, "tdc_%s.js" % NAME)
    open(path, "w", encoding="utf-8").write(src)
    h = hashlib.sha256(src.encode("utf-8", "surrogatepass")).hexdigest()[:16]
    meta = {"url": url, "scriptId": sid, "len": len(src), "sha256_16": h,
            "saved": path}
    json.dump(meta, open(os.path.join(OUT, "tdc_%s.json" % NAME), "w"), indent=1)
    print("saved", path, "len", len(src), "sha", h)


if __name__ == "__main__":
    main()
