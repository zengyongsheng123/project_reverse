# -*- coding: utf-8 -*-
"""Extract `eks` (TDC.getInfo().info) from a tdc.js build.

Finding (2026-10-24, instrumentation of a fresh tab): `eks` is NOT computed at
runtime and does NOT use the collect cipher.  tdc.js embeds it as a per-build
constant:

    window.<random 32-char name> = '<248-char base64>'   # 184 bytes

and the getInfo module does `Object()["info"] = window[<that name>]`
(bytecode: literal "info" ... literal "window", pushI, literal <name>,
mkpair2, getidx, setelem).

Because tdc.js is regenerated on every HTTP request, the name AND the value
change per build; the server that built tdc.js also knows the value.  Pure
Python therefore extracts the constant from the same build the page loaded
instead of trying to encrypt anything.

Usage:
    python extract_eks.py ../js/live_src/tdc_cur4.js
    python extract_eks.py --live        # fetch current source via CDP and
                                        # cross-check against TDC.getInfo()
"""
import base64
import hashlib
import json
import os
import re
import sys

PAT = re.compile(r"window\.([A-Za-z_$][\w$]*)\s*=\s*'([A-Za-z0-9+/=]{40,400})'")


def b64_len(v):
    try:
        return len(base64.b64decode(v + "=" * (-len(v) % 4)))
    except Exception:
        return -1


def find_eks(src):
    """Return [(global_name, value)] for window constants decoding to 184 B."""
    out = []
    for name, val in PAT.findall(src):
        if b64_len(val) == 184:
            out.append((name, val))
    return out


def live_source():
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    import instrument_eks_init as I
    t = I.new_target()
    c = I.CDP(t["webSocketDebuggerUrl"])
    try:
        c.call("Runtime.enable")
        c.call("Page.enable")
        c.call("Debugger.enable")
        c.call("Page.navigate", url=I.URL)
        tdc = "?"
        import time
        for _ in range(40):
            time.sleep(0.5)
            tdc = c.ev("typeof window.TDC", await_promise=False)
            if tdc == "object":
                break
        if tdc != "object":
            c.ev("(function(){var b=[...document.querySelectorAll('a.tpm-btn')]"
                 ".filter(function(e){return e.textContent.trim()==='立即体验';})[0];"
                 "if(b){b.click();return 1}return 0})()", await_promise=False)
            for _ in range(60):
                time.sleep(0.5)
                tdc = c.ev("typeof window.TDC", await_promise=False)
                if tdc == "object":
                    break
        info = c.ev("TDC.getInfo().info", await_promise=False)
        for _ in range(10):
            try:
                c.ws.settimeout(0.3)
                m = json.loads(c.ws.recv())
                if "method" in m:
                    c.events.append(m)
            except Exception:
                break
        scripts = {}
        for e in c.events:
            if e.get("method") == "Debugger.scriptParsed":
                p = e["params"]
                scripts[p["url"]] = p["scriptId"]
        sid = [v for u, v in scripts.items() if "tdc.js" in u][0]
        src = c.call("Debugger.getScriptSource", scriptId=sid)["scriptSource"]
        return src, info
    finally:
        try:
            c.ws.close()
        except Exception:
            pass
        I.close_target(t["id"])


def main():
    args = [a for a in sys.argv[1:] if not a.startswith("-")]
    info = None
    if "--live" in sys.argv:
        src, info = live_source()
        print("live source: %d chars" % len(src))
    else:
        path = args[0] if args else "../js/live_src/tdc_cur4.js"
        src = open(path, encoding="utf-8", errors="replace").read()
        print("source:", path, len(src), "chars")
    hits = find_eks(src)
    print("candidates:", [(n, len(v)) for n, v in hits])
    for name, val in hits:
        raw = base64.b64decode(val + "=" * (-len(val) % 4))
        print("  global:", name)
        print("  base64:", len(val), "chars ->", len(raw), "bytes, sha256_16",
              hashlib.sha256(raw).hexdigest()[:16])
        if info is not None:
            print("  equals TDC.getInfo().info:", val == info)
        print("  value:", val)


if __name__ == "__main__":
    main()
