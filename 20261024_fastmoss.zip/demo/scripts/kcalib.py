# -*- coding: utf-8 -*-
"""拿「真 collect」标定每会话 K 的推导规则（**不提交 verify**）。

思路：浏览器只当测量工具。弹一次验证码后直接调 `TDC.getData()` —— 它返回的
就是本会话 tdc.js 加密出来的真 collect，且 getData 不触发任何网络提交。
把「同一次会话的 tdc.js 源码」和「它产出的 collect」一起存下来，离线用候选
K / case / split 去解密：谁能解出 `[[1,1,12]]...` 明文，谁就是真 K。

这样就能在不消耗提交次数的前提下，把「选哪个 key 数组」的规则标定出来。

用法：python kcalib.py [--n 3]
产出：scripts/kcalib/sess_<ts>/tdc.js、collect.txt、pre.json、result.json
"""
import argparse
import json
import os
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
sys.path.insert(0, ROOT)

import base64
import urllib.parse

import fastmoss_flow as F
import derive_build as D
import extract_bc
import map_opcodes
import derive_key_table as dk

OUTDIR = os.path.join(HERE, "kcalib")


def collect_session():
    """弹验证码，取 (tdc.js 源码, collect, prehandle JSON)。"""
    hy = F.BrowserHybrid()
    hy._launch()
    t = hy._new_target()
    tid = t["id"]
    c = F._CDP(t["webSocketDebuggerUrl"])
    try:
        c.call("Runtime.enable")
        c.call("Page.enable")
        c.call("Network.enable")
        c.call("Debugger.enable")
        c.call("Page.navigate", url=hy.PAGE)
        time.sleep(1.5)
        c.ev(hy.LOAD % F.AID)
        for _ in range(80):
            time.sleep(0.5)
            if c.ev("typeof window.TDC") == "object":
                break
        for _ in range(60):
            time.sleep(0.5)
            if c.ev("!!document.querySelector('.tencent-captcha-dy__slider-block')"):
                break
        time.sleep(1.0)
        hy._drain(c)

        # tdc.js 源码：优先按 URL 找，其次按 TDC.getData 的函数位置找
        sid = None
        for e in c.events:
            if e.get("method") == "Debugger.scriptParsed":
                u = e["params"].get("url") or ""
                if "tdc.js" in u:
                    sid = e["params"]["scriptId"]
        if sid is None:
            raise SystemExit("找不到 tdc.js 的 scriptId")
        js = c.call("Debugger.getScriptSource", scriptId=sid)["scriptSource"]

        # 本会话真 collect（不提交）
        data = c.ev("TDC.getData()")
        if not isinstance(data, str) or len(data) < 100:
            raise SystemExit("TDC.getData() 异常：%r" % (data,))

        resps, _ = hy._net(c, "cap_union_prehandle")
        pre = None
        for r in reversed(resps):
            pre = hy._jsonp(r["body"])
            if pre:
                break
        return js, data, pre
    finally:
        try:
            c.ws.close()
        except Exception:
            pass
        hy._close_target(tid)
        if hy.proc is not None:
            try:
                hy.proc.terminate()
            except Exception:
                pass


def _dec_block(cip, ct, i):
    v0, v1 = cip._decrypt_block(cip._b2w(ct[i:i + 4]),
                                cip._b2w(ct[i + 4:i + 8]))
    return cip._w2b(v0) + cip._w2b(v1)


def try_decrypt(raw, keys, cases):
    """暴力 split。先只解第 0 个块做前缀筛（O(1)），命中再拼整段。"""
    hits, n = [], len(raw)
    for tag, key in keys:
        for ci, case in enumerate(cases):
            cip = F.TDCCipher({"key": key, "case": case, "split": n})
            for split in range(24, n + 1):
                ct = raw[split - 24:split] + raw[:split - 24] + raw[split:]
                if _dec_block(cip, ct, 0)[:2] != b"[[":
                    continue
                pt = b"".join(_dec_block(cip, ct, i)
                              for i in range(0, len(ct), 8))
                if b'{"cd":[' in pt[:120]:
                    hits.append({"tag": tag, "case_idx": ci, "case": case,
                                 "split": split, "pt": pt,
                                 "head": pt[:48].decode("latin-1", "replace")})
                    break
    return hits


def analyse(js_path, collect):
    old = map_opcodes.handlers(D.REF_SRC)
    live = map_opcodes.handlers(js_path)
    m = D.resolve_map(old, live)
    src = open(js_path, encoding="utf-8", errors="replace").read()
    bc = extract_bc.decode(extract_bc.find_arg(src))
    seen = dk.walk(bc, m)
    arrays = D.derive_key_arrays(seen)
    hits_ = D.find_cipher(seen)

    keys = [(tag, arr) for tag, arr in arrays.items()]
    cases = []
    for pc, f, pairs in hits_:
        case, _ = D.derive_case(seen, f)
        if case and case not in cases:
            cases.append(case)
    if not cases:
        cases = [F.PROFILE["case"]]

    raw = base64.b64decode(urllib.parse.unquote(collect))
    print("collect raw=%d bytes, K 候选=%d, case 候选=%d"
          % (len(raw), len(keys), len(cases)))
    hits = try_decrypt(raw, keys, cases)
    for h in hits:
        print("  命中！K 来自 %s  case=%s split=%d" % (h["tag"], h["case"], h["split"]))
        print("       明文头：%r" % h["head"])
    if not hits:
        print("  没有候选能解出明文")
    return {"keys": [[list(k), [hex(x) for x in v]] for k, v in keys],
            "cases": cases, "hits": [{k: v for k, v in h.items() if k != "pt"}
                                     for h in hits]}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=1)
    args = ap.parse_args()

    for i in range(args.n):
        print("=== 会话 %d/%d" % (i + 1, args.n))
        js, collect, pre = collect_session()
        d = os.path.join(OUTDIR, "sess_%d" % int(time.time()))
        os.makedirs(d, exist_ok=True)
        p = os.path.join(d, "tdc.js")
        open(p, "w", encoding="utf-8").write(js)
        open(os.path.join(d, "collect.txt"), "w").write(collect)
        json.dump(pre, open(os.path.join(d, "pre.json"), "w"),
                  ensure_ascii=False, indent=1)
        print("  tdc.js %d 字符，collect %d 字符 -> %s" % (len(js), len(collect), d))
        info = analyse(p, collect)
        json.dump(info, open(os.path.join(d, "result.json"), "w"), indent=1)
        time.sleep(1.0)


if __name__ == "__main__":
    main()
