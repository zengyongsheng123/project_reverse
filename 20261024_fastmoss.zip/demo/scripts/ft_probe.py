# -*- coding: utf-8 -*-
"""Does the optional ``sd.ft`` field depend on a *trusted* user gesture?

Every build sampled so far through fresh_session.py (programmatic
``element.click()``) produced ``"sd":{"od":"C"}`` with no ``ft``; every build
sampled from the long-lived page the user clicked by hand produced
``{"od":"C","ft":"6f_7ff__H"}``.  This script opens its own fresh target and
opens the captcha modal with real CDP mouse input (Input.dispatchMouseEvent),
which the page sees as a trusted click, then samples getData() three times.

It never touches the user's tab.

Usage: python ft_probe.py [name]
Writes js/live_src/tdc_<name>.js/.json and scripts/fresh_probe_<name>.json
so derive_build.py can be run offline on the result.
"""
import hashlib
import json
import os
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
JS = os.path.join(ROOT, "js")
sys.path.insert(0, HERE)

import instrument_eks_init as I
import fresh_session as F


def _button_center(c):
    r = c.ev("""(function(){
        var b=[].slice.call(document.querySelectorAll('a.tpm-btn')).filter(function(e){
            return e.textContent.trim()==='立即体验';})[0];
        if(!b) return null;
        b.scrollIntoView({block:'center'});
        var r=b.getBoundingClientRect();
        return {x:r.left+r.width/2, y:r.top+r.height/2};
    })()""", await_promise=False)
    return r if isinstance(r, dict) and "x" in r else None


def _trusted_click(c, x, y):
    for t in ("mouseMoved", "mousePressed", "mouseReleased"):
        p = {"type": t, "x": x, "y": y, "button": "left", "clickCount": 1}
        if t == "mouseReleased":
            p["clickCount"] = 1
        c.call("Input.dispatchMouseEvent", **p)
        time.sleep(0.08)


def collect(name):
    t = I.new_target()
    tid = t["id"]
    print("    fresh target", tid)
    c = I.CDP(t["webSocketDebuggerUrl"])
    try:
        c.call("Runtime.enable")
        c.call("Page.enable")
        c.call("Debugger.enable")
        c.call("Page.navigate", url=I.URL)
        tdc = "?"
        for _ in range(40):
            time.sleep(0.5)
            tdc = c.ev("typeof window.TDC", await_promise=False)
            if tdc == "object":
                break
        if tdc != "object":
            pos = _button_center(c)
            if not pos:
                raise SystemExit("立即体验 button not found")
            print("    trusted click at (%.0f, %.0f)" % (pos["x"], pos["y"]))
            c.ev("(function(){window.__ftTrusted=null;"
                 "document.addEventListener('click',function(e){"
                 "window.__ftTrusted=e.isTrusted;},true);return 1})()",
                 await_promise=False)
            _trusted_click(c, pos["x"], pos["y"])
            for _ in range(60):
                time.sleep(0.5)
                tdc = c.ev("typeof window.TDC", await_promise=False)
                if tdc == "object":
                    break
        if tdc != "object":
            raise SystemExit("TDC never appeared")
        print("    TDC up; click.isTrusted =",
              c.ev("window.__ftTrusted", await_promise=False))
        # real pointer movement over the captcha area (no click/drag, so no
        # verification is attempted) -- does that make the optional ft appear?
        for k in range(25):
            c.call("Input.dispatchMouseEvent", type="mouseMoved",
                   x=400 + (k % 10) * 12, y=380 + (k // 10) * 8,
                   button="none", buttons=0)
            time.sleep(0.02)
        time.sleep(0.3)

        url, sid = F._tdc_source(c)
        if sid is None:
            raise SystemExit("no tdc.js script")
        src = c.call("Debugger.getScriptSource", scriptId=sid).get("scriptSource", "")
        sha = hashlib.sha256(src.encode("utf-8", "surrogatepass")).hexdigest()[:16]
        os.makedirs(os.path.join(JS, "live_src"), exist_ok=True)
        src_path = os.path.join(JS, "live_src", "tdc_%s.js" % name)
        open(src_path, "w", encoding="utf-8").write(src)
        json.dump({"url": url, "scriptId": sid, "len": len(src), "sha256_16": sha,
                   "saved": src_path, "trusted_gesture": True},
                  open(os.path.join(JS, "live_src", "tdc_%s.json" % name), "w"), indent=1)
        print("    tdc.js %d chars sha %s" % (len(src), sha))

        samples = []
        for k in range(3):
            if k == 1:
                time.sleep(1.2)
            before = c.ev("Math.floor(Date.now()/1000)", await_promise=False)
            d = c.ev("TDC.getData()", await_promise=False)
            after = c.ev("Math.floor(Date.now()/1000)", await_promise=False)
            samples.append({"d": d, "now": before, "after": after})
            print("    getData #%d chars=%s" % (k + 1, len(d or "")))
    finally:
        try:
            c.ws.close()
        except Exception:
            pass
        I.close_target(tid)

    probe = os.path.join(HERE, "fresh_probe_%s.json" % name)
    json.dump({"sha256_16": sha, "src": src_path, "trusted_gesture": True,
               "datas": samples}, open(probe, "w"), indent=1)
    print("    wrote", probe)
    return {"src": src_path, "probe": probe, "sha": sha}


if __name__ == "__main__":
    collect(sys.argv[1] if len(sys.argv) > 1 else "ft")
