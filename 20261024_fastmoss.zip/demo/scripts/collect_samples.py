# -*- coding: utf-8 -*-
"""Fetch N captcha sessions (prehandle + bg/sprite images) into samples/sN/."""
import json, io, os, sys, time
from PIL import Image
from probe import prehandle, get_img

OUT = os.path.join(os.path.dirname(__file__), "..", "samples")

def main(n=4):
    os.makedirs(OUT, exist_ok=True)
    for i in range(1, n + 1):
        d = os.path.join(OUT, "s%d" % i)
        os.makedirs(d, exist_ok=True)
        tkid, resp = prehandle()
        info = resp["data"]["dyn_show_info"]
        bg = get_img(info["bg_elem_cfg"]["img_url"] + "&tkid=" + tkid, tkid)
        sp = get_img(info["sprite_url"] + "&tkid=" + tkid, tkid)
        Image.open(io.BytesIO(bg)).save(os.path.join(d, "bg.png"))
        Image.open(io.BytesIO(sp)).save(os.path.join(d, "sprite.png"))
        json.dump(resp, open(os.path.join(d, "resp.json"), "w"), ensure_ascii=False)
        print("session", i, "tkid", tkid, "sid", resp["data"].get("sid"),
              "size", info["bg_elem_cfg"]["size_2d"],
              "piece", [e for e in info["fg_elem_list"] if e["id"] == 1])
        time.sleep(1.0)

if __name__ == "__main__":
    main(int(sys.argv[1]) if len(sys.argv) > 1 else 4)
