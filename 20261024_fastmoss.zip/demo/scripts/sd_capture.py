# -*- coding: utf-8 -*-
"""看「拖动之后 SDK 的 collect 多了什么」——不发 verify（拦下 SDK 的提交）。

思路：同一个页面、同一个 build，先 TDC.getData() 拿一份「拖动前」的 collect，
拖到答案位置后，用 Fetch 域把 SDK 的 verify 请求**拦在半路**（failRequest，
请求不会到服务端），再 getData() 拿一份「拖动后」的 collect，两份解密后逐
token 对照。

产出：scripts/kcalib/sd_<ts>/tdc.js、a.txt、b.txt、a.pt、b.pt、diff.txt
"""
import base64
import json
import os
import sys
import time
import urllib.parse

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
sys.path.insert(0, ROOT)

import fastmoss_flow as F
import token_probe as T


def get_tdc_source(c):
    sid = None
    for e in c.events:
        if e.get("method") == "Debugger.scriptParsed":
            u = (e["params"].get("url") or "")
            if "tdc.js" in u:
                sid = e["params"]["scriptId"]
    if sid is None:
        return None
    return c.call("Debugger.getScriptSource", scriptId=sid)["scriptSource"]


def main():
    out = os.path.join(HERE, "kcalib", "sd_%d" % int(time.time()))
    os.makedirs(out, exist_ok=True)

    hy = F.BrowserHybrid()
    hy._launch()
    t = hy._new_target()
    c = F._CDP(t["webSocketDebuggerUrl"])
    try:
        for m in ("Runtime.enable", "Page.enable", "Network.enable",
                  "Debugger.enable"):
            c.call(m)
        c.call("Page.navigate", url=hy.PAGE)
        time.sleep(1.5)
        c.ev(hy.LOAD % F.AID)
        for _ in range(80):
            time.sleep(0.5)
            if c.ev("typeof window.TDC") == "object":
                break
        for _ in range(60):
            time.sleep(0.5)
            if c.ev("!!document.querySelector('.tencent-captcha-dy__slider-block')"):
                break
        time.sleep(1.0)
        hy._drain(c)
        js = get_tdc_source(c)
        if js:
            open(os.path.join(out, "tdc.js"), "w", encoding="utf-8").write(js)
            print("tdc.js %d 字符" % len(js))

        pre = None
        resps, _ = hy._net(c, "cap_union_prehandle")
        for r in reversed(resps):
            pre = hy._jsonp(r["body"])
            if pre:
                break
        dsi = (pre or {}).get("data", {}).get("dyn_show_info") or {}
        print("prehandle: sess=%d" % len((pre or {}).get("sess") or ""))

        # 缺口答案：用 Python 识别同一张图
        s = F.FastMossCaptchaFlow.make_session()
        tkid = str(int(time.time() * 1000) % 1000000000)
        ans = None
        try:
            open(F.BG, "wb").write(F.FastMossCaptchaFlow.get_image(
                s, dsi["bg_elem_cfg"]["img_url"], tkid))
            open(F.SP, "wb").write(F.FastMossCaptchaFlow.get_image(
                s, dsi["sprite_url"], tkid))
            ans = F.GapRecognizer("zncc").recognize(F.BG, F.SP, dsi)
            print("ans=%s" % ans["data"])
        except Exception as exc:
            print("识图失败（只用来看 sd，不影响）:", exc)

        a = c.ev("TDC.getData()")
        open(os.path.join(out, "a.txt"), "w").write(a)
        print("拖动前 collect %d 字符" % len(a))

        g = c.ev(hy.GEO)
        img_l, _img_t, img_w = g["img"][0], g["img"][1], g["img"][2]
        scale = g["fg"][2] / 120.0
        th_l, th_t, th_w, th_h = g["thumb"]
        sx, sy = th_l + th_w / 2.0, th_t + th_h / 2.0
        cur = (g["fg"][0] - img_l) / scale
        target = float(ans["x"]) if ans else cur + 100
        need = (target - cur) * scale
        print("scale=%.5f need_display=%.1f" % (scale, need))

        hy._mouse(c, "mousePressed", sx, sy, buttons=1)
        time.sleep(0.05)
        for k in range(1, 21):
            hy._mouse(c, "mouseMoved", sx + need * k / 20.0,
                      sy + (1.0 if k % 3 else 0.0), buttons=1)
            time.sleep(0.015)
        time.sleep(0.2)
        m = c.ev("TDC.getData()")
        open(os.path.join(out, "m.txt"), "w").write(m)
        print("拖动中 collect %d 字符" % len(m))

        # 记录页面 SDK 到底往 TDC.setData 里塞了什么
        print("setData 类型:", c.ev("typeof TDC.setData"))
        c.ev(r"""(function(){
          if (window.__sdLog) return 'already';
          window.__sdLog = [];
          var o = TDC.setData;
          TDC.setData = function (x) {
            try { window.__sdLog.push(String(JSON.stringify(x)).slice(0, 4000)); }
            catch (e) { window.__sdLog.push('ERR ' + e); }
            return o.apply(this, arguments);
          };
          return 'hooked';
        })()""")

        # 拦下 SDK 的 verify：请求不出去，只记下来
        c.call("Fetch.enable", patterns=[{"urlPattern": "*cap_union_new_verify*",
                                         "requestStage": "Request"}])
        blocked = []
        hy._mouse(c, "mouseReleased", sx + need, sy, buttons=0)
        t_end = time.time() + 20
        while time.time() < t_end:
            time.sleep(0.2)
            for e in list(c.events):
                if e.get("method") != "Fetch.requestPaused" or e.get("__done"):
                    continue
                e["__done"] = True
                p = e["params"]
                blocked.append(p)
                try:
                    c.call("Fetch.failRequest", requestId=p["requestId"],
                           errorReason="ConnectionRefused")
                except Exception:
                    pass
            if blocked:
                break
        print("拦下 %d 个 verify 请求（都没有发到服务端）" % len(blocked))
        log = c.ev("JSON.stringify(window.__sdLog || [])")
        print("setData 调用记录:", log)
        if blocked:
            q = blocked[0].get("request", {}).get("postData") or ""
            kv = dict(urllib.parse.parse_qsl(q, keep_blank_values=True))
            print("  SDK collect=%d tlg=%s ans=%s"
                  % (len(kv.get("collect", "")), kv.get("tlg"), kv.get("ans")))
            open(os.path.join(out, "blocked.json"), "w").write(
                json.dumps(blocked, ensure_ascii=False, indent=1))

        time.sleep(0.5)
        b = c.ev("TDC.getData()")
        open(os.path.join(out, "b.txt"), "w").write(b)
        print("拖动后 collect %d 字符" % len(b))

        if js and a and b:
            prm = T.params(os.path.join(out, "tdc.js"), a)
            print("params split=%d" % prm["split"])
            for name in ("a", "m", "b"):
                raw = open(os.path.join(out, "%s.txt" % name)).read()
                try:
                    pt = T.decrypt(raw, prm)
                except SystemExit as exc:
                    print(name, "解密失败:", exc)
                    continue
                open(os.path.join(out, "%s.pt" % name), "wb").write(pt)
                print("%s: %d 字节" % (name, len(pt)))
            ta = T.tokenize(open(os.path.join(out, "a.pt"), "rb").read())
            tb = T.tokenize(open(os.path.join(out, "b.pt"), "rb").read())
            lines = []
            print("\n拖动前后 token 对照（a=拖动前 b=拖动后）")
            for i in range(max(len(ta), len(tb))):
                x = ta[i] if i < len(ta) else "<missing>"
                y = tb[i] if i < len(tb) else "<missing>"
                mk = "  " if x.strip() == y.strip() else "!!"
                line = "%s %02d %-40r | %r" % (mk, i, x[:40], y[:40])
                print(line)
                lines.append(line)
            ea = open(os.path.join(out, "a.pt"), "rb").read().decode("latin-1")
            eb = open(os.path.join(out, "b.pt"), "rb").read().decode("latin-1")
            print("\na sd:", ea[ea.find('"sd"'):][:200])
            print("b sd:", eb[eb.find('"sd"'):][:1200])
            open(os.path.join(out, "diff.txt"), "w",
                 encoding="utf-8").write("\n".join(lines))
        print("产出 ->", out)
    finally:
        try:
            c.ws.close()
        except Exception:
            pass
        hy._close_target(t["id"])
        if hy.proc is not None:
            try:
                hy.proc.terminate()
            except Exception:
                pass


if __name__ == "__main__":
    main()
