# -*- coding: utf-8 -*-
"""探针：改 shim 的一个取值，看 collect 明文里哪个 token 跟着变。

这样不用逆 VM 就知道每个 token 对应哪个环境字段，从而把 Node 侧垫片
对齐到真浏览器。纯本地，不发网络请求（除了不用发）。

用法：python token_probe.py <diff 目录>
  diff 目录里要有 tdc.js、browser.txt（build_diff.py 的产出）
"""
import base64
import json
import os
import subprocess
import sys
import urllib.parse

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
sys.path.insert(0, ROOT)

import fastmoss_flow as F
import kcalib

MOCKS = [
    ("baseline", {}),
    ("docEl.clientHeight=1007", {"clientHeight": 1007}),
    ("docEl.offsetHeight=1007", {"offsetHeight": 1007}),
    ("plugins=[1,2,3]", {"plugins": [1, 2, 3]}),
    ("mimeTypes=[1]", {"mimeTypes": [1]}),
    ("cookieEnabled=false", {"cookieEnabled": False}),
    ("onLine=false", {"onLine": False}),
    ("webdriver=true", {"webdriver": True}),
    ("doNotTrack=1", {"doNotTrack": "1"}),
    ("appName=X", {"appName": "X"}),
    ("appVersion=X", {"appVersion": "X"}),
    ("product=X", {"product": "X"}),
    ("languages=[en]", {"languages": ["en"]}),
    ("language=en", {"language": "en"}),
    ("innerHeight=1007", {"innerHeight": 1007}),
    ("hardwareConcurrency=8", {"hardwareConcurrency": 8}),
]


def tokenize(pt):
    s = pt.decode("latin-1")
    i = s.find('{"cd":[')
    if i < 0:
        return []
    j = i + len('{"cd":[')
    depth, in_str, esc, start, out = 0, False, False, j, []
    while j < len(s):
        ch = s[j]
        if in_str:
            if esc:
                esc = False
            elif ch == "\\":
                esc = True
            elif ch == '"':
                in_str = False
        else:
            if ch == '"':
                in_str = True
            elif ch in "[{(":
                depth += 1
            elif ch in "]}":
                if depth == 0:
                    out.append(s[start:j])
                    return out
                depth -= 1
            elif ch == ",":
                if depth == 0:
                    out.append(s[start:j])
                    start = j + 1
        j += 1
    return out


def params(jsp, collect):
    info = kcalib.analyse(jsp, collect)
    if not info["hits"]:
        raise SystemExit("解不开")
    h = info["hits"][0]
    tag = tuple(tuple(x) for x in h["tag"])
    key = None
    for k, v in info["keys"]:
        if tuple(tuple(x) for x in k) == tag:
            key = [int(x, 16) for x in v]
    return {"key": key, "case": h["case"], "split": h["split"]}


def run_node(js_text, mock):
    work = os.path.join(ROOT, ".node_tdc_work")
    os.makedirs(work, exist_ok=True)
    p = os.path.join(work, "probe.js")
    open(p, "w", encoding="utf-8").write(js_text)
    cmd = [F.NODE_BIN, os.path.join(F.NODE_ASSETS, "run.js"), p, "--calls", "1",
           "--mock", json.dumps(mock)]
    r = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8",
                       errors="replace", timeout=180)
    lines = [l for l in (r.stdout or "").strip().splitlines() if l.startswith("{")]
    if not lines:
        raise SystemExit("node 无输出: %s" % (r.stderr or "")[:300])
    out = json.loads(lines[-1])
    if not out.get("ok"):
        raise SystemExit("node 失败: %s" % out.get("err"))
    return out["datas"][0]["d"]


def decrypt(collect, prm):
    """旋转偏移（split）是每条 collect 各自的，不是 build 常量，所以逐条试。

    只试 24 的倍数（已观测到的值全是 24 的倍数）。
    """
    raw = base64.b64decode(urllib.parse.unquote(collect))
    for step in (24, 1):
        for split in range(24, len(raw) + 1, step):
            cip = F.TDCCipher({"key": prm["key"], "case": prm["case"],
                               "split": split})
            pt = cip.decode_data(collect)
            # 浏览器那条明文头部是拖动三元组（[[42,25,3594],[-1,-1,16]{"cd":[...），
            # 不以 [[1,1,12]] 开头；只要是以 '[' 开头且 cd 数组在前 120 字节内就算对上。
            if pt.startswith(b"[") and b'{"cd":[' in pt[:120]:
                return pt
    raise SystemExit("解不开（split 试遍了）")


def main():
    d = sys.argv[1] if len(sys.argv) > 1 else os.path.join(
        HERE, "kcalib", sorted(x for x in os.listdir(os.path.join(HERE, "kcalib"))
                               if x.startswith("diff_"))[-1])
    jsp = os.path.join(d, "tdc.js")
    js = open(jsp, encoding="utf-8").read()
    bpt = open(os.path.join(d, "browser.pt"), "rb").read()
    base_collect = open(os.path.join(d, "browser.txt")).read()
    prm = params(jsp, base_collect)
    print("params: split=%d case=%s" % (prm["split"], prm["case"]))

    bt = tokenize(bpt)
    prev = None
    for name, mock in MOCKS:
        collect = run_node(js, mock)
        pt = decrypt(collect, prm)
        if b'{"cd":[' not in pt[:120]:
            print("%-32s 解不开（mock 破坏了初始化？）" % name)
            continue
        tk = tokenize(pt)
        cur = [t.strip() for t in tk]
        if prev is None:
            print("\n%s: %d token" % (name, len(tk)))
            for i, v in enumerate(tk):
                b = bt[i].strip() if i < len(bt) else "<none>"
                flag = "  " if v.strip() == b else "!!"
                print("%s %02d node=%-42r browser=%r" % (flag, i, v[:42], b[:42]))
        else:
            diff = [i for i in range(min(len(cur), len(prev)))
                    if cur[i] != prev[i]]
            if not diff:
                print("%-32s 无变化" % name)
            for i in diff:
                print("%-32s 改 token %02d: %r -> %r"
                      % (name, i, prev[i][:40], cur[i][:40]))
        prev = cur


if __name__ == "__main__":
    main()
