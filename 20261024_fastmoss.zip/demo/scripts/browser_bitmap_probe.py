# -*- coding: utf-8 -*-
"""在浏览器里逐个「拿掉一个 API」，看 collect 里那个能力位图（1007）掉了哪一位。

为什么这么做：同一 build 下 Node 侧该字段是 0，浏览器是 1007 —— 说明它是一张
「检测到的浏览器能力」位图。位图是 getData 时现算的（删掉 customElements 立刻
从 1007 变 1006），所以在**一次会话**里就能把每位对应哪个 API 全测出来。

只读：只调 TDC.getData()，不发 verify。

用法：python browser_bitmap_probe.py
"""
import json
import os
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
sys.path.insert(0, ROOT)

import fastmoss_flow as F
import token_probe as T
import counter_probe as C

# 候选：全局名 / 原型方法。"target" 是删除时用的路径
CANDS = [
    "CSS", "customElements", "IntersectionObserver", "ResizeObserver",
    "MutationObserver", "PerformanceObserver", "ReportingObserver", "Worker",
    "SharedWorker", "OffscreenCanvas", "WebSocket", "XMLHttpRequest",
    "indexedDB", "Notification", "AudioContext", "webkitAudioContext",
    "OfflineAudioContext", "speechSynthesis", "SpeechSynthesisUtterance",
    "SpeechRecognition", "matchMedia", "requestAnimationFrame",
    "requestIdleCallback", "structuredClone", "MessageChannel",
    "BroadcastChannel", "EventSource", "ReadableStream", "AbortController",
    "customElements", "HTMLDialogElement", "WebGLRenderingContext",
    "WebGL2RenderingContext", "Image", "fetch", "queueMicrotask",
    "Intl", "BigInt", "WeakRef", "Proxy", "history", "localStorage",
    "sessionStorage", "name", "crypto", "performance", "screen", "devicePixelRatio",
    "scrollX", "getComputedStyle", "chrome", "visualViewport", "top",
]
NAV = ["mediaDevices", "serviceWorker", "permissions", "storage", "geolocation",
       "getBattery", "sendBeacon", "connection", "userAgentData", "deviceMemory",
       "maxTouchPoints", "pdfViewerEnabled", "plugins", "mimeTypes", "cookieEnabled",
       "hardwareConcurrency", "languages", "webdriver", "credentials", "mediaSession",
       "clipboard", "userAgent", "platform", "vendor", "appName", "appVersion"]
DOC = ["fonts", "cookie", "hidden", "visibilityState", "hasFocus", "title",
       "characterSet", "referrer", "activeElement", "styleSheets", "scripts",
       "images", "links", "compatMode", "doctype", "defaultView", "baseURI"]
PROTO = [("Element.prototype", "animate"), ("Element.prototype", "attachShadow"),
         ("HTMLCanvasElement.prototype", "toBlob"),
         ("HTMLCanvasElement.prototype", "toDataURL"),
         ("HTMLCanvasElement.prototype", "captureStream"),
         ("MediaDevices.prototype", "getUserMedia"),
         ("Navigator.prototype", "getBattery"),
         ("Performance.prototype", "measureUserAgentSpecificMemory")]

SETUP = r"""
window.__saved = window.__saved || {};
window.__kill = function(path) {
  try {
    var parts = path.split('.');
    var obj = window, key = parts[0];
    for (var i = 0; i < parts.length - 1; i++) { obj = obj[parts[i]]; if (!obj) return 'noobj'; }
    key = parts[parts.length - 1];
    if (!(key in obj)) return 'absent';
    window.__saved[path] = { had: true, val: obj[key] };
    try { delete obj[key]; } catch (e) { try { obj[key] = undefined; } catch (e2) { return 'ro'; } }
    return ('undefined' === typeof obj[key]) ? 'killed' : 'stuck';
  } catch (e) { return 'err:' + e.message; }
};
window.__revive = function(path) {
  try {
    var rec = window.__saved[path]; if (!rec) return 'none';
    var parts = path.split('.'); var obj = window;
    for (var i = 0; i < parts.length - 1; i++) { obj = obj[parts[i]]; if (!obj) return 'noobj'; }
    obj[parts[parts.length - 1]] = rec.val; return 'ok';
  } catch (e) { return 'err:' + e.message; }
};
"""


def main():
    hy = F.BrowserHybrid()
    hy._launch()
    t = hy._new_target()
    c = F._CDP(t["webSocketDebuggerUrl"])
    try:
        for m in ("Runtime.enable", "Page.enable", "Network.enable", "Debugger.enable"):
            c.call(m)
        c.call("Page.navigate", url=hy.PAGE)
        time.sleep(1.5)
        c.ev(hy.LOAD % F.AID)
        for _ in range(80):
            time.sleep(0.5)
            if c.ev("typeof window.TDC") == "object":
                break
        for _ in range(60):
            time.sleep(0.5)
            if c.ev("!!document.querySelector('.tencent-captcha-dy__slider-block')"):
                break
        time.sleep(1.0)
        hy._drain(c)
        js = C.get_tdc_source(c)
        tdc_path = os.path.join(HERE, ".bitmap_tdc.js")
        open(tdc_path, "w", encoding="utf-8").write(js)
        c.ev(SETUP)

        first = c.ev("TDC.getData()")
        prm = T.params(tdc_path, first)

        def toks():
            d = c.ev("TDC.getData()")
            try:
                return [x.strip() for x in T.tokenize(T.decrypt(d, prm))]
            except Exception:
                return None

        base_t = toks()
        print("基线 token 数:", len(base_t))

        # 位图是哪一位？先拿 CSS / customElements 探一下：谁的值按位掉了就是它。
        # （不能按「值在 900~1200」筛，screen.height=1080 也会撞进来。）
        idx = None
        for feat in ("customElements", "CSS"):
            r = c.ev("window.__kill(%s)" % json.dumps(feat))
            t2 = toks()
            c.ev("window.__revive(%s)" % json.dumps(feat))
            if not t2:
                continue
            for i in range(min(len(base_t), len(t2))):
                a, b = base_t[i], t2[i]
                if a.isdigit() and b.isdigit() and a != b:
                    ia, ib = int(a), int(b)
                    if (ia & ib) == ib and 0 < ia - ib <= 1024:
                        print("kill %s: %s -> %s  (token %d, bit%s)"
                              % (feat, a, b, i, ia ^ ib))
                        idx = i
                        break
            if idx is not None:
                break
        if idx is None:
            print("没找到位图 token，退出")
            return

        def mask():
            t = toks()
            if t is None or idx >= len(t):
                return None
            v = t[idx]
            return int(v) if v.isdigit() else None

        base = mask()
        print("基线位图:", base, "二进制:", bin(base or 0), "(token %d)" % idx)

        out = open(os.path.join(HERE, "kcalib", "bitmap_%d.txt"
                                % int(time.time())), "w", encoding="utf-8")

        def log(line):
            print(line)
            out.write(line + "\n")
            out.flush()

        def probe(path):
            r = c.ev("window.__kill(%s)" % json.dumps(path))
            m = mask()
            c.ev("window.__revive(%s)" % json.dumps(path))
            if m is None:
                log("%-52s %-9s 位图没了" % (path, r))
                return
            if m == base:
                log("%-52s %-9s 不变" % (path, r))
                return
            x = base ^ m
            bit = x.bit_length() - 1 if x and (x & (x - 1)) == 0 else None
            log("%-52s %-9s %d -> %d  (bit %s)" % (path, r, base, m, bit))

        for name in CANDS:
            probe(name)
        for name in NAV:
            probe("Navigator.prototype." + name)
        for name in DOC:
            probe("Document.prototype." + name)
        for proto, name in PROTO:
            probe(proto + "." + name)
        out.close()
    finally:
        try:
            c.ws.close()
        except Exception:
            pass
        hy._close_target(t["id"])
        if hy.proc is not None:
            try:
                hy.proc.terminate()
            except Exception:
                pass


if __name__ == "__main__":
    main()
