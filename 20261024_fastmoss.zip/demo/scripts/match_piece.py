# -*- coding: utf-8 -*-
"""用拼图块的内容在背景图里做 ZNCC 搜索，判断哪个形状是真正的缺口。

缺口 = 拼图块原本所在的位置（内容被压暗，但边缘结构还在）。
诱饵 = 另一处拼图形状（通常是平涂填充，或者内容跟块对不上）。
ZNCC 对「整体乘个暗化系数」不敏感，所以压暗的缺口也能匹配上。

只读本地图片，不发网络请求。
用法：python match_piece.py [bg] [sprite]
"""
import os
import sys

import numpy as np
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)

try:
    from scipy.signal import fftconvolve
except Exception:                                   # 回退：numpy FFT 卷积
    fftconvolve = None


def corr_valid(a, b):
    """out[y,x] = sum_{u,v} a[y+u, x+v] * b[u,v]，形状 (H-ph+1, W-pw+1)。"""
    bf = b[::-1, ::-1]
    if fftconvolve is not None:
        return fftconvolve(a, bf, mode="valid")
    H, W = a.shape
    ph, pw = b.shape
    sh, sw = H + ph - 1, W + pw - 1
    fa = np.fft.rfft2(a, s=(sh, sw))
    fb = np.fft.rfft2(bf, s=(sh, sw))
    full = np.fft.irfft2(fa * fb, s=(sh, sw))
    return full[ph - 1:H, pw - 1:W]


def masked_zncc(img, patch, mask):
    m = mask.astype(np.float64)
    M = float(m.sum())
    pv = patch[mask]
    mean_p = float(pv.mean())
    norm_p = float(np.sqrt(((pv - mean_p) ** 2).sum()))
    if norm_p < 1e-6:
        norm_p = 1e-6
    s1 = corr_valid(img, m)
    s2 = corr_valid(img * img, m)
    mean_b = s1 / M
    var_b = np.maximum(s2 / M - mean_b ** 2, 1e-3)
    num = corr_valid(img, ((patch - mean_p) * m))
    return num / (np.sqrt(var_b * M) * norm_p)


def erode(mask, k=3):
    out = mask.copy()
    for _ in range(k):
        m = out
        e = m.copy()
        e[1:, :] &= m[:-1, :]
        e[:-1, :] &= m[1:, :]
        e[:, 1:] &= m[:, :-1]
        e[:, :-1] &= m[:, 1:]
        out = e
    return out


def selftest():
    rng = np.random.default_rng(0)
    img = rng.normal(80, 20, (60, 90))
    patch = rng.normal(80, 20, (12, 12))
    mask = np.zeros((12, 12), bool)
    mask[2:10, 2:10] = True
    ty, tx = 20, 33
    img[ty:ty + 12, tx:tx + 12][mask] = patch[mask] * 0.35   # 压暗后再贴
    c = masked_zncc(img, patch, mask)
    y, x = np.unravel_index(np.argmax(c), c.shape)
    print("selftest peak=%.3f at (%d,%d) expect (%d,%d)  (max=%.3f min=%.3f)"
          % (c[y, x], y, x, ty, tx, c.max(), c.min()))
    assert (y, x) == (ty, tx) and abs(c[y, x] - 1.0) < 0.05


def main():
    selftest()
    bg_p = sys.argv[1] if len(sys.argv) > 1 else os.path.join(ROOT, "fastmoss_bg.png")
    sp_p = sys.argv[2] if len(sys.argv) > 2 else os.path.join(ROOT, "fastmoss_sprite.png")

    bg = np.array(Image.open(bg_p).convert("RGB")).astype(np.float64).mean(axis=2)
    sp = np.array(Image.open(sp_p).convert("RGBA"))
    sx, sy, w, h = 140, 490, 120, 120
    crop = sp[sy:sy + h, sx:sx + w]
    pm = crop[:, :, 3] > 128
    ys, xs = np.nonzero(pm)
    ox, oy = int(xs.min()), int(ys.min())
    x1, y1 = int(xs.max()) + 1, int(ys.max()) + 1
    mask = erode(pm[oy:y1, ox:x1], 3)   # 去掉块自带的白色描边
    pc = crop[oy:y1, ox:x1, :3].astype(np.float64).mean(axis=2)
    print("piece content %dx%d offset=(%d,%d)  bg=%s"
          % (x1 - ox, y1 - oy, ox, oy, bg.shape))

    corr = masked_zncc(bg, pc, mask)
    print("corr map", corr.shape, "max=%.3f" % corr.max())
    flat = corr.ravel()
    order = np.argsort(-flat)
    seen = []
    for i in order:
        y, x = divmod(int(i), corr.shape[1])
        if any(abs(y - a) < 45 and abs(x - b) < 45 for a, b in seen):
            continue
        seen.append((y, x))
        print("   corr=%+.3f  piece@(x=%3d,y=%3d)  ans_x=x-ox=%3d"
              % (flat[i], x, y, x - ox))
        if len(seen) >= 6:
            break

    gy, gx = np.gradient(bg)
    gmag = np.hypot(gx, gy)
    print("\n区域对比 (边缘强度 / 亮度)：")
    for name, (a0, a1, b0, b1) in (("left ", (277, 366, 105, 194)),
                                   ("right", (556, 648, 115, 196))):
        g = gmag[b0:b1, a0:a1]
        l = bg[b0:b1, a0:a1]
        print("  %s grad=%.2f mean_lum=%.1f std_lum=%.1f"
              % (name, g.mean(), l.mean(), l.std()))
    print("  whole grad=%.2f mean_lum=%.1f" % (gmag.mean(), bg.mean()))


if __name__ == "__main__":
    main()
