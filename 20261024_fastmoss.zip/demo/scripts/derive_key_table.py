# -*- coding: utf-8 -*-
"""Build the key table (array1) from a build's bytecode using the closure
upvalue source register rule.

Key modules are closures created with upvalue pair (7 <- 8) whose body writes
`self[7][slot] = word(literal, off)`.  Closures with (7 <- 9) write the decoy
array2.  The cipher closure is also created with (7 <- 8): its body reads the
key through `self[7][i]`.

Usage: python derive_key_table.py <bytecode.json>
"""
import json
import sys
from collections import deque

from disasm_tdc import OPERANDS
from translate_bc import load_map

PUSH, PUSH1, SUB, MKPAIR, LOAD, SETELEM = 59, 35, 43, 34, 28, 38
EMPTYSTR, APPENDCHR, CLOSURE, CALLP = 46, 65, 52, 25


def walk(bc, live2old):
    n = len(bc)
    seen = {}
    q = deque([0])
    while q:
        pc = q.popleft()
        if not isinstance(pc, int) or pc in seen or pc < 0 or pc >= n:
            continue
        op = live2old.get(bc[pc])
        if op is None or OPERANDS.get(op) is None:
            continue
        cnt = OPERANDS[op]
        if cnt == -1:
            f, nup, narg = bc[pc + 1], bc[pc + 2], bc[pc + 3]
            end = pc + 4 + 2 * nup + narg
            pairs = [(bc[pc + 4 + 2 * i], bc[pc + 5 + 2 * i]) for i in range(nup)]
            seen[pc] = (op, [f, nup, narg], end, pairs)
            q.append(f)
            q.append(end)
            continue
        ops = bc[pc + 1:pc + 1 + cnt]
        end = pc + 1 + cnt
        seen[pc] = (op, ops, end, None)
        if op == 33:
            q.append(ops[0])
            continue
        q.append(end)
        if op in (63, 16):
            q.append(ops[0])
    return seen


def lit_at(seen, start_pc):
    pc = start_pc
    for _ in range(6):
        rec = seen.get(pc)
        if rec is None:
            return None
        if rec[0] == EMPTYSTR:
            s = ""
            cur = rec[2]
            while True:
                nx = seen.get(cur)
                if not nx or nx[0] != APPENDCHR:
                    break
                s += chr(nx[1][0] & 0xFFFF)
                cur = nx[2]
            return s
        pc = rec[2]
    return None


def body_info(seen, f):
    recs = [(pc, seen[pc]) for pc in sorted(seen) if f <= pc <= f + 200]
    offset = slot = None
    for i, (pc, (op, ops, end, _)) in enumerate(recs):
        if op == CALLP and ops == [1]:
            tail, cur = [], end
            for _ in range(4):
                r = seen.get(cur)
                if not r:
                    break
                tail.append(r)
                cur = r[2]
            if len(tail) >= 4 and tail[0][0] == PUSH and tail[1][0] == PUSH \
                    and tail[2][0] == SUB and tail[3][0] == SUB:
                offset = -tail[1][1][0]
            elif len(tail) >= 2 and tail[0][0] == PUSH and tail[1][0] == SUB:
                offset = tail[0][1][0]
        if op == SETELEM and i >= 4:
            p = recs[i - 4:i + 1]
            if p[0][1][0] == PUSH1 and p[0][1][1] == [7] and p[1][1][0] == PUSH \
                    and p[2][1][0] == MKPAIR and p[3][1][0] == LOAD:
                slot = p[1][1][1][0]
    return offset, slot


def word(s, off):
    acc = 0
    for i in range(min(4, len(s))):
        acc |= ((ord(s[i]) - off) << (8 * i)) & 0xFFFFFFFF
        acc &= 0xFFFFFFFF
    return acc


def main():
    path = sys.argv[1] if len(sys.argv) > 1 else "../js/bytecode_cur2b.json"
    bc = json.load(open(path))
    m = load_map()
    seen = walk(bc, m)
    print("reachable", len(seen), "instrs, closures:",
          sum(1 for v in seen.values() if v[0] == CLOSURE))
    arr1, arr2 = {}, {}
    for pc in sorted(seen):
        op, ops, end, pairs = seen[pc]
        if op != CLOSURE:
            continue
        f = ops[0]
        off, slot = body_info(seen, f)
        if off is None or slot is None:
            continue
        lit = lit_at(seen, end)
        if not lit:
            continue
        w = word(lit, off)
        tag = "%s@%d" % (lit, pc)
        pset = set(pairs or [])
        if (7, 8) in pset:
            arr1[slot] = (w, tag, off)
        elif (7, 9) in pset:
            arr2[slot] = (w, tag, off)
        else:
            print("  other upvalues %s slot=%d word=0x%08x lit=%r off=%d"
                  % (pairs, slot, w, lit, off))
    for name, arr in (("array1 (key)", arr1), ("array2 (decoy)", arr2)):
        print(name)
        out = []
        for slot in range(4):
            if slot in arr:
                w, tag, off = arr[slot]
                out.append(0xFFFFFFFF & w)
                print("  slot%d 0x%08x  from %-12s off=%d" % (slot, w, tag, off))
        print("  K =", out)


if __name__ == "__main__":
    main()
