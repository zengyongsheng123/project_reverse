# -*- coding: utf-8 -*-
"""用真实浏览器量出验证码弹窗的几何：图片真实尺寸 / CSS 尺寸 / 拼图块位置。

目标是把「背景图 672x390 但 size_2d=672x480」这个矛盾钉死，并确认
背景里两个拼图形状哪个是缺口（截图直接看）。

用法：python fastmoss_dom.py
产出：fastmoss_popup.png（弹窗区域截图）、fastmoss_dom.json
"""
import base64
import json
import os
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)

import fastmoss_probe as P

DUMP = r"""
(function(){
  function info(el){
    var r = el.getBoundingClientRect();
    return {tag: el.tagName, id: el.id, cls: el.className,
            src: (el.src || '').slice(0, 90),
            nat: [el.naturalWidth, el.naturalHeight],
            css: [el.style.width, el.style.height],
            box: [Math.round(r.left), Math.round(r.top),
                  Math.round(r.right), Math.round(r.bottom)],
            tf: getComputedStyle(el).transform};
  }
  var out = {imgs: [], divs: [], dpr: window.devicePixelRatio,
             iw: window.innerWidth, ih: window.innerHeight,
             scroll: [document.documentElement.scrollWidth,
                      document.documentElement.scrollHeight]};
  var im = document.querySelectorAll('img');
  for (var i = 0; i < im.length; i++) { try { out.imgs.push(info(im[i])); } catch(e){} }
  var ids = ['slideBg','slideBlock','slide','slideBox','tc','captcha'];
  ids.forEach(function(s){ var e = document.getElementById(s); if (e) out.divs.push(info(e)); });
  var cand = document.querySelectorAll('[id*="slide"],[class*="slide"],[id*="bg"],[id*="block"]');
  for (var j = 0; j < cand.length && out.divs.length < 24; j++) {
    try { out.divs.push(info(cand[j])); } catch(e){}
  }
  return out;
})()
"""


def main():
    proc = P.launch()
    t = P.new_target()
    tid = t["id"]
    c = P.CDP(t["webSocketDebuggerUrl"])
    try:
        c.call("Runtime.enable")
        c.call("Page.enable")
        c.call("Target.setDiscoverTargets", discover=True)
        c.call("Page.navigate", url=P.PAGE)
        time.sleep(1.5)
        print("show:", c.ev(P.LOAD))
        for _ in range(80):
            time.sleep(0.5)
            if c.ev("typeof window.TDC") == "object":
                break

        # 找验证码 iframe 的 frameId
        tree = c.call("Page.getFrameTree")
        frames = []

        def walk(n, depth=0):
            f = n["frame"]
            frames.append((depth, f.get("id"), f.get("url", "")[:100]))
            for ch in n.get("childFrames", []) or []:
                walk(ch, depth + 1)

        walk(tree["frameTree"])
        print("frames:")
        for d, fid, url in frames:
            print("   " * d, fid, url)
        tgt = [fid for d, fid, url in frames if "captcha.qcloud" in url]
        print("captcha frame:", tgt)

        # 在该 frame 建隔离世界再求值
        ctx = None
        if tgt:
            c.call("Page.enable")
            r = c.call("Page.createIsolatedWorld", frameId=tgt[0],
                       worldName="probe", grantUniveralAccess=True)
            ctx = r.get("executionContextId")
        print("context:", ctx)

        dump = None
        if ctx:
            r = c.call("Runtime.evaluate", expression=DUMP,
                       contextId=ctx, returnByValue=True)
            dump = r.get("result", {}).get("value")
        if not dump:
            dump = c.ev(DUMP)
        print(json.dumps(dump, ensure_ascii=False, indent=1)[:4000])

        shot = c.call("Page.captureScreenshot", format="png")
        b = base64.b64decode(shot["data"])
        sp = os.path.join(ROOT, "fastmoss_popup.png")
        open(sp, "wb").write(b)
        print("screenshot:", sp, len(b), "B")

        json.dump({"dump": dump, "frames": frames},
                  open(os.path.join(HERE, "fastmoss_dom.json"), "w"),
                  ensure_ascii=False, indent=1)
    finally:
        try:
            c.ws.close()
        except Exception:
            pass
        P.close_target(tid)
        if proc is not None:
            try:
                proc.terminate()
            except Exception:
                pass


if __name__ == "__main__":
    main()
