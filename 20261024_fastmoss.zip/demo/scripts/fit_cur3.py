# -*- coding: utf-8 -*-
"""Grab one live TDC.getData() sample and fit the per-build C placement.

K is derived from the build's bytecode (derive_key_table's upvalue rule).  The
two nonzero C constants are read off the cipher loop's branch bodies.  This
script tries every way of placing them into C[0..3] (12 combos) and both
segment-order interpretations, and reports the combination that decrypts the
live `data` into a well-formed collect plaintext.

Usage: python fit_cur3.py [bytecode.json] [c1] [c2]
"""
import base64
import itertools
import json
import sys
import time
import urllib.parse

sys.path.insert(0, ".")
sys.path.insert(0, "..")

import tdc_crypto as tc


def targets():
    import http.client
    c = http.client.HTTPConnection("127.0.0.1", 9222, timeout=5)
    c.request("GET", "/json")
    return json.loads(c.getresponse().read())


def evaluate(expr, timeout=60):
    import websocket
    pages = [t for t in targets() if t.get("type") == "page"]
    pages = [t for t in pages if (t.get("url") or "").startswith("http")] or pages
    pg = pages[0]
    ws = websocket.create_connection(pg["webSocketDebuggerUrl"], timeout=timeout,
                                     suppress_origin=True)
    ws.send(json.dumps({"id": 1, "method": "Runtime.evaluate",
                        "params": {"expression": expr, "returnByValue": True,
                                   "awaitPromise": True}}))
    end = time.time() + timeout
    while True:
        ws.settimeout(max(0.5, end - time.time()))
        m = json.loads(ws.recv())
        if m.get("id") == 1:
            r = m.get("result", {})
            if r.get("exceptionDetails"):
                raise RuntimeError(str(r["exceptionDetails"])[:300])
            return r.get("result", {}).get("value")


def derive_k(bcp):
    import derive_key_table as dk
    from translate_bc import load_map
    bc = json.load(open(bcp))
    seen = dk.walk(bc, load_map())
    arr1 = {}
    for pc in sorted(seen):
        op, ops, end, pairs = seen[pc]
        if op != dk.CLOSURE:
            continue
        off, slot = dk.body_info(seen, ops[0])
        if off is None or slot is None:
            continue
        lit = dk.lit_at(seen, end)
        if not lit:
            continue
        if (7, 8) in set(pairs or []):
            arr1[slot] = dk.word(lit, off)
    return [arr1[i] for i in range(4)]


def decrypt_raw(ct, key, case):
    out = bytearray()
    for i in range(0, len(ct), 8):
        w0 = ct[i] | (ct[i + 1] << 8) | (ct[i + 2] << 16) | (ct[i + 3] << 24)
        w1 = ct[i + 4] | (ct[i + 5] << 8) | (ct[i + 6] << 16) | (ct[i + 7] << 24)
        v0, v1 = tc._block_decrypt(w0, w1, key, case)
        out += tc._w2b(v0) + tc._w2b(v1)
    return bytes(out)


def main():
    bcp = sys.argv[1] if len(sys.argv) > 1 else "../js/bytecode_cur3.json"
    cvals = [int(x) for x in sys.argv[2:4]] or [460550, 657947]
    key = derive_k(bcp)
    print("K =", key)

    got = evaluate("(function(){var s=TDC.getData();return {d:s,"
                   "now:Math.floor(Date.now()/1000),info:TDC.getInfo().info,"
                   "token:TDC.getInfo().tokenid}})()")
    print("sample chars", len(got["d"]), "now", got["now"], "token", got["token"])
    raw = base64.b64decode(urllib.parse.unquote(got["d"]))
    print("raw", len(raw), raw[:8].hex(), "tail", raw[-8:].hex())

    variants = [("unrotate(24,192)", tc.unrotate(raw)), ("as-is", raw)]
    hits = []
    for vname, ct in variants:
        for slots in itertools.permutations(range(4), 2):
            for order in ((0, 1), (1, 0)):
                case = [0, 0, 0, 0]
                case[slots[0]] = cvals[order[0]]
                case[slots[1]] = cvals[order[1]]
                pt = decrypt_raw(ct, key, case)
                if pt[:12] == b"[[1,1,12]]":
                    hits.append((vname, case, pt))
    print("hits", len(hits))
    for vname, case, pt in hits:
        print(" ", vname, case, "len", len(pt))
        print("  ", pt)
    json.dump({"now": got["now"], "token": got["token"], "data": got["d"],
               "hits": [[h[0], h[1], h[2].decode("latin-1")] for h in hits]},
              open("fit_cur3.json", "w"), indent=1)


if __name__ == "__main__":
    main()
