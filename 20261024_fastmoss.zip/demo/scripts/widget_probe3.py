# -*- coding: utf-8 -*-
"""Read-only probe #3: find the VISIBLE captcha instance among all warps.

The demo page can hold hidden/preloaded widgets parked far off-screen; this
lists every `.tencent-captcha-dy__warp` with its rect, computed display/
visibility, and the rects of its area/fg/block children.  Read-only.

Usage: python widget_probe3.py
"""
import json
import os
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import instrument_eks_init as I  # noqa: E402

JS = r"""
(function(){
  function r(el){ if(!el) return null; var b=el.getBoundingClientRect();
    var cs=getComputedStyle(el);
    return [Math.round(b.x),Math.round(b.y),Math.round(b.width),Math.round(b.height),
            cs.display, cs.visibility, cs.opacity, (el.getAttribute('style')||'').slice(0,120)]; }
  var out={iw:innerWidth, ih:innerHeight, sx:scrollX, sy:scrollY, warps:[],
           caps:document.querySelectorAll('.tencent-captcha-dy__warp').length,
           tf:document.querySelectorAll('.tencent-captcha__transform').length};
  var ws=document.querySelectorAll('.tencent-captcha-dy__warp');
  for (var i=0;i<ws.length;i++){
    var w=ws[i];
    out.warps.push({i:i, rect:r(w),
      area:r(w.querySelector('.tencent-captcha-dy__image-area')),
      bg:r(w.querySelector('.tencent-captcha-dy__verify-bg')),
      fg:r(w.querySelector('.tencent-captcha-dy__fg-item')),
      block:r(w.querySelector('.tencent-captcha-dy__slider-block')),
      opera:r(w.querySelector('.tencent-captcha-dy__opera-area')),
      fgstyle:(function(){var e=w.querySelector('.tencent-captcha-dy__fg-item');
                          return e?(e.getAttribute('style')||'').slice(0,220):null})()});
  }
  return JSON.stringify(out);
})()
"""


def main():
    t = I.new_target()
    tid = t["id"]
    c = I.CDP(t["webSocketDebuggerUrl"])
    try:
        c.call("Runtime.enable")
        c.call("Page.enable")
        c.call("Page.navigate", url=I.URL)
        for _ in range(40):
            time.sleep(0.5)
            if c.ev("document.readyState", await_promise=False) == "complete":
                break
        c.ev("(function(){var b=[...document.querySelectorAll('a.tpm-btn')]"
             ".filter(function(e){return e.textContent.trim()==='立即体验';})[0];"
             "if(b){b.click();return 1}return 0})()", await_promise=False)
        for _ in range(30):
            time.sleep(0.5)
            if c.ev("document.querySelectorAll('.tencent-captcha-dy__fg-item').length",
                    await_promise=False):
                break
        d = json.loads(c.ev(JS, await_promise=False))
        print("viewport", d["iw"], d["ih"], "scroll", d["sx"], d["sy"],
              "warps", d["caps"], "transforms", d["tf"])
        for w in d["warps"]:
            print("warp", w["i"], w["rect"])
            for k in ("area", "bg", "fg", "block", "opera"):
                print("   %-6s %s" % (k, w[k]))
            print("   fgstyle", (w["fgstyle"] or "")[:160])
        json.dump(d, open(os.path.join(HERE, "widget_probe3.json"), "w"),
                  indent=1, ensure_ascii=False)
    finally:
        try:
            c.ws.close()
        except Exception:
            pass
        I.close_target(tid)


if __name__ == "__main__":
    main()
