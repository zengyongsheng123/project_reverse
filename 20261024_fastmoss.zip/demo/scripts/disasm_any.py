# -*- coding: utf-8 -*-
import json, sys
from collections import deque
from disasm_tdc import OPERANDS, NAMES
from translate_bc import load_map

def build(path):
    bc=json.load(open(path)); m=load_map(); n=len(bc); seen={}
    q=deque([0])
    while q:
        pc=q.popleft()
        if not isinstance(pc,int) or pc in seen or pc<0 or pc>=n: continue
        op=m.get(bc[pc])
        if op is None or OPERANDS.get(op) is None:
            seen[pc]=("<bad>",[bc[pc]],pc+1); continue
        cnt=OPERANDS[op]
        if cnt==-1:
            f,nup,narg=bc[pc+1],bc[pc+2],bc[pc+3]; end=pc+4+2*nup+narg
            seen[pc]=(NAMES.get(op),[f,nup,narg],end); q.append(f); q.append(end); continue
        ops=bc[pc+1:pc+1+cnt]; end=pc+1+cnt
        seen[pc]=(NAMES.get(op),ops,end)
        if op==33: q.append(ops[0]); continue
        q.append(end)
        if op in (63,16): q.append(ops[0])
    return seen

if __name__=="__main__":
    seen=build(sys.argv[1]); lo=int(sys.argv[2]); hi=int(sys.argv[3])
    for pc in sorted(seen):
        if lo<=pc<hi:
            nm,ops,end=seen[pc]
            print("%6d  %-9s %s"%(pc,nm," ".join(str(x) for x in ops)))
