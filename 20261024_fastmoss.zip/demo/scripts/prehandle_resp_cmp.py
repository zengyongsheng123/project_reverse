# -*- coding: utf-8 -*-
"""对照「我们发的 prehandle」和「真浏览器发的 prehandle」的**响应**。

前提（已由 node_collect_probe 证明）：collect 内容没问题 —— 同一个 Node 出的
collect 放进浏览器会话就是 errorCode 0。所以差异只剩「会话本身」。prehandle 是
产生 sess 的那条请求，服务端对这次会话的风险评级就写在响应里（state /
grayscale / capclass / dyn_show_info / pow_cfg …），两边逐字段对一遍就知道
服务端到底在哪一项上给了我们不同的档位。

不发任何 verify。输出：scripts/kcalib/pre_ours.json / pre_browser.json

用法：python prehandle_resp_cmp.py [ours|browser|both]
"""
import json
import os
import sys
import urllib.parse

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))
sys.path.insert(0, HERE)

import fastmoss_flow as F

KD = os.path.join(HERE, "kcalib")


def do_ours():
    s = F.FastMossCaptchaFlow.make_session()
    tkid, pre = F.FastMossCaptchaFlow.prehandle(s)
    out = {"tkid": tkid, "pre": pre, "sess": pre.get("sess") or "",
           "request_headers": dict(s.headers) if hasattr(s.headers, "items") else {}}
    open(os.path.join(KD, "pre_ours.json"), "w", encoding="utf-8").write(
        json.dumps(out, ensure_ascii=False, indent=1))
    print("ours: sess=%d tkid=%s -> pre_ours.json"
          % (len(out["sess"]), tkid))


def do_browser():
    hy = F.BrowserHybrid()
    hy._launch()
    t = hy._new_target()
    c = F._CDP(t["webSocketDebuggerUrl"])
    try:
        c.call("Runtime.enable")
        c.call("Page.enable")
        c.call("Network.enable")
        c.call("Page.navigate", url=hy.PAGE)
        import time as _t
        _t.sleep(1.5)
        c.ev(hy.LOAD % F.AID)
        for _ in range(80):
            _t.sleep(0.5)
            if c.ev("typeof window.TDC") == "object":
                break
        _t.sleep(1.0)
        hy._drain(c)
        resps, reqs = hy._net(c, "cap_union_prehandle")
        if not resps:
            print("浏览器没截到 prehandle")
            return 1
        r = resps[-1]
        pre = hy._jsonp(r["body"]) or {}
        out = {"tkid": "", "pre": pre, "sess": pre.get("sess") or "",
               "request_url": reqs[-1]["url"] if reqs else "",
               "resp_headers": r.get("headers")}
        open(os.path.join(KD, "pre_browser.json"), "w", encoding="utf-8").write(
            json.dumps(out, ensure_ascii=False, indent=1))
        print("browser: sess=%d -> pre_browser.json" % len(out["sess"]))
    finally:
        try:
            hy._close_target(t["id"])
        except Exception:
            pass
    return 0


def walk(o, p="", acc=None):
    acc = {} if acc is None else acc
    if isinstance(o, dict):
        for k, v in o.items():
            walk(v, p + "." + k if p else k, acc)
    elif isinstance(o, list):
        for i, v in enumerate(o):
            walk(v, "%s[%d]" % (p, i), acc)
    else:
        acc[p] = o
    return acc


def compare():
    a = walk(json.load(open(os.path.join(KD, "pre_ours.json"),
                            encoding="utf-8"))["pre"])
    b = walk(json.load(open(os.path.join(KD, "pre_browser.json"),
                            encoding="utf-8"))["pre"])
    SKIP = ("sess", "tdc_path", "img_url", "sprite_url", "bg_elem_cfg",
            "init_pos", "prefix", "md5", "uip", "tp_cd", "randstr")
    print("== 只浏览器有 / 只我们有 / 值不同（跳过易变项）==")
    for k in sorted(set(a) | set(b)):
        if any(x in k for x in SKIP):
            continue
        va, vb = a.get(k, "<无>"), b.get(k, "<无>")
        if va != vb:
            print("  %-46s brow=%r  ours=%r" % (k, str(vb)[:70], str(va)[:70]))
    print("\n== 结构层（两边都有、值被跳过的）==")
    for k in sorted(set(a) | set(b)):
        if any(x in k for x in SKIP) and k.split("[")[0] in a and k.split("[")[0] in b:
            pass
    print("sess:  brow %d / ours %d" % (len(json.load(open(os.path.join(
        KD, "pre_browser.json"), encoding="utf-8"))["sess"]),
        len(json.load(open(os.path.join(KD, "pre_ours.json"),
                           encoding="utf-8"))["sess"])))


if __name__ == "__main__":
    what = sys.argv[1] if len(sys.argv) > 1 else "both"
    if what in ("ours", "both"):
        do_ours()
    if what in ("browser", "both"):
        do_browser()
    if what in ("cmp", "both"):
        compare()
