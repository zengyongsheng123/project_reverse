# -*- coding: utf-8 -*-
"""取 FastMoss（aid 195941100）当前 tdc.js build 的源码与 getData 样本。

和 fresh_session.py 的区别：那个脚本写死了腾讯云 demo 页，这里改成用
本地测试台 captcha-test.html + 直接以 appid 195941100 弹验证码，只向腾讯
验证码服务加载 SDK（不请求 FastMoss 业务接口）。

产出：
    js/live_src/tdc_fastmoss.js   该 build 的解压源码（K/C/S 的推导输入）
    js/live_src/tdc_fastmoss.json meta
    scripts/fastmoss_probe.json   {"datas":[{d,now,after}...]}，喂给
                                  derive_build.py --from-json

用法：
    python fastmoss_probe.py
"""
import hashlib
import http.client
import json
import os
import subprocess
import sys
import time

import websocket

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
JS = os.path.join(ROOT, "js")
LIVE = os.path.join(JS, "live_src")

PORT = 9222
CHROME = r"D:\cloakbrowser\chrome.exe"
PROFILE = os.path.join(ROOT, ".cdp_tmp")          # 独立临时 profile，不动用户数据
PAGE = "file:///D:/20261024_fastmoss/captcha-test.html"
AID = "195941100"
NAME = "fastmoss"
SAMPLES = 12
SLEEP_BEFORE = 1


# --------------------------------------------------------------------------- #
# 浏览器 / CDP
# --------------------------------------------------------------------------- #
def cdp_alive():
    try:
        c = http.client.HTTPConnection("127.0.0.1", PORT, timeout=2)
        c.request("GET", "/json/version")
        return c.getresponse().status == 200
    except Exception:
        return False


def launch():
    """9222 没起来就拉一个独立实例（临时 profile），等端口可用。"""
    if cdp_alive():
        print("    reuse existing CDP on", PORT)
        return None
    print("    launching", CHROME)
    p = subprocess.Popen([
        CHROME,
        "--remote-debugging-port=%d" % PORT,
        "--user-data-dir=%s" % PROFILE,
        "--no-first-run", "--no-default-browser-check",
        "--disable-blink-features=AutomationControlled",
        "about:blank",
    ], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    for _ in range(60):
        time.sleep(0.5)
        if cdp_alive():
            return p
    raise SystemExit("chrome did not expose CDP on %d" % PORT)


def new_target():
    c = http.client.HTTPConnection("127.0.0.1", PORT, timeout=5)
    c.request("PUT", "/json/new?about:blank")
    return json.loads(c.getresponse().read())


def close_target(tid):
    try:
        c = http.client.HTTPConnection("127.0.0.1", PORT, timeout=5)
        c.request("PUT", "/json/close/" + tid)
        c.getresponse().read()
    except Exception:
        pass


class CDP:
    def __init__(self, url, timeout=120):
        self.ws = websocket.create_connection(url, timeout=timeout,
                                              suppress_origin=True)
        self.i = 0
        self.events = []

    def call(self, method, timeout=60, **p):
        self.i += 1
        mid = self.i
        self.ws.send(json.dumps({"id": mid, "method": method, "params": p}))
        end = time.time() + timeout
        while True:
            self.ws.settimeout(max(0.5, end - time.time()))
            m = json.loads(self.ws.recv())
            if m.get("id") == mid:
                if "error" in m:
                    raise RuntimeError("%s -> %s" % (method, m["error"]))
                return m.get("result", {})
            if "method" in m:
                self.events.append(m)

    def ev(self, expr, await_promise=False, timeout=60):
        r = self.call("Runtime.evaluate", expression=expr, returnByValue=True,
                      awaitPromise=await_promise, timeout=timeout)
        if r.get("exceptionDetails"):
            return {"__exc": str(r["exceptionDetails"])[:400]}
        return r.get("result", {}).get("value")


# 页面里：加载 TJCaptcha.js，再以 appid 直接弹验证码，触发 tdc.js 初始化
LOAD = r"""
(async function(){
  if (!window.TencentCaptcha) {
    await new Promise(function(res, rej){
      var s = document.createElement('script');
      s.src = 'https://turing.captcha.qcloud.com/TJCaptcha.js';
      s.async = true; s.onload = res; s.onerror = rej;
      document.body.appendChild(s);
    });
  }
  if (!window.__fmShown) {
    window.__fmShown = 1;
    new window.TencentCaptcha('%s', function(r){ window.__fmCb = r; }).show();
  }
  return typeof window.TDC;
})()
""" % AID


# 注入一条类人手拖动轨迹：{elapsed_ms: "x,y"}，末端回正
SETDATA = r"""
(function(){
  try {
    if (typeof TDC.setData !== 'function') return 'no setData';
    var t = {}, x0 = 120, y0 = 300, dist = 180, dur = 760;
    for (var ms = 0; ms <= dur; ms += 10) {
      var p = ms / dur;
      var e = p < 0.85 ? (1 - Math.pow(1 - p / 0.85, 3)) * 1.02
                       : 1 + 0.02 * (1 - (p - 0.85) / 0.15);
      t[ms] = Math.round(x0 + dist * e) + ',' + Math.round(y0 + Math.sin(p * 3) * 1.5);
    }
    TDC.setData(t);
    return 'set ' + Object.keys(t).length + ' points';
  } catch (e) { return 'err ' + e; }
})()
"""


def tdc_script(c):
    """TDC.getData 所在的 tdc.js 脚本的 (url, scriptId)。"""
    sids = {}
    for e in c.events:
        if e.get("method") == "Debugger.scriptParsed":
            p = e["params"]
            sids[p.get("url") or ""] = p["scriptId"]
    cands = [(u, sid) for u, sid in sids.items() if "tdc.js" in u]
    if not cands:
        return None, None
    picked = None
    try:
        r = c.call("Runtime.evaluate", expression="window.TDC && TDC.getData",
                   returnByValue=False)
        oid = r.get("result", {}).get("objectId")
        if oid:
            props = c.call("Runtime.getProperties", objectId=oid,
                           ownProperties=False)
            for p in props.get("internalProperties", []):
                if p.get("name") == "[[FunctionLocation]]":
                    picked = p.get("value", {}).get("value", {}).get("scriptId")
                    break
    except Exception:
        pass
    by_sid = {sid: u for u, sid in cands}
    if picked in by_sid:
        return by_sid[picked], picked
    url, sid = cands[-1]
    return url, sid


def main():
    proc = launch()
    t = new_target()
    tid = t["id"]
    print("    fresh target", tid)
    c = CDP(t["webSocketDebuggerUrl"])
    try:
        c.call("Runtime.enable")
        c.call("Page.enable")
        c.call("Debugger.enable")
        c.call("Page.navigate", url=PAGE)
        time.sleep(1.5)

        # 弹验证码 -> 触发 prehandle + 加载 tdc.js
        print("    showing captcha with appid", AID)
        print("    ->", c.ev(LOAD))
        tdc = "?"
        for _ in range(80):
            time.sleep(0.5)
            tdc = c.ev("typeof window.TDC")
            if tdc == "object":
                break
        if tdc != "object":
            raise SystemExit("TDC never appeared (typeof TDC = %r)" % tdc)
        print("    TDC ready")

        url, sid = tdc_script(c)
        if sid is None:
            raise SystemExit("no tdc.js script found")
        src = c.call("Debugger.getScriptSource", scriptId=sid).get("scriptSource", "")
        sha = hashlib.sha256(src.encode("utf-8", "surrogatepass")).hexdigest()[:16]
        os.makedirs(LIVE, exist_ok=True)
        src_path = os.path.join(LIVE, "tdc_%s.js" % NAME)
        open(src_path, "w", encoding="utf-8").write(src)
        meta = {"url": url, "scriptId": sid, "len": len(src),
                "sha256_16": sha, "saved": src_path, "aid": AID}
        json.dump(meta, open(os.path.join(LIVE, "tdc_%s.json" % NAME), "w"),
                  indent=1)
        print("    tdc.js %d chars sha %s" % (len(src), sha))

        # getInfo 里的 eks（同 build），顺便记下来
        info = c.ev("(function(){try{return TDC.getInfo()}catch(e){"
                    "return {err:String(e)}}})()")
        print("    getInfo.info len:", len((info or {}).get("info") or ""))

        samples = []
        for k in range(SAMPLES):
            if k == SLEEP_BEFORE:
                time.sleep(1.2)                 # 让 now_sec 跨秒
            before = c.ev("Math.floor(Date.now()/1000)")
            d = c.ev("TDC.getData()")
            after = c.ev("Math.floor(Date.now()/1000)")
            if not isinstance(d, str):
                raise SystemExit("getData #%d returned %r (captcha modal state?)"
                                 % (k + 1, d))
            samples.append({"d": d, "now": before, "after": after})
            print("    getData #%d chars=%d" % (k + 1, len(d)))

        # 再取一条「带拖动事件」的样本：先 setData 注入轨迹，再 getData。
        # getData 会清空事件缓冲，所以必须放在最后一条。
        print("    setData:", c.ev("typeof (window.TDC && TDC.setData)"))
        inj = c.ev(SETDATA)
        print("    setData ->", str(inj)[:120])
        before = c.ev("Math.floor(Date.now()/1000)")
        d = c.ev("TDC.getData()")
        after = c.ev("Math.floor(Date.now()/1000)")
        if isinstance(d, str):
            samples.append({"d": d, "now": before, "after": after,
                            "events": True})
            print("    getData(with events) chars=%d" % len(d))
        else:
            print("    setData/getData with events failed:", str(d)[:160])

        probe = {"sha256_16": sha, "src": src_path, "aid": AID,
                 "datas": samples, "info": info}
        pp = os.path.join(HERE, "fastmoss_probe.json")
        json.dump(probe, open(pp, "w"), indent=1)
        print("    wrote", pp)
    finally:
        try:
            c.ws.close()
        except Exception:
            pass
        close_target(tid)
        # 只关我们自己拉起来的实例
        if proc is not None:
            try:
                proc.terminate()
            except Exception:
                pass


if __name__ == "__main__":
    main()
