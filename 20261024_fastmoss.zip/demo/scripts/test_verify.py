# -*- coding: utf-8 -*-
"""Test strictness of server-side collect/eks validation with pure-python verify."""
import json, hashlib, time, sys
import requests
from probe import prehandle, R, BASE, AID

def solve_pow(prefix, target):
    n = 0
    t0 = time.time()
    while True:
        if hashlib.md5((prefix + str(n)).encode()).hexdigest() == target:
            return prefix + str(n), int((time.time() - t0) * 1000)
        n += 1

def verify(sess, tkid, ansx, answidth=120, collect="", eks="", sid=""):
    prefix, target = POW
    pow_answer, calc_ms = solve_pow(prefix, target)
    ans = json.dumps([{"elem_id": 1, "type": "DynAnswerType_POS", "data": "%d,228" % ansx}], separators=(",", ":"))
    body = {
        "collect": collect, "tlg": str(len(collect)), "eks": eks,
        "sess": sess, "ans": ans, "tkid": tkid,
        "pow_answer": pow_answer, "pow_calc_time": str(calc_ms),
    }
    r = R.post(BASE + "/cap_union_new_verify", data=body, timeout=10,
               headers={"Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
                        "Accept": "application/json, text/javascript, */*; q=0.01",
                        "Origin": "https://cloud.tencent.com"})
    return r.status_code, r.text

if __name__ == "__main__":
    mode = sys.argv[1] if len(sys.argv) > 1 else "empty"
    tkid, d = prehandle()
    POW = tuple(d["data"]["comm_captcha_cfg"]["pow_cfg"].values())
    print("tkid", tkid, "pow", POW)
    sess = d["sess"]
    collect = ""
    eks = ""
    if mode == "captured":
        cap = json.load(open("captured_verify.json"))
        collect, eks = cap["collect"], cap["eks"]
    x = int(sys.argv[2]) if len(sys.argv) > 2 else 400
    code, text = verify(sess, tkid, x, collect=collect, eks=eks)
    print(code, text[:800])
