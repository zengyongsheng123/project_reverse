# -*- coding: utf-8 -*-
"""Compare TDC.getData() with TDC.getData(true) -- the captcha SDK calls the
latter (tgJCap.js: window.TDC.getData(!0x0)) -- decrypt both and show the
plaintext sizes.

Usage: python live_check2.py
"""
import base64
import http.client
import json
import os
import sys
import time

import websocket

PORT = 9222
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
import tdc_crypto                                      # noqa: E402


def targets():
    c = http.client.HTTPConnection("127.0.0.1", PORT, timeout=5)
    c.request("GET", "/json")
    return json.loads(c.getresponse().read())


class CDP:
    def __init__(self, url):
        self.ws = websocket.create_connection(url, timeout=120, suppress_origin=True)
        self.i = 0

    def call(self, method, **p):
        self.i += 1
        mid = self.i
        self.ws.send(json.dumps({"id": mid, "method": method, "params": p}))
        end = time.time() + 90
        while True:
            self.ws.settimeout(max(0.5, end - time.time()))
            m = json.loads(self.ws.recv())
            if m.get("id") == mid:
                if "error" in m:
                    raise RuntimeError("%s -> %s" % (method, m["error"]))
                return m.get("result", {})


def ev(cdp, expr):
    r = cdp.call("Runtime.evaluate", expression=expr, returnByValue=True,
                 awaitPromise=True)
    if r.get("exceptionDetails"):
        raise RuntimeError(str(r["exceptionDetails"])[:400])
    return r["result"].get("value")


def main():
    pg = [t for t in targets() if t.get("type") == "page"][0]
    cdp = CDP(pg["webSocketDebuggerUrl"])
    cdp.call("Runtime.enable")
    print("typeof TDC.getData:", ev(cdp, "typeof TDC.getData"))
    for arg in ("", "true", "false"):
        expr = "TDC.getData(%s)" % arg
        v = ev(cdp, expr)
        import urllib.parse
        raw = base64.b64decode(urllib.parse.unquote(v))
        print("getData(%s): string=%d b64bytes=%d" % (arg or "noarg", len(v), len(raw)))
        for label, ct in (("direct", raw), ("unrotate", tdc_crypto.unrotate(raw))):
            if len(ct) % 8:
                print("   %s: len%%8=%d" % (label, len(ct) % 8))
                continue
            try:
                pt = bytearray()
                for i in range(0, len(ct), 8):
                    w0 = int.from_bytes(ct[i:i + 4], "little")
                    w1 = int.from_bytes(ct[i + 4:i + 8], "little")
                    v0, v1 = tdc_crypto._block_decrypt(w0, w1)
                    pt += bytes((v0 >> (8 * k)) & 255 for k in range(4))
                    pt += bytes((v1 >> (8 * k)) & 255 for k in range(4))
                pr = sum(1 for b in pt[:400] if 9 <= b < 127) / min(400, len(pt))
                print("   %s: printable=%.2f head=%r" % (label, pr, bytes(pt[:80])))
            except Exception as e:
                print("   %s: err %s" % (label, e))
        time.sleep(0.3)


if __name__ == "__main__":
    main()
