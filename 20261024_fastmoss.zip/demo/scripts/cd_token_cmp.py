# -*- coding: utf-8 -*-
"""用 quartet_probe 的 cd_spans（久经考验的切分器）对比两条明文的 cd token。

Node 与浏览器的明文都是「括号故意不平衡」的拼接格式，普通 JSON/逗号切分会切错，
所以直接复用 quartet_probe 的实现，按 token 下标对照（只看数量与集合，不看顺序，
因为字段顺序每会话随机）。

用法：python cd_token_cmp.py <node_tdc.js> <node_collect.txt> <browser_plaintext.txt>
"""
import os
import sys
from collections import Counter

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.dirname(HERE))

import build_diff as B
import quartet_probe as Q

js_path, node_collect, brow_pt = sys.argv[1:4]
node_pt, _ = B.decrypt(js_path, open(node_collect).read().strip(), "node")
brow_pt = open(brow_pt, "r", encoding="latin-1").read().strip().encode("latin-1")

for name, pt in (("NODE", node_pt), ("BROW", brow_pt)):
    toks = Q.tokenize_spans(pt)
    print("== %s  %d tokens" % (name, len(toks)))
    for i, (_a, _b, t) in enumerate(toks):
        print("| %02d %r" % (i, t[:90]))

cn = Counter(t for _a, _b, t in Q.tokenize_spans(node_pt))
cb = Counter(t for _a, _b, t in Q.tokenize_spans(brow_pt))
print("-- only node --")
for k, v in (cn - cb).items():
    print("| %r x%d" % (k[:90], v))
print("-- only browser --")
for k, v in (cb - cn).items():
    print("| %r x%d" % (k[:90], v))
