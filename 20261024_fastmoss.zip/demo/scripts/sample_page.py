# -*- coding: utf-8 -*-
"""Sample TDC.getData() from the page the user already has open.

Read-only: no breakpoints, no reload.  Used to compare the long-lived tab with
fresh tabs (e.g. presence of the optional ``sd.ft`` field).

Usage: python sample_page.py NAME [n]
Writes scripts/fresh_probe_<NAME>.json in the same shape as fresh_session.py.
"""
import json
import os
import sys
import time

import http.client
import websocket

HERE = os.path.dirname(os.path.abspath(__file__))
PORT = 9222


def page():
    c = http.client.HTTPConnection("127.0.0.1", PORT, timeout=5)
    c.request("GET", "/json")
    for t in json.loads(c.getresponse().read()):
        if t.get("type") == "page" and "cloud.tencent.com" in (t.get("url") or ""):
            return t
    raise SystemExit("no cloud.tencent.com page")


class CDP:
    def __init__(self, url):
        self.ws = websocket.create_connection(url, timeout=120, suppress_origin=True)
        self.i = 0

    def ev(self, expr, await_promise=False):
        self.i += 1
        mid = self.i
        self.ws.send(json.dumps({"id": mid, "method": "Runtime.evaluate",
                                 "params": {"expression": expr, "returnByValue": True,
                                            "awaitPromise": await_promise}}))
        while True:
            m = json.loads(self.ws.recv())
            if m.get("id") == mid:
                if "error" in m:
                    raise RuntimeError(m["error"])
                return m.get("result", {}).get("result", {}).get("value")


def main():
    name = sys.argv[1] if len(sys.argv) > 1 else "page"
    n = int(sys.argv[2]) if len(sys.argv) > 2 else 3
    t = page()
    c = CDP(t["webSocketDebuggerUrl"])
    print("page:", t.get("title", "")[:40], t.get("url", "")[:80])
    if c.ev("typeof window.TDC") != "object":
        raise SystemExit("TDC not present on this page")
    samples = []
    for k in range(n):
        if k == 1:
            time.sleep(1.2)
        before = c.ev("Math.floor(Date.now()/1000)")
        d = c.ev("TDC.getData()")
        after = c.ev("Math.floor(Date.now()/1000)")
        samples.append({"d": d, "now": before, "after": after})
        print("  getData #%d chars=%s" % (k + 1, len(d or "")))
    c.ws.close()
    out = os.path.join(HERE, "fresh_probe_%s.json" % name)
    json.dump({"src": None, "page": True, "datas": samples}, open(out, "w"), indent=1)
    print("wrote", out)


if __name__ == "__main__":
    main()
