# -*- coding: utf-8 -*-
"""Instrument a FRESH tab (pre-load hooks) to see how TDC.getInfo().info
(the `eks` field) is produced.

The value is computed once when tdc.js initialises and then cached, so runtime
hooks installed after the fact see nothing (verified: 2 getInfo() calls, 0
fromCharCode / 0 btoa).  This script instead creates a separate page target,
installs hooks with Page.addScriptToEvaluateOnNewDocument, then opens the
captcha demo modal so tdc.js runs with the hooks in place.

It never touches the page the user is working in.

Usage: python instrument_eks_init.py
Writes eks_init.json
"""
import http.client
import json
import time

import websocket

PORT = 9222
URL = "https://cloud.tencent.com/product/captcha"

HOOK = r"""
(function(){
  var L = {fcc: [], fccn: 0, lens: [], btoa: [], atob: [], stacks: [], u8: [],
           ca: [], chat: [], join: []};
  window.__EKSLOG = L;
  function interesting(n){ return (n >= 176 && n <= 192) || (n >= 240 && n <= 256); }
  // custom base64 encoders walk the ciphertext with charCodeAt/charAt; capture
  // the whole string the first time a string of the interesting length is read
  var oca = String.prototype.charCodeAt;
  String.prototype.charCodeAt = function(i){
    try {
      var s = String(this);
      if (interesting(s.length) && L.ca.length < 6) L.ca.push({len: s.length, i: i, str: s});
    } catch(e){}
    return oca.call(this, i);
  };
  var och = String.prototype.charAt;
  String.prototype.charAt = function(i){
    try {
      var s = String(this);
      if (interesting(s.length) && L.chat.length < 6) L.chat.push({len: s.length, i: i, str: s});
    } catch(e){}
    return och.call(this, i);
  };
  var oj = Array.prototype.join;
  Array.prototype.join = function(sep){
    var r = oj.apply(this, arguments);
    try {
      if (typeof r === 'string' && r.length >= 170 && r.length <= 260 && L.join.length < 8)
        L.join.push({n: this.length, len: r.length, str: r});
    } catch(e){}
    return r;
  };
  function allnum(a){ for (var i=0;i<a.length;i++) if (typeof a[i] !== 'number') return false; return a.length>0; }
  var ofcc = String.fromCharCode;
  String.fromCharCode = function(){
    var a = Array.prototype.slice.call(arguments);
    if (a.length >= 4 && allnum(a)) {
      L.fccn++;
      if (L.fcc.length < 8000) L.fcc.push(a.slice(0, 512).map(function(x){return x & 255;}));
      if (L.lens.length < 8000) L.lens.push(a.length);
      if (L.stacks.length < 8) { try { L.stacks.push(String(new Error().stack).slice(0,240)); } catch(e){} }
    }
    return ofcc.apply(String, arguments);
  };
  var ob = window.btoa;
  window.btoa = function(s){
    var r = ob.call(window, s);
    try {
      if (L.btoa.length < 40) L.btoa.push({in: String(s).length, out: r.length,
                                           full: String(s).slice(0, 1200)});
    } catch(e){}
    return r;
  };
  var oa = window.atob;
  window.atob = function(s){
    var r = oa.call(window, s);
    try { if (L.atob.length < 20) L.atob.push({in: String(s).length, out: r.length,
                                               head: String(s).slice(0,48)}); } catch(e){}
    return r;
  };
  try {
    var OU = window.Uint8Array;
    window.Uint8Array = function(){
      var u = new (Function.prototype.bind.apply(OU, [null].concat(Array.prototype.slice.call(arguments))))();
      try {
        if (L.u8.length < 40) L.u8.push({len: u.length,
          head: Array.prototype.slice.call(u, 0, 32)});
      } catch(e){}
      return u;
    };
    window.Uint8Array.prototype = OU.prototype;
    window.Uint8Array.from = OU.from;
    window.Uint8Array.of = OU.of;
  } catch(e){}
})();
"""


def new_target():
    c = http.client.HTTPConnection("127.0.0.1", PORT, timeout=5)
    c.request("PUT", "/json/new?about:blank")
    return json.loads(c.getresponse().read())


def close_target(tid):
    try:
        c = http.client.HTTPConnection("127.0.0.1", PORT, timeout=5)
        c.request("PUT", "/json/close/" + tid)
        c.getresponse().read()
    except Exception:
        pass


class CDP:
    def __init__(self, url, timeout=120):
        self.ws = websocket.create_connection(url, timeout=timeout, suppress_origin=True)
        self.i = 0
        self.events = []

    def call(self, method, timeout=60, **p):
        self.i += 1
        mid = self.i
        self.ws.send(json.dumps({"id": mid, "method": method, "params": p}))
        end = time.time() + timeout
        while True:
            self.ws.settimeout(max(0.5, end - time.time()))
            m = json.loads(self.ws.recv())
            if m.get("id") == mid:
                if "error" in m:
                    raise RuntimeError("%s -> %s" % (method, m["error"]))
                return m.get("result", {})
            if "method" in m:
                self.events.append(m)

    def ev(self, expr, timeout=60, await_promise=True):
        r = self.call("Runtime.evaluate", expression=expr, returnByValue=True,
                      awaitPromise=await_promise, timeout=timeout)
        if r.get("exceptionDetails"):
            return {"__exc": str(r["exceptionDetails"])[:300]}
        return r.get("result", {}).get("value")


def main():
    t = new_target()
    tid = t["id"]
    print("fresh target", tid)
    c = CDP(t["webSocketDebuggerUrl"])
    try:
        c.call("Runtime.enable")
        c.call("Page.enable")
        c.call("Page.addScriptToEvaluateOnNewDocument", source=HOOK)
        c.call("Page.navigate", url=URL)
        tdc = "?"
        for i in range(40):
            time.sleep(0.5)
            tdc = c.ev("typeof window.TDC", await_promise=False)
            if tdc == "object":
                break
        if tdc != "object":
            print("clicking 立即体验 ...")
            c.ev("(function(){var b=[...document.querySelectorAll('a.tpm-btn')]"
                 ".filter(function(e){return e.textContent.trim()==='立即体验';})[0];"
                 "if(b){b.click();return 1}return 0})()", await_promise=False)
            for i in range(60):
                time.sleep(0.5)
                tdc = c.ev("typeof window.TDC", await_promise=False)
                if tdc == "object":
                    break
        print("TDC:", tdc)
        info = c.ev("(function(){try{var r=TDC.getInfo();"
                    "return {info:r.info,tokenid:r.tokenid,keys:Object.keys(r)}}"
                    "catch(e){return {err:String(e)}}})()", await_promise=False)
        print("getInfo:", str(info)[:160])
        if isinstance(info, dict) and info.get("info"):
            print("info len:", len(info["info"]), "b64-decoded len:",
                  len(__import__("base64").b64decode(info["info"] + "=" * (-len(info["info"]) % 4))))
        log = c.ev("JSON.stringify(window.__EKSLOG)", await_promise=False)
        d = json.loads(log) if log else {}
        json.dump({"info": info, "log": d}, open("eks_init.json", "w"), indent=1)

        def show(x):
            return str(x).encode("unicode_escape").decode("ascii")

        print("fcc4+ calls:", d.get("fccn"), "lens:", d.get("lens", [])[:20])
        print("btoa calls:", len(d.get("btoa", [])), "atob:", len(d.get("atob", [])))
        for e in d.get("btoa", [])[:8]:
            print("  btoa in=%s out=%s head=%s" % (e["in"], e["out"], show(e["full"][:32])))
        print("u8 calls:", show(d.get("u8", [])[:3]))
        print("charCodeAt hits:", len(d.get("ca", [])))
        for e in d.get("ca", [])[:4]:
            print("  ca len=%s i=%s str=%s" % (e["len"], e["i"], show(e["str"][:120])))
        print("charAt hits:", len(d.get("chat", [])))
        for e in d.get("chat", [])[:4]:
            print("  chat len=%s i=%s str=%s" % (e["len"], e["i"], show(e["str"][:120])))
        print("join hits:", len(d.get("join", [])))
        for e in d.get("join", [])[:4]:
            print("  join n=%s len=%s str=%s" % (e["n"], e["len"], show(e["str"][:120])))
        print("stacks:")
        for s in d.get("stacks", [])[:4]:
            print("  ", show(s.replace("\n", " | ")[:200]))
    finally:
        try:
            c.ws.close()
        except Exception:
            pass
        close_target(tid)


if __name__ == "__main__":
    main()
