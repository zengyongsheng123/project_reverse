# -*- coding: utf-8 -*-
"""Drag the Tencent captcha slider via CDP Input events (trusted mouse events)."""
import json, sys, time, math, http.client
import websocket

PORT = 9222

def page_ws():
    conn = http.client.HTTPConnection("127.0.0.1", PORT, timeout=5)
    conn.request("GET", "/json")
    tabs = json.loads(conn.getresponse().read())
    for t in tabs:
        if t.get("type") == "page" and "cloud.tencent.com" in t.get("url", ""):
            return t["webSocketDebuggerUrl"]
    raise SystemExit("target page not found")

class CDP:
    def __init__(self):
        self.ws = websocket.create_connection(page_ws(), timeout=10, suppress_origin=True)
        self.i = 0
    def call(self, method, **params):
        self.i += 1
        self.ws.send(json.dumps({"id": self.i, "method": method, "params": params}))
        while True:
            msg = json.loads(self.ws.recv())
            if msg.get("id") == self.i:
                if "error" in msg:
                    raise RuntimeError(msg["error"])
                return msg.get("result", {})
    def eval(self, expr):
        r = self.call("Runtime.evaluate", expression=expr, returnByValue=True, awaitPromise=True)
        return r.get("result", {}).get("value")

    def mouse(self, typ, x, y, buttons=0, clickCount=0):
        self.call("Input.dispatchMouseEvent", type=typ, x=x, y=y,
                  button="left" if buttons else "none",
                  buttons=buttons, clickCount=clickCount,
                  pointerType="mouse")

def main():
    dist = float(sys.argv[1]) if len(sys.argv) > 1 else 150.0
    c = CDP()
    rect = c.eval("(()=>{const b=document.querySelector('.tencent-captcha-dy__slider-block');if(!b)return null;const r=b.getBoundingClientRect();return {x:r.x+r.width/2,y:r.y+r.height/2};})()")
    if not rect:
        raise SystemExit("slider block not found")
    x0, y0 = rect["x"], rect["y"]
    print("start at", x0, y0, "dist", dist)
    c.mouse("mouseMoved", x0, y0)
    time.sleep(0.05)
    c.mouse("mousePressed", x0, y0, buttons=1, clickCount=1)
    t0 = time.time()
    steps = 30
    for k in range(1, steps + 1):
        p = k / steps
        # ease-out cubic
        e = 1 - (1 - p) ** 3
        x = x0 + dist * e
        y = y0 + math.sin(p * math.pi) * 1.5
        time.sleep(0.014)
        c.mouse("mouseMoved", x, y, buttons=1)
    time.sleep(0.15)
    c.mouse("mouseReleased", x0 + dist, y0, buttons=0, clickCount=1)
    print("released after %.2fs" % (time.time() - t0))
    time.sleep(2.5)
    print("state:", c.eval("document.querySelector('.tencent-captcha-dy__header-text')?.textContent"))

if __name__ == "__main__":
    main()
