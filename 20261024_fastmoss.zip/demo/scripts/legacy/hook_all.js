(function(){
  if (window.__ha) return 'has';
  var D = window.__ha = {n: 0, shapes: {}, calls: [], fn: null, fc: 0};
  var W = Function.prototype.apply;
  Function.prototype.apply = function(self, args){
    var r = W.call(this, self, args);
    try{
      D.n++;
      var k = '';
      try { k = (args ? args.length : 'null') + ':' + (args && args[0] ? Object.prototype.toString.call(args[0]) : typeof args) + ':' + (args && args[0] && args[0].length); } catch(e){ k = 'e'; }
      D.shapes[k] = (D.shapes[k] || 0) + 1;
      if (args && args.length === 2 && args[0] && typeof args[0] === 'object' && args[0].length === 2 &&
          typeof args[0][0] === 'number' && typeof args[0][1] === 'number' && D.calls.length < 500){
        D.calls.push([args[0][0] >>> 0, args[0][1] >>> 0]);
        if (!D.fn && typeof this === 'function') D.fn = this;
      }
    }catch(e){}
    return r;
  };
  var ofc = String.fromCharCode;
  String.fromCharCode = function(){ try{ if (arguments.length === 4) D.fc++; }catch(e){} return ofc.apply(String, arguments); };
  return 'ok';
})();
