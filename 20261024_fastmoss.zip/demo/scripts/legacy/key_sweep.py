# -*- coding: utf-8 -*-
"""Wide offline sweep for the TDC XTEA key array.

Uses the captured (plaintext pair, ciphertext block) samples and tries every
structural candidate for

    K[i] = word(lit_i, off_i)      word(s,o) = sum((ord(c)-o) << 8*i)

where lit_i is a permutation of the four 4-char literals and off_i is drawn
from the small set of offsets observed in the module bodies.  Also tries the
C[0]/C[1] corrections and the two plausible block alignments
(call order vs collect order) plus word-swap / big-endian variants.
"""
import base64
import itertools
import json
import sys

DELTA = 0x9E3779B9
M = 0xFFFFFFFF
C = [197402, 1907983, 0, 0]
LITS = [")RiK", "Si^w", "761D", "HbRU"]
OFFS = [-33, -29, -5, -1, 0, 1, 5, 29, 33]


def word_le(s, off):
    v = 0
    for i, ch in enumerate(s):
        v |= ((ord(ch) - off) & 0xFF) << (8 * i)
    return v & M


def word_be(s, off):
    v = 0
    for i, ch in enumerate(s):
        v |= ((ord(ch) - off) & 0xFF) << (8 * (3 - i))
    return v & M


def xtea_enc(v0, v1, k):
    s = 0
    for _ in range(32):
        v0 = (v0 + (((((v1 << 4) & M) ^ (v1 >> 5)) + v1) & M ^ ((s + k[s & 3]) & M))) & M
        s = (s + DELTA) & M
        v1 = (v1 + (((((v0 << 4) & M) ^ (v0 >> 5)) + v0) & M ^ ((s + k[(s >> 11) & 3]) & M))) & M
    return v0, v1


def load(path):
    d = json.load(open(path, encoding="utf-8"))
    segs = [bytes.fromhex(e.get("inHex") or "") for e in (d["A"].get("btoa") or [])]
    pairs = [(e["v"][0], e["v"][1]) for e in (d["A"].get("calls") or [])]
    ct_call = b"".join(segs)
    from urllib.parse import unquote
    u = unquote(d["data"])
    ct_collect = base64.b64decode(u)
    # collect order: seg1, seg0, seg2, seg3  (verified) -> same permutation of pairs
    n = [len(s) // 8 for s in segs]
    order = [1, 0, 2, 3]
    perm_pairs = []
    for o in order:
        lo = sum(n[:o])
        perm_pairs.extend(pairs[lo:lo + n[o]])
    return pairs, ct_call, perm_pairs, ct_collect


def blocks(ct):
    return [ct[i:i + 8] for i in range(0, len(ct) - 7, 8)]


def main():
    path = sys.argv[1] if len(sys.argv) > 1 else "stack_log.json"
    pairs, ct_call, pairs_col, ct_col = load(path)
    print("pairs", len(pairs), "call ct", len(ct_call), "collect ct", len(ct_col))

    variants = []
    for name, ps, ct in (("call", pairs, ct_call), ("collect", pairs_col, ct_col)):
        if len(ps) * 8 != len(ct) or not ct:
            continue
        for swap in (0, 1):
            for endian in ("le", "be"):
                variants.append((name, swap, endian, ps, blocks(ct)))

    # structural offsets: the four observed values, in all assignments
    small = [-33, -1, 5, 29]
    cands = []
    for perm in itertools.permutations(LITS):
        for offs in itertools.product(small, repeat=4):
            base = [word_le(perm[i], offs[i]) for i in range(4)]
            cands.append(("lit", perm, offs, base))
    print("structural candidates", len(cands))

    def check(k, variant):
        name, swap, endian, ps, bs = variant
        for idx in (0, 3, 77, len(ps) - 1):
            if idx >= len(ps) or idx >= len(bs):
                continue
            w0, w1 = ps[idx]
            if swap:
                w0, w1 = w1, w0
            a, b = xtea_enc(w0, w1, k)
            bo = 'little' if endian == 'le' else 'big'
            got = a.to_bytes(4, bo) + b.to_bytes(4, bo)
            if got != bs[idx]:
                return None
        return True

    tested = 0
    for variant in variants:
        print("variant", variant[:3])
        for (_, perm, offs, base) in cands:
            kmods = [base, [(base[i] + C[i]) & M for i in range(4)],
                     [(base[i] - C[i]) & M for i in range(4)]]
            for k in kmods:
                tested += 1
                if check(k, variant):
                    print("*** HIT", variant[:3], perm, offs, [hex(x) for x in k])
                    return
    print("no hit after", tested, "trials")


if __name__ == "__main__":
    main()
