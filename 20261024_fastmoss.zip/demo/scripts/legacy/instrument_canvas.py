# -*- coding: utf-8 -*-
"""Instrument a FRESH tab to find where the collect payload's canvas field
comes from (a 66-byte base64-ish blob that decodes to `\\x1a\\n` + IHDR
300x150 RGBA + garbage).

Hooks (pre-load, main world):
    HTMLCanvasElement.prototype.toDataURL / toBlob
    HTMLCanvasElement.prototype.getContext
    CanvasRenderingContext2D.prototype.getImageData
    drawing ops: fillText/strokeText/fillRect/arc/measureText/getImageData
    OffscreenCanvas.prototype.convertToBlob (if present)

Then opens the captcha demo modal, calls TDC.getData() twice (>1 s apart),
saves collect_canvas_probe.json (payloads, canvas log, hook log, tdc.js sha).

It never touches the page the user is working in.

Usage: python instrument_canvas.py
"""
import base64
import hashlib
import json
import os
import sys
import time
import urllib.parse

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import instrument_eks_init as I

HERE = os.path.dirname(os.path.abspath(__file__))
JS = os.path.normpath(os.path.join(HERE, "..", "js"))

HOOK = r"""
(function(){
  var L = {ctx: [], dataurl: [], blob: [], imagedata: [], draw: [], offscreen: [],
           errors: []};
  window.__CANVASLOG = L;
  function st(){
    try { return String(new Error().stack).split('\n').slice(2, 7).join(' | ').slice(0, 300); }
    catch(e){ return ''; }
  }
  function cap(s, n){ s = String(s); return s.length > n ? s.slice(0, n) : s; }

  var P = HTMLCanvasElement.prototype;
  var oCtx = P.getContext;
  P.getContext = function(type){
    try { if (L.ctx.length < 40) L.ctx.push([String(type), this.width, this.height, st()]); } catch(e){}
    return oCtx.apply(this, arguments);
  };
  var oDU = P.toDataURL;
  P.toDataURL = function(){
    var r = oDU.apply(this, arguments);
    try {
      if (L.dataurl.length < 40)
        L.dataurl.push({w: this.width, h: this.height, args: [].slice.call(arguments),
                        len: r.length, full: r, stack: st()});
    } catch(e){}
    return r;
  };
  var oTB = P.toBlob;
  if (oTB) P.toBlob = function(cb){
    var self = this, args = arguments;
    try { if (L.blob.length < 20) L.blob.push({w: this.width, h: this.height,
                                               args: [].slice.call(arguments, 1), stack: st()}); } catch(e){}
    return oTB.call(this, function(b){
      try { L.blob[L.blob.length - 1].size = b && b.size; L.blob[L.blob.length - 1].type = b && b.type; } catch(e){}
      return cb.apply(this, arguments);
    });
  };

  var C = CanvasRenderingContext2D && CanvasRenderingContext2D.prototype;
  if (C) {
    var oGI = C.getImageData;
    C.getImageData = function(){
      var r;
      try {
        if (L.imagedata.length < 30) {
          var rec = {args: [].slice.call(arguments), stack: st()};
          L.imagedata.push(rec);
        }
      } catch(e){}
      r = oGI.apply(this, arguments);
      try {
        var rec = L.imagedata[L.imagedata.length - 1];
        if (rec && r && r.data) {
          rec.w = r.width; rec.h = r.height;
          var s = 0;
          for (var i = 0; i < r.data.length; i += 997) s = (s * 31 + r.data[i]) >>> 0;
          rec.sample_hash = s;
          var head = [];
          for (var i = 0; i < Math.min(64, r.data.length); i++) head.push(r.data[i]);
          rec.head = head;
        }
      } catch(e){}
      return r;
    };
    ['fillText','strokeText','fillRect','strokeRect','arc','rect','measureText',
     'createLinearGradient','drawImage','putImageData','setTransform','rotate',
     'translate','scale','clearRect'].forEach(function(name){
      var o = C[name];
      if (typeof o !== 'function') return;
      C[name] = function(){
        try {
          if (L.draw.length < 300) {
            L.draw.push({fn: name, args: [].slice.call(arguments).map(function(a){
              if (typeof a === 'string') return cap(a, 160);
              if (typeof a === 'number') return a;
              if (a && a.constructor && /Gradient|Pattern/.test(a.constructor.name)) return '<' + a.constructor.name + '>';
              return typeof a;
            }), stack: st()});
          }
        } catch(e){}
        return o.apply(this, arguments);
      };
    });
    var oMT = C.measureText;
    if (oMT) C.measureText = function(t){
      var r = oMT.apply(this, arguments);
      try { if (L.draw.length < 300) L.draw.push({fn: 'measureText:ret',
        args: [String(t), r && r.width], stack: st()}); } catch(e){}
      return r;
    };
  }

  try {
    if (window.OffscreenCanvas) {
      var OP = OffscreenCanvas.prototype;
      if (OP.convertToBlob) {
        var oCB = OP.convertToBlob;
        OP.convertToBlob = function(){
          var self = this;
          try { if (L.offscreen.length < 20) L.offscreen.push({w: self.width, h: self.height, stack: st()}); } catch(e){}
          return oCB.apply(this, arguments);
        };
      }
    }
  } catch(e){}

  try { window.addEventListener('error', function(e){
    if (L.errors.length < 10) L.errors.push(String(e.message));
  }); } catch(e){}
})();
"""


def main():
    t = I.new_target()
    tid = t["id"]
    print("fresh target", tid)
    c = I.CDP(t["webSocketDebuggerUrl"])
    try:
        c.call("Runtime.enable")
        c.call("Page.enable")
        c.call("Debugger.enable")
        c.call("Page.addScriptToEvaluateOnNewDocument", source=HOOK)
        c.call("Page.navigate", url=I.URL)
        tdc = "?"
        for _ in range(40):
            time.sleep(0.5)
            tdc = c.ev("typeof window.TDC", await_promise=False)
            if tdc == "object":
                break
        if tdc != "object":
            print("clicking 立即体验 ...")
            c.ev("(function(){var b=[...document.querySelectorAll('a.tpm-btn')]"
                 ".filter(function(e){return e.textContent.trim()==='立即体验';})[0];"
                 "if(b){b.click();return 1}return 0})()", await_promise=False)
            for _ in range(60):
                time.sleep(0.5)
                tdc = c.ev("typeof window.TDC", await_promise=False)
                if tdc == "object":
                    break
        print("TDC:", tdc)
        if tdc != "object":
            raise SystemExit("TDC never appeared")

        sids = {}
        for e in c.events:
            if e.get("method") == "Debugger.scriptParsed":
                sids[e["params"].get("url") or ""] = e["params"]["scriptId"]
        cand = [sid for u, sid in sids.items() if "tdc.js" in u]
        src = c.call("Debugger.getScriptSource", scriptId=cand[-1])["scriptSource"] if cand else ""
        sha = hashlib.sha256(src.encode()).hexdigest()[:16]
        print("tdc.js:", len(src), "chars sha256_16", sha)
        os.makedirs(os.path.join(JS, "live_src"), exist_ok=True)
        if src:
            open(os.path.join(JS, "live_src", "tdc_canvas_%s.js" % sha), "w",
                 encoding="utf-8").write(src)

        datas = []
        for k in range(2):
            if k:
                time.sleep(1.2)
            before = c.ev("Math.floor(Date.now()/1000)", await_promise=False)
            d = c.ev("TDC.getData()", await_promise=False)
            after = c.ev("Math.floor(Date.now()/1000)", await_promise=False)
            datas.append({"d": d, "before": before, "after": after})
            print("getData #%d: chars=%s t=%s..%s" % (k + 1, len(d or ""), before, after))

        log = json.loads(c.ev("JSON.stringify(window.__CANVASLOG)", await_promise=False))
    finally:
        try:
            c.ws.close()
        except Exception:
            pass
        I.close_target(tid)

    out = {"sha256_16": sha, "datas": datas, "log": log}
    json.dump(out, open(os.path.join(HERE, "collect_canvas_probe.json"), "w"), indent=1)
    print("getContext:", len(log.get("ctx", [])), "toDataURL:", len(log.get("dataurl", [])),
          "toBlob:", len(log.get("blob", [])), "getImageData:", len(log.get("imagedata", [])),
          "draw ops:", len(log.get("draw", [])), "offscreen:", len(log.get("offscreen", [])))
    for e in log.get("dataurl", [])[:6]:
        print("  toDataURL %dx%d len=%d head=%s" %
              (e["w"], e["h"], e["len"], e["full"][:40].encode("unicode_escape").decode()))
    for e in log.get("imagedata", [])[:6]:
        print("  getImageData", e.get("args"), e.get("w"), e.get("h"),
              "hash", e.get("sample_hash"))


if __name__ == "__main__":
    main()
