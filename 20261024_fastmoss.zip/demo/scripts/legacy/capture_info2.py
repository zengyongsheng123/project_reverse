# -*- coding: utf-8 -*-
"""Reload the page with pre-load hooks and capture how TDC.getInfo().info
(the `eks` field) is assembled.

Hooks installed before any page script runs:
  * window.btoa        -> record input/output lengths and input head
  * String.fromCharCode -> record 4-argument numeric calls (cipher words)

Then waits for window.TDC, calls getInfo(), and dumps the logs.

Usage: python capture_info2.py
Writes capture_info2.json
"""
import http.client
import json
import time

import websocket

PORT = 9222

HOOK = r"""
(function(){
  window.__L = {btoa: [], fcc: [], fccn: 0, calls: []};
  try {
    var ob = window.btoa;
    window.btoa = function(s){
      var r = ob.call(window, s);
      try {
        if (window.__L.btoa.length < 40)
          window.__L.btoa.push({in: String(s).length, out: r.length,
                                head: String(s).slice(0, 32)});
      } catch(e) {}
      return r;
    };
  } catch(e) {}
  try {
    var of = String.fromCharCode;
    String.fromCharCode = function(){
      var a = Array.prototype.slice.call(arguments);
      if (a.length === 4 && typeof a[0] === 'number' && typeof a[1] === 'number'
          && typeof a[2] === 'number' && typeof a[3] === 'number') {
        window.__L.fccn++;
        if (window.__L.fcc.length < 4000)
          window.__L.fcc.push([a[0] & 255, a[1] & 255, a[2] & 255, a[3] & 255]);
      }
      return of.apply(String, arguments);
    };
  } catch(e) {}
})();
"""


def targets():
    c = http.client.HTTPConnection("127.0.0.1", PORT, timeout=5)
    c.request("GET", "/json")
    return json.loads(c.getresponse().read())


class CDP:
    def __init__(self, url):
        self.ws = websocket.create_connection(url, timeout=180, suppress_origin=True)
        self.i = 0

    def call(self, method, timeout=90, **p):
        self.i += 1
        mid = self.i
        self.ws.send(json.dumps({"id": mid, "method": method, "params": p}))
        end = time.time() + timeout
        while True:
            self.ws.settimeout(max(0.5, end - time.time()))
            m = json.loads(self.ws.recv())
            if m.get("id") == mid:
                if "error" in m:
                    raise RuntimeError("%s -> %s" % (method, m["error"]))
                return m.get("result", {})

    def ev(self, expr, timeout=90):
        r = self.call("Runtime.evaluate", expression=expr, returnByValue=True,
                      awaitPromise=True, timeout=timeout)
        if r.get("exceptionDetails"):
            return {"__exc": str(r["exceptionDetails"])[:300]}
        return r.get("result", {}).get("value")


def main():
    pg = [t for t in targets() if t.get("type") == "page"][0]
    c = CDP(pg["webSocketDebuggerUrl"])
    c.call("Runtime.enable")
    c.call("Page.enable")
    c.call("Page.addScriptToEvaluateOnNewDocument", source=HOOK)
    print("reload:", c.ev("location.href"))
    c.call("Page.reload", ignoreCache=True)
    # TDC is created by the SDK on page load; poll for it
    info = None
    for i in range(40):
        time.sleep(0.5)
        try:
            t = c.ev("typeof window.TDC")
        except Exception:
            t = "?"
        if t == "object":
            break
    print("TDC after poll:", t)
    if t != "object":
        # open the live-demo modal, which is what loads the captcha SDK
        print("clicking demo button:",
              c.ev("(function(){var b=[...document.querySelectorAll('a.tpm-btn')]"
                   ".filter(e=>e.textContent.trim()==='立即体验')[0];"
                   "if(b){b.click();return 1}return 0})()"))
        for i in range(40):
            time.sleep(0.5)
            t = c.ev("typeof window.TDC")
            if t == "object":
                break
        print("TDC after click:", t)

    if t == "object":
        print("getInfo:", str(c.ev("JSON.stringify(TDC.getInfo())"))[:120])
        print("info len:", c.ev("TDC.getInfo().info.length"))
        time.sleep(0.5)
    log = c.ev("JSON.stringify(window.__L)")
    open("capture_info2.json", "w", encoding="utf-8").write(log)
    d = json.loads(log) if log else {}
    print("btoa calls:", len(d.get("btoa", [])), "fcc4 calls:", d.get("fccn"))
    for e in d.get("btoa", [])[:12]:
        print("  btoa in=%s out=%s head=%r" % (e["in"], e["out"], e["head"]))


if __name__ == "__main__":
    main()
