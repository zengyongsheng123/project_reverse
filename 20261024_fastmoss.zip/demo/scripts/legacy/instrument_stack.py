# -*- coding: utf-8 -*-
"""Recover the plaintext words and the key array fed to the TDC cipher.

Cipher (statically proven, bytecode 9233 = block function, caller loop 9276):

    sum = 0
    repeat 32 times:                       # exit when sum == 84941944608
        v0 += (((v1 << 4) ^ (v1 >>> 5)) + v1) ^ (sum + K[sum & 3]       + C[sum & 3])
        sum += 0x9E3779B9
        v1 += (((v0 << 4) ^ (v0 >>> 5)) + v0) ^ (sum + K[(sum>>>11)&3] + C[(sum>>>11)&3])
    C = [197402, 1907983, 0, 0]

i.e. textbook XTEA over 8-byte blocks, ECB, with a per-index constant added to
the key words.  K is the array captured as the cipher closure's upvalue; this
script records every array the VM creates (via `new Array`) so that K can be
identified by its four numeric words, together with the plaintext/ciphertext
word streams.

What is already proven (offline analysis of deep2_log.json):

  * every ciphertext 4-byte word is produced by
        String.fromCharCode(b0, b1, b2, b3)
    and the 4-char strings appear in ciphertext order (300/300 match, first
    32 bytes equal).
  * during TDC.getData() the VM calls String.prototype.charCodeAt exactly
    1464 times and **every receiver has length 4** (= 366 words * 4 bytes).
    It never scans a long string, so the plaintext must already exist as
    4-char "word strings" and charCodeAt reads them out byte by byte.
  * phase 1 (click) only produces 1-char fromCharCode output (a 256-entry
    byte table).

So: record every charCodeAt call whose receiver is 4 chars long, in order,
with the byte index and the receiver.  That list *is* the input byte stream
(interleaved with the ciphertext words being re-read, which we can recognise
because their bytes equal fromCharCode(4-arg) outputs).

Phases
    A: arm -> TDC.getData()
    B: arm -> TDC.getInfo().info

Run:  python instrument_stack.py
Out:  stack_log.json
"""
import json, time, http.client
import websocket

PORT = 9222

HOOK = r"""
(function(){
  if (window.__sk) return 'already';
  var D = window.__sk = {
    rec: false, btoa: [], cc4: [], fcc4: [], fcc: [], runs: [], json: [], join: [],
    calls: [], wstate: {},
    hist: {}, argc: {}, counts: {}, seen: {}, phase: 0, t0: 0,
    seq: 0, buf: '', bufLen: 0, bufSeq: 0, arrays: [], arrTotal: 0, frozen: false
  };

  /* ---- the decisive hook: the XTEA block function is invoked with
     args = [ [w0, w1], K[4] ] through Function.prototype.apply (the VM's
     callm/callp opcodes both use .apply).  That shape is unique, so record
     the plaintext word pair and the key words at the call site. ---- */
  var oApply = Function.prototype.apply;
  function snap(a, cap){
    var o = [], n = 0;
    try { n = a.length; } catch(e){ return null; }
    if (typeof n !== 'number' || n > 64) return {len: n, big: true};
    for (var i = 0; i < n && i < (cap || 8); i++) {
      var v = a[i], t = typeof v;
      o.push(t === 'number' ? v : t === 'string' ? v.slice(0, 32) : t);
    }
    return {len: n, v: o};
  }
  Function.prototype.apply = function(self, args){
    try {
      if (D.rec && args && typeof args === 'object' && args.length === 2) {
        var a0 = args[0];
        if (a0 && typeof a0 === 'object' && a0.length === 2 &&
            typeof a0[0] === 'number' && typeof a0[1] === 'number' && D.calls.length < 600) {
          var a1 = args[1];
          D.calls.push({
            t: now(), seq: D.seq, which: D.phase,
            v: [a0[0] >>> 0, a0[1] >>> 0],
            f: (this && this.name) || '', fl: (this && this.length),
            a1: (a1 && typeof a1 === 'object') ? snap(a1) : typeof a1,
            key: (a1 && typeof a1 === 'object' && a1.length === 4 &&
                  typeof a1[0] === 'number' && typeof a1[3] === 'number')
                   ? [a1[0] >>> 0, a1[1] >>> 0, a1[2] >>> 0, a1[3] >>> 0] : null
          });
        }
      }
    } catch(e){}
    return oApply.call(this, self, args);
  };
  var MAX_CC = 6000, MAX_FCC = 3000, MAX_BTOA = 20, MAX_RUNS = 400;
  function now(){ return Math.round(performance.now() - D.t0); }
  function toHex(s){
    s = String(s); var o = '', h = '0123456789abcdef';
    for (var i = 0; i < s.length && i < 40000; i++) {
      var c = s.charCodeAt(i) & 255;
      o += h[(c >> 4) & 15] + h[c & 15];
    }
    return o;
  }
  function bump(k){ D.counts[k] = (D.counts[k]||0)+1; }
  function flushBuf(){
    if (D.bufLen > 0 && D.runs.length < MAX_RUNS)
      D.runs.push({s0: D.bufSeq, s1: D.seq, len: D.bufLen, data: D.buf.slice(0, 120000)});
    D.buf = ''; D.bufLen = 0; D.bufSeq = D.seq;
  }

  var oBtoa = window.btoa;
  window.btoa = function(s){
    var out = oBtoa.apply(window, arguments);
    try {
      if (D.rec) {
        D.seq++; bump('btoa'); flushBuf();
        var st = '';
        try { st = (new Error()).stack || ''; } catch(e){}
        if (D.btoa.length < MAX_BTOA)
          D.btoa.push({t: now(), seq: D.seq, inLen: String(s).length,
                       inLenCtor: s && s.constructor && s.constructor.name,
                       inHex: toHex(s), out: out,
                       stack: st.split('\n').slice(0, 6).join('\n')});
      }
    } catch(e){}
    return out;
  };

  var oFCC = String.fromCharCode;
  String.fromCharCode = function(){
    var out = oFCC.apply(String, arguments);
    try {
      if (D.rec) {
        D.seq++; bump('fcc');
        var a = arguments.length;
        D.argc[a] = (D.argc[a]||0)+1;
        if (a === 4) {
          flushBuf();
          if (D.fcc4.length < MAX_FCC)
            D.fcc4.push({t: now(), seq: D.seq, b: [arguments[0]&255, arguments[1]&255, arguments[2]&255, arguments[3]&255]});
        } else if (a === 1) {
          if (D.bufLen < 120000) { D.buf += out; D.bufLen += 1; }
        } else {
          flushBuf();
          var k2 = 'F' + a + '|' + out.slice(0, 32);
          if (!D.seen[k2] && D.fcc.length < 400) { D.seen[k2] = 1; D.fcc.push({t: now(), argc: a, len: out.length, data: String(out).slice(0, 200)}); }
        }
      }
    } catch(e){}
    return out;
  };

  var oCC = String.prototype.charCodeAt;
  String.prototype.charCodeAt = function(i){
    try {
      if (D.rec) {
        D.seq++;
        var s = this, n = s.length;
        bump('cc'); D.hist[n] = (D.hist[n]||0)+1;
        if (n === 4) {
          flushBuf();
          if (D.cc4.length < MAX_CC)
            D.cc4.push({t: now(), seq: D.seq, i: i, s: String(s)});
        }
      }
    } catch(e){}
    return oCC.call(this, i);
  };

  var oStr = JSON.stringify;
  JSON.stringify = function(){
    var out = oStr.apply(JSON, arguments);
    try { if (D.rec) { D.seq++; flushBuf();
      if (typeof out === 'string' && out.length >= 8 && D.json.length < 40)
        D.json.push({t: now(), seq: D.seq, len: out.length, data: out.slice(0, 4000)}); } } catch(e){}
    return out;
  };

  var oJoin = Array.prototype.join;
  Array.prototype.join = function(sep){
    var out = oJoin.apply(this, arguments);
    try { if (D.rec) { D.seq++; flushBuf();
      if (typeof out === 'string' && out.length >= 8 && D.join.length < 60)
        D.join.push({t: now(), seq: D.seq, len: out.length, data: out.slice(0, 2000)}); } } catch(e){}
    return out;
  };

  /* ---- array capture: the cipher key lives in an array the VM builds with
     `new Array()` and reads as K[idx].  Record every array the VM creates so
     the four-word key can be picked out afterwards (its box is shared, so the
     value is read at dump time). ---- */
  var oArray = window.Array;
  var seenArr = (typeof WeakSet !== 'undefined') ? new WeakSet() : null;
  /* per-array numeric-write journal: the four key words are written into a
     `new Array()` with setelem, which is an ordinary index assignment, so a
     Proxy is the only way to see them. */
  var arrId = (typeof WeakMap !== 'undefined') ? new WeakMap() : null;
  var arrSeq = 0;
  function noteWrite(t, k, v){
    try {
      if (!arrId) return;
      if (typeof k !== 'string' || k.length > 3) return;
      var n = +k;
      if (!(n >= 0 && n < 64) || String(n) !== k) return;
      if (typeof v !== 'number' || !isFinite(v)) return;
      var id = arrId.get(t);
      if (!id) return;
      var st = D.wstate[id];
      if (!st) { st = D.wstate[id] = { n: 0, v: [], idx: [] }; }
      if (st.n < 12) { st.v.push(v >>> 0); st.idx.push(n); }
      st.n++;
    } catch(e){}
  }
  function wrapArr(a){
    try {
      if (typeof Proxy === 'undefined' || !arrId) return a;
      arrId.set(a, ++arrSeq);
      return new Proxy(a, {
        set: function(t, k, v, r){ noteWrite(t, k, v); return Reflect.set(t, k, v, r); }
      });
    } catch(e){ return a; }
  }
  function noteArr(a, why){
    try {
      if (D.frozen) return;
      if (!a || typeof a !== 'object') return;
      if (seenArr) { if (seenArr.has(a)) return; seenArr.add(a); }
      if (D.arrTotal < 40000) { D.arrTotal++; D.arrays.push({a: a, t: now(), phase: D.phase, n: why}); }
    } catch(e){}
  }
  function SkArray(){
    var a;
    if (arguments.length === 0) a = [];
    else if (arguments.length === 1 && typeof arguments[0] === 'number') a = new oArray(arguments[0]);
    else { a = []; for (var i = 0; i < arguments.length; i++) a[i] = arguments[i]; }
    noteArr(a, 'new');
    return wrapArr(a);
  }
  SkArray.prototype = oArray.prototype;
  try { oArray.prototype.constructor = SkArray; } catch(e){}
  try {
    Reflect.ownKeys(oArray).forEach(function(ak){
      if (ak === 'prototype' || ak === 'length' || ak === 'name') return;
      try { Object.defineProperty(SkArray, ak, Object.getOwnPropertyDescriptor(oArray, ak)); } catch(e){}
    });
  } catch(e){}
  try { Object.defineProperty(SkArray, 'name', {value: 'Array'}); } catch(e){}
  window.Array = SkArray;
  /* NOTE: Array.prototype.push/unshift are deliberately NOT wrapped any more.
     The VM creates a fresh frame array per body invocation, so a push hook
     floods D.arrays past its cap before the cipher key is ever built.  Both
     key arrays and the cipher upvalue are created with `new Array()` in the
     VM, which SkArray already captures. */

  window.__skArm = function(){
    D.phase += 1; D.rec = true; D.frozen = false; D.t0 = performance.now();
    D.seen = {}; D.hist = {}; D.argc = {}; D.counts = {};
    D.btoa.length = 0; D.cc4.length = 0; D.fcc4.length = 0; D.fcc.length = 0;
    D.calls.length = 0;
    D.runs.length = 0; D.json.length = 0; D.join.length = 0;
    D.seq = 0; D.buf = ''; D.bufLen = 0; D.bufSeq = 0;
    return D.phase;
  };
  window.__skDump = function(){
    D.rec = false; flushBuf(); D.frozen = true;
    var o = {};
    for (var k in D) if (k !== 'seen' && k !== 'arrays' && k !== 'wstate') o[k] = D[k];
    /* keep only arrays that received a handful of numeric index writes: the
       cipher key is exactly four, written once by the module prelude */
    var ws = {}, wn = 0;
    for (var wid in D.wstate) {
      var st = D.wstate[wid];
      if (!st || st.n < 2 || st.n > 12) continue;
      ws[wid] = { n: st.n, v: st.v, idx: st.idx };
      if (++wn >= 4000) break;
    }
    o.wstate = ws;
    o.wcount = wn;
    var arrs = [];
    for (var i = 0; i < D.arrays.length; i++) {
      var rec = D.arrays[i], a = rec.a, n;
      try { n = a.length; } catch(e){ continue; }
      if (typeof n !== 'number' || n > 64) continue;
      var snap = [], ok = true;
      for (var j = 0; j < n; j++) {
        var v = a[j], t = typeof v;
        if (v === null || t === 'number' || t === 'string' || t === 'boolean' || t === 'undefined') {
          snap.push(t === 'string' ? v.slice(0, 64) : v);
        } else { ok = false; break; }
      }
      if (!ok) continue;
      arrs.push({i: i, t: rec.t, phase: rec.phase, len: n, v: snap});
    }
    o.arrays = arrs;
    o.buf = ''; o.bufLen = 0;
    return o;
  };
  return 'ok';
})()
"""


def page_ws():
    conn = http.client.HTTPConnection("127.0.0.1", PORT, timeout=5)
    conn.request("GET", "/json")
    for t in json.loads(conn.getresponse().read()):
        if t.get("type") == "page" and "cloud.tencent.com" in t.get("url", ""):
            return t["webSocketDebuggerUrl"]
    raise SystemExit("page not found")


class CDP:
    def __init__(self):
        self.ws = websocket.create_connection(page_ws(), timeout=60, suppress_origin=True)
        self.i = 0

    def call(self, method, **params):
        self.i += 1
        self.ws.send(json.dumps({"id": self.i, "method": method, "params": params}))
        while True:
            msg = json.loads(self.ws.recv())
            if msg.get("id") == self.i:
                if "error" in msg:
                    raise RuntimeError(msg["error"])
                return msg.get("result", {})

    def ev(self, expr):
        r = self.call("Runtime.evaluate", expression=expr, returnByValue=True, awaitPromise=True)
        res = r.get("result", {})
        if res.get("subtype") == "error":
            print("JSERR", res.get("description"))
        return res.get("value")


def summarize(tag, d):
    print("== %s ==" % tag)
    print("  counts", d.get("counts"), "argc", d.get("argc"))
    print("  ccHist", d.get("hist"))
    print("  btoa", [(e["inLen"], len(e["out"])) for e in d.get("btoa", [])])
    print("  cc4", len(d.get("cc4") or []), "fcc4", len(d.get("fcc4") or []))
    calls = d.get("calls") or []
    print("  cipher calls", len(calls))
    for e in calls[:6]:
        print("    C v=%s key=%s a1=%s f=%r" %
              ([hex(x) for x in e["v"]], e.get("key"), e.get("a1"), e.get("f")))
    seen_k = []
    for e in calls:
        k = e.get("key")
        if k and k not in seen_k:
            seen_k.append(k)
    for k in seen_k[:10]:
        print("    UNIQUE KEY %s" % [hex(x) for x in k])
    print("  fcc1 runs", [(r["s0"], r["s1"], r["len"]) for r in (d.get("runs") or [])][:20])
    # quick reconstruction: bytes of the cc4 receivers in order
    b = b"".join(bytes(ord(c) & 0xFF for c in e["s"]) for e in (d.get("cc4") or []))
    print("  cc4 byte stream len", len(b), "head", b[:32].hex())
    f = b"".join(bytes(e["b"]) for e in (d.get("fcc4") or []))
    print("  fcc4 byte stream len", len(f), "head", f[:32].hex())
    arrs = d.get("arrays") or []

    def _num(x):
        if isinstance(x, (int, float)):
            return True
        return isinstance(x, str) and x.strip().lstrip("-").isdigit()

    cand = [a for a in arrs if 2 <= a["len"] <= 16 and a["v"]
            and all(_num(x) for x in a["v"])]
    print("  arrays total", d.get("arrTotal"), "snap", len(arrs), "numeric candidates", len(cand))
    ws = d.get("wstate") or {}
    four = [k for k, v in ws.items() if len(v.get("v") or []) == 4]
    print("  write-journal arrays", len(ws), "with exactly 4 numeric writes", len(four))
    for k in four[:6]:
        print("    w#%s idx=%s v=%s" % (k, ws[k]["idx"], ws[k]["v"]))
    for a in cand[:40]:
        print("    arr#%d len=%d phase=%s %s" % (a["i"], a["len"], a.get("phase"), a["v"]))


def main():
    c = CDP()
    c.call("Page.enable")
    try:
        c.call("Page.addScriptToEvaluateOnNewDocument", source=HOOK)
    except Exception as e:  # noqa: BLE001
        print("addScriptToEvaluateOnNewDocument failed:", e)
    c.call("Page.navigate", url="https://cloud.tencent.com/product/captcha")
    time.sleep(5)
    print("hook:", c.ev(HOOK))
    c.ev("(()=>{const e=[...document.querySelectorAll('a.tpm-btn')].filter(e=>e.textContent.trim()==='立即体验')[0]; if(e){e.scrollIntoView({block:'center'}); e.click();} })()")
    for _ in range(30):
        time.sleep(0.5)
        if c.ev("!!window.TDC"):
            break
    time.sleep(1.0)
    print("TDC:", c.ev("!!window.TDC"))

    c.ev("window.__skArm()")
    data = c.ev("window.TDC?String(window.TDC.getData()):null")
    dA = c.ev("window.__skDump()") or {}
    summarize("A getData", dA)

    c.ev("window.__skArm()")
    info = c.ev("window.TDC?String(window.TDC.getInfo().info):null")
    dB = c.ev("window.__skDump()") or {}
    summarize("B getInfo", dB)

    out = {"A": dA, "B": dB, "data": data, "info": info}
    json.dump(out, open("stack_log.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print("collect len", len(data or ""), "info len", len(info or ""))
    print("--- btoa stacks (phase A) ---")
    for e in (dA.get("btoa") or []):
        print("# inLen", e["inLen"], "ctor", e.get("inLenCtor"))
        print(e.get("stack", "")[:700])
    print("-> stack_log.json")


if __name__ == "__main__":
    main()
