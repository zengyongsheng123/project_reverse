# -*- coding: utf-8 -*-
"""Patch specific globals (JSON/btoa/URI) in place before opening the captcha; dump calls."""
import json, time, http.client
import websocket

PORT = 9222

def page_ws():
    conn = http.client.HTTPConnection("127.0.0.1", PORT, timeout=5)
    conn.request("GET", "/json")
    for t in json.loads(conn.getresponse().read()):
        if t.get("type") == "page" and "cloud.tencent.com" in t.get("url", ""):
            return t["webSocketDebuggerUrl"]
    raise SystemExit("page not found")

class CDP:
    def __init__(self):
        self.ws = websocket.create_connection(page_ws(), timeout=20, suppress_origin=True)
        self.i = 0
    def call(self, method, **params):
        self.i += 1
        self.ws.send(json.dumps({"id": self.i, "method": method, "params": params}))
        while True:
            msg = json.loads(self.ws.recv())
            if msg.get("id") == self.i:
                if "error" in msg: raise RuntimeError(msg["error"])
                return msg.get("result", {})
    def ev(self, expr):
        r = self.call("Runtime.evaluate", expression=expr, returnByValue=True, awaitPromise=True)
        res = r.get("result", {})
        if res.get("subtype") == "error": print("JSERR", res.get("description"))
        return res.get("value")

PATCH = r"""
(function(){
  if (window.__gp) return 'already';
  window.__gp = [];
  var S=function(v){
    try{
      if (typeof v==='string') return v.length>400?('<str '+v.length+'>'+v.slice(0,400)):v;
      if (typeof v==='object'&&v) { try{ var s=JSON.stringify(v); return s.length>400?('<json '+s.length+'>'+s.slice(0,400)):s; }catch(e){ return '<obj>'; } }
      return String(v);
    }catch(e){return '?';}
  };
  var L=function(n,a,r){ try{ var arr=Array.prototype.slice.call(a||[]); if(window.__gp.length<600) window.__gp.push({n:n,a:arr.map(S),r:S(r)}); }catch(e){} };
  var p=function(obj,name,keys){
    keys.forEach(function(k){
      var o=obj[k]; if(typeof o!=='function'||o.__p) return;
      var w=function(){ var r=o.apply(this,arguments); L(name+'.'+k, arguments, r); return r; };
      w.__p=1; obj[k]=w;
    });
  };
  p(window, 'window', ['btoa','atob','encodeURIComponent','decodeURIComponent','escape','unescape','parseInt']);
  p(JSON, 'JSON', ['stringify','parse']);
  if (window.TextEncoder) p(TextEncoder.prototype,'TextEncoder',['encode']);
  return 'ok';
})()
"""

def main():
    c = CDP()
    c.call("Page.enable")
    c.call("Page.navigate", url="https://cloud.tencent.com/product/captcha")
    time.sleep(5)
    print("url", c.ev("location.href"))
    print("patch", c.ev(PATCH))
    c.ev("window.__gp.length=0")
    c.ev("(()=>{const e=[...document.querySelectorAll('a.tpm-btn')].filter(e=>e.textContent.trim()==='立即体验')[0]; if(e){e.scrollIntoView({block:'center'}); e.click();} })()")
    for _ in range(30):
        time.sleep(0.5)
        if c.ev("!!window.TDC"): break
    time.sleep(1)
    print("TDC", c.ev("!!window.TDC"))
    d = c.ev("window.TDC?String(window.TDC.getData()):null")
    i = c.ev("window.TDC?JSON.stringify(window.TDC.getInfo()):null")
    print("data", (d or '')[:60], len(d or ''))
    print("info", (i or '')[:60], len(i or ''))
    logs = c.ev("window.__gp.slice(0,600)") or []
    json.dump(logs, open("globals_log.json", "w"), indent=1)
    print("logs", len(logs))
    for e in logs:
        print(e["n"], "ARGS:", str(e["a"])[:180], "=>", str(e["r"])[:180])

if __name__ == "__main__":
    main()
