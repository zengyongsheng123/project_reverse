# -*- coding: utf-8 -*-
"""Rewrite tdc.js via CDP Fetch so the Chaos VM runs with a logging window Proxy."""
import json, time, base64, http.client, os, sys
import websocket

PORT = 9222
TDC_SRC = os.path.join(os.path.dirname(__file__), "..", "js", "tdc.dec.js")
ORIG = open(TDC_SRC, encoding="utf-8").read()
assert ORIG.count(",window)}()") == 1, ORIG.count(",window)}()")
MOD = ORIG.replace(",window)}()", ",window.__capHost)}()")

PRELUDE = r"""
(function(){
  if (window.__capHost) return;
  window.__capLog = [];
  var MAX = 400;
  var S = function(v){
    try{
      if (typeof v === 'string') return v.length > 300 ? ('<str len='+v.length+'> '+v.slice(0,300)) : v;
      if (typeof v === 'function') return '[fn]';
      if (v && typeof v === 'object') return '<obj '+(v.constructor&&v.constructor.name)+'>';
      return String(v);
    }catch(e){ return '?'; }
  };
  var log = function(kind, name, args, ret){
    if (window.__capLog.length > MAX) return;
    window.__capLog.push({k:kind, n:name, a:(args||[]).map(S), r: S(ret)});
  };
  var real = window;
  var wrapObj = function(obj, name, depth){
    if (!obj || (typeof obj !== 'object' && typeof obj !== 'function')) return obj;
    if (depth > 2) return obj;
    if (obj.__capWrapped) return obj;
    try { obj.__capWrapped = true; } catch(e){}
    return new Proxy(obj, {
      get: function(t, p, recv){
        var v;
        try { v = Reflect.get(t, p, t); } catch(e) { return undefined; }
        if (typeof v === 'function') {
          return new Proxy(v, { apply: function(fn, thisArg, args){
              var r = Reflect.apply(fn, t, args);
              if (/stringify|parse|btoa|atob|encodeURIComponent|decodeURIComponent|getContext|toDataURL|getImageData|getParameter|now|getTime|random|charCodeAt/i.test(String(p))) {
                log('call', name+'.'+String(p), args, r);
              }
              return r;
            }});
        }
        if (v && typeof v === 'object' && /document|navigator|screen|location|performance|crypto|history|localStorage|sessionStorage|JSON|Math|Date|Array|Object|String|Number/i.test(String(p))) {
          return wrapObj(v, name+'.'+String(p), depth+1);
        }
        return v;
      },
      set: function(t, p, v){
        log('set', name+'.'+String(p), [v], v);
        return Reflect.set(t, p, v, t);
      }
    });
  };
  window.__capHost = new Proxy(real, {
    get: function(t, p){
      var v;
      try { v = Reflect.get(t, p, t); } catch(e) { return undefined; }
      if (typeof v === 'function') {
        return new Proxy(v, { apply: function(fn, thisArg, args){
            var r = Reflect.apply(fn, t, args);
            if (/stringify|parse|btoa|atob|encodeURIComponent|decodeURIComponent/i.test(String(p))) log('call', 'window.'+String(p), args, r);
            return r;
          }});
      }
      if (v && typeof v === 'object' && /document|navigator|screen|location|performance|crypto|history|localStorage|sessionStorage|JSON|Math|Date/i.test(String(p))) {
        return wrapObj(v, 'window.'+String(p), 1);
      }
      return v;
    },
    set: function(t, p, v){ log('set','window.'+String(p),[v],v); return Reflect.set(t,p,v,t); }
  });
})();
"""

def page_ws():
    conn = http.client.HTTPConnection("127.0.0.1", PORT, timeout=5)
    conn.request("GET", "/json")
    for t in json.loads(conn.getresponse().read()):
        if t.get("type") == "page" and "cloud.tencent.com" in t.get("url", ""):
            return t["webSocketDebuggerUrl"]
    raise SystemExit("page not found")

class CDP:
    def __init__(self):
        self.ws = websocket.create_connection(page_ws(), timeout=30, suppress_origin=True)
        self.i = 0
        self.events = []
    def send(self, method, **params):
        self.i += 1
        self.ws.send(json.dumps({"id": self.i, "method": method, "params": params}))
        return self.i
    def wait(self, mid):
        while True:
            msg = json.loads(self.ws.recv())
            if msg.get("id") == mid:
                if "error" in msg: raise RuntimeError(msg["error"])
                return msg.get("result", {})
            if "method" in msg:
                self.events.append(msg)
    def call(self, method, **params):
        return self.wait(self.send(method, **params))
    def poll(self, timeout=0.2):
        self.ws.settimeout(timeout)
        try:
            msg = json.loads(self.ws.recv())
            if "method" in msg: self.events.append(msg)
            return msg
        except Exception:
            return None
        finally:
            self.ws.settimeout(30)
    def ev(self, expr):
        r = self.call("Runtime.evaluate", expression=expr, returnByValue=True, awaitPromise=True)
        res = r.get("result", {})
        if res.get("subtype") == "error": print("JSERR", res.get("description"))
        return res.get("value")

def pump(c, seconds, on_event=None):
    end = time.time() + seconds
    while time.time() < end:
        m = c.poll(0.2)
        if m and on_event:
            on_event(c, m)
        # drain queued events
        while c.events:
            ev = c.events.pop(0)
            if on_event: on_event(c, ev)

def main():
    c = CDP()
    c.call("Page.enable")
    c.call("Fetch.enable", patterns=[{"urlPattern": "*tdc.js*", "requestStage": "Request"}])
    c.call("Page.addScriptToEvaluateOnNewDocument", source=PRELUDE)

    def on_event(c, msg):
        if msg.get("method") == "Fetch.requestPaused":
            p = msg["params"]
            body = base64.b64encode(MOD.encode()).decode()
            c.send("Fetch.fulfillRequest", requestId=p["requestId"], responseCode=200,
                   responseHeaders=[{"name": "Content-Type", "value": "application/javascript; charset=utf-8"}],
                   body=body)
            print("[fulfilled tdc.js]", p["request"]["url"][:80])

    c.call("Page.navigate", url="https://cloud.tencent.com/product/captcha")
    pump(c, 6, on_event)
    print("hooked:", c.ev("!!window.__capHost"))
    c.ev("(()=>{const e=[...document.querySelectorAll('a.tpm-btn')].filter(e=>e.textContent.trim()==='立即体验')[0]; if(e){e.scrollIntoView({block:'center'}); e.click();} })()")
    pump(c, 8, on_event)
    print("TDC:", c.ev("!!window.TDC"), "log:", c.ev("window.__capLog?window.__capLog.length:null"))
    print("data len:", c.ev("window.TDC?String(window.TDC.getData()).length:null"))
    print("info len:", c.ev("window.TDC?String(window.TDC.getInfo().info).length:null"))
    logs = c.ev("window.__capLog.slice(0,400)") or []
    json.dump(logs, open("host_log.json", "w"), indent=1)
    for e in logs[:120]:
        print(e["k"], e["n"], "ARGS:", str(e["a"])[:160], "RET:", str(e["r"])[:160])

if __name__ == "__main__":
    main()
