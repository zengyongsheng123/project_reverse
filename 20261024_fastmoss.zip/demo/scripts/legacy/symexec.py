# -*- coding: utf-8 -*-
"""Symbolic stack executor for a slice of Chaos-VM bytecode.

Values are either opaque symbols (strings) or explicit boxes (Box for local
index arrays, Pair for [obj, key] tuples).  This lets us read what an
instruction range computes without knowing the runtime values.

    python symexec.py 9288 9413
"""
import sys, json

BC = "../js/bytecode.json"


class Box:
    def __init__(self, idx):
        self.idx = idx

    def __repr__(self):
        return "Box(%s)" % self.idx


class Pair:
    def __init__(self, a, b):
        self.a = a
        self.b = b

    def __repr__(self):
        return "Pair(%r,%r)" % (self.a, self.b)


def sym(v):
    return str(v)


def deref(v, V):
    if isinstance(v, Box):
        return V.get(v.idx, "local[%d]" % v.idx)
    if isinstance(v, int):
        return V.get(v, "local[%d]" % v)
    return "deref(%s)" % sym(v)


def run(bc, lo, hi, V=None, decisions=None, verbose=True):
    """Run instructions in [lo,hi) assuming straight-line flow to hi.

    decisions: dict pc -> bool controlling jz (True = jump taken).
    """
    V = dict(V or {})
    decisions = decisions or {}
    pc = lo
    stack = []
    trace = []

    def note(pc, op, st):
        if verbose:
            trace.append((pc, op, list(st)))

    while pc < hi:
        op = bc[pc]
        start = pc
        pc += 1
        if op == 5:                      # drop
            stack.pop()
        elif op == 12:                   # dup
            stack.append(stack[-1])
        elif op == 35:                   # push1 -> box/inline array [imm]
            stack.append(Box(int(bc[pc]))); pc += 1
        elif op == 59:                   # push imm
            stack.append(bc[pc]); pc += 1
        elif op == 54:                   # setimm
            stack[-1] = bc[pc]; pc += 1
        elif op == 28:                   # load local
            stack.append(deref(int(bc[pc]), V)); pc += 1
        elif op == 7:                    # deref0
            v = stack.pop()
            stack.append(deref(v, V))
        elif op == 34:                   # mkpair: [V[idx][0], B]
            b = stack.pop()
            idx = stack.pop()
            stack.append(Pair(deref(idx, V), b))
        elif op == 9:                    # getidx
            b = stack.pop()
            if isinstance(b, Pair):
                stack.append("(%s)[%s]" % (b.a, sym(b.b)))
            else:
                stack.append("idx(%s)" % sym(b))
        elif op == 6:                    # store: rotate top into V[len-2-B]
            b = int(bc[pc]); pc += 1
            i = len(stack) - 2 - b
            q = stack[i]
            stack[i] = stack.pop()
            stack.append(q)
        elif op == 31:                   # setprop (does NOT pop)
            val = stack[-1]
            idx = stack[-2]
            trace.append(("ASSIGN", "%s" % sym(idx), sym(val)))
        elif op == 2:
            b = stack.pop(); stack[-1] = "(%s | %s)" % (sym(stack[-1]), sym(b))
        elif op == 3:
            b = stack.pop(); stack[-1] = "(%s << %s)" % (sym(stack[-1]), sym(b))
        elif op == 4:
            b = stack.pop(); stack[-1] = "(%s >> %s)" % (sym(stack[-1]), sym(b))
        elif op == 40:
            b = stack.pop(); stack[-1] = "(%s >>> %s)" % (sym(stack[-1]), sym(b))
        elif op == 37:
            b = stack.pop(); stack[-1] = "(%s ^ %s)" % (sym(stack[-1]), sym(b))
        elif op == 51:
            b = stack.pop(); stack[-1] = "(%s + %s)" % (sym(stack[-1]), sym(b))
        elif op == 43:
            b = stack.pop(); stack[-1] = "(%s - %s)" % (sym(stack[-1]), sym(b))
        elif op == 55:
            b = stack.pop(); stack[-1] = "(%s & %s)" % (sym(stack[-1]), sym(b))
        elif op == 50:
            b = stack.pop(); stack[-1] = "(%s * %s)" % (sym(stack[-1]), sym(b))
        elif op == 57:
            b = stack.pop(); stack[-1] = "(%s / %s)" % (sym(stack[-1]), sym(b))
        elif op == 20:
            b = stack.pop(); stack[-1] = "(%s %% %s)" % (sym(stack[-1]), sym(b))
        elif op == 8:
            b = stack.pop(); stack[-1] = "(%s === %s)" % (sym(stack[-1]), sym(b))
        elif op == 58:
            b = stack.pop(); stack[-1] = "(%s == %s)" % (sym(stack[-1]), sym(b))
        elif op == 36:
            b = stack.pop(); stack[-1] = "(%s >= %s)" % (sym(stack[-1]), sym(b))
        elif op == 62:
            b = stack.pop(); stack[-1] = "(%s > %s)" % (sym(stack[-1]), sym(b))
        elif op == 30:
            stack[-1] = "(!%s)" % sym(stack[-1])
        elif op == 29:
            stack[-1] = "typeof %s" % sym(stack[-1])
        elif op == 63:                   # jz target  (tests top, does NOT pop)
            tgt = int(bc[pc]); pc += 1
            cond = stack[-1]
            take = decisions.get(start)
            if take is None:
                trace.append(("JZ?", start, sym(cond), tgt))
                return stack, trace
            if take:
                pc = tgt
        elif op == 33:                   # jmp
            tgt = int(bc[pc]); pc += 1
            pc = tgt
        elif op == 48:                   # halt
            break
        elif op == 18:                   # ret
            break
        elif op == 46:
            stack.append('""')
        elif op == 65:
            stack[-1] = "%s+chr(%d)" % (sym(stack[-1]), int(bc[pc])); pc += 1
        elif op == 26:
            stack.append("undefined")
        elif op == 24:
            stack.append("null")
        elif op == 66:
            stack.append("true")
        elif op == 67:
            stack.append("false")
        elif op == 68:
            stack[-1] = "host(%s)" % sym(stack[-1])
        elif op == 64:                   # setlen
            pc += 1
        elif op == 21:                   # local init
            V[int(bc[pc])] = V.get(int(bc[pc]), "local[%d]" % int(bc[pc]))
            pc += 1
        elif op == 16:                   # try (2 operands)
            pc += 2
        elif op == 19:                   # clrF
            pass
        elif op == 14:                   # tpop
            pass
        elif op == 60:                   # throw
            trace.append(("THROW", start, sym(stack[-1])))
            break
        else:
            trace.append(("UNSUPPORTED", start, op))
            break
        note(start, op, stack)
    return stack, trace


def main():
    bc = json.load(open(BC, encoding="utf-8"))
    lo, hi = int(sys.argv[1]), int(sys.argv[2])
    # local boxes: idx -> symbolic name
    V = {5: "v0", 6: "v1", 7: "sum", 8: "K", 3: "arg0", 4: "arg1"}
    stack, trace = run(bc, lo, hi, V)
    for t in trace:
        print(t)
    print("FINAL STACK", [sym(x) for x in stack])


if __name__ == "__main__":
    main()
