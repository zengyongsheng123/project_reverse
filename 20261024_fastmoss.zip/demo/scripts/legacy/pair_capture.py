# -*- coding: utf-8 -*-
"""Capture one full plaintext/ciphertext pairing from a single live build:

  * plaintext  = the single [w0,w1] argument the VM hands to the cipher
                 closure (read while paused on the trampoline)
  * ciphertext = the 4-byte String.fromCharCode calls the caller makes after
                 each cipher call (preload hook)

Flow: install the fromCharCode hook, reload, wait for TDC, reset counters,
break on every trampoline call, call TDC.getData(), collect both streams.

Usage: python pair_capture.py
Writes pairs_live.json
"""
import http.client
import json
import time

import websocket

PORT = 9222

PRELOAD = r"""
(function(){
  if (window.__fc) return;
  var D = window.__fc = {fcc4: [], n: 0, t0: performance.now()};
  var ofc = String.fromCharCode;
  String.fromCharCode = function(){
    var out = ofc.apply(String, arguments);
    try{
      if (arguments.length === 4){
        D.fcc4.push([arguments[0]&255, arguments[1]&255, arguments[2]&255, arguments[3]&255, Math.round(performance.now())]);
      }
    }catch(e){}
    return out;
  };
})();
"""


def targets():
    c = http.client.HTTPConnection("127.0.0.1", PORT, timeout=5)
    c.request("GET", "/json")
    return json.loads(c.getresponse().read())


class CDP:
    def __init__(self, url):
        self.ws = websocket.create_connection(url, timeout=180, suppress_origin=True)
        self.i = 0
        self.events = []

    def send(self, method, **p):
        self.i += 1
        self.ws.send(json.dumps({"id": self.i, "method": method, "params": p}))
        return self.i

    def recv(self, timeout):
        self.ws.settimeout(timeout)
        return json.loads(self.ws.recv())

    def call(self, method, timeout=60, **p):
        mid = self.send(method, **p)
        end = time.time() + timeout
        while True:
            m = self.recv(max(0.5, end - time.time()))
            if m.get("id") == mid:
                if "error" in m:
                    raise RuntimeError("%s -> %s" % (method, m["error"]))
                return m.get("result", {})
            if "method" in m:
                self.events.append(m)

    def ev(self, expr, timeout=60):
        r = self.call("Runtime.evaluate", expression=expr, returnByValue=True,
                      awaitPromise=True, timeout=timeout)
        if r.get("exceptionDetails"):
            return {"__exc": str(r["exceptionDetails"])[:300]}
        return r.get("result", {}).get("value")


ARGPROBE = r"""
(function(A){
  try{
    if(A.length===1 && A[0] && typeof A[0]==='object' && A[0].length===2 &&
       typeof A[0][0]==='number' && typeof A[0][1]==='number')
      return JSON.stringify([A[0][0]>>>0, A[0][1]>>>0]);
  }catch(e){}
  return '';
})(arguments)
"""


def main():
    pg = [t for t in targets() if t.get("type") == "page"][0]
    c = CDP(pg["webSocketDebuggerUrl"])
    c.call("Page.enable")
    c.call("Runtime.enable")
    c.call("Page.addScriptToEvaluateOnNewDocument", source=PRELOAD)
    print("preload installed; reloading")
    c.call("Page.reload", ignoreCache=False)
    time.sleep(6)
    # tdc.js is loaded lazily when the demo widget is opened
    try:
        for typ, extra in (("mouseMoved", {}),
                           ("mousePressed", {"button": "left", "clickCount": 1}),
                           ("mouseReleased", {"button": "left", "clickCount": 1})):
            c.call("Input.dispatchMouseEvent", type=typ, x=569, y=545, **extra)
            time.sleep(0.1)
        print("clicked widget trigger")
    except Exception as e:
        print("click failed:", e)
    # wait for TDC
    for _ in range(20):
        v = c.ev("(function(){try{return typeof TDC==='object' && typeof TDC.getData==='function' && TDC.getData().length>0}catch(e){return false}})()")
        print("tdc ready:", v)
        if v is True:
            break
        time.sleep(1)
    c.call("Debugger.enable")
    proto = c.call("Runtime.evaluate", expression="Function.prototype")["result"]["objectId"]
    objs = c.call("Runtime.queryObjects", prototypeObjectId=proto)["objects"]["objectId"]
    finder = ("function(){var out=[];for(var i=0;i<this.length;i++){try{"
              "if(Function.prototype.toString.call(this[i]).indexOf('__TENCENT_CHAOS_VM')>=0)"
              "out.push(this[i])}catch(e){}}return out.slice(0,8)}")
    rr = c.call("Runtime.callFunctionOn", objectId=objs, functionDeclaration=finder,
                returnByValue=False)
    props = c.call("Runtime.getProperties", objectId=rr["result"]["objectId"], ownProperties=True)
    fns = [p["value"]["objectId"] for p in props.get("result", []) if p.get("name", "").isdigit()]
    bps = []
    for oid in fns:
        try:
            bps.append(c.call("Debugger.setBreakpointOnFunctionCall", objectId=oid).get("breakpointId"))
        except RuntimeError as e:
            if "already exists" not in str(e):
                raise
    print("breakpoints:", bps)
    # reset hook counters, then run getData under the breakpoints
    print("reset:", c.ev("(function(){window.__fc.fcc4=[];window.__fc.n=0;return 'ok'})()"))
    mid = c.send("Runtime.evaluate", expression="TDC.getData().length", returnByValue=True)
    blocks = []
    npauses = 0
    done = None
    end = time.time() + 240
    while time.time() < end:
        try:
            m = c.recv(1.0)
        except Exception:
            continue
        if m.get("id") == mid:
            done = m
            break
        if m.get("method") != "Debugger.paused":
            c.events.append(m)
            continue
        npauses += 1
        cf = m["params"]["callFrames"][0]
        hit = ""
        if npauses <= 3000:
            try:
                r = c.call("Debugger.evaluateOnCallFrame", callFrameId=cf["callFrameId"],
                           expression=ARGPROBE, returnByValue=True, silent=True)
                hit = r.get("result", {}).get("value") or ""
            except Exception:
                hit = ""
        if hit:
            blocks.append(json.loads(hit))
        c.call("Debugger.resume")
    print("pauses:", npauses, "cipher blocks:", len(blocks), "done:", bool(done))
    for b in bps:
        try:
            c.call("Debugger.removeBreakpoint", breakpointId=b)
        except Exception:
            pass
    if done:
        print("getData len:", done.get("result", {}).get("result", {}).get("value"))
    fcc = c.ev("window.__fc?window.__fc.fcc4:null")
    print("fromCharCode(4) calls:", len(fcc) if fcc else 0)
    out = {"blocks": blocks, "fcc": fcc,
           "tdc_len": done.get("result", {}).get("result", {}).get("value") if done else None}
    json.dump(out, open("pairs_live.json", "w"))
    print("wrote pairs_live.json")
    if fcc:
        print("first fcc:", fcc[:4])
    print("first blocks:", blocks[:4])


if __name__ == "__main__":
    main()
