// Probe tdc.js VM: run it in a vm sandbox with a logging Proxy window.
const vm = require('vm');
const fs = require('fs');
const path = require('path');

const src = fs.readFileSync(process.argv[2] || '../js/tdc.dec.js', 'utf8');
const log = [];
const seen = new Set();
const short = v => {
  try {
    if (typeof v === 'string') return JSON.stringify(v.slice(0, 60));
    if (typeof v === 'function') return '[fn]';
    if (v && typeof v === 'object') return '[obj ' + (v.constructor && v.constructor.name) + ']';
    return String(v);
  } catch (e) { return '?'; }
};

function makeFn(label, parent) {
  const f = function (...args) {
    log.push({ t: 'call', label, args: args.map(short) });
    if (label === 'window.document.createElement') {
      return makeFn('canvas', null);
    }
    return makeObj(label + '()');
  };
  return new Proxy(f, {
    get(t, p) {
      if (p === Symbol.toPrimitive) return () => '';
      if (p === 'toString') return () => '';
      if (p === 'length') return 0;
      if (p === 'prototype') return {};
      if (!(p in t)) t[p] = makeFn(label + '.' + String(p));
      return t[p];
    },
    apply(t, thisArg, args) { return t(...args); }
  });
}

function makeObj(label) {
  const target = {};
  return new Proxy(target, {
    get(t, p) {
      if (p === Symbol.toPrimitive) return () => '';
      if (p === Symbol.iterator) return undefined;
      if (p === 'toString') return () => '';
      if (p === 'valueOf') return () => 0;
      if (p === 'length') return 0;
      if (!(p in t)) {
        const key = label + '.' + String(p);
        if (!seen.has(key)) { seen.add(key); }
        t[p] = makeFn(key);
      }
      return t[p];
    },
    set(t, p, v) {
      log.push({ t: 'set', key: label + '.' + String(p), v: short(v) });
      t[p] = v; return true;
    }
  });
}

const win = makeObj('window');
const sandbox = {
  window: win,
  document: makeObj('document'),
  navigator: makeObj('navigator'),
  location: makeObj('location'),
  screen: makeObj('screen'),
  performance: makeObj('performance'),
  console: { log: (...a) => log.push({ t: 'log', a: a.map(short) }) },
  setTimeout: (f, ms) => { log.push({ t: 'setTimeout', ms }); return 0; },
  setInterval: () => 0,
  Date, Math, JSON, String, Number, Boolean, Array, Object, RegExp, Error,
  Function, parseInt, parseFloat, isNaN, encodeURIComponent, decodeURIComponent,
  escape, unescape, btoa: s => Buffer.from(s, 'binary').toString('base64'),
  atob: s => Buffer.from(s, 'base64').toString('binary'),
  Uint8Array, Uint16Array, Uint32Array, Int8Array, Int32Array, Float32Array, ArrayBuffer,
  Symbol, Promise, Map, Set, WeakMap, Proxy, Reflect, TypeError, RangeError,
};
sandbox.globalThis = sandbox;
sandbox.self = sandbox;

try {
  vm.createContext(sandbox);
  vm.runInContext(src, sandbox, { filename: 'tdc.js', timeout: 10000 });
  console.log('[load ok]');
  const w = sandbox.window;
  console.log('TDC keys:', w.TDC ? Object.keys(w.TDC) : null);
  console.log('window keys added:', Object.keys(w).filter(k => !k.startsWith('window.')).slice(0, 60));

  // Add a rich canvas-like document to allow getData later; first just probe.
  console.log('--- log first 120 ---');
  console.log(JSON.stringify(log.slice(0, 120), null, 1));
  console.log('--- distinct accessed keys ---');
  const keys = new Set(log.map(e => e.label || e.key).filter(Boolean));
  console.log([...keys].slice(0, 300).join('\n'));
} catch (e) {
  console.log('[load error]', e && e.stack || e);
  console.log('--- log tail ---');
  console.log(JSON.stringify(log.slice(-80), null, 1));
}
