# -*- coding: utf-8 -*-
"""Exact transcription of the old build's cipher, validated on real pairs.

Bytecode @9233..9560 (canonical old build):

    setlen 9; local 2..7
    local5 = 0; local6 = 0; local7 = 0            (sum)
    loop:
      if (sum == 84941944608) break               # 32 * delta
      local5 = local5 + ( (((local6<<4)^(local6>>>5)) + local6)
                          ^ (sum + key[sum&3] + C[sum&3]) )
      sum = sum + 2654435769
      local6 = local6 + ( (((local5<<4)^(local5>>>5)) + local5)
                          ^ (sum + key[(sum>>>11)&3] + C[(sum>>>11)&3]) )
    C = [197402, 1907983, 0, 0]                   # from the three-way branch

Evidence pairs: `calls` (161 plaintext blocks) vs the 4 base64 outputs
(624+432+216+16 = 1288 = 161 blocks).
"""
import json

M32 = 0xFFFFFFFF
DELTA = 0x9E3779B9
SUM_MAX = DELTA * 32
C_TABLE = [197402, 1907983, 0, 0]

K1 = [0x2a483108, 0x7c636e58, 0x614e5354, 0x5a57674d]
K2 = [0x4a685128, 0x563d4832, 0x614e5354, 0x54516147]


def i32(x):
    """JS ToInt32."""
    x &= M32
    return x - 0x100000000 if x & 0x80000000 else x


def u32(x):
    return x & M32


def round_f(v):
    return u32((u32(v << 4) ^ (v >> 5)) + v)


def idx_hi(s):
    """(sum >>> 11) & 3 with JS ToUint32 semantics (sum may exceed 2^32)."""
    return ((s & M32) >> 11) & 3


def enc_block(v0, v1, key, ctab=C_TABLE, rounds=32):
    s = 0
    for i in range(rounds):
        k = key[s & 3]
        v0 = u32(v0 + (round_f(v1) ^ u32(s + k + ctab[s & 3])))
        s = s + DELTA
        idx = idx_hi(s)
        v1 = u32(v1 + (round_f(v0) ^ u32(s + key[idx] + ctab[idx])))
    return v0, v1


def dec_block(v0, v1, key, ctab=C_TABLE, rounds=32):
    s = DELTA * rounds
    for i in range(rounds):
        idx = idx_hi(s)
        v1 = u32(v1 - (round_f(v0) ^ u32(s + key[idx] + ctab[idx])))
        s = s - DELTA
        v0 = u32(v0 - (round_f(v1) ^ u32(s + key[s & 3] + ctab[s & 3])))
    return v0, v1


def main():
    d = json.loads(open("stack_log.json", "rb").read().decode("utf-8", "replace"))
    A = d["A"]
    plain = [(c["v"][0], c["v"][1]) for c in A["calls"]]
    blob = b"".join(bytes.fromhex(e["inHex"]) for e in A["btoa"])
    ct = [(int.from_bytes(blob[i * 8:i * 8 + 4], "little"),
           int.from_bytes(blob[i * 8 + 4:i * 8 + 8], "little"))
          for i in range(len(blob) // 8)]
    print("pairs", len(plain), "blocks", len(ct))

    for kname, key in (("K1", K1), ("K2", K2)):
        for mode, fn in (("enc", enc_block), ("dec", dec_block)):
            for swap in (False, True):
                ok = 0
                bad = None
                for i, (p, c) in enumerate(zip(plain, ct)):
                    a = p if not swap else (p[1], p[0])
                    r = fn(a[0], a[1], key)
                    if not swap:
                        exp = c
                    else:
                        exp = (c[1], c[0])
                    if r == exp:
                        ok += 1
                    elif bad is None:
                        bad = (i, p, c, r)
                print("%s %s swap=%s -> %d/%d" % (kname, mode, swap, ok, len(plain)))
                if ok and bad is None:
                    print("   FULL MATCH")
                if 0 < ok < len(plain):
                    print("   first bad", bad)


if __name__ == "__main__":
    main()
