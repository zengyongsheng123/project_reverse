# -*- coding: utf-8 -*-
"""Disassemble a live-build bytecode range in canonical opcode names.

Usage: python disasm_live.py 9100 9460
"""
import json
import sys
from disasm_tdc import OPERANDS, NAMES
from translate_bc import load_map

BC = "../js/bytecode_live.json"


def main():
    lo = int(sys.argv[1]) if len(sys.argv) > 1 else 0
    hi = int(sys.argv[2]) if len(sys.argv) > 2 else lo + 200
    bc = json.load(open(BC))
    live2old = load_map()
    n = len(bc)
    # follow control flow from 0 so operand decoding is always in stride
    from collections import deque
    seen = {}
    q = deque([0])
    while q:
        pc = q.popleft()
        if not isinstance(pc, int) or pc in seen or pc < 0 or pc >= n:
            continue
        op = live2old.get(bc[pc])
        if op is None or OPERANDS.get(op) is None:
            seen[pc] = ("<bad>", [bc[pc]], pc + 1)
            continue
        cnt = OPERANDS[op]
        if cnt == -1:
            f, nup, narg = bc[pc + 1], bc[pc + 2], bc[pc + 3]
            end = pc + 4 + 2 * nup + narg
            seen[pc] = (NAMES.get(op), [f, nup, narg], end)
            q.append(f)
            q.append(end)
            continue
        ops = bc[pc + 1:pc + 1 + cnt]
        end = pc + 1 + cnt
        seen[pc] = (NAMES.get(op), ops, end)
        if op == 33:
            q.append(ops[0])
            continue
        q.append(end)
        if op in (63, 16):
            q.append(ops[0])
    for pc in sorted(seen):
        if lo <= pc < hi:
            name, ops, end = seen[pc]
            print("%6d  %-10s %s" % (pc, name, " ".join(str(x) for x in ops)))


if __name__ == "__main__":
    main()
