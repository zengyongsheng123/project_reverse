# -*- coding: utf-8 -*-
"""Scan a Chrome .heapsnapshot for numeric JS arrays of length 4/8 that could
be the TDC XTEA key, then verify each candidate against the captured samples.

Usage:  python heap_arrays.py heap.heapsnapshot [out.json]
"""
import json
import sys

NF = 6   # node fields
EF = 3   # edge fields


def main():
    path = sys.argv[1] if len(sys.argv) > 1 else "../heap.heapsnapshot"
    out = sys.argv[2] if len(sys.argv) > 2 else "heap_key_candidates.json"
    d = json.load(open(path, encoding="utf-8"))
    nodes, edges, strings = d["nodes"], d["edges"], d["strings"]

    n_nodes = len(nodes) // NF
    prefix = [0] * (n_nodes + 1)
    acc = 0
    for i in range(n_nodes):
        prefix[i] = acc
        acc += nodes[i * NF + 4]
    prefix[n_nodes] = acc

    found = {}
    scanned = 0
    for i in range(n_nodes):
        t = nodes[i * NF]
        # 1 = array (internal), 3 = object (JS Array, name "Array")
        if t != 1 and t != 3:
            continue
        name = strings[nodes[i * NF + 1]]
        if t == 3 and name != "Array":
            continue
        scanned += 1
        e0, ec = prefix[i], nodes[i * NF + 4]
        if ec < 4 or ec > 16:
            continue
        vals = {}
        ok = True
        for e in range(e0, e0 + ec):
            et = edges[e * EF]
            enm = edges[e * EF + 1]
            to = edges[e * EF + 2]
            if et not in (1, 2):      # element / property
                continue
            idx = None
            if et == 1:
                idx = enm
            else:
                s = strings[enm]
                if s.isdigit():
                    idx = int(s)
            if idx is None:
                continue
            nt = nodes[to]
            nn = strings[nodes[to + 1]]
            if nt == 7:               # "number" node: name is the decimal value
                try:
                    vals[idx] = int(float(nn)) if e_dot(nn) else int(nn)
                except Exception:
                    ok = False
                    break
            elif nt == 13:            # bigint
                try:
                    vals[idx] = int(nn.rstrip("n"))
                except Exception:
                    ok = False
                    break
            else:
                ok = False
                break
        if not ok or not vals:
            continue
        n = max(vals) + 1
        if n not in (4, 8) or len(vals) != n:
            continue
        key = tuple(vals[k] & 0xFFFFFFFF for k in range(n))
        found.setdefault(key, 0)
        found[key] += 1

    print("array-like nodes scanned", scanned, "distinct numeric 4/8 arrays", len(found))
    json.dump({str(list(k)): v for k, v in found.items()}, open(out, "w", encoding="utf-8"))
    print("written", out)


def e_dot(s):
    return ("." in s) or ("e" in s.lower())


if __name__ == "__main__":
    main()
