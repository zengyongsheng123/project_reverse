# -*- coding: utf-8 -*-
"""Use raw CDP Runtime.queryObjects to enumerate every Array instance in each
execution context of the captcha page, then dump numeric 4-element arrays with
at least two "big" (>=2^20) values -- candidate XTEA key arrays.

Runtime.queryObjects needs a prototype objectId, which is the reliable route;
the console-only queryObjects() helper is not injected with includeCommandLineAPI
in this Chrome build.
"""
import json, sys, time, http.client
import websocket

PORT = 9222

FILTER = r"""
function () {
  var roots = this, out = [], n = roots.length >>> 0;
  for (var i = 0; i < n; i++) {
    var a;
    try { a = roots[i]; } catch (e) { continue; }
    if (!a || typeof a !== 'object') continue;
    if (a.length !== 4) continue;
    var vals = [], ok = true, big = 0;
    for (var k = 0; k < 4; k++) {
      var v;
      try { v = a[k]; } catch (e) { ok = false; break; }
      if (typeof v !== 'number' || !isFinite(v)) { ok = false; break; }
      if (Math.abs(v) >= 1048576) big++;
      vals.push(v >>> 0);
    }
    if (!ok || big < 2) continue;
    out.push(vals);
    if (out.length > 4000) break;
  }
  return JSON.stringify(out);
}
"""


def targets():
    conn = http.client.HTTPConnection("127.0.0.1", PORT, timeout=5)
    conn.request("GET", "/json")
    return json.loads(conn.getresponse().read())


class CDP:
    def __init__(self, url):
        self.ws = websocket.create_connection(url, timeout=25, suppress_origin=True)
        self.i = 0
        self.events = []

    def call(self, method, **params):
        self.i += 1
        mid = self.i
        self.ws.send(json.dumps({"id": mid, "method": method, "params": params}))
        while True:
            msg = json.loads(self.ws.recv())
            if msg.get("id") == mid:
                if "error" in msg:
                    raise RuntimeError("%s -> %s" % (method, msg["error"]))
                return msg.get("result", {})
            if "method" in msg:
                self.events.append(msg)


def main():
    ts = [t for t in targets() if t.get("type") in ("page", "iframe", "webview")]
    pick = None
    for t in ts:
        if "cloud.tencent.com" in t.get("url", "") and t.get("type") == "page":
            pick = t
            break
    if not pick:
        raise SystemExit("page not found")
    print("using", pick.get("url", "")[:100])
    c = CDP(pick["webSocketDebuggerUrl"])
    c.call("Runtime.enable")
    time.sleep(0.8)
    try:
        c.ws.settimeout(0.3)
        while True:
            msg = json.loads(c.ws.recv())
            if "method" in msg:
                c.events.append(msg)
    except Exception:
        pass
    c.ws.settimeout(25)

    ctxs = {}
    for e in c.events:
        if e.get("method") == "Runtime.executionContextCreated":
            ctx = e["params"]["context"]
            aux = ctx.get("auxData", {})
            if aux.get("isDefault"):
                ctxs.setdefault(ctx["id"], (ctx.get("origin", ""), aux.get("frameId", "")))
    print("default contexts:", ctxs)

    all_found = {}
    for cid, info in ctxs.items():
        try:
            r = c.call("Runtime.evaluate", expression="location.href", contextId=cid, returnByValue=True)
            href = r.get("result", {}).get("value")
        except Exception as ex:
            href = "ERR %s" % ex
        print("ctx", cid, info[0], "->", str(href)[:100])
        try:
            proto = c.call("Runtime.evaluate", expression="Array.prototype", contextId=cid)
            pid = proto.get("result", {}).get("objectId")
            if not pid:
                print("   no Array.prototype objectId")
                continue
            q = c.call("Runtime.queryObjects", prototypeObjectId=pid)
            qid = q.get("objects", {}).get("objectId")
            if not qid:
                print("   queryObjects returned nothing", q)
                continue
            n = c.call("Runtime.callFunctionOn", objectId=qid, functionDeclaration="function(){return this.length}",
                       returnByValue=True).get("result", {}).get("value")
            print("   Array instances:", n)
            out = c.call("Runtime.callFunctionOn", objectId=qid, functionDeclaration=FILTER, returnByValue=True)
            v = out.get("result", {}).get("value")
            arrs = json.loads(v) if isinstance(v, str) else []
            print("   numeric 4-arrays with >=2 big:", len(arrs))
            for a in arrs[:80]:
                print("     ", [hex(x) for x in a], a)
            if arrs:
                all_found[str(cid)] = arrs
        except Exception as ex:
            print("   ERR", ex)

    if all_found:
        json.dump(all_found, open("live_key_candidates.json", "w"))
        print("written live_key_candidates.json")
    else:
        print("no candidates")


if __name__ == "__main__":
    main()
