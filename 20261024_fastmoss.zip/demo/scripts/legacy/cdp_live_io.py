# -*- coding: utf-8 -*-
"""Clean-room capture: install the cipher hooks, reload, open the widget,
and read the call log from the same build.

The cipher is invoked through Function.prototype.apply as f([w0,w1], K) by
the VM's callm opcode (proven by stack_log.json).  Hooking apply therefore
yields, for one single tdc.js build:

  * plaintext block      args[0] = [w0, w1]
  * ciphertext word      String.fromCharCode(b0,b1,b2,b3)
  * a reference to the cipher function (for a later breakpoint/scope read)

Usage: python cdp_live_io.py [--reload] [--click x y]
"""
import http.client
import json
import sys
import time

import websocket

PORT = 9222

HOOK = r"""
(function(){
  if (window.__io) return;
  var D = window.__io = {calls: [], fcc4: [], btoa: [], fns: [], loc: location.href, t0: performance.now()};
  var oa = Function.prototype.apply;
  Function.prototype.apply = function(self, args){
    var r = oa.call(this, self, args);
    try{
      if (args && typeof args === 'object' && args.length === 2 && args[0] &&
          typeof args[0] === 'object' && args[0].length === 2 &&
          typeof args[0][0] === 'number' && typeof args[0][1] === 'number' &&
          D.calls.length < 5000){
        var a1 = args[1];
        D.calls.push({p: [args[0][0] >>> 0, args[0][1] >>> 0],
                      a1t: Object.prototype.toString.call(a1),
                      a1len: (a1 && typeof a1 === 'object') ? a1.length : -1,
                      t: Math.round(performance.now())});
        if (D.fns.length < 4 && typeof this === 'function') D.fns.push(this);
      }
    }catch(e){}
    return r;
  };
  var ofc = String.fromCharCode;
  String.fromCharCode = function(){
    var out = ofc.apply(String, arguments);
    try{
      if (arguments.length === 4 && D.fcc4.length < 5000)
        D.fcc4.push([arguments[0] & 255, arguments[1] & 255, arguments[2] & 255, arguments[3] & 255]);
    }catch(e){}
    return out;
  };
  var ob = window.btoa;
  window.btoa = function(s){
    var out = ob.apply(window, arguments);
    try{
      if (D.btoa.length < 8 && typeof s === 'string' && s.length > 100){
        var h = '';
        for (var i = 0; i < s.length && i < 40000; i++){
          var c = s.charCodeAt(i) & 255;
          h += (c < 16 ? '0' : '') + c.toString(16);
        }
        D.btoa.push({len: s.length, hex: h});
      }
    }catch(e){}
    return out;
  };
})();
"""


def targets():
    c = http.client.HTTPConnection("127.0.0.1", PORT, timeout=5)
    c.request("GET", "/json")
    return json.loads(c.getresponse().read())


class CDP:
    def __init__(self, url):
        self.ws = websocket.create_connection(url, timeout=30, suppress_origin=True)
        self.i = 0
        self.ctx = []
        self.events = []

    def send(self, method, **p):
        self.i += 1
        self.ws.send(json.dumps({"id": self.i, "method": method, "params": p}))
        return self.i

    def _drain(self, mid, timeout=40):
        self.ws.settimeout(timeout)
        while True:
            m = json.loads(self.ws.recv())
            if m.get("id") == mid:
                if "error" in m:
                    raise RuntimeError("%s -> %s" % (m.get("method"), m["error"]))
                return m.get("result", {})
            if "method" in m:
                if m["method"] == "Runtime.executionContextCreated":
                    self.ctx.append(m["params"]["context"])
                self.events.append(m)

    def call(self, method, **p):
        return self._drain(self.send(method, **p))

    def ev(self, expr, ctx=None, by_value=True):
        p = {"expression": expr, "returnByValue": by_value, "awaitPromise": True}
        if ctx is not None:
            p["contextId"] = ctx
        r = self.call("Runtime.evaluate", **p)
        if r.get("exceptionDetails"):
            return {"__exc": str(r["exceptionDetails"])[:300]}
        return r.get("result", {}).get("value")

    def pump(self, sec):
        end = time.time() + sec
        self.ws.settimeout(0.3)
        while time.time() < end:
            try:
                m = json.loads(self.ws.recv())
            except Exception:
                continue
            if "method" in m:
                if m["method"] == "Runtime.executionContextCreated":
                    self.ctx.append(m["params"]["context"])
                self.events.append(m)

    def main_ctx(self):
        best = None
        for c in self.ctx:
            if c.get("auxData", {}).get("isDefault") and \
               "cloud.tencent.com" in (c.get("origin") or ""):
                best = c["id"]
        return best


def main():
    args = sys.argv[1:]
    reload = "--reload" in args
    click = None
    if "--click" in args:
        i = args.index("--click")
        click = (float(args[i + 1]), float(args[i + 2]))

    pg = [t for t in targets() if t.get("type") == "page"][0]
    c = CDP(pg["webSocketDebuggerUrl"])
    c.call("Page.enable")
    c.call("Runtime.enable")
    c.call("Page.addScriptToEvaluateOnNewDocument", source=HOOK)
    print("script installed on new document")
    if reload:
        c.call("Page.reload", ignoreCache=False)
        print("reloading")
        c.pump(5.0)
    else:
        c.ev(HOOK)
        c.pump(0.5)
    cid = c.main_ctx()
    print("main ctx", cid)
    print("state", json.dumps(c.ev("(function(){return {href:location.href, io:!!window.__io, "
                                   "calls:(window.__io?__io.calls.length:-1)}})()", cid), ensure_ascii=False))
    if click:
        x, y = click
        for typ, extra in (("mouseMoved", {}), ("mousePressed", {"button": "left", "clickCount": 1}),
                           ("mouseReleased", {"button": "left", "clickCount": 1})):
            c.call("Input.dispatchMouseEvent", type=typ, x=x, y=y, **extra)
            time.sleep(0.08)
        print("clicked", x, y)
        c.pump(5.0)
        cid = c.main_ctx() or cid
        st = c.ev("(function(){var D=window.__io;return {calls:D.calls.length,fcc4:D.fcc4.length,btoa:D.btoa.length,"
                  "fns:D.fns.length,p0:D.calls.slice(0,3)}})()", cid)
        print("after click", json.dumps(st, ensure_ascii=False)[:600])
        out = {"ctx": cid, "state": st,
               "calls": c.ev("window.__io?__io.calls:null", cid),
               "fcc4": c.ev("window.__io?__io.fcc4:null", cid),
               "btoa": c.ev("window.__io?__io.btoa:null", cid)}
        json.dump(out, open("live_io.json", "w"), ensure_ascii=False)
        print("wrote live_io.json")


if __name__ == "__main__":
    main()
