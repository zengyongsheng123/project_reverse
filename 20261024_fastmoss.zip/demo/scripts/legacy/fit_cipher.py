# -*- coding: utf-8 -*-
"""Offline fit: given candidate key arrays, search XTEA-shaped models against
the captured (plaintext pair -> ciphertext block) samples.

Usage:
    python fit_cipher.py key_candidates.json        # {"[w0,w1,w2,w3]": "label"}
    python fit_cipher.py --key 0x...,0x...,0x...,0x...

A hit requires the candidate key to reproduce block 0 and blocks 5/77/160.
"""
import itertools
import json
import sys

DELTA = 0x9E3779B9
M = 0xFFFFFFFF
CS = [0, 197402, 1907983]


def load_samples(path="stack_log.json"):
    d = json.load(open(path, encoding="utf-8"))
    pairs = [(e["v"][0] & M, e["v"][1] & M) for e in d["A"]["calls"]]
    ct = b"".join(bytes.fromhex(e["inHex"]) for e in d["A"]["btoa"])
    blocks = [ct[i:i + 8] for i in range(0, len(ct) - 7, 8)]
    return pairs, blocks


def enc(v0, v1, k, rounds, pre, post, extra, sh0, sh1, swap):
    s = 0
    for _ in range(rounds):
        if pre:
            s = (s + DELTA) & M
        a, b = (v1, v0) if swap else (v0, v1)
        a = (a + ((((((b << 4) & M) ^ (b >> 5)) + b) & M) ^ ((s + k[(s >> sh0) & 3]) & M))) & M
        if post:
            s = (s + DELTA) & M
        u, w = (a, b) if swap else (a, b)
        v0, v1 = a, b
        # second half always updates the other word
        v1 = (v1 + ((((((v0 << 4) & M) ^ (v0 >> 5)) + v0) & M) ^ ((s + k[(s >> sh1) & 3]) & M))) & M
        if extra:
            s = (s + DELTA) & M
    return v0, v1


def le(a, b):
    return (a & M).to_bytes(4, "little") + (b & M).to_bytes(4, "little")


def variants(k):
    for rounds in (16, 32, 33, 64):
        for pre in (0, 1):
            for post in (0, 1):
                for extra in (0, 1):
                    for sh0 in (0, 11):
                        for sh1 in (0, 11):
                            for combo in itertools.product(range(3), repeat=4):
                                kk = [(k[i] + CS[combo[i]]) & M for i in range(4)]
                                for perm in ((0, 1, 2, 3), (3, 2, 1, 0)):
                                    kp = [kk[i] for i in perm]
                                    yield (rounds, pre, post, extra, sh0, sh1, combo, perm, kp)


def check(k, pairs, blocks, idx_probe=(0, 5, 77, 78, 160)):
    for rounds, pre, post, extra, sh0, sh1, combo, perm, kk in variants(k):
        try:
            if le(*enc(pairs[0][0], pairs[0][1], kk, rounds, pre, post, extra, sh0, sh1, 0)) != blocks[0]:
                continue
            if all(le(*enc(pairs[i][0], pairs[i][1], kk, rounds, pre, post, extra, sh0, sh1, 0)) == blocks[i]
                   for i in idx_probe):
                return (rounds, pre, post, extra, sh0, sh1, combo, perm), kk
        except Exception:
            pass
    return None


def main():
    pairs, blocks = load_samples()
    cands = []
    if len(sys.argv) > 2 and sys.argv[1] == "--key":
        cands.append(("cli", [int(x, 16) if x.startswith("0x") else int(x) for x in sys.argv[2].split(",")]))
    else:
        path = sys.argv[1] if len(sys.argv) > 1 else "key_candidates.json"
        raw = json.load(open(path, encoding="utf-8"))
        if isinstance(raw, dict):
            for k, label in raw.items():
                try:
                    key = json.loads(k)
                except Exception:
                    continue
                cands.append((label, key))
        else:
            for i, key in enumerate(raw):
                cands.append(("cand%d" % i, key))
    print("candidates", len(cands))
    for label, key in cands:
        key = [int(x) & M for x in key]
        if len(key) == 8:
            for part in (key[:4], key[4:]):
                hit = check(part, pairs, blocks)
                if hit:
                    print("HIT", label, [hex(x) for x in part], hit[0], [hex(x) for x in hit[1]])
                    return
            continue
        if len(key) != 4:
            continue
        hit = check(key, pairs, blocks)
        if hit:
            print("HIT", label, [hex(x) for x in key], hit[0], [hex(x) for x in hit[1]])
            return
        print("  miss", label, [hex(x) for x in key])
    print("no hit")


if __name__ == "__main__":
    main()
