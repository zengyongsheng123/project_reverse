# -*- coding: utf-8 -*-
"""Fit the tdc block cipher against real input/output pairs.

Evidence (old-build session, stack_log.json):
  * `calls`: 161 sequential calls y(v0, v1)  -> 161 8-byte blocks
  * `A.btoa`: 4 base64 outputs, 624+432+216+16 = 1288 bytes = 161 blocks
  * `A.fcc4`: String.fromCharCode(4 bytes) per output word, little-endian

So plaintext block i = calls[i].v and ciphertext block i = words of the
concatenated btoa inputs.  Brute-force the structural variants against
block 0 and report the ones that reproduce it.
"""
import base64
import itertools
import json

M32 = 0xFFFFFFFF
DELTA = 0x9E3779B9

K1 = [0x2a483108, 0x7c636e58, 0x614e5354, 0x5a57674d]
K2 = [0x4a685128, 0x563d4832, 0x614e5354, 0x54516147]
C_OLD = (197402, 1907983)


def u(x):
    return x & M32


def le_words(b, off):
    return int.from_bytes(b[off:off + 4], "little"), int.from_bytes(b[off + 4:off + 8], "little")


def f(x, s, k, c, mode):
    """TEA round function.  mode selects where c enters."""
    r = u(((u(x << 4) ^ (x >> 5)) + x))
    if mode == "key":      # (sum + key + c)
        t = u(u(s + k) + c)
    elif mode == "round":  # (sum + key) ^ ... then +c?  -> ((round) + c) ^ (sum+key)
        t = u(s + k)
        return u((r + c) ^ t)
    elif mode == "none":
        t = u(s + k)
    else:
        raise ValueError(mode)
    return u(r ^ t)


def encrypt(p0, p1, ka, kb, ca, cb, idx_mode, cmode, swap):
    v0, v1 = p0, p1
    s = 0
    for _ in range(32):
        i0 = s & 3
        k = ka[i0]
        v0 = u(v0 + f(v1, s, k, ca, cmode))
        s = u(s + DELTA)
        if idx_mode == "shr11":
            i1 = (s >> 11) & 3
        else:
            i1 = s & 3
        v1 = u(v1 + f(v0, s, kb[i1], cb, cmode))
    return v1, v0 if swap else (v0, v1)


def decrypt(c0, c1, ka, kb, ca, cb, idx_mode, cmode, swap):
    v0, v1 = c0, c1
    s = u(DELTA * 32)
    for _ in range(32):
        if idx_mode == "shr11":
            i1 = (s >> 11) & 3
        else:
            i1 = s & 3
        v1 = u(v1 - f(v0, s, kb[i1], cb, cmode))
        s = u(s - DELTA)
        v0 = u(v0 - f(v1, s, ka[s & 3], ca, cmode))
    return v1, v0 if swap else (v0, v1)


def main():
    d = json.loads(open("stack_log.json", "rb").read().decode("utf-8", "replace"))
    A = d["A"]
    calls = A["calls"]
    plain = [(c["v"][0], c["v"][1]) for c in calls]
    blob = b"".join(bytes.fromhex(e["inHex"]) for e in A["btoa"])
    print("blocks: plain", len(plain), "cipher bytes", len(blob), "=", len(blob) // 8)
    ct = [le_words(blob, i * 8) for i in range(len(blob) // 8)]
    print("cipher[0] 0x%08x 0x%08x" % ct[0])
    p0, p1 = plain[0]
    c0, c1 = ct[0]
    pc0, pc1 = bytes([p0 & 255, (p0 >> 8) & 255, (p0 >> 16) & 255, (p0 >> 24) & 255]), \
               bytes([p1 & 255, (p1 >> 8) & 255, (p1 >> 16) & 255, (p1 >> 24) & 255])
    print("plain[0] LE bytes", pc0, pc1)
    print("plain[1] LE bytes", plain[1])

    hits = []
    for keyset in ("K1K2", "K2K1", "K1K1", "K2K2"):
        ka, kb = {"K1K2": (K1, K2), "K2K1": (K2, K1), "K1K1": (K1, K1), "K2K2": (K2, K2)}[keyset]
        for idx_mode in ("and3", "shr11"):
            for cmode in ("key", "round", "none"):
                for cvals in (C_OLD, (0, 0), (C_OLD[1], C_OLD[0])):
                    for swap in (False, True):
                        for fn, name in ((encrypt, "enc"), (decrypt, "dec")):
                            a = fn(p0, p1, ka, kb, cvals[0], cvals[1], idx_mode, cmode, swap)
                            if a == (c0, c1) or a == (c1, c0):
                                hits.append((name, keyset, idx_mode, cmode, cvals, swap, a))
    print("hits:", len(hits))
    for h in hits[:20]:
        print(" ", h)


if __name__ == "__main__":
    main()
