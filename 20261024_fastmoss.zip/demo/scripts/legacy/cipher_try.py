# -*- coding: utf-8 -*-
"""Offline validation of the tdc XTEA-like cipher.

Keys recovered from the old build's bytecode (derive_keys.py old):
  K1 = [0x2a483108, 0x7c636e58, 0x614e5354, 0x5a57674d]
  K2 = [0x4a685128, 0x563d4832, 0x614e5354, 0x54516147]
Cipher constants seen in the old build: 197402 and 1907983.

We take a real ciphertext (verify collect / btoa input) and brute-force the
structural variants, looking for printable plaintext.  A wrong key gives noise,
so a readable head is strong evidence.
"""
import base64
import json
import urllib.parse

DELTA = 0x9E3779B9
M32 = 0xFFFFFFFF

K1 = [0x2a483108, 0x7c636e58, 0x614e5354, 0x5a57674d]
K2 = [0x4a685128, 0x563d4832, 0x614e5354, 0x54516147]
C_OLD = (197402, 1907983)


def u32(x):
    return x & M32


def xtea_dec_block(v0, v1, ka, kb, ca, cb, ib, ksel):
    """Decrypt one 8-byte block; ksel picks how the second half indexes keys."""
    s = u32(DELTA * 32)
    for _ in range(32):
        if ksel == "shr11":
            kb_i = (s >> 11) & 3
        else:
            kb_i = s & 3
        v1 = u32(v1 - (u32(((u32(v0 << 4) ^ (v0 >> 5)) + v0) ^ u32(s + kb[kb_i] + cb))))
        s = u32(s - DELTA)
        v0 = u32(v0 - (u32(((u32(v1 << 4) ^ (v1 >> 5)) + v1) ^ u32(s + ka[s & 3] + ca))))
    return v0, v1


def le(b, off):
    return int.from_bytes(b[off:off + 4], "little")


def dec_all(data, ka, kb, ca, cb, ib, ksel, byteorder="little"):
    out = bytearray()
    for off in range(0, len(data) - 7, 8):
        if byteorder == "little":
            v0, v1 = le(data, off), le(data, off + 4)
        else:
            v0, v1 = int.from_bytes(data[off:off + 4], "big"), int.from_bytes(data[off + 4:off + 8], "big")
        v0, v1 = xtea_dec_block(v0, v1, ka, kb, ca, cb, ib, ksel)
        if byteorder == "little":
            out += v0.to_bytes(4, "little") + v1.to_bytes(4, "little")
        else:
            out += v0.to_bytes(4, "big") + v1.to_bytes(4, "big")
    return bytes(out)


def printable(b):
    n = sum(1 for c in b[:64] if 9 <= c < 127)
    return n


def samples():
    cv = json.load(open("captured_verify.json"))
    res = []
    for item in cv if isinstance(cv, list) else [cv]:
        body = item.get("body", "")
        q = urllib.parse.parse_qs(body)
        if "collect" in q:
            v = q["collect"][0]
            res.append(("verify.collect", base64.b64decode(v + "=" * ((4 - len(v) % 4) % 4))))
    d = json.loads(open("stack_log.json", "rb").read().decode("utf-8", "replace"))
    for i, e in enumerate(d["A"]["btoa"]):
        res.append(("btoa[%d]" % i, bytes.fromhex(e["inHex"])))
    return res


def main():
    ss = samples()
    for name, data in ss:
        print("=== %s len=%d head=%s" % (name, len(data), data[:16].hex()))
    best = []
    for name, data in ss:
        for bo in ("little", "big"):
            for ksel in ("shr11", "and3"):
                for keyset in ("K1K2", "K2K1", "K1K1", "K2K2"):
                    ka, kb = {"K1K2": (K1, K2), "K2K1": (K2, K1),
                              "K1K1": (K1, K1), "K2K2": (K2, K2)}[keyset]
                    for cconst in ("both", "first", "second", "none"):
                        ca, cb = {
                            "both": C_OLD, "first": (C_OLD[0], 0),
                            "second": (0, C_OLD[1]), "none": (0, 0),
                        }[cconst]
                        out = dec_all(data, ka, kb, ca, cb, 0, ksel, bo)
                        sc = printable(out)
                        best.append((sc, name, bo, ksel, keyset, cconst, out[:24]))
    best.sort(reverse=True)
    for sc, name, bo, ksel, keyset, cconst, head in best[:15]:
        print("%2d/64 %-14s %-6s %-5s %-5s %-6s %s | %r"
              % (sc, name, bo, ksel, keyset, cconst, head.hex(), head))


if __name__ == "__main__":
    main()
