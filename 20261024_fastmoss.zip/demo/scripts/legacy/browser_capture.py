# -*- coding: utf-8 -*-
"""Reopen the demo captcha, drag it, and capture the verify request body + TDC outputs."""
import json, time, math, sys, http.client
import websocket

PORT = 9222
HOOK = r"""
(function(){
  if (window.__capHooked) return;
  window.__capHooked = true;
  window.__capReq = [];
  var oOpen = XMLHttpRequest.prototype.open, oSend = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open = function(m,u){ this.__u=String(u); this.__m=m; return oOpen.apply(this,arguments); };
  XMLHttpRequest.prototype.send = function(b){
    try { if (this.__u && this.__u.indexOf('cap_union_new_verify')!==-1) window.__capReq.push({url:this.__u, body:String(b), t:Date.now()}); } catch(e){}
    return oSend.apply(this, arguments);
  };
})();
"""

def page_ws():
    conn = http.client.HTTPConnection("127.0.0.1", PORT, timeout=5)
    conn.request("GET", "/json")
    for t in json.loads(conn.getresponse().read()):
        if t.get("type") == "page" and "cloud.tencent.com" in t.get("url", ""):
            return t["webSocketDebuggerUrl"]
    raise SystemExit("page not found")

class CDP:
    def __init__(self):
        self.ws = websocket.create_connection(page_ws(), timeout=15, suppress_origin=True)
        self.i = 0
    def call(self, method, **params):
        self.i += 1
        self.ws.send(json.dumps({"id": self.i, "method": method, "params": params}))
        while True:
            msg = json.loads(self.ws.recv())
            if msg.get("id") == self.i:
                if "error" in msg: raise RuntimeError(msg["error"])
                return msg.get("result", {})
    def ev(self, expr):
        r = self.call("Runtime.evaluate", expression=expr, returnByValue=True, awaitPromise=True)
        return r.get("result", {}).get("value")
    def mouse(self, typ, x, y, buttons=0, click=True):
        self.call("Input.dispatchMouseEvent", type=typ, x=x, y=y,
                  button="left" if buttons or typ in ("mousePressed","mouseReleased") else "none",
                  buttons=buttons, clickCount=1 if click else 0, pointerType="mouse")

def drag(c, dist, steps=28):
    r = c.ev("(()=>{const b=document.querySelector('.tencent-captcha-dy__slider-block');if(!b)return null;const r=b.getBoundingClientRect();return [r.x+r.width/2,r.y+r.height/2];})()")
    if not r: raise SystemExit("no slider")
    x0, y0 = r
    c.mouse("mouseMoved", x0, y0, 0, False)
    time.sleep(0.05)
    c.mouse("mousePressed", x0, y0, 1, True)
    for k in range(1, steps + 1):
        p = k / steps
        e = 1 - (1 - p) ** 3
        time.sleep(0.012)
        c.mouse("mouseMoved", x0 + dist * e, y0 + math.sin(p * math.pi) * 1.2, 1, False)
    time.sleep(0.12)
    c.mouse("mouseReleased", x0 + dist, y0, 0, True)

def main():
    dist = float(sys.argv[1]) if len(sys.argv) > 1 else 150
    c = CDP()
    c.ev(HOOK)
    # click first 立即体验 (slider demo)
    btns = c.ev("[...document.querySelectorAll('a.tpm-btn')].filter(e=>e.textContent.trim()==='立即体验').map(e=>{const r=e.getBoundingClientRect();return [r.x+r.width/2,r.y+r.height/2];})")
    print("buttons", btns)
    bx, by = btns[0]
    c.mouse("mouseMoved", bx, by, 0, False)
    time.sleep(0.05)
    c.mouse("mousePressed", bx, by, 1, True)
    time.sleep(0.05)
    c.mouse("mouseReleased", bx, by, 0, True)
    time.sleep(2.0)
    vis = c.ev("(()=>{const b=document.querySelector('.tencent-captcha-dy__slider-block');if(!b)return null;const r=b.getBoundingClientRect();return [r.x,r.y,r.width,r.height,document.querySelector('#tCaptchaDyContent').getBoundingClientRect().x];})()")
    print("slider state", vis)
    if not vis or vis[4] < 0:
        print("dialog not visible; dump html", c.ev("document.querySelector('#tCaptchaDyContent')?.outerHTML.slice(0,200)"))
    # capture prehandle config from perf/network is separate; drag
    drag(c, dist)
    time.sleep(2.5)
    reqs = c.ev("window.__capReq || []")
    print("captured", len(reqs))
    if reqs:
        body = reqs[-1]["body"]
        json.dump(reqs, open("captured_verify.json", "w"), ensure_ascii=False, indent=1)
        print(body[:300], "...")
        print("len", len(body))
    state = c.ev("document.querySelector('.tencent-captcha-dy__header-text')?.textContent")
    print("state", state)
    print("TDC len", c.ev("window.TDC ? String(window.TDC.getData()).length : null"))
    print("TDC info", c.ev("window.TDC ? JSON.stringify(window.TDC.getInfo()).slice(0,80) : null"))

if __name__ == "__main__":
    main()
