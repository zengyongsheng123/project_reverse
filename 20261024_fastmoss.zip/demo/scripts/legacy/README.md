# scripts/legacy —— 历史一次性探针归档

2026-10-24 整理时，把已经被后续路线取代、但可能还想翻看的脚本挪到这里。
**主线流程不依赖本目录**；`scripts/` 顶层只保留 README §2 列出的工具。

- 本目录（`legacy/`）：一次性实验脚本、hook 注入脚本（`*_hook.js`、`hook_*.js`）、
  早期断点/堆/符号执行探针。
- `legacy/data/`：这些脚本产生的 JSON/日志/BIN 转储（`capture_*`、`deep_*_log`、
  `tramp_*`、`fcc_codes.json`、`live_io*.json` 等）。要重跑实验时按脚本里的
  输出文件名放回 `scripts/` 即可。

仍在用的工具（不要挪）：`derive_build.py`、`derive_key_table.py`、`disasm_tdc.py`、
`translate_bc.py`、`map_opcodes.py`、`extract_bc.py`、`extract_eks.py`、
`extract_build_const.py`、`fit_cur3.py`（`derive_build` 的 live 采样依赖）、
`instrument_eks_init.py`、`instrument_collect_env.py`、`verify_once.py`、
`widget_drag_oracle.py`、`real_event_capture.py`、`widget_probe*.py`、
`probe.py`、`slider_solver.py`、`fresh_session.py`、`sample_page.py`、
`ft_probe.py`、`fetch_live_build.py`、`seed_probe.py`、`setdata_probe.py`、
`script_probe.py`、`disasm_any.py`、`capture_full.py`、`live_check*.py`、
`walk_live.py`、`collect_samples.py`（⛔ 不做批量取样的边界见 README §7）、
`test_verify.py`（仅历史参考）。
