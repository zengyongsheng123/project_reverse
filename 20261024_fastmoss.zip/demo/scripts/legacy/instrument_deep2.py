# -*- coding: utf-8 -*-
"""Phase-gated capture around window.TDC.getData().

The previous run (instrument_deep.py) showed the page's own SDKs (Aegis/Beacon)
generate so much traffic that the capture buffers filled up *before* TDC ran.
This version records nothing until `__dpArm()` is called, and does two phases:

    phase 1: arm -> click 立即体验 -> wait for window.TDC   (payload built at click?)
    phase 2: arm -> TDC.getData()                          (payload built at getData?)

Hooks (installed at document start and again after load):
  charCodeAt / codePointAt : receivers >= 8 chars stored verbatim,
                             runs of 1-char receivers concatenated,
                             receiver-length histogram
  fromCharCode             : outputs
  JSON.stringify           : strings >= 8 chars
  btoa / atob              : inputs and outputs
  TextEncoder.encode       : input string
  escape/unescape          : input/output strings

Run:  python instrument_deep2.py
Out:  deep2_log.json
"""
import json, time, http.client
import websocket

PORT = 9222

HOOK = r"""
(function(){
  if (window.__dp) return 'already';
  var D = window.__dp = {
    rec: false,
    strs: [], cc: [], runs: [], fcc: [], json: [], btoa: [], atob: [],
    te: [], esc: [], join: [], hist: {}, counts: {}, seen: {}, cur: '',
    curLen: 0, phase: 0, t0: 0
  };
  var MAX = 600, MAX_RUN = 120, MAX_RUNLEN = 20000;
  function now(){ return Math.round(performance.now() - D.t0); }

  function flushRun(){
    if (D.curLen > 0 && D.runs.length < MAX_RUN)
      D.runs.push({len: D.curLen, data: D.cur.slice(0, MAX_RUNLEN)});
    D.cur = ''; D.curLen = 0;
  }
  function bump(k){ D.counts[k] = (D.counts[k]||0)+1; }
  function keep(list, key, len, data){
    if (!D.rec || list.length >= MAX) return;
    if (D.seen[key]) return;
    D.seen[key] = 1;
    list.push({t: now(), len: len, data: data});
  }

  var oCC = String.prototype.charCodeAt;
  String.prototype.charCodeAt = function(i){
    try {
      if (D.rec) {
        var s = this, n = s.length;
        bump('cc');
        D.hist[n] = (D.hist[n]||0)+1;
        if (n === 1) { if (D.curLen < MAX_RUNLEN) { D.cur += s; D.curLen++; } }
        else {
          flushRun();
          if (n >= 8) keep(D.cc, 'C'+n+'|'+s, n, String(s).slice(0, 20000));
        }
      }
    } catch(e){}
    return oCC.call(this, i);
  };

  var oCP = String.prototype.codePointAt;
  if (oCP) String.prototype.codePointAt = function(i){
    try {
      if (D.rec) {
        var s = this, n = s.length;
        bump('cp');
        if (n >= 8) keep(D.cc, 'P'+n+'|'+s, n, String(s).slice(0, 20000));
      }
    } catch(e){}
    return oCP.call(this, i);
  };

  var oFCC = String.fromCharCode;
  String.fromCharCode = function(){
    var out = oFCC.apply(String, arguments);
    try {
      if (D.rec) {
        bump('fcc'); flushRun();
        keep(D.fcc, 'F'+arguments.length+'|'+out.slice(0,40), out.length, out.slice(0, 20000));
      }
    } catch(e){}
    return out;
  };

  var oStr = JSON.stringify;
  JSON.stringify = function(){
    var out = oStr.apply(JSON, arguments);
    try {
      if (D.rec && typeof out === 'string' && out.length >= 8)
        keep(D.json, 'J'+out.length+'|'+out.slice(0,40), out.length, out.slice(0, 20000));
    } catch(e){}
    return out;
  };

  var oBtoa = window.btoa;
  window.btoa = function(s){
    var out = oBtoa.apply(window, arguments);
    try {
      if (D.rec) {
        bump('btoa'); flushRun();
        if (D.btoa.length < 60)
          D.btoa.push({t: now(), inLen: String(s).length,
                       inB64: oBtoa.call(window, String(s)), out: out});
      }
    } catch(e){}
    return out;
  };

  var oAtob = window.atob;
  window.atob = function(s){
    var out = oAtob.apply(window, arguments);
    try { if (D.rec) { bump('atob'); keep(D.atob, 'A'+String(s).length+'|'+String(s).slice(0,40), String(s).length, String(s).slice(0,20000)); } } catch(e){}
    return out;
  };

  var oJoin = Array.prototype.join;
  Array.prototype.join = function(sep){
    var out = oJoin.apply(this, arguments);
    try {
      if (D.rec && typeof out === 'string' && out.length >= 8)
        keep(D.join, 'M'+out.length+'|'+out.slice(0,40), out.length, out.slice(0,20000));
    } catch(e){}
    return out;
  };

  if (window.TextEncoder) {
    var oEnc = TextEncoder.prototype.encode;
    TextEncoder.prototype.encode = function(s){
      try { if (D.rec) { bump('TextEncoder'); keep(D.te, 'T'+String(s).length+'|'+String(s).slice(0,32), String(s).length, String(s).slice(0,20000)); } } catch(e){}
      return oEnc.apply(this, arguments);
    };
  }
  ['escape','unescape'].forEach(function(k){
    var f = window[k];
    window[k] = function(a){
      var r = f.apply(window, arguments);
      try { if (D.rec) { bump(k); if (typeof a === 'string') keep(D.esc, k+'|'+a.length+'|'+String(a).slice(0,32), a.length, String(a).slice(0,20000)); } } catch(e){}
      return r;
    };
  });

  window.__dpArm = function(){
    D.phase += 1; D.rec = true; D.t0 = performance.now();
    D.seen = {}; D.hist = {}; D.counts = {};
    D.strs.length = 0; D.cc.length = 0; D.runs.length = 0; D.fcc.length = 0;
    D.json.length = 0; D.btoa.length = 0; D.atob.length = 0; D.te.length = 0;
    D.esc.length = 0; D.join.length = 0; D.cur = ''; D.curLen = 0;
    return D.phase;
  };
  window.__dpDump = function(){
    D.rec = false; flushRun();
    var o = {};
    for (var k in D) if (k !== 'seen') o[k] = D[k];
    o.cur = ''; o.curLen = 0;
    return o;
  };
  return 'ok';
})()
"""


def page_ws():
    conn = http.client.HTTPConnection("127.0.0.1", PORT, timeout=5)
    conn.request("GET", "/json")
    for t in json.loads(conn.getresponse().read()):
        if t.get("type") == "page" and "cloud.tencent.com" in t.get("url", ""):
            return t["webSocketDebuggerUrl"]
    raise SystemExit("page not found")


class CDP:
    def __init__(self):
        self.ws = websocket.create_connection(page_ws(), timeout=30, suppress_origin=True)
        self.i = 0

    def call(self, method, **params):
        self.i += 1
        self.ws.send(json.dumps({"id": self.i, "method": method, "params": params}))
        while True:
            msg = json.loads(self.ws.recv())
            if msg.get("id") == self.i:
                if "error" in msg:
                    raise RuntimeError(msg["error"])
                return msg.get("result", {})

    def ev(self, expr):
        r = self.call("Runtime.evaluate", expression=expr, returnByValue=True, awaitPromise=True)
        res = r.get("result", {})
        if res.get("subtype") == "error":
            print("JSERR", res.get("description"))
        return res.get("value")


def report(tag, d):
    print("== %s ==" % tag)
    print("  counts", d.get("counts"))
    hist = {int(k): v for k, v in (d.get("hist") or {}).items()}
    top = sorted(hist.items(), key=lambda kv: -kv[1])[:10]
    print("  ccHist", top)
    print("  btoa", [(e["inLen"], len(e["out"])) for e in d.get("btoa", [])])
    print("  json", [(e["len"], e["data"][:30]) for e in d.get("json", [])][:10])
    print("  cc", [(e["len"], e["data"][:30]) for e in d.get("cc", [])][:10])
    print("  fcc", [(e["len"], e["data"][:20]) for e in d.get("fcc", [])][:10])
    print("  te", [(e["len"], e["data"][:30]) for e in d.get("te", [])][:5])
    print("  join", [(e["len"], e["data"][:40]) for e in d.get("join", [])][:10])
    print("  runs", [(e["len"], e["data"][:40]) for e in d.get("runs", [])][:10])


def main():
    c = CDP()
    c.call("Page.enable")
    try:
        c.call("Page.addScriptToEvaluateOnNewDocument", source=HOOK)
    except Exception as e:  # noqa: BLE001
        print("addScriptToEvaluateOnNewDocument failed:", e)
    c.call("Page.navigate", url="https://cloud.tencent.com/product/captcha")
    time.sleep(5)
    print("hook:", c.ev(HOOK))

    # ---- phase 1: click -> TDC ready --------------------------------------
    c.ev("window.__dpArm()")
    c.ev("(()=>{const e=[...document.querySelectorAll('a.tpm-btn')].filter(e=>e.textContent.trim()==='立即体验')[0]; if(e){e.scrollIntoView({block:'center'}); e.click();} })()")
    for _ in range(30):
        time.sleep(0.5)
        if c.ev("!!window.TDC"):
            break
    time.sleep(1.0)
    d1 = c.ev("window.__dpDump()") or {}
    print("TDC:", c.ev("!!window.TDC"))
    report("phase1 click", d1)

    # ---- phase 2: getData --------------------------------------------------
    c.ev("window.__dpArm()")
    data = c.ev("window.TDC?String(window.TDC.getData()):null")
    info = c.ev("window.TDC?String(window.TDC.getInfo().info):null")
    d2 = c.ev("window.__dpDump()") or {}
    report("phase2 getData", d2)

    out = {"phase1": d1, "phase2": d2, "data": data, "info": info}
    json.dump(out, open("deep2_log.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print("collect len", len(data or ""), "info len", len(info or ""))
    print("-> deep2_log.json")


if __name__ == "__main__":
    main()
