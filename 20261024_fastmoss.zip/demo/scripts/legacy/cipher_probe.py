# -*- coding: utf-8 -*-
"""Try XXTEA/XTEA/TEA decryption of captured chunks with candidate keys."""
import struct, json, base64, string

DELTA = 0x9E3779B9
M32 = 0xFFFFFFFF

def to_words(b):
    b = b[:len(b) // 4 * 4]
    return list(struct.unpack("<%dI" % (len(b) // 4), b))

def from_words(w):
    return struct.pack("<%dI" % len(w), *[x & M32 for x in w])

def xxtea_decrypt(data, key):
    if len(data) < 8: return b""
    v = to_words(data)
    n = len(v)
    k = (list(key) + [0, 0, 0, 0])[:4]
    rounds = 6 + 52 // n
    s = (rounds * DELTA) & M32
    y = v[0]
    while s:
        e = (s >> 2) & 3
        for p in range(n - 1, -1, -1):
            z = v[(p - 1) % n]
            mx = (((z >> 5) ^ (y << 2)) + ((y >> 3) ^ (z << 4))) ^ ((s ^ y) + (k[(p & 3) ^ e] ^ z))
            v[p] = (v[p] - mx) & M32
            y = v[p]
        s = (s - DELTA) & M32
    return from_words(v)

def xxtea_encrypt(data, key):
    v = to_words(data)
    if len(v) < 2: return b""
    n = len(v)
    k = (list(key) + [0, 0, 0, 0])[:4]
    rounds = 6 + 52 // n
    s = 0
    z = v[-1]
    for _ in range(rounds):
        s = (s + DELTA) & M32
        e = (s >> 2) & 3
        for p in range(n):
            y = v[(p + 1) % n]
            mx = (((z >> 5) ^ (y << 2)) + ((y >> 3) ^ (z << 4))) ^ ((s ^ y) + (k[(p & 3) ^ e] ^ z))
            v[p] = (v[p] + mx) & M32
            z = v[p]
    return from_words(v)

def key_from_str(s):
    b = s.encode()
    if len(b) < 16: b = b + b"\x00" * (16 - len(b))
    return to_words(b[:16])

def score(b):
    if not b: return 0
    printable = sum(1 for c in b if 9 <= c <= 13 or 32 <= c <= 126)
    return printable / len(b)

def try_keys(chunks, keys):
    for name, key in keys:
        for i, ch in enumerate(chunks):
            if len(ch) < 8: continue
            pt = xxtea_decrypt(ch, key)
            sc = score(pt)
            if sc > 0.75 or b'{' in pt or b'[' in pt:
                print("HIT", name, "chunk", i, "score", round(sc, 3), repr(pt[:120]))

if __name__ == "__main__":
    chunks = [open("chunk%d.bin" % i, "rb").read() for i in range(5)]
    keys = []
    for s in ["890859047", "192962660", "tdc", "TDC", "turing", "captcha", "tencent",
              "0", "1", "a", "mmsns", "qcloud", "cloud.tencent.com", "1811603099878481920"]:
        keys.append((s, key_from_str(s)))
    # numeric candidates
    for name, words in [
        ("const-mix1", [84941944608 & M32, 1907983, 197402, DELTA]),
        ("const-mix2", [1907983, 197402, 84941944608 & M32, 982286738]),
        ("token-words", [890859047, 890859047, 890859047, 890859047]),
    ]:
        keys.append((name, words))
    try_keys(chunks, keys)
    print("done", [len(c) for c in chunks])
