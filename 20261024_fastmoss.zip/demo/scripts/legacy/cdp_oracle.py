# -*- coding: utf-8 -*-
"""Open the demo captcha with hooks installed and pull, from the SAME build:

  * the cipher call log (args + return value) from the tdc frame
  * the tdc.js URL actually loaded
  * a live oracle: call the captured cipher function with chosen vectors
  * the key arrays present in the frame (queryObjects)

Usage: python cdp_oracle.py [--no-click]
Writes oracle.json.
"""
import http.client
import json
import sys
import time

import websocket

PORT = 9222

HOOK = r"""
(function(){
  if (window.__fc) return;
  var D = window.__fc = {calls: [], fcc4: [], btoa: [], fns: [], loc: location.href, t0: 0};
  try { D.t0 = performance.now(); } catch(e) {}
  var oa = Function.prototype.apply;
  Function.prototype.apply = function(self, args){
    var r;
    try { r = oa.call(this, self, args); } catch(e) { throw e; }
    try{
      if (args && typeof args === 'object' && args.length === 2 && args[0] &&
          typeof args[0] === 'object' && args[0].length === 2 &&
          typeof args[0][0] === 'number' && typeof args[0][1] === 'number' &&
          D.calls.length < 4000){
        var a1 = args[1], o = {t: Math.round(performance.now()), p: [args[0][0] >>> 0, args[0][1] >>> 0], fname: this && this.name || ''};
        o.a1t = typeof a1;
        if (a1 && typeof a1 === 'object') {
          o.a1len = a1.length;
          o.a1 = [];
          for (var i = 0; i < Math.min(a1.length || 0, 8); i++) {
            var e = a1[i];
            o.a1.push(typeof e === 'number' ? (e >>> 0) : (e === undefined ? 'u' : typeof e));
          }
        } else o.a1 = String(a1).slice(0, 40);
        // return value
        if (r && typeof r === 'object' && typeof r.length === 'number' && r.length <= 8) {
          o.r = [];
          for (var j = 0; j < r.length; j++) {
            var x = r[j];
            o.r.push(typeof x === 'number' ? (x >>> 0) : typeof x);
          }
        } else if (typeof r === 'number') o.r = [r >>> 0];
        else o.r = typeof r === 'string' ? r.slice(0, 60) : typeof r;
        D.calls.push(o);
        if (D.fns.length < 8 && typeof this === 'function') D.fns.push(this);
      }
    }catch(e){}
    return r;
  };
  var ofc = String.fromCharCode;
  String.fromCharCode = function(){
    var out = ofc.apply(String, arguments);
    try{
      if (arguments.length === 4 && D.fcc4.length < 4000)
        D.fcc4.push([arguments[0] & 255, arguments[1] & 255, arguments[2] & 255, arguments[3] & 255]);
    }catch(e){}
    return out;
  };
  var ob = window.btoa;
  window.btoa = function(s){
    var out = ob.apply(window, arguments);
    try{
      if (D.btoa.length < 8 && typeof s === 'string' && s.length > 100){
        var h = '';
        for (var i = 0; i < s.length && i < 40000; i++){
          var c = s.charCodeAt(i) & 255;
          h += (c < 16 ? '0' : '') + c.toString(16);
        }
        D.btoa.push({len: s.length, hex: h});
      }
    }catch(e){}
    return out;
  };
})();
"""


def targets():
    conn = http.client.HTTPConnection("127.0.0.1", PORT, timeout=5)
    conn.request("GET", "/json")
    return json.loads(conn.getresponse().read())


class CDP:
    def __init__(self, url):
        self.ws = websocket.create_connection(url, timeout=30, suppress_origin=True)
        self.i = 0
        self.events = []

    def send(self, method, **params):
        self.i += 1
        self.ws.send(json.dumps({"id": self.i, "method": method, "params": params}))
        return self.i

    def pump(self, seconds):
        self.ws.settimeout(0.4)
        end = time.time() + seconds
        while time.time() < end:
            try:
                msg = json.loads(self.ws.recv())
            except Exception:
                continue
            if "method" in msg:
                self.events.append(msg)

    def call(self, method, **params):
        mid = self.send(method, **params)
        self.ws.settimeout(40)
        while True:
            msg = json.loads(self.ws.recv())
            if msg.get("id") == mid:
                if "error" in msg:
                    raise RuntimeError("%s -> %s" % (method, msg["error"]))
                return msg.get("result", {})
            if "method" in msg:
                self.events.append(msg)

    def ev(self, expr, ctx=None):
        p = {"expression": expr, "returnByValue": True, "awaitPromise": True}
        if ctx is not None:
            p["contextId"] = ctx
        r = self.call("Runtime.evaluate", **p)
        if r.get("exceptionDetails"):
            return {"__exc": str(r["exceptionDetails"])[:400]}
        return r.get("result", {}).get("value")


def main():
    no_click = "--no-click" in sys.argv
    pg = [t for t in targets() if t.get("type") == "page"][0]
    c = CDP(pg["webSocketDebuggerUrl"])
    c.call("Page.enable")
    c.call("Runtime.enable")
    ids = []
    for t in targets():
        if t.get("type") != "page":
            continue
    c.call("Page.addScriptToEvaluateOnNewDocument", source=HOOK)
    # also run the hook in the current document of every existing frame
    c.ev(HOOK)
    print("hooks installed")
    if not no_click:
        c.call("Input.dispatchMouseEvent", type="mouseMoved", x=569, y=545)
        time.sleep(0.1)
        c.call("Input.dispatchMouseEvent", type="mousePressed", x=569, y=545, button="left", clickCount=1)
        time.sleep(0.08)
        c.call("Input.dispatchMouseEvent", type="mouseReleased", x=569, y=545, button="left", clickCount=1)
        print("clicked")
    c.pump(6.0)
    # find turing contexts
    ctxs = {}
    for e in c.events:
        if e.get("method") == "Runtime.executionContextCreated":
            ctx = e["params"]["context"]
            ctxs[ctx["id"]] = ctx
    print("contexts seen:", len(ctxs))
    turing = [i for i, x in ctxs.items() if "turing" in (x.get("origin") or "")]
    print("turing contexts:", turing)
    if not turing:
        # ask the page for its frames' origins
        print("frame list:", c.ev("(function(){var o=[];for(var i=0;i<frames.length;i++){try{o.push(frames[i].location.href)}catch(e){o.push('x:'+e)}}return o})()"))
    out = {}
    for cid in turing:
        info = c.ev("(function(){return {href: location.href, n: (window.__fc? __fc.calls.length : -1),"
                    " fcc: (window.__fc? __fc.fcc4.length : -1), btoa: (window.__fc? __fc.btoa.length : -1),"
                    " scripts: performance.getEntriesByType('resource').map(function(e){return e.name}).filter(function(n){return n.indexOf('tdc.js')>=0})}})()", cid)
        print("ctx", cid, json.dumps(info, ensure_ascii=False)[:500])
        out[str(cid)] = info
    # dump the first context's log
    if turing:
        cid = turing[-1]
        dump = c.ev("(function(){var D=window.__fc;return {loc:D.loc, calls:D.calls.slice(0,5), "
                    "fcc4:D.fcc4.slice(0,4), btoa:D.btoa.map(function(b){return {len:b.len, hex:b.hex.slice(0,64)}})}})()", cid)
        print("DUMP", json.dumps(dump, ensure_ascii=False)[:2000])
        # oracle test: call the captured function directly
        test = c.ev("(function(){"
                    "var D=window.__fc; if(!D.fns.length) return 'nofn';"
                    "var f=D.fns[0]; var out={};"
                    "var pairs=[[1,2],[0x12345678,0x9abcdef0],[0xffffffff,0]];"
                    "try{ var c0=D.calls[0]; var a1=[]; for(var i=0;i<(c0.a1len||0);i++)a1.push(undefined);"
                    " out.replay = f([c0.p[0],c0.p[1]], a1); }catch(e){ out.replay='ERR '+e; }"
                    "try{ out.fixed=[]; for(var j=0;j<pairs.length;j++){ out.fixed.push(f(pairs[j], [])); } }catch(e){ out.fixed='ERR '+e; }"
                    "out.play = D.calls.slice(0,3);"
                    "return out})()", cid)
        print("ORACLE", json.dumps(test, ensure_ascii=False)[:3000])
        out["oracle"] = test
    json.dump(out, open("oracle.json", "w"), ensure_ascii=False, indent=1)


if __name__ == "__main__":
    main()
