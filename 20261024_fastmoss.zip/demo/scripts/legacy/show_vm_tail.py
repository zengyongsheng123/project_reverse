# -*- coding: utf-8 -*-
import sys
sys.path.insert(0, ".")
from disasm_tdc import balanced, SRC

s = open(SRC, encoding="utf-8", errors="replace").read()
a = s.find("for(var A=[")
start = s.find("[", a)
end = start + len(balanced(s, start))
print("A ends at", end)
print("=== context after opcode table ===")
print(s[end:end + 2000])
