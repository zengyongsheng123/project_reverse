# -*- coding: utf-8 -*-
"""Recursive disassembler for the Chaos VM bytecode.

Linear sweeps desync because jump targets create unreachable regions, so this
walks from entry points (pc 0, closure bodies, jump targets) and records every
instruction that is actually reachable.

Usage:
    python redisasm_tdc.py 9380 9460       # listing for pcs in range
    python redisasm_tdc.py --find 9424     # show the instruction(s) covering a pc
"""
import sys, json
from collections import deque
from disasm_tdc import OPERANDS, NAMES

BC = "../js/bytecode.json"


def walk(bc):
    n = len(bc)
    seen = {}          # pc -> (op, operands, nextpc)
    q = deque([0])
    closures = []
    while q:
        pc = q.popleft()
        if not isinstance(pc, int):
            pc = int(pc)
        if pc in seen or pc < 0 or pc >= n:
            continue
        op = bc[pc]
        start = pc
        pc += 1
        if op == 52:
            f = int(bc[start + 1])
            nup = int(bc[start + 2])
            narg = int(bc[start + 3])
            pc += 3 + 2 * nup + narg
            closures.append(f)
            q.append(f)
        elif op in OPERANDS:
            pc += OPERANDS[op]
        else:
            seen[start] = (op, ["<invalid>"], None)
            continue
        ops = bc[start + 1:pc]
        seen[start] = (op, ops, pc)
        if op == 33:            # jmp target
            q.append(int(ops[0]))
        elif op == 63:          # conditional jump
            q.append(int(ops[0]))
            q.append(pc)        # fallthrough
        elif op == 48:          # halt
            pass
        elif op == 18:          # ret
            pass
        else:
            q.append(pc)
    return seen, closures


def main():
    bc = json.load(open(BC, encoding="utf-8"))
    seen, closures = walk(bc)
    print("reachable instructions", len(seen), "closure bodies", len(closures))

    if len(sys.argv) >= 3 and sys.argv[1] == "--find":
        targets = [int(x) for x in sys.argv[2:]]
        starts = sorted(seen)
        for t in targets:
            prev = None
            for s in starts:
                if s <= t:
                    prev = s
                else:
                    break
            if prev is None:
                print(t, "no instruction")
                continue
            op, ops, nxt = seen[prev]
            print("pc %d -> instr at %d %s %s (next %s)" % (t, prev, NAMES.get(op, op), ops, nxt))
        return

    lo, hi = int(sys.argv[1]), int(sys.argv[2])
    for s in sorted(seen):
        if lo <= s < hi:
            op, ops, nxt = seen[s]
            print("%6d  %-10s %s" % (s, NAMES.get(op, "op%d" % op), " ".join(str(x) for x in ops)))


if __name__ == "__main__":
    main()
