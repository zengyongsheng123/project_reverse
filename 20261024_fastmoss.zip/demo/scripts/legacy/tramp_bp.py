# -*- coding: utf-8 -*-
"""Pause inside the Chaos-VM trampolines during TDC.getData() and dump the
closure scope of each trampoline frame.  The cipher closure keeps its key
array as an upvalue, so one of these scopes should carry it.

Usage: python tramp_bp.py [max_pauses]
Writes tramp_bp.json
"""
import http.client
import json
import sys
import time

import websocket

PORT = 9222
MAXP = int(sys.argv[1]) if len(sys.argv) > 1 else 60


def targets():
    c = http.client.HTTPConnection("127.0.0.1", PORT, timeout=5)
    c.request("GET", "/json")
    return json.loads(c.getresponse().read())


class CDP:
    def __init__(self, url):
        self.ws = websocket.create_connection(url, timeout=120, suppress_origin=True)
        self.i = 0
        self.events = []

    def send(self, method, **p):
        self.i += 1
        self.ws.send(json.dumps({"id": self.i, "method": method, "params": p}))
        return self.i

    def recv(self, timeout):
        self.ws.settimeout(timeout)
        return json.loads(self.ws.recv())

    def call(self, method, timeout=60, **p):
        mid = self.send(method, **p)
        end = time.time() + timeout
        while True:
            m = self.recv(max(0.5, end - time.time()))
            if m.get("id") == mid:
                if "error" in m:
                    raise RuntimeError("%s -> %s" % (method, m["error"]))
                return m.get("result", {})
            if "method" in m:
                self.events.append(m)


SCOPE_SUM = r"""
function(){
  var out={}, names=Object.getOwnPropertyNames(this);
  for(var i=0;i<names.length;i++){
    var k=names[i], v;
    try{ v=this[k]; }catch(e){ continue; }
    var t=typeof v;
    if(t==='number') out[k]={t:'n',v:v>>>0};
    else if(t==='string') out[k]={t:'s',l:v.length,pre:v.slice(0,48)};
    else if(v&&t==='object'){
      var o={t:'o',tag:Object.prototype.toString.call(v)};
      if(typeof v.length==='number'){
        o.len=v.length; var a=[];
        for(var j=0;j<Math.min(v.length,20);j++){
          var e=v[j]; a.push(typeof e==='number'?(e>>>0):(e===undefined?'u':typeof e));
        }
        o.e=a;
      }
      out[k]=o;
    } else out[k]={t:t};
  }
  return JSON.stringify(out);
}
"""

ARGS_SUM = r"""
function(){
  try{
    var a=[]; for(var i=0;i<arguments.length;i++){
      var v=arguments[i], t=typeof v;
      if(v&&t==='object'&&typeof v.length==='number'){
        var e=[];for(var j=0;j<Math.min(v.length,10);j++)e.push(typeof v[j]==='number'?(v[j]>>>0):(v[j]===undefined?'u':typeof v[j]));
        a.push('arr'+v.length+':'+e.join(','));
      } else if(t==='object'||t==='function') a.push(t);
      else a.push(t==='number'?(v>>>0):String(v).slice(0,40));
    }
    return JSON.stringify(a);
  }catch(e){ return 'E:'+e; }
}
"""


def on_paused(c, params, recs):
    frames = params.get("callFrames", [])
    if not frames:
        c.call("Debugger.resume")
        return
    top = frames[0]
    rec = {"reason": params.get("reason"), "n": len(frames),
           "fn": top.get("functionName"), "url": (top.get("url") or "")[-40:],
           "line": top.get("location", {}).get("lineNumber"),
           "col": top.get("location", {}).get("columnNumber"),
           "scopes": [], "args": None}
    try:
        r = c.call("Debugger.evaluateOnCallFrame", callFrameId=top["callFrameId"],
                   expression=ARGS_SUM, returnByValue=True, silent=True)
        rec["args"] = r.get("result", {}).get("value")
    except Exception as e:
        rec["args"] = "ERR " + str(e)[:80]
    for sc in top.get("scopeChain", []):
        entry = {"type": sc.get("type")}
        oid = (sc.get("object") or {}).get("objectId")
        if oid and sc.get("type") in ("local", "closure", "block", "catch", "with"):
            try:
                r = c.call("Runtime.callFunctionOn", objectId=oid,
                           functionDeclaration=SCOPE_SUM, returnByValue=True)
                entry["vars"] = r.get("result", {}).get("value")
            except Exception as e:
                entry["vars"] = "ERR " + str(e)[:80]
        rec["scopes"].append(entry)
    recs.append(rec)
    c.call("Debugger.resume")


def main():
    pg = [t for t in targets() if t.get("type") == "page"][0]
    c = CDP(pg["webSocketDebuggerUrl"])
    c.call("Runtime.enable")
    c.call("Debugger.enable")
    proto = c.call("Runtime.evaluate", expression="Function.prototype")["result"]["objectId"]
    objs = c.call("Runtime.queryObjects", prototypeObjectId=proto)["objects"]["objectId"]
    finder = ("function(){var out=[];for(var i=0;i<this.length;i++){try{"
              "if(Function.prototype.toString.call(this[i]).indexOf('__TENCENT_CHAOS_VM')>=0)"
              "out.push(this[i])}catch(e){}}return this.slice(0,0).concat(out.slice(0,8))}")
    r = c.call("Runtime.callFunctionOn", objectId=objs, functionDeclaration=finder,
               returnByValue=False)
    arr = r["result"]
    print("trampoline array:", arr.get("description"))
    props = c.call("Runtime.getProperties", objectId=arr["objectId"], ownProperties=True)
    fns = []
    for p in props.get("result", []):
        name = p.get("name")
        if name and name.isdigit():
            fns.append(p["value"]["objectId"])
    print("trampolines:", len(fns))
    if not fns:
        return
    bps = []
    for oid in fns[:8]:
        try:
            b = c.call("Debugger.setBreakpointOnFunctionCall", objectId=oid)
            bps.append(b.get("breakpointId"))
        except RuntimeError as e:
            if "already exists" not in str(e):
                raise
    print("breakpoints:", bps)
    # call getData asynchronously; the paused events arrive while it runs
    mid = c.send("Runtime.evaluate", expression="TDC.getData().length", returnByValue=True)
    recs = []
    done = None
    end = time.time() + 90
    while time.time() < end:
        try:
            m = c.recv(1.0)
        except Exception:
            continue
        if m.get("id") == mid:
            done = m
            break
        if m.get("method") == "Debugger.paused":
            if len(recs) < MAXP:
                on_paused(c, m["params"], recs)
            else:
                c.call("Debugger.resume")
        else:
            c.events.append(m)
    print("pauses recorded:", len(recs), "eval done:", bool(done))
    if done and "result" in done:
        print("getData length:", done["result"].get("result", {}).get("value"))
    for b in bps:
        try:
            c.call("Debugger.removeBreakpoint", breakpointId=b)
        except Exception:
            pass
    json.dump(recs, open("tramp_bp.json", "w"), ensure_ascii=False, indent=1)
    print("wrote tramp_bp.json")
    # highlight scopes carrying interesting constants
    MAGIC = {1776394, 592135, 1852730980, 0x63516950, 0x48364e35, 0x90668375, 0x592f4c3e, 0x4d395150, 0x311d3534}
    for i, r in enumerate(recs):
        hit = False
        for sc in r["scopes"]:
            v = sc.get("vars") or ""
            try:
                d = json.loads(v)
            except Exception:
                continue
            for k, val in d.items():
                if val.get("t") == "n" and (val.get("v") in MAGIC):
                    hit = True
                if val.get("t") == "o" and "e" in val and any(x in MAGIC for x in val["e"]):
                    hit = True
        if hit:
            print("HIT pause", i, r["fn"], r["args"])
    return recs


if __name__ == "__main__":
    main()
