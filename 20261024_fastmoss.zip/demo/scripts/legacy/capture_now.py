# -*- coding: utf-8 -*-
"""One-shot capture from a single live build:

  * plaintext blocks  (single [w0,w1] argument of the cipher trampoline)
  * cipher key        (register-file upvalue, slot 7)
  * ciphertext words  (4-byte String.fromCharCode calls)

Installs the fromCharCode hook, reloads, opens the widget, waits for TDC,
then breaks on the trampolines while TDC.getData() runs.

Usage: python capture_all.py
Writes capture_all.json
"""
import http.client
import json
import time

import websocket

PORT = 9222

PRELOAD = r"""
(function(){
  if (window.__fc) return;
  var D = window.__fc = {fcc4: [], n: 0, t0: performance.now()};
  var ofc = String.fromCharCode;
  String.fromCharCode = function(){
    var out = ofc.apply(String, arguments);
    try{
      if (arguments.length === 4){
        D.fcc4.push([arguments[0]&255, arguments[1]&255, arguments[2]&255, arguments[3]&255, Math.round(performance.now())]);
      }
    }catch(e){}
    return out;
  };
})();
"""

SHAPE = r"""
function(AR){
  try{
    if(AR.length===1 && AR[0] && typeof AR[0]==='object' && AR[0].length===2 &&
       typeof AR[0][0]==='number' && typeof AR[0][1]==='number')
      return JSON.stringify([AR[0][0]>>>0, AR[0][1]>>>0]);
  }catch(e){}
  return '';
}
"""

DEEP = r"""
function(){
  var v=this, out={tag:Object.prototype.toString.call(v)};
  if(typeof v.length==='number'){
    out.len=v.length; out.e=[];
    for(var i=0;i<Math.min(v.length,16);i++){
      var x=v[i];
      if(typeof x==='number') out.e.push(x>>>0);
      else if(x&&typeof x==='object'&&typeof x.length==='number'){
        var q=[];for(var j=0;j<Math.min(x.length,8);j++){var y=x[j];
          q.push(typeof y==='number'?(y>>>0):(y===undefined?'u':typeof y))}
        out.e.push({len:x.length,e:q});
      } else out.e.push(x===undefined?'u':typeof x);
    }
  }
  return JSON.stringify(out);
}
"""


def targets():
    c = http.client.HTTPConnection("127.0.0.1", PORT, timeout=5)
    c.request("GET", "/json")
    return json.loads(c.getresponse().read())


class CDP:
    def __init__(self, url):
        self.ws = websocket.create_connection(url, timeout=180, suppress_origin=True)
        self.i = 0
        self.events = []
        self.auto_resume = False

    def send(self, method, **p):
        self.i += 1
        self.ws.send(json.dumps({"id": self.i, "method": method, "params": p}))
        return self.i

    def recv(self, timeout):
        self.ws.settimeout(timeout)
        return json.loads(self.ws.recv())

    def call(self, method, timeout=60, **p):
        mid = self.send(method, **p)
        end = time.time() + timeout
        while True:
            m = self.recv(max(0.5, end - time.time()))
            if m.get("id") == mid:
                if "error" in m:
                    raise RuntimeError("%s -> %s" % (method, m["error"]))
                return m.get("result", {})
            if "method" in m:
                self.events.append(m)
                if m["method"] == "Debugger.paused" and self.auto_resume:
                    self.i += 1
                    self.ws.send(json.dumps({"id": self.i, "method": "Debugger.resume", "params": {}}))

    def ev(self, expr, timeout=60):
        r = self.call("Runtime.evaluate", expression=expr, returnByValue=True,
                      awaitPromise=True, timeout=timeout)
        return r.get("result", {}).get("value")


def dump_scopes(c, cf):
    scopes = []
    for sc in cf.get("scopeChain", []):
        if sc.get("type") not in ("closure", "local", "block"):
            continue
        oid = (sc.get("object") or {}).get("objectId")
        if not oid:
            continue
        props = c.call("Runtime.getProperties", objectId=oid, ownProperties=True)
        vars_ = {}
        for p in props.get("result", []):
            name = p.get("name")
            val = p.get("value") or {}
            if not name:
                continue
            if val.get("type") == "number":
                vars_[name] = {"n": val.get("value")}
            elif val.get("type") == "object" and val.get("objectId"):
                try:
                    r = c.call("Runtime.callFunctionOn", objectId=val["objectId"],
                               functionDeclaration=DEEP, returnByValue=True)
                    vars_[name] = json.loads(r.get("result", {}).get("value") or "{}")
                except Exception as e:
                    vars_[name] = {"err": str(e)[:60]}
        scopes.append({"type": sc.get("type"), "vars": vars_})
    return scopes


def find_keys(scopes):
    hits = []
    for si, sc in enumerate(scopes):
        for name, d in sc["vars"].items():
            if not isinstance(d, dict):
                continue
            if d.get("len") == 8:
                e = d.get("e") or []
                if len(e) > 7 and isinstance(e[7], dict):
                    inner = e[7].get("e") or []
                    if len(inner) == 1 and isinstance(inner[0], dict):
                        arr = inner[0].get("e") or []
                        if len(arr) == 4 and all(isinstance(x, int) for x in arr):
                            hits.append({"var": name, "key": arr, "scope": si})
    return hits


def main():
    pg = [t for t in targets() if t.get("type") == "page"][0]
    c = CDP(pg["webSocketDebuggerUrl"])
    c.call("Page.enable")
    c.call("Runtime.enable")
    c.auto_resume = True
    c.call("Debugger.enable")
    time.sleep(0.4)
    # no reload: the page already runs a build; reuse it if TDC is alive
    if c.ev("(function(){try{return typeof TDC==='object'&&typeof TDC.getData==='function'}catch(e){return false}})()") is not True:
        print("TDC missing; installing preload + reload")
        c.call("Page.addScriptToEvaluateOnNewDocument", source=PRELOAD)
        c.call("Page.reload", ignoreCache=False)
        time.sleep(6)
        for typ, extra in (("mouseMoved", {}),
                           ("mousePressed", {"button": "left", "clickCount": 1}),
                           ("mouseReleased", {"button": "left", "clickCount": 1})):
            c.call("Input.dispatchMouseEvent", type=typ, x=569, y=545, **extra)
            time.sleep(0.1)
        for _ in range(25):
            if c.ev("(function(){try{return TDC.getData().length>0}catch(e){return false}})()") is True:
                break
            time.sleep(1)
    if not c.ev("window.__fc?1:0"):
        print("WARN: fromCharCode hook absent (no preload); ciphertext may be missing")
    c.call("Debugger.enable")
    proto = c.call("Runtime.evaluate", expression="Function.prototype")["result"]["objectId"]
    objs = c.call("Runtime.queryObjects", prototypeObjectId=proto)["objects"]["objectId"]
    finder = ("function(){var out=[];for(var i=0;i<this.length;i++){try{"
              "if(Function.prototype.toString.call(this[i]).indexOf('__TENCENT_CHAOS_VM')>=0)"
              "out.push(this[i])}catch(e){}}return out.slice(0,8)}")
    rr = c.call("Runtime.callFunctionOn", objectId=objs, functionDeclaration=finder,
                returnByValue=False)
    props = c.call("Runtime.getProperties", objectId=rr["result"]["objectId"], ownProperties=True)
    fns = [p["value"]["objectId"] for p in props.get("result", []) if p.get("name", "").isdigit()]
    bps = []
    for oid in fns:
        try:
            bps.append(c.call("Debugger.setBreakpointOnFunctionCall", objectId=oid).get("breakpointId"))
        except RuntimeError as e:
            if "already exists" not in str(e):
                raise
    print("breakpoints:", bps)
    c.ev("(function(){window.__fc.fcc4=[];window.__fc.n=0;return 1})()")
    c.auto_resume = False
    mid = c.send("Runtime.evaluate", expression="TDC.getData()", returnByValue=True)
    blocks = []
    keyrecs = []
    npauses = 0
    done = None
    end = time.time() + 300
    while time.time() < end:
        try:
            m = c.recv(1.0)
        except Exception:
            continue
        if m.get("id") == mid:
            done = m
            # keep the breakpoints alive briefly for trailing cipher calls
            tail_until = time.time() + 5
            while time.time() < tail_until:
                try:
                    m2 = c.recv(0.5)
                except Exception:
                    continue
                if m2.get("method") == "Debugger.paused":
                    npauses += 1
                    cf = m2["params"]["callFrames"][0]
                    try:
                        r2 = c.call("Debugger.evaluateOnCallFrame", callFrameId=cf["callFrameId"],
                                    expression=SHAPE, returnByValue=True, silent=True)
                        v2 = r2.get("result", {}).get("value")
                        a2 = json.loads(v2) if v2 else None
                    except Exception:
                        a2 = None
                    if a2:
                        blocks.append(a2)
                        if len(keyrecs) < 3:
                            sc = dump_scopes(c, cf)
                            keyrecs.append({"arg": a2, "keys": find_keys(sc),
                                            "scopes": sc, "fn": cf.get("functionName")})
                            print("TAIL KEYREC", len(keyrecs), [hex(x) for x in a2], keyrecs[-1]["keys"])
                    c.call("Debugger.resume")
                elif m2.get("method"):
                    c.events.append(m2)
            break
        if m.get("method") != "Debugger.paused":
            c.events.append(m)
            continue
        npauses += 1
        cf = m["params"]["callFrames"][0]
        arg = None
        try:
            r = c.call("Debugger.evaluateOnCallFrame", callFrameId=cf["callFrameId"],
                       expression=SHAPE, returnByValue=True, silent=True)
            v = r.get("result", {}).get("value")
            arg = json.loads(v) if v else None
        except Exception:
            pass
        if arg:
            blocks.append(arg)
            if len(keyrecs) < 3:
                scopes = dump_scopes(c, cf)
                keyrecs.append({"arg": arg, "keys": find_keys(scopes),
                                "scopes": scopes,
                                "fn": cf.get("functionName")})
                print("KEYREC", len(keyrecs), [hex(x) for x in arg],
                      keyrecs[-1]["keys"])
        c.call("Debugger.resume")
    print("pauses:", npauses, "blocks:", len(blocks), "done:", bool(done))
    for b in bps:
        try:
            c.call("Debugger.removeBreakpoint", breakpointId=b)
        except Exception:
            pass
    fcc = c.ev("window.__fc?window.__fc.fcc4:null")
    data = done.get("result", {}).get("result", {}).get("value") if done else None
    print("data len:", len(data) if isinstance(data, str) else data)
    out = {"blocks": blocks, "fcc": fcc, "keyrecs": keyrecs, "data": data}
    json.dump(out, open("capture_all.json", "w"), ensure_ascii=False)
    print("fcc:", len(fcc) if fcc else 0, "wrote capture_all.json")


if __name__ == "__main__":
    main()
