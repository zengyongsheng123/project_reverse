# -*- coding: utf-8 -*-
"""Hook String.prototype.charCodeAt to capture the *plaintext* strings that the
Chaos VM encrypts right before btoa(), plus btoa outputs, during getData()."""
import json, time, http.client
import websocket

PORT = 9222

def page_ws():
    conn = http.client.HTTPConnection("127.0.0.1", PORT, timeout=5)
    conn.request("GET", "/json")
    for t in json.loads(conn.getresponse().read()):
        if t.get("type") == "page" and "cloud.tencent.com" in t.get("url", ""):
            return t["webSocketDebuggerUrl"]
    raise SystemExit("page not found")

class CDP:
    def __init__(self):
        self.ws = websocket.create_connection(page_ws(), timeout=30, suppress_origin=True)
        self.i = 0
    def call(self, method, **params):
        self.i += 1
        self.ws.send(json.dumps({"id": self.i, "method": method, "params": params}))
        while True:
            msg = json.loads(self.ws.recv())
            if msg.get("id") == self.i:
                if "error" in msg: raise RuntimeError(msg["error"])
                return msg.get("result", {})
    def ev(self, expr):
        r = self.call("Runtime.evaluate", expression=expr, returnByValue=True, awaitPromise=True)
        res = r.get("result", {})
        if res.get("subtype") == "error": print("JSERR", res.get("description"))
        return res.get("value")

PATCH = r"""
(function(){
  if (window.__ca) return 'already';
  window.__ca = {strs:[], btoa:[], seen:{}};
  var origCC = String.prototype.charCodeAt;
  var origBtoa = window.btoa;
  var seen = window.__ca.seen;
  String.prototype.charCodeAt = function(i){
    var s = this;
    try {
      if (s.length >= 8 && s.length <= 8000) {
        var k = s.length + ':' + origCC.call(s, 0) + ':' + origCC.call(s, s.length - 1) + ':' + s.slice(0, 24);
        if (!seen[k]) {
          seen[k] = 1;
          if (window.__ca.strs.length < 200)
            window.__ca.strs.push({len: s.length, data: String(s).slice(0, 8000)});
        }
      }
    } catch(e){}
    return origCC.call(s, i);
  };
  window.btoa = function(s){
    var out = origBtoa.apply(window, arguments);
    try {
      if (window.__ca.btoa.length < 60)
        window.__ca.btoa.push({inLen: String(s).length, inB64: origBtoa.call(window, String(s)), out: out});
    } catch(e){}
    return out;
  };
  return 'ok';
})()
"""

def main():
    c = CDP()
    c.call("Page.enable")
    c.call("Page.navigate", url="https://cloud.tencent.com/product/captcha")
    time.sleep(5)
    print("patch", c.ev(PATCH))
    c.ev("(()=>{const e=[...document.querySelectorAll('a.tpm-btn')].filter(e=>e.textContent.trim()==='立即体验')[0]; if(e){e.scrollIntoView({block:'center'}); e.click();} })()")
    for _ in range(30):
        time.sleep(0.5)
        if c.ev("!!window.TDC"): break
    time.sleep(1.0)
    print("TDC", c.ev("!!window.TDC"))
    # isolate the getData() moment
    c.ev("window.__ca.strs.length=0; window.__ca.btoa.length=0; for (var k in window.__ca.seen) delete window.__ca.seen[k];")
    data = c.ev("window.TDC?String(window.TDC.getData()):null")
    info = c.ev("window.TDC?String(window.TDC.getInfo().info):null")
    out = c.ev("window.__ca") or {}
    out["data"] = data
    out["info"] = info
    json.dump(out, open("charat_log.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print("getData len", len(data or ""), "info len", len(info or ""))
    for i, e in enumerate(out.get("btoa", [])):
        print("btoa", i, "inLen", e["inLen"], "outLen", len(e["out"]), e["out"][:24])
    for i, e in enumerate(out.get("strs", [])):
        print("str", i, "len", e["len"], repr(e["data"][:160]))

if __name__ == "__main__":
    main()
