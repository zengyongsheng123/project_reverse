# -*- coding: utf-8 -*-
"""Diagnostic 2: element-edge arrays and their number-valued slots."""
import json, sys, collections

d = json.load(open(sys.argv[1], encoding="utf-8"))
nodes, edges, strings = d["nodes"], d["edges"], d["strings"]
NF = 6
n_nodes = len(nodes) // NF
prefix = [0] * (n_nodes + 1)
acc = 0
for i in range(n_nodes):
    prefix[i] = acc
    acc += nodes[i * NF + 4]
prefix[n_nodes] = acc

# all number nodes and their string names
nums = []
for i in range(n_nodes):
    if nodes[i * NF] == 7:
        nums.append((i, strings[nodes[i * NF + 1]]))
print("number nodes:", len(nums))
print("sample:", [(i, s) for i, s in nums[:20]])
big = [(i, s) for i, s in nums if s.replace('.', '').replace('-', '').isdigit() and abs(float(s)) >= 2**20]
print("big number nodes (>=2^20):", len(big))
print("big values sample:", [s for _, s in big[:40]])

# arrays with element edges
stat = collections.Counter()
with_elems = []
for i in range(n_nodes):
    if nodes[i * NF] != 1 and not (nodes[i * NF] == 3 and strings[nodes[i * NF + 1]] == "Array"):
        continue
    e0, ec = prefix[i], nodes[i * NF + 4]
    elems = []
    for e in range(e0, e0 + ec):
        et, enm, to = edges[e * 3], edges[e * 3 + 1], edges[e * 3 + 2]
        if et == 1:
            elems.append((enm, nodes[to], strings[nodes[to + 1]]))
    if elems:
        stat[(nodes[i * NF], strings[nodes[i * NF + 1]], len(elems))] += 1
        with_elems.append((i, elems))
print("nodes with element edges by (type,name,n):", dict(list(stat.items())[:20]))
print("total with element edges:", len(with_elems))

# elements pointing at number nodes with big values
hits = []
for i, elems in with_elems:
    nv = [(idx, s) for idx, t, s in elems if t == 7]
    if len(nv) >= 2 and all(abs(float(s)) >= 2**20 for _, s in nv if s.replace('.', '').replace('-', '').isdigit()):
        hits.append((i, nodes[i * NF], strings[nodes[i * NF + 1]], nv))
print("candidates (>=2 big numbers):", len(hits))
for h in hits[:40]:
    print(" node", h[0], "type", h[1], h[2], h[3][:8])
