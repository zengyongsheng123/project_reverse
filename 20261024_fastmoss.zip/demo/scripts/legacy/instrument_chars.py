# -*- coding: utf-8 -*-
"""Hook String.fromCharCode in the page, open captcha, dump VM-built strings."""
import json, time, http.client, re
import websocket

PORT = 9222

def page_ws():
    conn = http.client.HTTPConnection("127.0.0.1", PORT, timeout=5)
    conn.request("GET", "/json")
    for t in json.loads(conn.getresponse().read()):
        if t.get("type") == "page" and "cloud.tencent.com" in t.get("url", ""):
            return t["webSocketDebuggerUrl"]
    raise SystemExit("page not found")

class CDP:
    def __init__(self):
        self.ws = websocket.create_connection(page_ws(), timeout=20, suppress_origin=True)
        self.i = 0
    def call(self, method, **params):
        self.i += 1
        self.ws.send(json.dumps({"id": self.i, "method": method, "params": params}))
        while True:
            msg = json.loads(self.ws.recv())
            if msg.get("id") == self.i:
                if "error" in msg: raise RuntimeError(msg["error"])
                return msg.get("result", {})
    def ev(self, expr):
        r = self.call("Runtime.evaluate", expression=expr, returnByValue=True, awaitPromise=True)
        res = r.get("result", {})
        if res.get("subtype") == "error":
            print("JS error:", res.get("description"))
        return res.get("value")

PATCH = r"""
(function(){
  if (window.__fccHooked) return 'already';
  window.__fccHooked = true;
  window.__fcc = [];
  var orig = String.fromCharCode;
  String.fromCharCode = function(){
    if (window.__fcc.length < 500000) {
      for (var i=0;i<arguments.length;i++) window.__fcc.push(arguments[i]);
    }
    return orig.apply(String, arguments);
  };
  return 'ok';
})()
"""

def main():
    c = CDP()
    print(c.ev("location.href"))
    print("patch:", c.ev(PATCH))
    print("clear:", c.ev("window.__fcc.length=0, 'cleared'"))
    c.ev("(()=>{const e=[...document.querySelectorAll('a.tpm-btn')].filter(e=>e.textContent.trim()==='立即体验')[0]; if(e){e.scrollIntoView({block:'center'}); e.click();} })()")
    for _ in range(30):
        time.sleep(0.5)
        if c.ev("!!window.TDC"): break
    time.sleep(1.0)
    print("TDC:", c.ev("!!window.TDC"), "chars:", c.ev("window.__fcc.length"))
    # Call getData/getInfo to ensure full program path executed
    print("data len:", c.ev("window.TDC?String(window.TDC.getData()).length:null"))
    print("info:", c.ev("window.TDC?JSON.stringify(window.TDC.getInfo()).slice(0,40):null"))
    codes = c.ev("window.__fcc.slice()")
    print("collected codes", len(codes) if codes else 0)
    if codes:
        json.dump(codes, open("fcc_codes.json", "w"))
        # printable runs >= 4
        runs = []; cur = []
        for v in codes:
            if isinstance(v, int) and 32 <= v <= 126:
                cur.append(chr(v))
            else:
                if len(cur) >= 4: runs.append(''.join(cur))
                cur = []
        if len(cur) >= 4: runs.append(''.join(cur))
        print("runs", len(runs))
        seen = set(); out = []
        for r in runs:
            if r not in seen:
                seen.add(r); out.append(r)
        for r in out[:250]:
            print(repr(r))

if __name__ == "__main__":
    main()
