/* 一次性取证脚本（纯页面内，DevTools Console 运行，不需要 CDP）。
 *
 * 背景：tdc 的 collect/eks 是 XTEA 形状的分组加密，密钥数组由 8 个"模块"
 * 闭包写入，静态推导出的两个候选数组都对不上真实密文，说明要么密钥数组
 * 在运行时另有写入，要么加密模型与反汇编理解有偏差。所以这里直接从堆上
 * 把"候选密钥数组"抓出来，再离线拟合算法。
 *
 * 用法：
 *   A. 整段粘进 Console 回车（只布钩子）。
 *   B. 重新拖一次滑块，让验证码完整走一遍。
 *   C. 执行：__capDump(queryObjects(Array))
 *      若怀疑是 TypedArray，再执行：__capDump(queryObjects(Uint32Array))
 *   D. 把输出的 CAP= 开头的整行发给我。
 *
 * 可选：__capSolve(queryObjects(Array)) 会额外按 XTEA 模型做一次在线校验，
 *       命中就直接输出 KEY=...（模型若不对会未命中，属正常）。
 */
(function () {
  'use strict';
  var cap = (window.__cap = { p: null, p2: null, c: null });

  var _apply = Function.prototype.apply;
  Function.prototype.apply = function (self, args) {
    try {
      var a0 = args && args[0];
      if (args && args.length === 2 && a0 && typeof a0 === 'object' && a0.length === 2 &&
          typeof a0[0] === 'number' && typeof a0[1] === 'number') {
        if (!cap.p) cap.p = [a0[0] >>> 0, a0[1] >>> 0];
        else if (!cap.p2) cap.p2 = [a0[0] >>> 0, a0[1] >>> 0];
      }
    } catch (e) {}
    return _apply.call(this, self, args);
  };

  var _btoa = window.btoa;
  window.btoa = function (s) {
    try {
      if (cap.p && !cap.c && typeof s === 'string' && s.length >= 16) {
        var h = [];
        for (var i = 0; i < 16; i++) h.push(s.charCodeAt(i) & 255);
        cap.c = h;
      }
    } catch (e) {}
    return _btoa.call(window, s);
  };

  function isBigNum(v) {
    return typeof v === 'number' && isFinite(v) && Math.abs(v) >= 1048576; // >= 2^20
  }
  function candOf(a) {
    if (!a || typeof a !== 'object') return null;
    var n = a.length;
    if (n !== 4 && n !== 8) return null;
    var out = [], big = 0;
    for (var i = 0; i < n; i++) {
      var v = a[i];
      if (typeof v !== 'number' || !isFinite(v) || v !== Math.floor(v)) return null;
      if (isBigNum(v)) big++;
      out.push(v >>> 0);
    }
    if (big < 2) return null;
    return out;
  }

  window.__capDump = function (roots) {
    if (!roots) return '请调用 __capDump(queryObjects(Array))';
    var seen = {}, list = [], n = roots.length >>> 0, scanned = 0;
    for (var i = 0; i < n; i++) {
      scanned++;
      try {
        var a = roots[i], c = candOf(a);
        if (!c) {
          if (a && a.length === 1) c = candOf(a[0]);
        }
        if (c) {
          var key = c.join(',');
          if (!seen[key]) { seen[key] = 1; list.push(c); }
        }
        if (list.length >= 3000) break;
      } catch (e) {}
    }
    var head = 'CAP scanned=' + scanned + ' cand=' + list.length +
               ' sampleP=' + JSON.stringify(cap.p) + ' sampleP2=' + JSON.stringify(cap.p2) +
               ' sampleC=' + JSON.stringify(cap.c);
    return head + '\nCAPLIST=' + JSON.stringify(list);
  };

  /* ---- 可选：在线按 XTEA(+C) 模型验证 ---- */
  var DELTA = 0x9e3779b9, C = [197402, 1907983, 0, 0];
  function enc(v0, v1, k) {
    var sum = 0;
    for (var i = 0; i < 32; i++) {
      v0 = (v0 + ((((v1 << 4) ^ (v1 >>> 5)) + v1) ^ (sum + k[sum & 3]))) >>> 0;
      sum = (sum + DELTA) >>> 0;
      v1 = (v1 + ((((v0 << 4) ^ (v0 >>> 5)) + v0) ^ (sum + k[(sum >>> 11) & 3]))) >>> 0;
    }
    return [v0 >>> 0, v1 >>> 0];
  }
  function eqBlock(r, bytes, off) {
    for (var i = 0; i < 4; i++) {
      if (((r[0] >>> (8 * i)) & 255) !== bytes[off + i]) return false;
      if (((r[1] >>> (8 * i)) & 255) !== bytes[off + 4 + i]) return false;
    }
    return true;
  }
  window.__capSolve = function (roots) {
    if (!cap.p || !cap.c) return '还没有样本：先布钩子，重新拖一次滑块，再执行';
    if (!roots) return '请调用 __capSolve(queryObjects(Array))';
    var n = roots.length >>> 0;
    for (var i = 0; i < n; i++) {
      var c;
      try { c = candOf(roots[i]) || (roots[i] && candOf(roots[i][0])); } catch (e) { continue; }
      if (!c || c.length !== 4) continue;
      var vs = [c, [(c[0] + C[0]) >>> 0, (c[1] + C[1]) >>> 0, c[2], c[3]],
                [(c[0] - C[0]) >>> 0, (c[1] - C[1]) >>> 0, c[2], c[3]]];
      for (var v = 0; v < 3; v++) {
        if (!eqBlock(enc(cap.p[0], cap.p[1], vs[v]), cap.c, 0)) continue;
        if (cap.p2 && !eqBlock(enc(cap.p2[0], cap.p2[1], vs[v]), cap.c, 8)) continue;
        window.__KEY = vs[v];
        return 'KEY=' + vs[v].map(function (x) { return '0x' + (x >>> 0).toString(16); }).join(',') +
               ' raw=' + JSON.stringify(c) + ' idx=' + i + ' variant=' + v;
      }
    }
    return '按 XTEA 模型未命中（预期内）；请用 __capDump(queryObjects(Array)) 导出候选';
  };

  return 'armed; 拖一次滑块后执行 __capDump(queryObjects(Array))';
})();
