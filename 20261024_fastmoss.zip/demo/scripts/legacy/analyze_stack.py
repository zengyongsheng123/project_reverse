# -*- coding: utf-8 -*-
"""Offline analyzer for stack_log.json (output of instrument_stack.py).

Goal: prove the cipher and recover the key array without any more live runs.

The instrumentation records, for every Function.prototype.apply call whose
first argument is a 2-element numeric array:
    v   = [w0, w1]   the pair the VM is about to encrypt (pre-mutation)
    key = the second argument, when it is a 4-element numeric array

and for every btoa call the raw input bytes (inHex = the ciphertext bytes).

If `v` pairs are genuine pre-encryption words, then for the right key K:
    xtea_enc(w0, w1, K)  ==  the 8 ciphertext bytes that follow in collect.
A wrong key gives a 2^-64 false-positive rate, so a single hit identifies K.

Run:  python analyze_stack.py [stack_log.json]
"""
import sys, json, itertools

DELTA = 0x9E3779B9
M = 0xFFFFFFFF
C = [197402, 1907983, 0, 0]
LIT = [")RiK", "Si^w", "761D", "HbRU"]


def xtea_enc(v0, v1, k):
    s = 0
    for _ in range(32):
        v0 = (v0 + (((((v1 << 4) & M) ^ (v1 >> 5)) + v1) & M ^ ((s + k[s & 3]) & M))) & M
        s = (s + DELTA) & M
        v1 = (v1 + (((((v0 << 4) & M) ^ (v0 >> 5)) + v0) & M ^ ((s + k[(s >> 11) & 3]) & M))) & M
    return v0, v1


def xtea_dec(v0, v1, k):
    s = (DELTA * 32) & M
    for _ in range(32):
        v1 = (v1 - (((((v0 << 4) & M) ^ (v0 >> 5)) + v0) & M ^ ((s + k[(s >> 11) & 3]) & M))) & M
        s = (s - DELTA) & M
        v0 = (v0 - (((((v1 << 4) & M) ^ (v1 >> 5)) + v1) & M ^ ((s + k[s & 3]) & M))) & M
    return v0, v1


def le(a, b):
    return (a & M).to_bytes(4, "little") + (b & M).to_bytes(4, "little")


def word(s, off, be=False):
    v = 0
    for i, ch in enumerate(s):
        x = (ord(ch) - off) & 0xFF
        v |= x << (8 * (3 - i) if be else 8 * i)
    return v & M


def literal_keys():
    out = []
    for off in (1, 33, 0, 32, 64):
        for perm in itertools.permutations(range(4)):
            k = [word(LIT[perm[i]], off) for i in range(4)]
            out.append(("lit off=%d perm=%s" % (off, perm), k))
            out.append(("lit off=%d perm=%s +C" % (off, perm), [(k[i] + C[i]) & M for i in range(4)]))
    return out


def main():
    path = sys.argv[1] if len(sys.argv) > 1 else "stack_log.json"
    d = json.load(open(path, encoding="utf-8"))
    print("collect len", len(d.get("data") or ""), "info len", len(d.get("info") or ""))

    ct = b""
    for ph in ("A", "B"):
        blk = d.get(ph) or {}
        segs = [bytes.fromhex(e.get("inHex") or "") for e in (blk.get("btoa") or [])]
        print("%s: btoa calls %d lens %s" % (ph, len(segs), [len(s) for s in segs]))
        if ph == "A":
            ct = b"".join(segs)
            for i, e in enumerate(blk.get("btoa") or []):
                print("   seg%d len=%d head=%s" % (i, e.get("inLen", -1), (e.get("inHex") or "")[:32]))
        calls = blk.get("calls") or []
        print("%s: apply calls %d" % (ph, len(calls)))
        if calls[:4]:
            for e in calls[:4]:
                print("   v=%s key=%s a1=%s" % ([hex(x) for x in e["v"]], e.get("key"), e.get("a1")))

    # candidate keys: explicit ones from calls, then arrays, then literals
    cands = []
    seen = set()
    for ph in ("A", "B"):
        for e in (d.get(ph) or {}).get("calls") or []:
            k = e.get("key")
            if k:
                t = tuple(k)
                if t not in seen:
                    seen.add(t)
                    cands.append(("call key", list(t)))
    for ph in ("A", "B"):
        for wid, st in ((d.get(ph) or {}).get("wstate") or {}).items():
            v = st.get("v") or []
            if len(v) == 4 and all(isinstance(x, (int, float)) for x in v):
                t = tuple(int(x) & M for x in v)
                if t not in seen:
                    seen.add(t)
                    cands.append(("wstate#%s" % wid, list(t)))
    for ph in ("A", "B"):
        for a in (d.get(ph) or {}).get("arrays") or []:
            v = a.get("v") or []
            if a.get("len") == 4 and all(isinstance(x, (int, float)) for x in v):
                t = tuple(int(x) & M for x in v)
                if t not in seen:
                    seen.add(t)
                    cands.append(("array#%s" % a.get("i"), list(t)))
    cands += [(n, k) for n, k in literal_keys() if tuple(k) not in seen]

    pairs = []
    for ph in ("A", "B"):
        for e in (d.get(ph) or {}).get("calls") or []:
            pairs.append((e["v"][0], e["v"][1]))
    print("\ncandidate keys %d, plaintext pairs %d, ciphertext bytes %d"
          % (len(cands), len(pairs), len(ct)))

    print("\n-- key search: does enc(pair) appear in the ciphertext? --")
    hits = 0
    for name, k in cands:
        ok = 0
        first = None
        for (w0, w1) in pairs[:40]:
            bs = le(*xtea_enc(w0, w1, k))
            p = ct.find(bs)
            if p >= 0:
                ok += 1
                if first is None:
                    first = (hex(w0), hex(w1), p)
        if ok:
            hits += 1
            print("  HIT %-28s key=%s  matches=%d/%d first=%s"
                  % (name, [hex(x) for x in k], ok, min(40, len(pairs)), first))
    if not hits:
        print("  no key candidate matched")

    if hits:
        return
    print("\n-- fallback: printable ratio after decrypting the whole stream --")
    for name, k in cands[:1200]:
        out = bytearray()
        for i in range(0, len(ct) - 7, 8):
            w0 = int.from_bytes(ct[i:i + 4], "little")
            w1 = int.from_bytes(ct[i + 4:i + 8], "little")
            out += le(*xtea_dec(w0, w1, k))
        r = sum(1 for x in out if 32 <= x < 127) / max(1, len(out))
        if r > 0.8:
            print("  printable %.3f  %s  key=%s" % (r, name, [hex(x) for x in k]))
            print("   ", bytes(x if 32 <= x < 127 else 46 for x in out[:120]).decode())


if __name__ == "__main__":
    main()
