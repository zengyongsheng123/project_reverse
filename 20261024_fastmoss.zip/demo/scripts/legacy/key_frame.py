# -*- coding: utf-8 -*-
"""Break on the cipher trampoline and read its upvalue register map A[7][0]
(the live key array) from the closure scope.

Usage: python key_frame.py
"""
import json
import time

import websocket

PORT = 9222


def targets():
    import http.client
    c = http.client.HTTPConnection("127.0.0.1", PORT, timeout=5)
    c.request("GET", "/json")
    return json.loads(c.getresponse().read())


class CDP:
    def __init__(self, url):
        self.ws = websocket.create_connection(url, timeout=180, suppress_origin=True)
        self.i = 0
        self.q = []

    def send(self, method, **p):
        self.i += 1
        self.ws.send(json.dumps({"id": self.i, "method": method, "params": p}))
        return self.i

    def call(self, method, timeout=60, **p):
        mid = self.send(method, **p)
        end = time.time() + timeout
        while True:
            self.ws.settimeout(max(0.5, end - time.time()))
            m = json.loads(self.ws.recv())
            if m.get("id") == mid:
                if "error" in m:
                    raise RuntimeError("%s -> %s" % (method, m["error"]))
                return m.get("result", {})
            if m.get("method") == "Debugger.paused":
                self.q.append(m)

    def next_pause(self, timeout=5):
        if self.q:
            return self.q.pop(0)
        self.ws.settimeout(timeout)
        return json.loads(self.ws.recv())

    def ev(self, expr, timeout=60):
        r = self.call("Runtime.evaluate", expression=expr, returnByValue=True,
                      awaitPromise=True, timeout=timeout)
        return r.get("result", {}).get("value")


FRAME_EXPR = ("(function(){try{"
              "var r={S:(typeof S!=='undefined'?S:null),B:(typeof B!=='undefined'?JSON.stringify(B):null),A:A.length};"
              "r.a7=(A[7]&&A[7].length!==undefined)?A[7].length:typeof A[7];"
              "try{r.k=JSON.stringify(A[7]&&A[7][0]&&Array.prototype.slice.call(A[7][0]))}catch(e){r.k='e1'} "
              "try{r.k1=JSON.stringify(A[7]&&A[7][1]&&Array.prototype.slice.call(A[7][1]))}catch(e){r.k1='e1'} "
              "try{r.a3=JSON.stringify(A[3])}catch(e){r.a3='e'} "
              "try{r.a2=JSON.stringify(A[2])}catch(e){r.a2='e'} "
              "try{r.a4=JSON.stringify(A[4])}catch(e){r.a4='e'} "
              "try{r.a5=JSON.stringify(A[5])}catch(e){r.a5='e'} "
              "try{r.a6=JSON.stringify(A[6])}catch(e){r.a6='e'} "
              "return JSON.stringify(r)}catch(e){return 'ERR '+String(e)}"
              "})()")


def main():
    pg = [t for t in targets() if t.get("type") == "page"][0]
    c = CDP(pg["webSocketDebuggerUrl"])
    c.call("Runtime.enable")
    c.call("Debugger.enable")
    time.sleep(0.3)
    proto = c.call("Runtime.evaluate", expression="Function.prototype")["result"]["objectId"]
    objs = c.call("Runtime.queryObjects", prototypeObjectId=proto)["objects"]["objectId"]
    finder = ("function(){var out=[];for(var i=0;i<this.length;i++){try{"
              "if(Function.prototype.toString.call(this[i]).indexOf('__TENCENT_CHAOS_VM')>=0)"
              "out.push(this[i])}catch(e){}}return out}")
    r = c.call("Runtime.callFunctionOn", objectId=objs, functionDeclaration=finder,
               returnByValue=False)
    props = c.call("Runtime.getProperties", objectId=r["result"]["objectId"], ownProperties=True)
    fns = [p["value"]["objectId"] for p in props.get("result", [])
           if p.get("name", "").isdigit() and (p.get("value") or {}).get("objectId")]
    bps = []
    for oid in fns:
        try:
            bid = c.call("Debugger.setBreakpointOnFunctionCall", objectId=oid).get("breakpointId")
            bps.append(bid)
        except RuntimeError:
            pass
    print("bps", len(bps))
    mid = c.send("Runtime.evaluate", expression="(function(){return TDC.getData()})()",
                 returnByValue=True)
    seen = set()
    got = []
    end = time.time() + 60
    while time.time() < end and len(got) < 1:
        m = c.next_pause(5)
        if m.get("id") == mid:
            print("done", json.dumps(m)[:300])
            break
        if m.get("method") != "Debugger.paused":
            continue
        cf = m["params"]["callFrames"][0]
        try:
            rr = c.call("Debugger.evaluateOnCallFrame", callFrameId=cf["callFrameId"],
                        expression=FRAME_EXPR, returnByValue=True, silent=True)
            v = (rr.get("result") or {}).get("value")
            if v and v not in seen and '"S":7154' in v:
                seen.add(v)
                got.append(v)
                print(v)
        except Exception as e:
            print("evalerr", str(e)[:100])
        if got:
            for b in bps:
                try:
                    c.call("Debugger.removeBreakpoint", breakpointId=b)
                except Exception:
                    pass
            bps = []
        c.call("Debugger.resume")
    for b in bps:
        try:
            c.call("Debugger.removeBreakpoint", breakpointId=b)
        except Exception:
            pass
    print("collected", len(got))


if __name__ == "__main__":
    main()
