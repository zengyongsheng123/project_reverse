(function(){
  if (window.__hr) return 'has';
  var D = window.__hr = {rec: false, v: [], fc: 0, n: 0, other: 0};
  var W = Function.prototype.apply;
  Function.prototype.apply = function(self, args){
    var r = W.call(this, self, args);
    try{
      D.n++;
      if (D.rec && args && args.length === 2 && args[0] && typeof args[0] === 'object' &&
          typeof args[0].length === 'number' && args[0].length === 2 && D.v.length < 200){
        var o = {t0: typeof args[0][0], t1: typeof args[0][1],
                 v0: typeof args[0][0] === 'number' ? (args[0][0] >>> 0) : String(args[0][0]).slice(0,30),
                 v1: typeof args[0][1] === 'number' ? (args[0][1] >>> 0) : String(args[0][1]).slice(0,30),
                 a1: (args[1] && typeof args[1] === 'object') ? Array.prototype.slice.call(args[1], 0).map(function(x){return typeof x === 'number' ? x : typeof x}) : typeof args[1],
                 self: (typeof this === 'function') ? String(this).slice(0, 50) : typeof this};
        D.v.push(o);
      }
    }catch(e){}
    return r;
  };
  var ofc = String.fromCharCode;
  String.fromCharCode = function(){ try{ if (arguments.length === 4) D.fc++; }catch(e){} return ofc.apply(String, arguments); };
  var oa = Array.prototype.push;
  return 'ok';
})();
