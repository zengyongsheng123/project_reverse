# -*- coding: utf-8 -*-
"""List every execution context / frame of the page target, including
same-process cross-origin iframes, and report which one runs tdc.js."""
import http.client
import json

import websocket

PORT = 9222


def page_ws():
    c = http.client.HTTPConnection("127.0.0.1", PORT, timeout=5)
    c.request("GET", "/json")
    for t in json.loads(c.getresponse().read()):
        if t.get("type") == "page":
            return t["webSocketDebuggerUrl"]


class CDP:
    def __init__(self, url):
        self.ws = websocket.create_connection(url, timeout=30, suppress_origin=True)
        self.i = 0
        self.ctx = []

    def call(self, method, **params):
        self.i += 1
        mid = self.i
        self.ws.send(json.dumps({"id": mid, "method": method, "params": params}))
        while True:
            msg = json.loads(self.ws.recv())
            if msg.get("id") == mid:
                if "error" in msg:
                    raise RuntimeError("%s -> %s" % (method, msg["error"]))
                return msg.get("result", {})
            if msg.get("method") == "Runtime.executionContextCreated":
                self.ctx.append(msg["params"]["context"])
            if msg.get("method") == "Runtime.executionContextDestroyed":
                pass

    def ev(self, expr, ctx=None, by_value=True):
        p = dict(expression=expr, returnByValue=by_value, awaitPromise=True)
        if ctx is not None:
            p["contextId"] = ctx
        return self.call("Runtime.evaluate", **p).get("result", {})


def main():
    c = CDP(page_ws())
    c.call("Runtime.enable")
    ft = c.call("Page.getFrameTree")
    print(json.dumps(ft, ensure_ascii=False)[:1500])
    print("contexts:", len(c.ctx))
    for e in c.ctx:
        aux = e.get("auxData", {})
        print(" ctx", e["id"], e.get("origin"), "frame", aux.get("frameId"),
              "default" if aux.get("isDefault") else "", "name", e.get("name"))
    # probe each context for tdc globals / key arrays
    for e in c.ctx:
        cid = e["id"]
        r = c.ev("(function(){var out={href:0,tdc:0,vm:0};try{out.href=location.href;"
                 "out.tdc=!!window.__TENCENT_CHAOS_VM;"
                 "out.keys=Object.keys(window).filter(function(k){return /tdc|chaos|TENCENT/i.test(k)})}catch(x){out.err=String(x)}return out})()", cid)
        print("ctx", cid, json.dumps(r.get("value"), ensure_ascii=False)[:300])
    # arrays in every context
    proto = c.call("Runtime.evaluate", expression="Array.prototype",
                   contextId=c.ctx[0]["id"] if c.ctx else None)
    print("proto ok")


if __name__ == "__main__":
    main()
