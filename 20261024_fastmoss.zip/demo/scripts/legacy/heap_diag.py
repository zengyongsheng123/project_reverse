# -*- coding: utf-8 -*-
"""Diagnostic: understand heap snapshot node/edge typing before filtering."""
import json, sys, collections

d = json.load(open(sys.argv[1], encoding="utf-8"))
nodes, edges, strings = d["nodes"], d["edges"], d["strings"]
NF = 6
n_nodes = len(nodes) // NF
prefix = [0] * (n_nodes + 1)
acc = 0
for i in range(n_nodes):
    prefix[i] = acc
    acc += nodes[i * NF + 4]
prefix[n_nodes] = acc

types = collections.Counter()
names = collections.Counter()
for i in range(n_nodes):
    types[nodes[i * NF]] += 1
    names[strings[nodes[i * NF + 1]]] += 1
print("node type histogram:", dict(types))
print("name histogram top:", names.most_common(30))

# distribution of edge counts for type 1 (array) nodes with small counts
ec_hist = collections.Counter()
for i in range(n_nodes):
    if nodes[i * NF] == 1:
        ec_hist[min(nodes[i * NF + 4], 20)] += 1
print("array-node edge_count hist (cap 20):", dict(sorted(ec_hist.items())))

# inspect a few type-1 nodes with edge_count 4..8
shown = 0
for i in range(n_nodes):
    if nodes[i * NF] != 1:
        continue
    ec = nodes[i * NF + 4]
    if not (4 <= ec <= 8):
        continue
    e0 = prefix[i]
    desc = []
    for e in range(e0, e0 + ec):
        et, enm, to = edges[e * 3], edges[e * 3 + 1], edges[e * 3 + 2]
        tt = nodes[to]
        tn = strings[nodes[to + 1]]
        desc.append((et, strings[enm] if et in (0, 2, 3, 4, 6) else enm, tt, tn[:20]))
    print("node", i, "edges", desc)
    shown += 1
    if shown >= 8:
        break
