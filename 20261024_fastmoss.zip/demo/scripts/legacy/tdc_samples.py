# -*- coding: utf-8 -*-
"""Reload page N times, capture raw TDC.getData()/getInfo() at idle (no interaction)."""
import json, time, sys, http.client, urllib.parse, base64
import websocket

PORT = 9222

def page_ws():
    conn = http.client.HTTPConnection("127.0.0.1", PORT, timeout=5)
    conn.request("GET", "/json")
    for t in json.loads(conn.getresponse().read()):
        if t.get("type") == "page" and "cloud.tencent.com" in t.get("url", ""):
            return t["webSocketDebuggerUrl"]
    raise SystemExit("page not found")

class CDP:
    def __init__(self):
        self.ws = websocket.create_connection(page_ws(), timeout=20, suppress_origin=True)
        self.i = 0
    def call(self, method, **params):
        self.i += 1
        self.ws.send(json.dumps({"id": self.i, "method": method, "params": params}))
        while True:
            msg = json.loads(self.ws.recv())
            if msg.get("id") == self.i:
                if "error" in msg: raise RuntimeError(msg["error"])
                return msg.get("result", {})
    def ev(self, expr):
        r = self.call("Runtime.evaluate", expression=expr, returnByValue=True, awaitPromise=True)
        res = r.get("result", {})
        if res.get("subtype") == "error": raise RuntimeError(res.get("description"))
        return res.get("value")

def main():
    n = int(sys.argv[1]) if len(sys.argv) > 1 else 3
    c = CDP()
    out = []
    for k in range(n):
        c.call("Page.navigate", url="https://cloud.tencent.com/product/captcha")
        time.sleep(4.0)
        # open the slider demo to trigger captcha init
        c.ev("(()=>{const e=[...document.querySelectorAll('a.tpm-btn')].filter(e=>e.textContent.trim()==='立即体验')[0]; if(e){e.scrollIntoView({block:'center'}); e.click();} })()")
        for _ in range(30):
            ok = c.ev("!!(window.TDC)")
            if ok: break
            time.sleep(0.5)
        time.sleep(0.8)
        info = c.ev("window.TDC ? {data: window.TDC.getData(), info: window.TDC.getInfo()} : null")
        if not info:
            print("no TDC", k); continue
        raw = info["data"]
        out.append({
            "raw": raw,
            "decoded": urllib.parse.unquote(raw),
            "eks": info["info"]["info"],
            "tokenid": info["info"]["tokenid"],
            "ua": c.ev("navigator.userAgent"),
            "screen": c.ev("[screen.width,screen.height,screen.availWidth,screen.availHeight,devicePixelRatio]"),
        })
        print(k, "rawlen", len(raw), "tokenid", info["info"]["tokenid"], "ekslen", len(info["info"]["info"]))
    json.dump(out, open("tdc_samples.json", "w"), indent=1)
    # compare
    if len(out) >= 2:
        a, b = out[0]["decoded"], out[1]["decoded"]
        print("decoded lens", len(a), len(b))
        same = 0
        for i in range(min(len(a), len(b))):
            if a[i] == b[i]: same += 1
            else:
                print("first diff at", i, repr(a[max(0,i-10):i+10]), repr(b[max(0,i-10):i+10])); break
        print("prefix equal chars", same)
        # byte-level
        ba = base64.b64decode(a + "=" * ((4 - len(a) % 4) % 4)) if len(a) % 4 == 0 else None
        bb = base64.b64decode(b + "=" * ((4 - len(b) % 4) % 4)) if len(b) % 4 == 0 else None
        if ba and bb:
            print("bytes", len(ba), len(bb), "equal prefix", next((i for i in range(min(len(ba),len(bb))) if ba[i]!=bb[i]), min(len(ba),len(bb))))
            open("collect_a.bin","wb").write(ba); open("collect_b.bin","wb").write(bb)

if __name__ == "__main__":
    main()
