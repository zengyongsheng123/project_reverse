# -*- coding: utf-8 -*-
"""Capture full JSON.stringify/btoa payloads from the TDC VM right before getData()."""
import json, time, http.client
import websocket

PORT = 9222

def page_ws():
    conn = http.client.HTTPConnection("127.0.0.1", PORT, timeout=5)
    conn.request("GET", "/json")
    for t in json.loads(conn.getresponse().read()):
        if t.get("type") == "page" and "cloud.tencent.com" in t.get("url", ""):
            return t["webSocketDebuggerUrl"]
    raise SystemExit("page not found")

class CDP:
    def __init__(self):
        self.ws = websocket.create_connection(page_ws(), timeout=20, suppress_origin=True)
        self.i = 0
    def call(self, method, **params):
        self.i += 1
        self.ws.send(json.dumps({"id": self.i, "method": method, "params": params}))
        while True:
            msg = json.loads(self.ws.recv())
            if msg.get("id") == self.i:
                if "error" in msg: raise RuntimeError(msg["error"])
                return msg.get("result", {})
    def ev(self, expr):
        r = self.call("Runtime.evaluate", expression=expr, returnByValue=True, awaitPromise=True)
        res = r.get("result", {})
        if res.get("subtype") == "error": print("JSERR", res.get("description"))
        return res.get("value")

PATCH = r"""
(function(){
  if (window.__jp) return 'already';
  window.__jp = []; window.__jpStat = {n:0, big:0};
  var origStr = JSON.stringify, origBtoa = window.btoa;
  JSON.stringify = function(v, r, s){
    var out = origStr.apply(JSON, arguments);
    window.__jpStat.n++;
    try {
      if (typeof out === 'string' && out.length > 400) {
        window.__jpStat.big++;
        if (window.__jpStat.big <= 40) window.__jp.push({kind:'stringify', len: out.length, data: out.slice(0, 60000)});
      }
    } catch(e){}
    return out;
  };
  window.btoa = function(s){
    var out = origBtoa.apply(window, arguments);
    try { if (String(s).length > 200) window.__jp.push({kind:'btoa', len:String(s).length, data:String(s).slice(0,1000)}); } catch(e){}
    return out;
  };
  return 'ok';
})()
"""

def main():
    c = CDP()
    c.call("Page.enable")
    c.call("Page.navigate", url="https://cloud.tencent.com/product/captcha")
    time.sleep(5)
    print("patch", c.ev(PATCH))
    c.ev("(()=>{const e=[...document.querySelectorAll('a.tpm-btn')].filter(e=>e.textContent.trim()==='立即体验')[0]; if(e){e.scrollIntoView({block:'center'}); e.click();} })()")
    for _ in range(30):
        time.sleep(0.5)
        if c.ev("!!window.TDC"): break
    time.sleep(0.8)
    print("TDC", c.ev("!!window.TDC"), "stat", c.ev("window.__jpStat"))
    # clear logs right before the final getData call to isolate plaintext
    c.ev("window.__jp.length=0")
    d = c.ev("window.TDC?String(window.TDC.getData()):null")
    i = c.ev("window.TDC?String(window.TDC.getInfo().info):null")
    print("data", len(d or ""), "info", len(i or ""))
    logs = c.ev("window.__jp.slice()") or []
    json.dump({"data": d, "info": i, "logs": logs}, open("json_log.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print("logs", len(logs))
    for e in logs:
        print(e["kind"], e["len"], repr(e["data"][:200]))

if __name__ == "__main__":
    main()
