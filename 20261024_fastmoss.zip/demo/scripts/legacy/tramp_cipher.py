# -*- coding: utf-8 -*-
"""Break on every Chaos-VM trampoline invocation during TDC.getData() and,
for calls whose arguments look like the cipher call (first arg = 2-element
numeric array, second = 4-element numeric array), dump the full scope chain.

Usage: python tramp_cipher.py
Writes tramp_cipher.json
"""
import http.client
import json
import sys
import time

import websocket

PORT = 9222
MAXP = int(sys.argv[1]) if len(sys.argv) > 1 else 4000


def targets():
    c = http.client.HTTPConnection("127.0.0.1", PORT, timeout=5)
    c.request("GET", "/json")
    return json.loads(c.getresponse().read())


class CDP:
    def __init__(self, url):
        self.ws = websocket.create_connection(url, timeout=180, suppress_origin=True)
        self.i = 0
        self.events = []
        self.auto_resume = False

    def send(self, method, **p):
        self.i += 1
        self.ws.send(json.dumps({"id": self.i, "method": method, "params": p}))
        return self.i

    def recv(self, timeout):
        self.ws.settimeout(timeout)
        return json.loads(self.ws.recv())

    def call(self, method, timeout=60, **p):
        mid = self.send(method, **p)
        end = time.time() + timeout
        while True:
            m = self.recv(max(0.5, end - time.time()))
            if m.get("id") == mid:
                if "error" in m:
                    raise RuntimeError("%s -> %s" % (method, m["error"]))
                return m.get("result", {})
            if "method" in m:
                self.events.append(m)
                if m["method"] == "Debugger.paused" and self.auto_resume:
                    self.i += 1
                    self.ws.send(json.dumps({"id": self.i, "method": "Debugger.resume", "params": {}}))


SHAPE = r"""
function(A){
  try{
    function isNumArr(a,n){ if(!a||typeof a!=='object'||a.length!==n)return false;
      for(var i=0;i<n;i++) if(typeof a[i]!=='number')return false; return true; }
    var out={n:A.length};
    if (isNumArr(A[0],2) && isNumArr(A[1],4)) {
      out.hit=1;
      out.a0=[A[0][0]>>>0,A[0][1]>>>0];
      out.a1=[A[1][0]>>>0,A[1][1]>>>0,A[1][2]>>>0,A[1][3]>>>0];
    }
    var shapes=[];
    for(var i=0;i<A.length && i<6;i++){
      var v=A[i], t=typeof v;
      if(v&&t==='object'&&typeof v.length==='number'){
        var e=[];for(var j=0;j<Math.min(v.length,6);j++)e.push(typeof v[j]==='number'?(v[j]>>>0):(v[j]===undefined?'u':typeof v[j]));
        shapes.push('['+e.join(',')+']len'+v.length);
      } else if(t==='number') shapes.push(String(v>>>0));
      else if(t==='string') shapes.push('s:'+v.slice(0,20));
      else shapes.push(t);
    }
    out.shapes=shapes;
    return JSON.stringify(out);
  }catch(e){ return 'E:'+e; }
}
"""

SCOPE_SUM = r"""
function(){
  var out={}, names=Object.getOwnPropertyNames(this);
  for(var i=0;i<names.length;i++){
    var k=names[i], v;
    try{ v=this[k]; }catch(e){ continue; }
    var t=typeof v;
    if(t==='number') out[k]={t:'n',v:v>>>0};
    else if(t==='string') out[k]={t:'s',l:v.length,pre:v.slice(0,64)};
    else if(v&&t==='object'){
      var o={t:'o',tag:Object.prototype.toString.call(v)};
      if(typeof v.length==='number'){
        o.len=v.length; var a=[];
        for(var j=0;j<Math.min(v.length,12);j++){
          var e=v[j]; a.push(typeof e==='number'?(e>>>0):(e===undefined?'u':typeof e));
        }
        o.e=a;
      }
      out[k]=o;
    } else out[k]={t:t};
  }
  return JSON.stringify(out);
}
"""


def ev_frame(c, cf, expr):
    r = c.call("Debugger.evaluateOnCallFrame", callFrameId=cf["callFrameId"],
               expression=expr, returnByValue=True, silent=True)
    return r.get("result", {}).get("value")


def dump_frame(c, cf):
    rec = {"fn": cf.get("functionName"), "url": (cf.get("url") or "")[-50:],
           "line": cf.get("location", {}).get("lineNumber"),
           "col": cf.get("location", {}).get("columnNumber"), "scopes": []}
    for sc in cf.get("scopeChain", []):
        e = {"type": sc.get("type")}
        oid = (sc.get("object") or {}).get("objectId")
        if oid and sc.get("type") in ("local", "closure", "block", "catch", "with"):
            try:
                r = c.call("Runtime.callFunctionOn", objectId=oid,
                           functionDeclaration=SCOPE_SUM, returnByValue=True)
                e["vars"] = r.get("result", {}).get("value")
            except Exception as ex:
                e["vars"] = "ERR " + str(ex)[:100]
        rec["scopes"].append(e)
    return rec


def main():
    pg = [t for t in targets() if t.get("type") == "page"][0]
    c = CDP(pg["webSocketDebuggerUrl"])
    c.call("Runtime.enable")
    c.auto_resume = True
    c.call("Debugger.enable")
    time.sleep(0.4)
    c.auto_resume = False
    proto = c.call("Runtime.evaluate", expression="Function.prototype")["result"]["objectId"]
    objs = c.call("Runtime.queryObjects", prototypeObjectId=proto)["objects"]["objectId"]
    finder = ("function(){var out=[];for(var i=0;i<this.length;i++){try{"
              "if(Function.prototype.toString.call(this[i]).indexOf('__TENCENT_CHAOS_VM')>=0)"
              "out.push(this[i])}catch(e){}}return out.slice(0,8)}")
    r = c.call("Runtime.callFunctionOn", objectId=objs, functionDeclaration=finder,
               returnByValue=False)
    props = c.call("Runtime.getProperties", objectId=r["result"]["objectId"], ownProperties=True)
    fns = [p["value"]["objectId"] for p in props.get("result", []) if p.get("name", "").isdigit()]
    print("trampolines:", len(fns))
    bps = []
    for oid in fns:
        try:
            bps.append(c.call("Debugger.setBreakpointOnFunctionCall", objectId=oid).get("breakpointId"))
        except RuntimeError as e:
            if "already exists" not in str(e):
                raise
    print("breakpoints:", bps)
    mid = c.send("Runtime.evaluate", expression="TDC.getData().length", returnByValue=True)
    hits = []
    counts = {"pauses": 0, "shape": 0}
    shapes = {}
    done = None
    end = time.time() + 180
    while time.time() < end:
        try:
            m = c.recv(1.0)
        except Exception:
            continue
        if m.get("id") == mid:
            done = m
            break
        if m.get("method") != "Debugger.paused":
            c.events.append(m)
            continue
        counts["pauses"] += 1
        if counts["pauses"] > MAXP:
            c.call("Debugger.resume")
            continue
        cf = m["params"]["callFrames"][0]
        try:
            sh = ev_frame(c, cf, "(" + SHAPE + ")(arguments)")
            sj = json.loads(sh) if sh else {}
        except Exception:
            sj = {}
        key = str(sj.get("shapes"))
        shapes[key] = shapes.get(key, 0) + 1
        if sj.get("hit"):
            counts["shape"] += 1
            if len(hits) < 12:
                h = {"shape": sj, "frames": [dump_frame(c, f) for f in m["params"]["callFrames"][:4]]}
                hits.append(h)
                print("HIT", len(hits), sj.get("a0"), sj.get("a1"))
        c.call("Debugger.resume")
    print("pauses:", counts["pauses"], "cipher-shaped:", counts["shape"], "eval done:", bool(done))
    if done:
        print("len:", done.get("result", {}).get("result", {}).get("value"))
    for b in bps:
        try:
            c.call("Debugger.removeBreakpoint", breakpointId=b)
        except Exception:
            pass
    json.dump({"hits": hits, "counts": counts, "shapes": shapes},
              open("tramp_cipher.json", "w"), ensure_ascii=False, indent=1)
    print("wrote tramp_cipher.json; distinct arg shapes:", len(shapes))
    for k, v in sorted(shapes.items(), key=lambda x: -x[1])[:15]:
        print(v, k[:200])


if __name__ == "__main__":
    main()
