# -*- coding: utf-8 -*-
"""Log every btoa call (full input) and JSON.stringify big outputs; dump collect/info too."""
import json, time, base64, http.client
import websocket

PORT = 9222

def page_ws():
    conn = http.client.HTTPConnection("127.0.0.1", PORT, timeout=5)
    conn.request("GET", "/json")
    for t in json.loads(conn.getresponse().read()):
        if t.get("type") == "page" and "cloud.tencent.com" in t.get("url", ""):
            return t["webSocketDebuggerUrl"]
    raise SystemExit("page not found")

class CDP:
    def __init__(self):
        self.ws = websocket.create_connection(page_ws(), timeout=20, suppress_origin=True)
        self.i = 0
    def call(self, method, **params):
        self.i += 1
        self.ws.send(json.dumps({"id": self.i, "method": method, "params": params}))
        while True:
            msg = json.loads(self.ws.recv())
            if msg.get("id") == self.i:
                if "error" in msg: raise RuntimeError(msg["error"])
                return msg.get("result", {})
    def ev(self, expr):
        r = self.call("Runtime.evaluate", expression=expr, returnByValue=True, awaitPromise=True)
        res = r.get("result", {})
        if res.get("subtype") == "error": print("JSERR", res.get("description"))
        return res.get("value")

PATCH = r"""
(function(){
  if (window.__bt) return 'already';
  window.__bt = {btoa:[], str:[]};
  var origStr = JSON.stringify, origBtoa = window.btoa;
  JSON.stringify = function(){
    var out = origStr.apply(JSON, arguments);
    try { if (typeof out === 'string' && out.length > 1000 && window.__bt.str.length < 60)
      window.__bt.str.push({len: out.length, data: out.slice(0, 60000)}); } catch(e){}
    return out;
  };
  window.btoa = function(s){
    var out = origBtoa.apply(window, arguments);
    try {
      if (window.__bt.btoa.length < 60)
        window.__bt.btoa.push({inLen: String(s).length, inB64: origBtoa.call(window, String(s)), out: out});
    } catch(e){}
    return out;
  };
  return 'ok';
})()
"""

def main():
    c = CDP()
    c.call("Page.enable")
    c.call("Page.navigate", url="https://cloud.tencent.com/product/captcha")
    time.sleep(5)
    print("patch", c.ev(PATCH))
    c.ev("(()=>{const e=[...document.querySelectorAll('a.tpm-btn')].filter(e=>e.textContent.trim()==='立即体验')[0]; if(e){e.scrollIntoView({block:'center'}); e.click();} })()")
    for _ in range(30):
        time.sleep(0.5)
        if c.ev("!!window.TDC"): break
    time.sleep(0.8)
    print("TDC", c.ev("!!window.TDC"))
    data = c.ev("window.TDC?String(window.TDC.getData()):null")
    info = c.ev("window.TDC?String(window.TDC.getInfo().info):null")
    bt = c.ev("window.__bt") or {}
    json.dump({"data": data, "info": info, "bt": bt}, open("btoa_log.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print("data len", len(data or ""), "info len", len(info or ""))
    bl = bt.get("btoa", [])
    print("btoa calls", len(bl))
    for i, e in enumerate(bl):
        print(i, "inLen", e["inLen"], "outLen", len(e["out"]), "out", e["out"][:50])
    # relationship
    import urllib.parse
    dec = urllib.parse.unquote(data or "")
    print("collect starts", dec[:40])
    print("info in collect?", (info or "x")[:20] in dec)
    for i, e in enumerate(bl):
        print(i, "btoa-out substring of collect?", e["out"][:20] in dec, "prefix", e["out"][:16])

if __name__ == "__main__":
    main()
