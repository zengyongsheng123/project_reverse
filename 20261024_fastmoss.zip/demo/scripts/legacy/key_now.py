# -*- coding: utf-8 -*-
"""Read the cipher key (closure upvalue) from the CURRENT page build.

The cipher trampoline is called once per 8-byte block with a single
[w0,w1] argument.  Its closure scope holds the register file: an array of
length 8 whose slot 7 is a one-element box containing the 4-word key.
Variable names are re-randomised per build, so the scope is scanned
generically.

Usage: python key_now.py [n_hits]
Writes key_now.json
"""
import http.client
import json
import sys
import time

import websocket

PORT = 9222
NHIT = int(sys.argv[1]) if len(sys.argv) > 1 else 2


def targets():
    c = http.client.HTTPConnection("127.0.0.1", PORT, timeout=5)
    c.request("GET", "/json")
    return json.loads(c.getresponse().read())


class CDP:
    def __init__(self, url):
        self.ws = websocket.create_connection(url, timeout=180, suppress_origin=True)
        self.i = 0
        self.events = []

    def send(self, method, **p):
        self.i += 1
        self.ws.send(json.dumps({"id": self.i, "method": method, "params": p}))
        return self.i

    def recv(self, timeout):
        self.ws.settimeout(timeout)
        return json.loads(self.ws.recv())

    def call(self, method, timeout=60, **p):
        mid = self.send(method, **p)
        end = time.time() + timeout
        while True:
            m = self.recv(max(0.5, end - time.time()))
            if m.get("id") == mid:
                if "error" in m:
                    raise RuntimeError("%s -> %s" % (method, m["error"]))
                return m.get("result", {})
            if "method" in m:
                self.events.append(m)


SHAPE = r"""
function(AR){
  try{
    if(AR.length===1 && AR[0] && typeof AR[0]==='object' && AR[0].length===2 &&
       typeof AR[0][0]==='number' && typeof AR[0][1]==='number')
      return JSON.stringify([AR[0][0]>>>0, AR[0][1]>>>0]);
  }catch(e){}
  return '';
}
"""

DEEP = r"""
function(){
  var v=this, out={tag:Object.prototype.toString.call(v)};
  if(typeof v.length==='number'){
    out.len=v.length; out.e=[];
    for(var i=0;i<Math.min(v.length,16);i++){
      var x=v[i];
      if(typeof x==='number') out.e.push(x>>>0);
      else if(x&&typeof x==='object'&&typeof x.length==='number'){
        var q=[];for(var j=0;j<Math.min(x.length,8);j++){var y=x[j];
          q.push(typeof y==='number'?(y>>>0):(y===undefined?'u':typeof y))}
        out.e.push({len:x.length,e:q});
      } else out.e.push(x===undefined?'u':typeof x);
    }
  }
  return JSON.stringify(out);
}
"""


def dump_scopes(c, cf):
    scopes = []
    for sc in cf.get("scopeChain", []):
        if sc.get("type") not in ("closure", "local", "block"):
            continue
        oid = (sc.get("object") or {}).get("objectId")
        if not oid:
            continue
        props = c.call("Runtime.getProperties", objectId=oid, ownProperties=True)
        vars_ = {}
        for p in props.get("result", []):
            name = p.get("name")
            val = p.get("value") or {}
            if not name:
                continue
            if val.get("type") == "number":
                vars_[name] = {"n": val.get("value")}
            elif val.get("type") == "object" and val.get("objectId"):
                try:
                    r = c.call("Runtime.callFunctionOn", objectId=val["objectId"],
                               functionDeclaration=DEEP, returnByValue=True)
                    vars_[name] = json.loads(r.get("result", {}).get("value") or "{}")
                except Exception as e:
                    vars_[name] = {"err": str(e)[:60]}
        scopes.append({"type": sc.get("type"), "vars": vars_})
    return scopes


def find_key(scopes):
    """register file: array of len 8, slot 7 = [4-number array]"""
    keys = []
    for sc in scopes:
        for name, d in sc["vars"].items():
            if not isinstance(d, dict) or d.get("len") != 8:
                continue
            e = d.get("e") or []
            if len(e) > 7 and isinstance(e[7], dict):
                inner = e[7].get("e") or []
                if len(inner) == 1 and isinstance(inner[0], dict):
                    arr = inner[0].get("e") or []
                    if len(arr) == 4 and all(isinstance(x, int) for x in arr):
                        keys.append({"var": name, "key": arr})
    return keys


def main():
    pg = [t for t in targets() if t.get("type") == "page"][0]
    c = CDP(pg["webSocketDebuggerUrl"])
    c.call("Runtime.enable")
    c.call("Debugger.enable")
    proto = c.call("Runtime.evaluate", expression="Function.prototype")["result"]["objectId"]
    objs = c.call("Runtime.queryObjects", prototypeObjectId=proto)["objects"]["objectId"]
    finder = ("function(){var out=[];for(var i=0;i<this.length;i++){try{"
              "if(Function.prototype.toString.call(this[i]).indexOf('__TENCENT_CHAOS_VM')>=0)"
              "out.push(this[i])}catch(e){}}return out.slice(0,8)}")
    r = c.call("Runtime.callFunctionOn", objectId=objs, functionDeclaration=finder,
               returnByValue=False)
    props = c.call("Runtime.getProperties", objectId=r["result"]["objectId"], ownProperties=True)
    fns = [p["value"]["objectId"] for p in props.get("result", []) if p.get("name", "").isdigit()]
    bps = []
    for oid in fns:
        try:
            bps.append(c.call("Debugger.setBreakpointOnFunctionCall", objectId=oid).get("breakpointId"))
        except RuntimeError as e:
            if "already exists" not in str(e):
                raise
    print("breakpoints:", bps)
    mid = c.send("Runtime.evaluate", expression="TDC.getData().length", returnByValue=True)
    hits = []
    npauses = 0
    matched = 0
    errs = 0
    done = None
    end = time.time() + 300
    while time.time() < end:
        try:
            m = c.recv(1.0)
        except Exception:
            continue
        if m.get("id") == mid:
            done = m
            break
        if m.get("method") != "Debugger.paused":
            c.events.append(m)
            continue
        npauses += 1
        cf = m["params"]["callFrames"][0]
        arg = None
        try:
            rr = c.call("Debugger.evaluateOnCallFrame", callFrameId=cf["callFrameId"],
                        expression=SHAPE, returnByValue=True, silent=True)
            v = rr.get("result", {}).get("value")
            arg = json.loads(v) if v else None
        except Exception as e:
            errs += 1
        if arg:
            matched += 1
        if arg and len(hits) < NHIT:
            scopes = dump_scopes(c, cf)
            h = {"arg": arg, "fn": cf.get("functionName"),
                 "keys": find_key(scopes), "scopes": scopes}
            hits.append(h)
            print("HIT", len(hits), "arg", [hex(x) for x in arg],
                  "key", h["keys"])
        c.call("Debugger.resume")
    print("pauses:", npauses, "matched:", matched, "errcount:", errs, "hits:", len(hits), "done:", bool(done))
    if done: print("len:", done.get("result",{}).get("result",{}).get("value"))
    for b in bps:
        try:
            c.call("Debugger.removeBreakpoint", breakpointId=b)
        except Exception:
            pass
    json.dump(hits, open("key_now.json", "w"), ensure_ascii=False, indent=1)
    print("wrote key_now.json")


if __name__ == "__main__":
    main()
