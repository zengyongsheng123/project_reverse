(function(){
  if (window.__hk) return 'has';
  var D = window.__hk = {calls: [], fn: null};
  var W = Function.prototype.apply;
  Function.prototype.apply = function(self, args){
    var r = W.call(this, self, args);
    try{
      if (args && typeof args === 'object' && args.length === 2 && args[0] &&
          typeof args[0] === 'object' && args[0].length === 2 &&
          typeof args[0][0] === 'number' && typeof args[0][1] === 'number' &&
          D.calls.length < 500){
        D.calls.push([args[0][0] >>> 0, args[0][1] >>> 0]);
        if (!D.fn && typeof this === 'function') D.fn = this;
      }
    }catch(e){}
    return r;
  };
  return 'ok';
})();
