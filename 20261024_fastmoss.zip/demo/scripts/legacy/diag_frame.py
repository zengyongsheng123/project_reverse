# -*- coding: utf-8 -*-
"""Pause on the cipher call and dump, for every closure/local scope, each
array variable with two levels of nesting (register file, key, block, sum).

Usage: python diag_frame.py
Writes diag_frame.json
"""
import http.client
import json
import time

import websocket

PORT = 9222


def targets():
    c = http.client.HTTPConnection("127.0.0.1", PORT, timeout=5)
    c.request("GET", "/json")
    return json.loads(c.getresponse().read())


class CDP:
    def __init__(self, url):
        self.ws = websocket.create_connection(url, timeout=180, suppress_origin=True)
        self.i = 0
        self.events = []
        self.auto_resume = False

    def send(self, method, **p):
        self.i += 1
        self.ws.send(json.dumps({"id": self.i, "method": method, "params": p}))
        return self.i

    def recv(self, timeout):
        self.ws.settimeout(timeout)
        return json.loads(self.ws.recv())

    def call(self, method, timeout=60, **p):
        mid = self.send(method, **p)
        end = time.time() + timeout
        while True:
            m = self.recv(max(0.5, end - time.time()))
            if m.get("id") == mid:
                if "error" in m:
                    raise RuntimeError("%s -> %s" % (method, m["error"]))
                return m.get("result", {})
            if "method" in m:
                self.events.append(m)
                if m["method"] == "Debugger.paused" and self.auto_resume:
                    self.i += 1
                    self.ws.send(json.dumps(
                        {"id": self.i, "method": "Debugger.resume", "params": {}}))


SHAPE = r"""
(function(AR){
  try{
    if(AR.length===1 && AR[0] && typeof AR[0]==='object' && AR[0].length===2 &&
       typeof AR[0][0]==='number' && typeof AR[0][1]==='number')
      return JSON.stringify([AR[0][0]>>>0, AR[0][1]>>>0]);
  }catch(e){}
  return '';
})(arguments)
"""

DESC = r"""
function(){
  function d(x, depth){
    if (x===null) return 'null';
    var t=typeof x;
    if(t==='number') return 'n:'+x;
    if(t==='string') return 's:'+x.slice(0,12);
    if(t==='function') return 'fn';
    if(t==='undefined') return 'u';
    if(t==='object'){
      if(typeof x.length==='number'){
        if(depth<=0) return '[...]len'+x.length;
        var e=[];for(var i=0;i<Math.min(x.length,10);i++) e.push(d(x[i],depth-1));
        return '['+e.join(',')+']';
      }
      return 'obj';
    }
    return t;
  }
  return d(this, 3);
}
"""

SHORT = r"""
function(){ return Object.prototype.toString.call(this) + ' len=' + (typeof this.length==='number'?this.length:'-'); }
"""


def props(c, oid):
    r = c.call("Runtime.getProperties", objectId=oid, ownProperties=True)
    return {p.get("name"): p.get("value") for p in r.get("result", [])}


def main():
    pg = [t for t in targets() if t.get("type") == "page"][0]
    c = CDP(pg["webSocketDebuggerUrl"])
    c.call("Runtime.enable")
    c.auto_resume = True
    c.call("Debugger.enable")
    c.auto_resume = False

    proto = c.call("Runtime.evaluate", expression="Function.prototype")["result"]["objectId"]
    objs = c.call("Runtime.queryObjects", prototypeObjectId=proto)["objects"]["objectId"]
    finder = ("function(){var out=[];for(var i=0;i<this.length;i++){try{"
              "if(Function.prototype.toString.call(this[i]).indexOf('__TENCENT_CHAOS_VM')>=0)"
              "out.push(this[i])}catch(e){}}return out}")
    r = c.call("Runtime.callFunctionOn", objectId=objs, functionDeclaration=finder,
               returnByValue=False)
    p = c.call("Runtime.getProperties", objectId=r["result"]["objectId"], ownProperties=True)
    fns = [x["value"]["objectId"] for x in p.get("result", [])
           if x.get("name", "").isdigit() and (x.get("value") or {}).get("objectId")]
    bps = []
    for oid in fns:
        try:
            bps.append(c.call("Debugger.setBreakpointOnFunctionCall", objectId=oid).get("breakpointId"))
        except RuntimeError as e:
            if "already exists" not in str(e):
                raise
    print("trampolines", len(fns), "bps", len(bps))

    mid = c.send("Runtime.evaluate", expression="TDC.getData().length", returnByValue=True)
    found = None
    done = None
    n = 0

    def next_pause(timeout=1.0):
        for k, e in enumerate(c.events):
            if e.get("method") == "Debugger.paused":
                return c.events.pop(k)
        while True:
            m = c.recv(timeout)
            if m.get("method") == "Debugger.paused":
                return m
            if m.get("id") == mid:
                return m
            c.events.append(m)

    end = time.time() + 240
    while time.time() < end:
        try:
            m = next_pause()
        except Exception:
            continue
        if m.get("id") == mid:
            done = m
            break
        n += 1
        cf = m["params"]["callFrames"][0]
        try:
            rr = c.call("Debugger.evaluateOnCallFrame", callFrameId=cf["callFrameId"],
                        expression=SHAPE, returnByValue=True, silent=True)
            hit = rr.get("result", {}).get("value") or ""
        except Exception:
            hit = ""
        if hit and found is None:
            rec = {"pre": json.loads(hit), "scopes": []}
            for sc in cf.get("scopeChain") or []:
                oid = (sc.get("object") or {}).get("objectId")
                if not oid or sc.get("type") not in ("closure", "local", "block"):
                    continue
                ent = {"type": sc.get("type"), "vars": {}}
                try:
                    vs = props(c, oid)
                except Exception:
                    continue
                for name, v in vs.items():
                    if not v:
                        continue
                    if v.get("type") == "object" and v.get("objectId"):
                        try:
                            d = c.call("Runtime.callFunctionOn",
                                       objectId=v["objectId"], returnByValue=True,
                                       functionDeclaration=DESC)
                            ent["vars"][name] = (d.get("result") or {}).get("value")
                        except Exception as e:
                            ent["vars"][name] = "ERR"
                    else:
                        ent["vars"][name] = "%s:%s" % (v.get("type"), v.get("value", v.get("description")))
                rec["scopes"].append(ent)
            found = rec
            print("HIT", found["pre"])
            print(json.dumps(found["scopes"], indent=1)[:4000])
        c.call("Debugger.resume")
    print("pauses", n, "done", bool(done))
    for b in bps:
        try:
            c.call("Debugger.removeBreakpoint", breakpointId=b)
        except Exception:
            pass
    json.dump(found, open("diag_frame.json", "w"), ensure_ascii=False, indent=1)
    print("wrote diag_frame.json")


if __name__ == "__main__":
    main()
