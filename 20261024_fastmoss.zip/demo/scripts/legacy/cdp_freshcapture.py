# -*- coding: utf-8 -*-
"""Capture a fresh TDC sample set from one captcha instance:

  * plaintext word pairs  (Function.prototype.apply / .call with [w0,w1])
  * ciphertext words       (String.fromCharCode with 4 args)
  * btoa input bytes       (the assembled payload)
  * cipher function refs   (this inside the apply hook)

Hooks are installed with Page.addScriptToEvaluateOnNewDocument so they exist
before tdc.js runs; the page is reloaded and the demo captcha popup is opened
by clicking 立即体验 (no slider solve, no verify submission).

Usage: python cdp_freshcapture.py [out.json] [--reload]
"""
import json, sys, time, http.client
import websocket

PORT = 9222

HOOK = r"""
(function(){
  if (window.__fc) return;
  var D = window.__fc = {calls: [], fcc4: [], btoa: [], fns: [], n: 0, t0: performance.now()};
  var oa = Function.prototype.apply;
  Function.prototype.apply = function(self, args){
    try{
      if (args && typeof args === 'object' && args.length === 2 && args[0] &&
          typeof args[0] === 'object' && args[0].length === 2 &&
          typeof args[0][0] === 'number' && typeof args[0][1] === 'number' &&
          D.calls.length < 8000){
        var a0 = args[0], a1 = args[1];
        var info = {seq: ++D.n, v: [a0[0] >>> 0, a0[1] >>> 0], a1t: typeof a1};
        if (a1 && typeof a1 === 'object'){
          info.len = a1.length;
          var s = [];
          for (var i = 0; i < Math.min(a1.length || 0, 8); i++){
            var e = a1[i]; s.push(typeof e === 'number' ? (e >>> 0) : typeof e);
          }
          info.a1 = s;
        } else info.a1 = String(a1).slice(0, 40);
        D.calls.push(info);
        if (D.fns.length < 20 && typeof this === 'function') D.fns.push(this);
      }
    }catch(e){}
    return oa.call(this, self, args);
  };
  var oc = Function.prototype.call;
  Function.prototype.call = function(self){
    try{
      if (arguments.length === 3 && self && typeof self === 'object' && self.length === 2 &&
          typeof self[0] === 'number' && typeof self[1] === 'number' && D.calls.length < 8000){
        var a1 = arguments[2];
        var info = {seq: ++D.n, v: [self[0] >>> 0, self[1] >>> 0], a1t: typeof a1, via: 'call'};
        if (a1 && typeof a1 === 'object'){
          info.len = a1.length;
          var s = [];
          for (var i = 0; i < Math.min(a1.length || 0, 8); i++){
            var e = a1[i]; s.push(typeof e === 'number' ? (e >>> 0) : typeof e);
          }
          info.a1 = s;
        } else info.a1 = String(a1).slice(0, 40);
        D.calls.push(info);
        if (D.fns.length < 20 && typeof this === 'function') D.fns.push(this);
      }
    }catch(e){}
    return oc.apply(this, arguments);
  };
  var ofc = String.fromCharCode;
  String.fromCharCode = function(){
    var out = ofc.apply(String, arguments);
    try{
      if (arguments.length === 4 && D.fcc4.length < 8000)
        D.fcc4.push([arguments[0] & 255, arguments[1] & 255, arguments[2] & 255, arguments[3] & 255]);
    }catch(e){}
    return out;
  };
  var ob = window.btoa;
  window.btoa = function(s){
    var out = ob.apply(window, arguments);
    try{
      if (D.btoa.length < 8 && typeof s === 'string' && s.length > 100){
        var h = '';
        for (var i = 0; i < s.length && i < 60000; i++){
          var c = s.charCodeAt(i) & 255; h += (c < 16 ? '0' : '') + c.toString(16);
        }
        D.btoa.push({len: s.length, hex: h});
      }
    }catch(e){}
    return out;
  };
})();
"""


def targets():
    conn = http.client.HTTPConnection("127.0.0.1", PORT, timeout=5)
    conn.request("GET", "/json")
    return json.loads(conn.getresponse().read())


class CDP:
    def __init__(self, url):
        self.ws = websocket.create_connection(url, timeout=30, suppress_origin=True)
        self.i = 0

    def call(self, method, **params):
        self.i += 1
        mid = self.i
        self.ws.send(json.dumps({"id": mid, "method": method, "params": params}))
        while True:
            msg = json.loads(self.ws.recv())
            if msg.get("id") == mid:
                if "error" in msg:
                    raise RuntimeError("%s -> %s" % (method, msg["error"]))
                return msg.get("result", {})

    def ev(self, expr):
        r = self.call("Runtime.evaluate", expression=expr, returnByValue=True, awaitPromise=True)
        res = r.get("result", {})
        if res.get("subtype") == "error":
            print("JS error:", res.get("description"))
        return res.get("value")

    def mouse(self, typ, x, y, buttons=0, click=True):
        self.call("Input.dispatchMouseEvent", type=typ, x=x, y=y,
                  button="left" if buttons or typ in ("mousePressed", "mouseReleased") else "none",
                  buttons=buttons, clickCount=1 if click else 0, pointerType="mouse")


def main():
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    out_path = args[0] if args else "fresh_log.json"
    reload_page = "--reload" in sys.argv
    ts = [t for t in targets() if t.get("type") == "page" and "cloud.tencent.com" in t.get("url", "")]
    if not ts:
        raise SystemExit("page not found")
    c = CDP(ts[0]["webSocketDebuggerUrl"])

    if reload_page:
        c.call("Page.enable")
        r = c.call("Page.addScriptToEvaluateOnNewDocument", source=HOOK)
        print("hook id", r.get("identifier"))
        c.call("Page.reload", ignoreCache=False)
        time.sleep(6.0)
    else:
        print("hook:", c.ev(HOOK) or "installed")
    print("armed:", c.ev("!!window.__fc"))

    btns = c.ev("[...document.querySelectorAll('a.tpm-btn')].filter(e=>e.textContent.trim()==='立即体验').map(e=>{const r=e.getBoundingClientRect();return [r.x+r.width/2,r.y+r.height/2,r.width,r.height];})")
    print("buttons", btns)
    if not btns:
        raise SystemExit("no 立即体验 button (page state?)")
    bx, by = btns[0][0], btns[0][1]
    c.mouse("mouseMoved", bx, by, 0, False)
    time.sleep(0.05)
    c.mouse("mousePressed", bx, by, 1, True)
    time.sleep(0.05)
    c.mouse("mouseReleased", bx, by, 0, True)
    time.sleep(5.0)

    state = c.ev("document.querySelector('.tencent-captcha-dy__header-text')?.textContent")
    print("captcha state", state)
    print("counts", c.ev("({calls: window.__fc.calls.length, fcc4: window.__fc.fcc4.length, btoa: window.__fc.btoa.length, fns: window.__fc.fns.length})"))

    d = c.ev("({calls: window.__fc.calls, fcc4: window.__fc.fcc4, btoa: window.__fc.btoa})")
    json.dump(d, open(out_path, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print("written", out_path, "bytes", len(json.dumps(d)))
    if d and d.get("btoa"):
        print("btoa lens", [(x["len"], len(x["hex"]) // 2) for x in d["btoa"]])
    if d and d.get("calls"):
        print("sample calls", d["calls"][:3])
        print("distinct a1 shapes", sorted({(x.get("a1t"), x.get("len"), str(x.get("a1"))[:40]) for x in d["calls"]})[:6])


if __name__ == "__main__":
    main()
