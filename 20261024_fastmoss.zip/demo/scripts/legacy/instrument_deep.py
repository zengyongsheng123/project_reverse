# -*- coding: utf-8 -*-
"""Deep capture of the TDC (tdc.js) data path.

Run this locally (it drives the already-open Cloak browser on :9222):

    python instrument_deep.py

It installs hooks *before the page loads* (Page.addScriptToEvaluateOnNewDocument)
and again after load, then opens the captcha demo and calls
window.TDC.getData()/getInfo(), dumping everything to deep_log.json.

What it records
---------------
* JSON.stringify  : every string >= 16 chars (payload plaintext, if used)
* btoa            : input bytes + output (the collect segments)
* charCodeAt      : histogram by receiver length, plus
                    - long receivers (>= 16 chars) stored verbatim
                    - runs of 1-char receivers, concatenated -> recovers the
                      string if the VM walks it character by character
* fromCharCode    : outputs (binary strings assembled from char codes)
* TextEncoder.encode / escape / unescape / encodeURIComponent : counts
"""
import json, time, http.client
import websocket

PORT = 9222

HOOK = r"""
(function(){
  if (window.__dp) return 'already';
  var D = window.__dp = {
    str: [], btoa: [], longcc: [], runs: [], fcc: [], ccHist: {}, counts: {},
    cur: "", curLen: 0, seen: {}, t0: Date.now()
  };
  var MAX_STR = 300, MAX_LONG = 200, MAX_RUNS = 120, MAX_RUNLEN = 8192;

  function flushRun(){
    if (D.curLen > 0 && D.runs.length < MAX_RUNS)
      D.runs.push({len: D.curLen, data: D.cur.slice(0, MAX_RUNLEN)});
    D.cur = ""; D.curLen = 0;
  }
  function bump(k){ D.counts[k] = (D.counts[k]||0)+1; }

  // --- JSON.stringify -----------------------------------------------------
  var oStr = JSON.stringify;
  JSON.stringify = function(){
    var out = oStr.apply(JSON, arguments);
    try {
      bump('stringify');
      if (typeof out === 'string' && out.length >= 16 && D.str.length < MAX_STR) {
        var k = out.length + '|' + out.slice(0, 40);
        if (!D.seen[k]) { D.seen[k] = 1; D.str.push({len: out.length, data: out.slice(0, 20000)}); }
      }
    } catch(e){}
    return out;
  };

  // --- btoa ---------------------------------------------------------------
  var oBtoa = window.btoa;
  window.btoa = function(s){
    var out = oBtoa.apply(window, arguments);
    try {
      bump('btoa'); flushRun();
      if (D.btoa.length < 60)
        D.btoa.push({inLen: String(s).length, inB64: oBtoa.call(window, String(s)), out: out});
    } catch(e){}
    return out;
  };

  // --- String.prototype.charCodeAt ---------------------------------------
  var oCC = String.prototype.charCodeAt;
  String.prototype.charCodeAt = function(i){
    try {
      var s = this, n = s.length;
      D.ccHist[n] = (D.ccHist[n]||0)+1;
      if (n >= 16) {
        flushRun();
        if (D.longcc.length < MAX_LONG) {
          var k2 = 'L' + n + '|' + oCC.call(s, 0) + '|' + s.slice(0, 32);
          if (!D.seen[k2]) { D.seen[k2] = 1; D.longcc.push({len: n, data: String(s).slice(0, 20000)}); }
        }
      } else if (n === 1) {
        if (D.curLen < MAX_RUNLEN) { D.cur += s; D.curLen++; }
      } else {
        flushRun();
        if (D.longcc.length < MAX_LONG) {
          var k3 = 'S' + n + '|' + s;
          if (!D.seen[k3]) { D.seen[k3] = 1; D.longcc.push({len: n, data: String(s)}); }
        }
      }
    } catch(e){}
    return oCC.call(this, i);
  };

  // --- String.fromCharCode ------------------------------------------------
  var oFCC = String.fromCharCode;
  String.fromCharCode = function(){
    var out = oFCC.apply(String, arguments);
    try {
      bump('fromCharCode'); flushRun();
      if (D.fcc.length < 40) D.fcc.push({argc: arguments.length, outLen: out.length, out: out.slice(0, 300)});
    } catch(e){}
    return out;
  };

  // --- encoders -----------------------------------------------------------
  if (window.TextEncoder) {
    var oEnc = TextEncoder.prototype.encode;
    TextEncoder.prototype.encode = function(s){
      try { bump('TextEncoder'); } catch(e){}
      return oEnc.apply(this, arguments);
    };
  }
  ['escape','unescape','encodeURIComponent','decodeURIComponent','parseInt'].forEach(function(k){
    var f = window[k]; if (typeof f !== 'function') return;
    window[k] = function(){ try { bump(k); } catch(e){} return f.apply(window, arguments); };
  });
  return 'ok';
})()
"""


def page_ws():
    conn = http.client.HTTPConnection("127.0.0.1", PORT, timeout=5)
    conn.request("GET", "/json")
    for t in json.loads(conn.getresponse().read()):
        if t.get("type") == "page" and "cloud.tencent.com" in t.get("url", ""):
            return t["webSocketDebuggerUrl"]
    raise SystemExit("page not found")


class CDP:
    def __init__(self):
        self.ws = websocket.create_connection(page_ws(), timeout=30, suppress_origin=True)
        self.i = 0

    def call(self, method, **params):
        self.i += 1
        self.ws.send(json.dumps({"id": self.i, "method": method, "params": params}))
        while True:
            msg = json.loads(self.ws.recv())
            if msg.get("id") == self.i:
                if "error" in msg:
                    raise RuntimeError(msg["error"])
                return msg.get("result", {})

    def ev(self, expr):
        r = self.call("Runtime.evaluate", expression=expr, returnByValue=True, awaitPromise=True)
        res = r.get("result", {})
        if res.get("subtype") == "error":
            print("JSERR", res.get("description"))
        return res.get("value")


def main():
    c = CDP()
    c.call("Page.enable")
    try:
        c.call("Page.addScriptToEvaluateOnNewDocument", source=HOOK)
    except Exception as e:  # noqa: BLE001
        print("addScriptToEvaluateOnNewDocument failed:", e)
    c.call("Page.navigate", url="https://cloud.tencent.com/product/captcha")
    time.sleep(5)
    print("hook after load:", c.ev(HOOK))
    c.ev("(()=>{const e=[...document.querySelectorAll('a.tpm-btn')].filter(e=>e.textContent.trim()==='立即体验')[0]; if(e){e.scrollIntoView({block:'center'}); e.click();} })()")
    for _ in range(30):
        time.sleep(0.5)
        if c.ev("!!window.TDC"):
            break
    time.sleep(1.0)
    print("TDC:", c.ev("!!window.TDC"))
    # mark the boundary instead of clearing: payloads may be built during the
    # click, i.e. *before* getData() is called.
    c.ev("if(window.__dp){window.__dp.mark={str:window.__dp.str.length,btoa:window.__dp.btoa.length,"
         "longcc:window.__dp.longcc.length,runs:window.__dp.runs.length,fcc:window.__dp.fcc.length};}")
    data = c.ev("window.TDC?String(window.TDC.getData()):null")
    info = c.ev("window.TDC?String(window.TDC.getInfo().info):null")
    dp = c.ev("window.__dp") or {}
    dp["data"] = data
    dp["info"] = info
    json.dump(dp, open("deep_log.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)

    mark = dp.get("mark") or {}
    print("collect len", len(data or ""), "info len", len(info or ""))
    print("counts", dp.get("counts"))
    print("charCodeAt length histogram:",
          dict(sorted((dp.get("ccHist") or {}).items(), key=lambda x: int(x[0]))[:20]))
    for i, e in enumerate(dp.get("btoa", [])):
        tag = "AFTER" if i >= mark.get("btoa", 10**9) else "before"
        print("btoa", i, tag, "inLen", e["inLen"], "outLen", len(e["out"]))
    for i, e in enumerate((dp.get("str") or [])[:30]):
        tag = "AFTER" if i >= mark.get("str", 10**9) else "before"
        print("json", i, tag, e["len"], repr(e["data"][:160]))
    for i, e in enumerate((dp.get("longcc") or [])[:20]):
        tag = "AFTER" if i >= mark.get("longcc", 10**9) else "before"
        print("cc", i, tag, e["len"], repr(e["data"][:160]))
    for i, e in enumerate((dp.get("runs") or [])[:10]):
        tag = "AFTER" if i >= mark.get("runs", 10**9) else "before"
        print("run", i, tag, e["len"], repr(e["data"][:160]))
    print("-> deep_log.json")


if __name__ == "__main__":
    main()
