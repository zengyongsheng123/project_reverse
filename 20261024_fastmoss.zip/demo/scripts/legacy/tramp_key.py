# -*- coding: utf-8 -*-
"""Catch the cipher closure trampoline during TDC.getData(): its only
argument is a 2-word block [w0,w1], and its register file I (visible in the
trampoline closure scope) holds the closure upvalue, i.e. the key array.

Usage: python tramp_key.py [max_pauses]
Writes tramp_key.json
"""
import http.client
import json
import sys
import time

import websocket

PORT = 9222
MAXP = int(sys.argv[1]) if len(sys.argv) > 1 else 1200


def targets():
    c = http.client.HTTPConnection("127.0.0.1", PORT, timeout=5)
    c.request("GET", "/json")
    return json.loads(c.getresponse().read())


class CDP:
    def __init__(self, url):
        self.ws = websocket.create_connection(url, timeout=180, suppress_origin=True)
        self.i = 0
        self.events = []

    def send(self, method, **p):
        self.i += 1
        self.ws.send(json.dumps({"id": self.i, "method": method, "params": p}))
        return self.i

    def recv(self, timeout):
        self.ws.settimeout(timeout)
        return json.loads(self.ws.recv())

    def call(self, method, timeout=60, **p):
        mid = self.send(method, **p)
        end = time.time() + timeout
        while True:
            m = self.recv(max(0.5, end - time.time()))
            if m.get("id") == mid:
                if "error" in m:
                    raise RuntimeError("%s -> %s" % (method, m["error"]))
                return m.get("result", {})
            if "method" in m:
                self.events.append(m)


PROBE = r"""
(function(AR){
  function desc(v){
    if(v&&typeof v==='object'&&typeof v.length==='number'){
      var o={len:v.length};
      if(v.length<=12){o.e=[];for(var i=0;i<v.length;i++){var x=v[i];
        if(typeof x==='number')o.e.push(x>>>0);
        else if(x&&typeof x==='object'&&typeof x.length==='number'){
          var q=[];for(var j=0;j<Math.min(x.length,8);j++){var y=x[j];q.push(typeof y==='number'?(y>>>0):(y===undefined?'u':typeof y))}
          o.e.push({len:x.length,e:q});
        } else o.e.push(x===undefined?'u':typeof x);
      }}
      return o;
    }
    if(typeof v==='number')return v>>>0;
    if(typeof v==='string')return 's:'+v.slice(0,60);
    return typeof v;
  }
  function dbg(v){
    if(v===null)return 'null';
    var t=typeof v;
    if(t==='number')return v>>>0;
    if(t==='string')return 's:'+v.slice(0,80);
    if(t!=='object')return t;
    var o={tag:Object.prototype.toString.call(v), ctor:(v.constructor&&v.constructor.name)||''};
    if(typeof v.length==='number'){o.len=v.length;o.e=[];for(var i=0;i<Math.min(v.length,8);i++){var x=v[i];o.e.push(typeof x==='number'?(x>>>0):(x&&typeof x==='object'?'obj:'+Object.prototype.toString.call(x):String(x).slice(0,30)))}}
    var ks=Object.getOwnPropertyNames(v).slice(0,12);o.k=[];
    for(var j=0;j<ks.length;j++){var y;try{y=v[ks[j]]}catch(e){continue}
      o.k.push(ks[j]+'='+(typeof y==='number'?(y>>>0):(typeof y==='string'?('s:'+y.slice(0,30)):typeof y)))}
    return o;
  }
  var out={arg:desc(AR[0]), nargs:AR.length};
  try{ out.A=desc(A); }catch(e){ out.A='n/a' }
  try{ var i7=I[7]; if(i7&&typeof i7==='object'&&i7.length) out.i7_0=dbg(i7[0]); }catch(e){ out.i7_0='e:'+e }
  try{ out.I=(typeof I!=='undefined')?desc(I):'n/a'; }catch(e){ out.I='e:'+e }
  try{ out.W=(typeof W!=='undefined')?desc(W):'n/a'; }catch(e){ out.W='e:'+e }
  try{ out.pcC=(typeof C!=='undefined')?desc(C):'n/a'; }catch(e){ out.pcC='n/a' }
  return JSON.stringify(out);
})(arguments)
"""


def main():
    pg = [t for t in targets() if t.get("type") == "page"][0]
    c = CDP(pg["webSocketDebuggerUrl"])
    c.call("Runtime.enable")
    c.call("Debugger.enable")
    proto = c.call("Runtime.evaluate", expression="Function.prototype")["result"]["objectId"]
    objs = c.call("Runtime.queryObjects", prototypeObjectId=proto)["objects"]["objectId"]
    finder = ("function(){var out=[];for(var i=0;i<this.length;i++){try{"
              "if(Function.prototype.toString.call(this[i]).indexOf('__TENCENT_CHAOS_VM')>=0)"
              "out.push(this[i])}catch(e){}}return out.slice(0,8)}")
    r = c.call("Runtime.callFunctionOn", objectId=objs, functionDeclaration=finder,
               returnByValue=False)
    props = c.call("Runtime.getProperties", objectId=r["result"]["objectId"], ownProperties=True)
    fns = [p["value"]["objectId"] for p in props.get("result", []) if p.get("name", "").isdigit()]
    bps = []
    for oid in fns:
        try:
            bps.append(c.call("Debugger.setBreakpointOnFunctionCall", objectId=oid).get("breakpointId"))
        except RuntimeError as e:
            if "already exists" not in str(e):
                raise
    print("breakpoints:", bps)
    mid = c.send("Runtime.evaluate", expression="TDC.getData().length", returnByValue=True)
    hits = []
    seen = set()
    npauses = 0
    done = None
    end = time.time() + 180
    while time.time() < end:
        try:
            m = c.recv(1.0)
        except Exception:
            continue
        if m.get("id") == mid:
            done = m
            break
        if m.get("method") != "Debugger.paused":
            c.events.append(m)
            continue
        npauses += 1
        if npauses > MAXP:
            c.call("Debugger.resume")
            continue
        cf = m["params"]["callFrames"][0]
        try:
            rr = c.call("Debugger.evaluateOnCallFrame", callFrameId=cf["callFrameId"],
                        expression=PROBE, returnByValue=True, silent=True)
            v = rr.get("result", {}).get("value")
            d = json.loads(v)
        except Exception as e:
            d = {"err": str(e)[:100]}
        arg = d.get("arg")
        if isinstance(arg, dict) and arg.get("len") == 2 and d.get("nargs") == 1:
            key = json.dumps(arg.get("e"))
            if key not in seen:
                seen.add(key)
                d["frame"] = {"fn": cf.get("functionName"),
                              "loc": cf.get("location"),
                              "n": len(m["params"]["callFrames"])}
                hits.append(d)
                print("HIT", len(hits), arg.get("e"), "I=", json.dumps(d.get("I"))[:300])
        c.call("Debugger.resume")
    print("pauses:", npauses, "unique blocks:", len(hits), "done:", bool(done))
    for b in bps:
        try:
            c.call("Debugger.removeBreakpoint", breakpointId=b)
        except Exception:
            pass
    json.dump(hits, open("tramp_key.json", "w"), ensure_ascii=False, indent=1)
    print("wrote tramp_key.json")


if __name__ == "__main__":
    main()
