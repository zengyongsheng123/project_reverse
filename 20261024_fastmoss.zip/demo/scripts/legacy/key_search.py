# -*- coding: utf-8 -*-
"""Recover the cipher key by testing every array the runtime wrote.

We have 161 verified (plaintext-block -> ciphertext-block) pairs from the
old-build session.  The round structure is known exactly (cipher_fit3.py);
the only unknown is the 4-word key array.  stack_log.json's `arrays`
journal lists every array the instrumented run wrote, so we can brute-force
each candidate array as the key.
"""
import json

from cipher_fit3 import C_TABLE, dec_block, enc_block, K1, K2

D = json.loads(open("stack_log.json", "rb").read().decode("utf-8", "replace"))
A = D["A"]
plain = [(c["v"][0], c["v"][1]) for c in A["calls"]]
blob = b"".join(bytes.fromhex(e["inHex"]) for e in A["btoa"])
ct = [(int.from_bytes(blob[i * 8:i * 8 + 4], "little"),
       int.from_bytes(blob[i * 8 + 4:i * 8 + 8], "little"))
      for i in range(len(blob) // 8)]


def score(key, fn, n=3):
    ok = 0
    for p, c in zip(plain[:n], ct[:n]):
        if fn(p[0], p[1], key) == c:
            ok += 1
    return ok


def main():
    seen = set()
    cands = []
    for e in A.get("arrays", []):
        v = e.get("v") or []
        if len(v) < 4 or e.get("len", 0) < 4:
            continue
        vs = v[:4]
        if not all(isinstance(x, int) for x in vs):
            continue
        key = tuple(x & 0xFFFFFFFF for x in vs)
        if key in seen:
            continue
        seen.add(key)
        cands.append((key, e.get("i"), e.get("t"), e.get("len")))
    print("distinct 4+ arrays with numeric head:", len(cands))
    for key, i, t, ln in cands:
        s1 = score(list(key), enc_block)
        s2 = score(list(key), dec_block)
        if s1 or s2:
            print("HIT", key, "idx", i, "t", t, "len", ln, "enc", s1, "dec", s2)
    # also the derived module keys
    print("K1/K2 scores:", score(K1, enc_block), score(K2, enc_block),
          score(K1, dec_block), score(K2, dec_block))


if __name__ == "__main__":
    main()
