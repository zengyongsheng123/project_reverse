# -*- coding: utf-8 -*-
"""Enumerate every execution context + list loaded tdc.js resources, then dump
arrays with numeric content per context (any length <= 32)."""
import json, time, http.client
import websocket

PORT = 9222


def targets():
    conn = http.client.HTTPConnection("127.0.0.1", PORT, timeout=5)
    conn.request("GET", "/json")
    return json.loads(conn.getresponse().read())


class CDP:
    def __init__(self, url):
        self.ws = websocket.create_connection(url, timeout=25, suppress_origin=True)
        self.i = 0
        self.events = []

    def call(self, method, **params):
        self.i += 1
        mid = self.i
        self.ws.send(json.dumps({"id": mid, "method": method, "params": params}))
        while True:
            msg = json.loads(self.ws.recv())
            if msg.get("id") == mid:
                if "error" in msg:
                    raise RuntimeError("%s -> %s" % (method, msg["error"]))
                return msg.get("result", {})
            if "method" in msg:
                self.events.append(msg)

    def ev(self, expr, ctx=None):
        p = dict(expression=expr, returnByValue=True, awaitPromise=True)
        if ctx is not None:
            p["contextId"] = ctx
        return self.call("Runtime.evaluate", **p).get("result", {}).get("value")


FILTER = r"""
function (minLen, maxLen, thresh) {
  var roots = this, out = [], n = roots.length >>> 0;
  for (var i = 0; i < n; i++) {
    var a; try { a = roots[i]; } catch (e) { continue; }
    if (!a || typeof a !== 'object') continue;
    var L = a.length;
    if (typeof L !== 'number' || L < minLen || L > maxLen) continue;
    var vals = [], ok = true, big = 0, num = 0;
    for (var k = 0; k < L; k++) {
      var v; try { v = a[k]; } catch (e) { ok = false; break; }
      if (typeof v === 'number' && isFinite(v)) { num++; if (Math.abs(v) >= thresh) big++; }
      vals.push(v);
    }
    if (!ok || big < 2) continue;
    out.push(vals.map(function (x) { return typeof x === 'number' ? (x >>> 0) : String(x); }));
    if (out.length > 2000) break;
  }
  return out;
}
"""


def main():
    ts = [t for t in targets() if t.get("type") == "page" and "cloud.tencent.com" in t.get("url", "")]
    if not ts:
        raise SystemExit("page not found")
    c = CDP(ts[0]["webSocketDebuggerUrl"])
    c.call("Runtime.enable")
    time.sleep(0.8)
    try:
        c.ws.settimeout(0.4)
        while True:
            msg = json.loads(c.ws.recv())
            if "method" in msg:
                c.events.append(msg)
    except Exception:
        pass
    c.ws.settimeout(25)

    ctxs = {}
    for e in c.events:
        if e.get("method") == "Runtime.executionContextCreated":
            ctx = e["params"]["context"]
            ctxs[ctx["id"]] = (ctx.get("origin", ""), ctx.get("name", ""),
                               ctx.get("auxData", {}).get("isDefault"), ctx.get("auxData", {}).get("frameId", "")[:8])
    print("ALL contexts:")
    for k, v in ctxs.items():
        print("  ", k, v)

    # resources on the main frame
    res = c.ev("""(()=>{const o=[];for(const e of performance.getEntriesByType('resource')){
      if(/tdc|cap_union|TJCaptcha|JCap|dy-jy/i.test(e.name)) o.push([e.name.slice(0,180), e.transferSize, e.encodedBodySize]);}
      return o;})()""")
    print("resources:")
    for r in res or []:
        print("  ", r)

    for cid, info in ctxs.items():
        if not info[2]:
            continue
        href = c.ev("location.href", ctx=cid)
        print("ctx", cid, info[0], "prim", str(href)[:90])
        try:
            pid = c.call("Runtime.evaluate", expression="Array.prototype", contextId=cid).get("result", {}).get("objectId")
            qid = c.call("Runtime.queryObjects", prototypeObjectId=pid).get("objects", {}).get("objectId")
            n = c.call("Runtime.callFunctionOn", objectId=qid, functionDeclaration="function(){return this.length}",
                       returnByValue=True).get("result", {}).get("value")
            print("   arrays:", n)
            for lo, hi, th in ((4, 4, 65536), (8, 8, 65536), (1, 32, 1 << 20)):
                out = c.call("Runtime.callFunctionOn", objectId=qid, functionDeclaration=FILTER,
                             arguments=[{"value": lo}, {"value": hi}, {"value": th}], returnByValue=True)
                arrs = out.get("result", {}).get("value") or []
                arrs = [a for a in arrs if isinstance(a, list)]
                print("   len %d-%d thr %d -> %d" % (lo, hi, th, len(arrs)))
                for a in arrs[:25]:
                    ints = [x for x in a if isinstance(x, int)]
                    if len(ints) == len(a):
                        print("      ", [hex(x) for x in a])
                    else:
                        print("      ", a)
                if arrs:
                    json.dump(arrs, open("arrays_ctx%s_%d_%d.json" % (cid, lo, hi), "w"))
        except Exception as ex:
            print("   ERR", ex)


if __name__ == "__main__":
    main()
