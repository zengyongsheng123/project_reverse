# -*- coding: utf-8 -*-
"""Extract string constants built by consecutive appendchr instructions.

The Chaos VM builds string literals as `emptystr; appendchr c1; appendchr c2; ...`.
Scanning those runs recovers every literal in a build, which is what the key
modules feed into word(lit, offset).

Usage: python find_literals.py old|live [minlen]
"""
import json
import sys
from disasm_tdc import disasm
from translate_bc import load_map
from disasm_live import main as _  # noqa  (kept importable)

sys.path.insert(0, ".")


def load(kind):
    if kind == "old":
        bc = json.load(open("../js/bytecode.json"))
        return bc, {i: i for i in range(1000)}
    bc = json.load(open("../js/bytecode_live.json"))
    m = load_map()
    return bc, m


def walk(bc, live2old):
    from collections import deque
    from disasm_tdc import OPERANDS
    n = len(bc)
    seen = {}
    q = deque([0])
    while q:
        pc = q.popleft()
        if not isinstance(pc, int) or pc in seen or pc < 0 or pc >= n:
            continue
        op = live2old.get(bc[pc])
        if op is None or OPERANDS.get(op) is None:
            continue
        cnt = OPERANDS[op]
        if cnt == -1:
            f, nup, narg = bc[pc + 1], bc[pc + 2], bc[pc + 3]
            end = pc + 4 + 2 * nup + narg
            seen[pc] = (op, [f, nup, narg], end)
            q.append(f)
            q.append(end)
            continue
        ops = bc[pc + 1:pc + 1 + cnt]
        end = pc + 1 + cnt
        seen[pc] = (op, ops, end)
        if op == 33:
            q.append(ops[0])
            continue
        q.append(end)
        if op in (63, 16):
            q.append(ops[0])
    return seen


def main():
    kind = sys.argv[1] if len(sys.argv) > 1 else "live"
    minlen = int(sys.argv[2]) if len(sys.argv) > 2 else 3
    bc, m = load(kind)
    seen = walk(bc, m)
    # appendchr canonical opcode is 65
    runs = []
    for pc in sorted(seen):
        op, ops, end = seen[pc]
        if op != 65:
            continue
        # collect a maximal run of consecutive appendchr
        s = chr(ops[0] & 0xFFFF)
        cur = pc
        while True:
            nxt = seen.get(end)
            if not nxt or nxt[0] != 65:
                break
            s += chr(nxt[1][0] & 0xFFFF)
            end = nxt[2]
        runs.append((pc, s))
    seen_s = set()
    for pc, s in runs:
        if len(s) >= minlen and s not in seen_s:
            seen_s.add(s)
            print("%6d %r" % (pc, s))


if __name__ == "__main__":
    main()
