
(function(){
  if (window.__sk) return 'already';
  var D = window.__sk = {
    rec: false, btoa: [], cc4: [], fcc4: [], fcc: [], runs: [], json: [], join: [],
    hist: {}, argc: {}, counts: {}, seen: {}, phase: 0, t0: 0,
    seq: 0, buf: '', bufLen: 0, bufSeq: 0, arrays: [], arrTotal: 0, frozen: false
  };
  var MAX_CC = 6000, MAX_FCC = 3000, MAX_BTOA = 20, MAX_RUNS = 400;
  function now(){ return Math.round(performance.now() - D.t0); }
  function bump(k){ D.counts[k] = (D.counts[k]||0)+1; }
  function flushBuf(){
    if (D.bufLen > 0 && D.runs.length < MAX_RUNS)
      D.runs.push({s0: D.bufSeq, s1: D.seq, len: D.bufLen, data: D.buf.slice(0, 120000)});
    D.buf = ''; D.bufLen = 0; D.bufSeq = D.seq;
  }

  var oBtoa = window.btoa;
  window.btoa = function(s){
    var out = oBtoa.apply(window, arguments);
    try {
      if (D.rec) {
        D.seq++; bump('btoa'); flushBuf();
        var st = '';
        try { st = (new Error()).stack || ''; } catch(e){}
        if (D.btoa.length < MAX_BTOA)
          D.btoa.push({t: now(), seq: D.seq, inLen: String(s).length, inLenCtor: s && s.constructor && s.constructor.name,
                       inB64: oBtoa.call(window, String(s)), out: out,
                       stack: st.split('\n').slice(0, 6).join('\n')});
      }
    } catch(e){}
    return out;
  };

  var oFCC = String.fromCharCode;
  String.fromCharCode = function(){
    var out = oFCC.apply(String, arguments);
    try {
      if (D.rec) {
        D.seq++; bump('fcc');
        var a = arguments.length;
        D.argc[a] = (D.argc[a]||0)+1;
        if (a === 4) {
          flushBuf();
          if (D.fcc4.length < MAX_FCC)
            D.fcc4.push({t: now(), seq: D.seq, b: [arguments[0]&255, arguments[1]&255, arguments[2]&255, arguments[3]&255]});
        } else if (a === 1) {
          if (D.bufLen < 120000) { D.buf += out; D.bufLen += 1; }
        } else {
          flushBuf();
          var k2 = 'F' + a + '|' + out.slice(0, 32);
          if (!D.seen[k2] && D.fcc.length < 400) { D.seen[k2] = 1; D.fcc.push({t: now(), argc: a, len: out.length, data: String(out).slice(0, 200)}); }
        }
      }
    } catch(e){}
    return out;
  };

  var oCC = String.prototype.charCodeAt;
  String.prototype.charCodeAt = function(i){
    try {
      if (D.rec) {
        D.seq++;
        var s = this, n = s.length;
        bump('cc'); D.hist[n] = (D.hist[n]||0)+1;
        if (n === 4) {
          flushBuf();
          if (D.cc4.length < MAX_CC)
            D.cc4.push({t: now(), seq: D.seq, i: i, s: String(s)});
        }
      }
    } catch(e){}
    return oCC.call(this, i);
  };

  var oStr = JSON.stringify;
  JSON.stringify = function(){
    var out = oStr.apply(JSON, arguments);
    try { if (D.rec) { D.seq++; flushBuf();
      if (typeof out === 'string' && out.length >= 8 && D.json.length < 40)
        D.json.push({t: now(), seq: D.seq, len: out.length, data: out.slice(0, 4000)}); } } catch(e){}
    return out;
  };

  var oJoin = Array.prototype.join;
  Array.prototype.join = function(sep){
    var out = oJoin.apply(this, arguments);
    try { if (D.rec) { D.seq++; flushBuf();
      if (typeof out === 'string' && out.length >= 8 && D.join.length < 60)
        D.join.push({t: now(), seq: D.seq, len: out.length, data: out.slice(0, 2000)}); } } catch(e){}
    return out;
  };

  /* ---- array capture: the cipher key lives in an array the VM builds with
     `new Array()` and reads as K[idx].  Record every array the VM creates so
     the four-word key can be picked out afterwards (its box is shared, so the
     value is read at dump time). ---- */
  var oArray = window.Array;
  var seenArr = (typeof WeakSet !== 'undefined') ? new WeakSet() : null;
  function noteArr(a, why){
    try {
      if (D.frozen) return;
      if (!a || typeof a !== 'object') return;
      if (seenArr) { if (seenArr.has(a)) return; seenArr.add(a); }
      if (D.arrTotal < 40000) { D.arrTotal++; D.arrays.push({a: a, t: now(), phase: D.phase, n: why}); }
    } catch(e){}
  }
  function SkArray(){
    var a;
    if (arguments.length === 0) a = [];
    else if (arguments.length === 1 && typeof arguments[0] === 'number') a = new oArray(arguments[0]);
    else { a = []; for (var i = 0; i < arguments.length; i++) a[i] = arguments[i]; }
    noteArr(a, 'new');
    return a;
  }
  SkArray.prototype = oArray.prototype;
  try { oArray.prototype.constructor = SkArray; } catch(e){}
  try {
    Reflect.ownKeys(oArray).forEach(function(ak){
      if (ak === 'prototype' || ak === 'length' || ak === 'name') return;
      try { Object.defineProperty(SkArray, ak, Object.getOwnPropertyDescriptor(oArray, ak)); } catch(e){}
    });
  } catch(e){}
  try { Object.defineProperty(SkArray, 'name', {value: 'Array'}); } catch(e){}
  window.Array = SkArray;
  /* arrays that are literals and then filled with push/splice/unshift */
  ['push', 'unshift', 'splice'].forEach(function(m){
    var o = Array.prototype[m];
    if (typeof o !== 'function') return;
    Array.prototype[m] = function(){
      var r = o.apply(this, arguments);
      noteArr(this, m);
      return r;
    };
  });

  window.__skArm = function(){
    D.phase += 1; D.rec = true; D.frozen = false; D.t0 = performance.now();
    D.seen = {}; D.hist = {}; D.argc = {}; D.counts = {};
    D.btoa.length = 0; D.cc4.length = 0; D.fcc4.length = 0; D.fcc.length = 0;
    D.runs.length = 0; D.json.length = 0; D.join.length = 0;
    D.seq = 0; D.buf = ''; D.bufLen = 0; D.bufSeq = 0;
    return D.phase;
  };
  window.__skDump = function(){
    D.rec = false; flushBuf(); D.frozen = true;
    var o = {};
    for (var k in D) if (k !== 'seen' && k !== 'arrays') o[k] = D[k];
    var arrs = [];
    for (var i = 0; i < D.arrays.length; i++) {
      var rec = D.arrays[i], a = rec.a, n;
      try { n = a.length; } catch(e){ continue; }
      if (typeof n !== 'number' || n > 64) continue;
      var snap = [], ok = true;
      for (var j = 0; j < n; j++) {
        var v = a[j], t = typeof v;
        if (v === null || t === 'number' || t === 'string' || t === 'boolean' || t === 'undefined') {
          snap.push(t === 'string' ? v.slice(0, 64) : v);
        } else { ok = false; break; }
      }
      if (!ok) continue;
      arrs.push({i: i, t: rec.t, phase: rec.phase, len: n, v: snap});
    }
    o.arrays = arrs;
    o.buf = ''; o.bufLen = 0;
    return o;
  };
  return 'ok';
})()
