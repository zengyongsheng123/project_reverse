import requests


headers = {
    "Accept": "*/*",
    "Accept-Language": "zh,zh-CN;q=0.9",
    "Cache-Control": "no-cache",
    "Connection": "keep-alive",
    "Content-Type": "application/json",
    "Origin": "null",
    "Pragma": "no-cache",
    "Sec-Fetch-Dest": "empty",
    "Sec-Fetch-Mode": "cors",
    "Sec-Fetch-Site": "cross-site",
    "Sec-Fetch-Storage-Access": "active",
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36",
    "lang": "zh-CN",
    "sec-ch-ua": "\"Not:A-Brand\";v=\"8\", \"Chromium\";v=\"156\", \"Google Chrome\";v=\"156\"",
    "sec-ch-ua-mobile": "?0",
    "sec-ch-ua-platform": "\"Windows\""
}
url = 'http://localhost:8787/api/captcha/verify'
data = {
    "ticket": "tr03glxkjP_1vgdjqqNuvdYxp6or9ZwgYc4gDsqxrQpI7hmbueopgM9xUPvgfTs5ZLhIBKNpmnYQ59q9xuYKdEI_DWBufEGCwZCvI2oIX4h2T17JEFfhnUrCpHccwPSdRVBA8D3TijvbfvA*",
    "randstr": "@4Kr",
    "platform": 1,
    "business_id": 1,
    "scene_id": 1,
    "id": 0,
    "type": 1,
    "lang": "zh-CN"
}
response = requests.post(url, headers=headers, json=data)

print(response.text)
print(response)