import requests


headers = {
    "Accept": "*/*",
    "Accept-Language": "zh,zh-CN;q=0.9",
    "Cache-Control": "no-cache",
    "Connection": "keep-alive",
    "Pragma": "no-cache",
    "Sec-Fetch-Dest": "script",
    "Sec-Fetch-Mode": "no-cors",
    "Sec-Fetch-Site": "cross-site",
    "Sec-Fetch-Storage-Access": "active",
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36",
    "sec-ch-ua": "\"Not:A-Brand\";v=\"8\", \"Chromium\";v=\"156\", \"Google Chrome\";v=\"156\"",
    "sec-ch-ua-mobile": "?0",
    "sec-ch-ua-platform": "\"Windows\""
}
url = 'https://turing.captcha.qcloud.com/cap_union_prehandle'
params = {
    "aid": "195941100",
    "protocol": "https",
    "accver": "1",
    "showtype": "popup",
    "ua": "TW96aWxsYS81LjAgKFdpbmRvd3MgTlQgMTAuMDsgV2luNjQ7IHg2NCkgQXBwbGVXZWJLaXQvNTM3LjM2IChLSFRNTCwgbGlrZSBHZWNrbykgQ2hyb21lLzE1Ni4wLjAuMCBTYWZhcmkvNTM3LjM2",
    "noheader": "1",
    "fb": "0",
    "aged": "0",
    "enableAged": "0",
    "enableDarkMode": "0",
    "grayscale": "1",
    "clientype": "2",
    "userLanguage": "zh-cn",
    "cap_cd": "",
    "uid": "",
    "lang": "zh",
    "entry_url": "file:///D:/20261024_fastmoss/captcha-test.html",
    "elder_captcha": "0",
    "js": "/tgJCap.2f0b2c65.js",
    "login_appid": "",
    "wb": "1",
    "tkid": "1629299459",
    "subsid": "3",
    "callback": "_aq_487039",
    "sess": ""
}
response = requests.get(url, headers=headers, params=params)

print(response.text)
print(response)