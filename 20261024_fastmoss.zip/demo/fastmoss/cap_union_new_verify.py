import requests


headers = {
    "Accept": "application/json, text/javascript, */*; q=0.01",
    "Accept-Language": "zh,zh-CN;q=0.9",
    "Cache-Control": "no-cache",
    "Connection": "keep-alive",
    "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
    "Origin": "null",
    "Pragma": "no-cache",
    "Sec-Fetch-Dest": "empty",
    "Sec-Fetch-Mode": "cors",
    "Sec-Fetch-Site": "cross-site",
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36",
    "sec-ch-ua": "\"Not:A-Brand\";v=\"8\", \"Chromium\";v=\"156\", \"Google Chrome\";v=\"156\"",
    "sec-ch-ua-mobile": "?0",
    "sec-ch-ua-platform": "\"Windows\""
}
url = 'https://turing.captcha.qcloud.com/cap_union_new_verify'
data = 'collect=%2BlK%2B9XRPZyZL%2FufHzUDyK3F4IbePaAZ0y5DqcklpJhfCdn5XpRG1%2BpgfQ93XP7BTVHXvrnARMlT4FT%2BCY9AHOILRBKWF7pT63v3jFYmL%2BlF%2F%2B8GlES8dz%2BahnRviss5YuE05%2Bi7ujZG905K2uPEEcUvAY%2FX8vHqRrCy8hedaWgPTrunRbAvpTI9KT0bjX%2BOg9iWr4L11mCRPLgCbTr0%2BhU8uAJtOvT6Fg6JDbaKAIzmx3%2Fmtp5m5yyJjr%2FpHlWmkvhtkyq6WjcsiY6%2F6R5VppDduA4POBl1Tl08%2B0rd985dBmmDnRNwtqddH5z9UiQuHgrcZMo%2F6yb19mWpuEUb4CCQsl7QpyvZ6XvU%2FQMzq6E%2Fk3tuEm7r4ZDduA4POBl1Tiu%2FfsoDcT37FvMBrR4lBh1ZntLCUP6NlVme0sJQ%2Fo2VEb1TZd8kybt2JzEZeAc3fVme0sJQ%2Fo2ViTUR0OrfbuK6cWhMHgD7S6RuOthuPJqvpG462G48mq2ea9LQhejL2mQo7ErNOUjJQrVCLG08YLGJXNTs7w3IbgSN0qfmbq1CBI3Sp%2BZurUCQFFTb6pntNEvWwevwzPqil%2FEbJ7zcWEZZudbTl6PlM4LmAXPEpN7Y0qu0zaM1qwrbhbFV41LJaSjmOrssjtElwwW%2BmWzSPbGlxngO2HAbPazxMtxwP8Q6YVpFwHV6R5%2Bzfhfo0gkI9GpAQLNMdnPQfQ2ymKmYnDPVPudN2JV0s6RuOthuPJqv1T7nTdiVdLPVPudN2JV0sv9zD%2FUNeTiO%2FVDZe%2BV1n%2B5RGnHQxsnDvTKndyyi5ofLpBQ%2BD449FzvUVZ5KMONrN9RVnkow42s31FWeSjDjazey0sUJVTNfvI3ERqNRE9P03bgODzgZdU0b4VxaZ%2FqzFKQGFVkASSFzFvMBrR4lBh7Od0EpIe9vHzBMqCruRSLHTw7mPKD7gURMImh5QHkGTEIhZ%2B67ZbRW9y4L0zZBY9kvJEj1w5PxZfx73SsbyXL6vsyumYRXaZq9jFwb1KsOUejGdpAaWwzIX86ximewq9xiaoW9P5HDwT1ogJJVnPmJXSfgdN4YQXBUtdcwtSmoZvheMqLOXT%2FCWF2deiSFAgLMKBTVF92EX6NAI9miIbR5JR7Sha4B%2F0%2FDPNjREJXwXgPrFdfTVT27eXyK17ycbTYbFBct6htpIpJF6brSeaZlMuZlOQ3JrP2CjujIJvpNldkyKJzjuuEH63fWZ3JP4c2ufbMi9uNw1iZGeDiRnmvHL6sPXOkSG1%2F1kJArA1shwm74EZC0F96QywxO946LvyUroEmPjEkqlwfQdiQ3B%2FVaYcVsOBf5cfY6VeZWeqmnG8oS3%2Bw7LWDHkUqrG5oVcLO2LAkwuXJ6zEciKbsGi09MSXTyhpURrj3IBmHkHDJGxvFodbc7RNAEVmP7MFfrq4KY1BmtKYl2Zo0hSS9KGv0imq6AcX505ceWH0SYt3WDQS8Bj9fy8epGQIgj9cJIDq01%2B7XSI2NY2f%2BsodS0tQCI2qurxyuteeCXkc976oDmicXB7X2Qhe%2Fczn99DsCg3M0KgBx6rb6iCm%2FB8ap26yoeZ2EJ%2BF6bAElu8G1P2%2FT4NTy4Am069PoVPLgCbTr0%2BhU8uAJtOvT6FM1TAuQNquzKiW%2FMa%2FlJOEGbQLTqMkCd%2FNSUTQZf703DauYJv65eKyA%3D%3D&tlg=1688&eks=Tn9X0zYSE4SX2PGRl0krt0Bmtr1oYD2gx%2FNPGDAxmnvFZLFlpB2D%2BLyMi3ahRKVecjQR5bcIZOKjh9Q5iEiNL2rWKcta%2FTzx4n9e0cg1cLXlCLgAq4Xl%2BAKLfIn2xjjcp2EHLdV5g80bHJkU3aRJ5RL9KL0728o6k3SXaurS82cmqCiwoT9GRI58e1Fv3SWFJijRBC0vDOnlcrcUsnN0jLdH%2Bmb6YmJwMEEElz77SGFRk2eMRaO7BA%3D%3D&sess=s0oaCvjD7mFcidsfHiozxepexszwljgq96cJerzbU2jEl5aFdoos7NZ0xKrRuLIet0_7FtNvQ4F5WmxMRl2sQMN3SJA5xBYMZ9lDTHcerr3KqRbllKh4-C132fcHtsWJDsIJjA5DQsu9XWqypoAbOaUkEuSL3QTF07eJAqFKZAfOy5O5tX92Xy1pnSsFWysPv-CiZtOF2sW-f7ZTCk_D9hTt4FPRg77gUpitm_rNIzHPwvQ18ewVeZ2ktShWpkgKcL2kPpjw4aNIP1QqbshBDsR8rZ5SXALdfH-P6uOZJvnnAxIFfPrM8YEtpKKXSR00R8hbdn_YB9vd954VD1dX3-Pj2RRUXT1td_wb2FZo2UvBwOO7xLhjo-QBfXA2YuwZv-4hOFIxfiv345AEY_DavsVw**&ans=%5B%7B%22elem_id%22%3A1%2C%22type%22%3A%22DynAnswerType_POS%22%2C%22data%22%3A%22536%2C101%22%7D%5D&tkid=1629299459&pow_answer=f07b6b43ab9454d1%2329196&pow_calc_time=86'
response = requests.post(url, headers=headers, data=data)

print(response.text)
print(response)