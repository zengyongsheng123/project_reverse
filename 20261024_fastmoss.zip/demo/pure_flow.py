# -*- coding: utf-8 -*-
"""腾讯 TCaptcha v2 滑块（aid 192962660）—— 单文件、无浏览器、全流程。

整条链路封装在 `TencentCaptchaFlow` 中：

    prehandle 取会话/挑战
      -> 同一个 Session 下载背景图与拼图雪碧图
      -> GapRecognizer 识别缺口（默认 captcha-recognizer，失败回退内置解算）
      -> Trajectory 生成拖动轨迹并序列化成 TDC 事件串
      -> CollectBuilder 回放明文布局、填入动态字段、加密成 collect
      -> 本地 PoW
      -> cap_union_new_verify（一次 POST）

依赖：requests、numpy、Pillow；识别默认需要 captcha-recognizer
（pip install captcha-recognizer，会带 opencv-python/onnxruntime/shapely）。
模型缺失或推理异常时自动回退到内置的掩码/模板解算，流程不中断。

内嵌常量（静态、按 build 固定）
------------------------------
  XTEA 变体的 key/case、分段 split、248 字符 eks、collect 明文布局
  （含 canvas PNG、UA、WebGL、屏幕、sd、build 的 seed 常量）。它们和密码学
  密钥一样属于某个 build 的静态常量，早已从 tdc.js 与抓包明文里提取，内嵌后
  本文件即可自给自足。

  常量所属 build：sha256_16 = "83bd1bbee1c6cad8"（profile 名 cur9）。
  tdc.js 每次 HTTP 请求都会重新随机，但服务端不校验 collect 与本会话 tdc.js
  的绑定（2026-10-24 实测 200 / errorCode "0"），所以固定一个 build 够用。

运行方式
--------
    python pure_flow.py                        默认：全流程 + 提交一次
    python pure_flow.py --dry-run              只组装请求，不发包
    python pure_flow.py --recognizer builtin   强制内置识别（仍会提交）

安全边界
--------
  * 用户已授予默认提交授权（2026-10-24）：AUTHORIZED_SUBMIT = True，
    普通运行会提交，不需要逐次确认；
  * 每次调用只 POST 一次，脚本内没有重试循环；
  * 只对公开 demo aid 192962660（cloud.tencent.com）使用；
  * 不批量拉取验证码样本，不对非公开 aid 使用本流程。
退出码：0 成功，2 服务端拒绝，1 初始化错误。
"""
import base64
import hashlib
import json
import os
import random
import re
import sys
import time
import urllib.parse
from collections import deque

import numpy as np
import requests
from PIL import Image

# --------------------------------------------------------------------------- #
# 全局配置
# --------------------------------------------------------------------------- #
HERE = os.path.dirname(os.path.abspath(__file__))
AID = "192962660"                                  # 腾讯云「在线体验」公开 demo
BASE = "https://turing.captcha.qcloud.com"          # 验证码服务端
UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36")
OUT = os.path.join(HERE, "pure_flow_result.json")   # 结果落盘
BG = os.path.join(HERE, "pure_flow_bg.png")         # 本次背景图
SP = os.path.join(HERE, "pure_flow_sprite.png")     # 本次拼图雪碧图

# 默认提交授权：用户 2026-10-24 明确要求「默认授权可以请求」。
# 普通运行 = 全流程 + 提交一次；--dry-run 可只组装不发包。
AUTHORIZED_SUBMIT = True

# 某个 build 的静态常量（K/C/split、eks、明文布局；不用浏览器即可复用）
PROFILE = {'name': 'cur9', 'sha256_16': '83bd1bbee1c6cad8', 'key': [1366125416, 1247952441, 1315062119, 1213807443], 'case': [0, 197429, 0, 657937], 'split': 456, 'eks': 'tsk6OO36Ybs4wl1K69V/INtWLxCkEI+5PR51d+U0C0LMSLYoUllG2RNEQDWbJow3MZiwUAMw9Ij9sN5cHTU5pUWATebsceFcfE7AZQX/IXWPM2/zXq172QBueIc+GhPT4jJswF/26bS903xjugOfOOTSxpfCKtK4OQ5fbvLF3+RlL+MzhoMbVjKNEnddzXPd8v7CedQlKvEh9891V1oaMfjzOSWIfQfIYzTgO9Qv63tvBE4W74H+2Q==', 'layout': {'prefix': '[[1,1,12]]              {"cd":[', 'tokens': ['32', '0', '"GgoAAAANSUhEUgAAASwAAACWCAYAAA76+IlaBIhKxWufqtcCsxKQ71/n6pjUB0H3elg4cAvgAAAABJRU5ErkJggg=="', '[]', '27', '1950354050', '["zh-CN","zh"]', '"ANGLE (NVIDIA, NVIDIA GeForce RTX 3060 Ti (0x00002489) Direct3D11 vs_5_0 ps_5_0, D3D11)"', '0', '"Google Inc. (NVIDIA)"', '1920', '0', '1', '"1920-1080-1032-32-*-*-|-*"', '1023', '"Win32"', '8', '"UTF-8"', '1080', '"+08"', '"https://cloud.tencent.com/product/captcha"', '""', '1792825037', '1792824655', '890859047', '1792807554', '0', '""', '              ', '[360,358]', '0', '"98k"', '"top"', '""', '2', '"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36"', '0', '"https://cloud.tencent.com/product/captcha?rand=1519713624347"'], 'suffix': '],      "sd":{"od":"C","ft":"6f_7ff__H"}}', 'dynamic': {'now_sec': 22, 'counter': 4, 'positions': [4, 22], 'prefix_dynamic': False, 'pads': {}, 'suffix_pad_width': None}}, 'samples_verified': 12}


# --------------------------------------------------------------------------- #
# 1. collect 加解密
#    与 tdc.js 一致：XTEA 变体（32 轮）、24/split 分段轮转、base64 + URL 编码。
# --------------------------------------------------------------------------- #
class TDCCipher:
    """TDC `collect` 的加密/解密器。

    collect 明文按 8 字节分块，每块做 32 轮变体 XTEA；密文先按 24 字节
    头部槽位与 split 位置轮转，再整体 base64 并做 URL 百分号编码。
    """

    M32 = 0xFFFFFFFF
    DELTA = 2654435769
    SUM_END = 32 * DELTA

    def __init__(self, profile):
        self.key = profile["key"]      # 4 个 32 位密钥字
        self.case = profile["case"]    # 4 个加法常量（原版 C）
        self.split = profile["split"]  # 该 build 的分段边界

    # ---- 32 位整数工具：模拟 JS 的位运算/加法回绕 ----
    @staticmethod
    def _i32(x):
        """截断为有符号 32 位整数。"""
        x &= 0xFFFFFFFF
        return x - 0x100000000 if x & 0x80000000 else x

    @staticmethod
    def _u32(x):
        """截断为无符号 32 位整数。"""
        return x & 0xFFFFFFFF

    def _mix(self, v, k, c):
        """一轮混合函数：((v<<4 ^ v>>>5) + v) ^ (k + c)。"""
        return self._i32((self._i32(v << 4) ^ (self._u32(v) >> 5)) + v) ^ self._i32(k + c)

    def _encrypt_block(self, v0, v1):
        """单个 8 字节块加密（32 轮）。"""
        s = 0
        while s != self.SUM_END:
            i = self._u32(s) & 3
            v0 = v0 + self._mix(v1, s + self.key[i], self.case[i])
            s += self.DELTA
            i = (self._u32(s) >> 11) & 3
            v1 = v1 + self._mix(v0, s + self.key[i], self.case[i])
        return v0, v1

    def _decrypt_block(self, v0, v1):
        """单个 8 字节块解密（轮序与加密相反）。"""
        s = self.SUM_END
        while s:
            i = (self._u32(s) >> 11) & 3
            v1 = v1 - self._mix(v0, s + self.key[i], self.case[i])
            s -= self.DELTA
            i = self._u32(s) & 3
            v0 = v0 - self._mix(v1, s + self.key[i], self.case[i])
        return v0, v1

    # ---- 字节 <-> 32 位字（小端） ----
    @staticmethod
    def _w2b(x):
        x = x & 0xFFFFFFFF
        return bytes((x & 255, (x >> 8) & 255, (x >> 16) & 255, (x >> 24) & 255))

    @staticmethod
    def _b2w(b):
        return b[0] | (b[1] << 8) | (b[2] << 16) | (b[3] << 24)

    def encrypt_blocks(self, pt):
        """整段明文（长度须为 8 的倍数）-> 密文字节。"""
        if len(pt) % 8:
            raise ValueError("plaintext must be a multiple of 8 bytes")
        out = bytearray()
        for i in range(0, len(pt), 8):
            v0, v1 = self._encrypt_block(self._b2w(pt[i:i + 4]),
                                         self._b2w(pt[i + 4:i + 8]))
            out += self._w2b(v0) + self._w2b(v1)
        return bytes(out)

    def rotate(self, ct):
        """密文轮转：ct[24:split] + ct[0:24] + ct[split:]。"""
        return ct[24:self.split] + ct[0:24] + ct[self.split:]

    def unrotate(self, raw):
        """轮转的逆操作（解密/分析用）。"""
        k = self.split - 24
        return raw[k:self.split] + raw[0:k] + raw[self.split:]

    def get_data(self, pt):
        """明文 -> 可直接放进请求体的 collect 字符串。"""
        raw = self.rotate(self.encrypt_blocks(pt))
        return urllib.parse.quote(base64.b64encode(raw).decode("ascii"), safe="")

    def decode_data(self, data):
        """collect 字符串 -> 明文（自检/分析用）。"""
        raw = base64.b64decode(urllib.parse.unquote(data))
        ct = self.unrotate(raw)
        out = bytearray()
        for i in range(0, len(ct), 8):
            v0, v1 = self._decrypt_block(self._b2w(ct[i:i + 4]),
                                         self._b2w(ct[i + 4:i + 8]))
            out += self._w2b(v0) + self._w2b(v1)
        return bytes(out)


# 兼容旧版模块级调用（README 里的对拍会用到）
def get_data(pt, prof=None):
    """模块级加密入口：get_data(明文, profile) -> collect。"""
    return TDCCipher(prof or PROFILE).get_data(pt)


def decode_data(data, prof=None):
    """模块级解密入口：decode_data(collect, profile) -> 明文。"""
    return TDCCipher(prof or PROFILE).decode_data(data)


# --------------------------------------------------------------------------- #
# 2. 缺口识别
#    默认用 captcha-recognizer 的 ONNX 模型；不可用时回退到内置 numpy 解算。
# --------------------------------------------------------------------------- #
class GapRecognizer:
    """滑块缺口识别器。

    对外只暴露 `recognize()`：返回答案（ans 坐标）、拼图偏移和调试信息。
    引擎选择：
      * "captcha-recognizer"（默认）：`Slider().identify(背景图)` 直接给出缺口框；
      * "builtin"：内置的掩码连通域 + 模板匹配，只依赖 numpy/Pillow。
    """

    _model = None      # captcha-recognizer 模型实例（懒加载、全进程复用）

    def __init__(self, engine="captcha-recognizer"):
        self.engine = engine

    # ---- 公共入口 ----
    def recognize(self, bg_path, sprite_path, dsi):
        """识别缺口并按腾讯坐标系算出 ans。

        dsi 即 prehandle 响应里的 `dyn_show_info`，提供拼图在雪碧图中的
        位置（sprite_pos/size_2d）与初始位置（init_pos）。
        """
        if self.engine == "captcha-recognizer":
            try:
                return self._recognize_model(bg_path, sprite_path, dsi)
            except ImportError:
                print("captcha-recognizer not installed "
                      "(pip install captcha-recognizer) -> built-in solver")
            except Exception as exc:                # 模型/图片异常都回退
                print("captcha-recognizer failed (%s) -> built-in solver" % exc)
        return self._recognize_builtin(bg_path, sprite_path, dsi)

    # ---- 拼图块几何：从雪碧图裁出拼图格，量出内容相对格子的偏移 ----
    @staticmethod
    def piece_geometry(sprite_path, dsi):
        """返回 (裁剪块, 不透明掩码, offset_x, offset_y, init_x, init_y)。"""
        fg = [e for e in dsi["fg_elem_list"] if e.get("id") == 1][0]
        sx, sy = fg["sprite_pos"]
        w, h = fg["size_2d"]
        init_x, init_y = fg["init_pos"]
        sprite = np.array(Image.open(sprite_path).convert("RGBA"))
        crop = sprite[sy:sy + h, sx:sx + w]
        pmask = crop[:, :, 3] > 128
        ys, xs = np.nonzero(pmask)
        return crop, pmask, int(xs.min()), int(ys.min()), init_x, init_y

    # ---- 引擎一：captcha-recognizer ----
    def _recognize_model(self, bg_path, sprite_path, dsi):
        """用 ONNX 模型找缺口框，再把框换算成 ans 坐标。"""
        if GapRecognizer._model is None:
            from captcha_recognizer.slider import Slider
            GapRecognizer._model = Slider()
        _crop, _pmask, ox, oy, init_x, init_y = self.piece_geometry(sprite_path, dsi)

        box, confidence = GapRecognizer._model.identify(source=bg_path)
        if not box:
            raise RuntimeError("captcha-recognizer found no gap")

        hole_x = int(round(min(box[0], box[2])))
        hole_y = int(round(min(box[1], box[3])))
        ans_x = hole_x - ox
        dy = hole_y - (init_y + oy)
        return {"x": ans_x, "y": init_y, "data": "%d,%d" % (ans_x, init_y),
                "piece_offset": (ox, oy), "engine": "captcha-recognizer",
                "hole": {"hole_x": hole_x, "hole_y": hole_y, "box": list(box),
                         "confidence": float(confidence),
                         "method": "captcha-recognizer", "iou": None,
                         "dy": dy},
                "init_pos": [init_x, init_y], "y_check_ok": abs(dy) <= 6}

    # ---- 引擎二：内置 numpy/Pillow 解算 ----
    def _recognize_builtin(self, bg_path, sprite_path, dsi):
        """掩码连通域（变体 A）优先，失败回退模板匹配（变体 B）。"""
        crop, pmask, ox, oy, init_x, init_y = self.piece_geometry(sprite_path, dsi)
        fg = [e for e in dsi["fg_elem_list"] if e.get("id") == 1][0]
        ys, xs = np.nonzero(pmask)
        pw, ph = int(xs.max() - ox + 1), int(ys.max() - oy + 1)

        bg = np.array(Image.open(bg_path).convert("RGB"))
        bg_lum = np.array(Image.open(bg_path).convert("L")).astype(np.float32)
        expected_y = init_y + oy

        hole = self.find_hole(bg, bg_lum, pmask, (ox, oy, pw, ph),
                              expected_y=expected_y)
        if hole is None or hole.get("iou", 0) < 0.5:
            alt = self.match_piece(bg,
                                   np.array(Image.open(sprite_path).convert("RGBA")),
                                   fg, expected_y=expected_y)
            if hole is None or alt["iou"] >= 0.5:
                hole = alt

        ans_x = hole["hole_x"] - ox
        dy = hole["hole_y"] - expected_y
        return {"x": int(ans_x), "y": int(init_y),
                "data": "%d,%d" % (ans_x, init_y),
                "piece_offset": (ox, oy), "hole": hole, "engine": "builtin",
                "init_pos": [init_x, init_y], "y_check_ok": abs(dy) <= 4}

    # ---- 内置解算：连通域 ----
    @staticmethod
    def _components(mask, min_area):
        """四连通域标记，返回面积 >= min_area 的组件（含像素与包围盒）。"""
        h, w = mask.shape
        seen = mask.copy()
        out = []
        ys, xs = np.nonzero(mask)
        for sy, sx in zip(ys, xs):
            if not seen[sy, sx]:
                continue
            q = deque([(sy, sx)])
            seen[sy, sx] = False
            n = 0
            minx = maxx = sx
            miny = maxy = sy
            pix = []
            while q:
                y, x = q.popleft()
                n += 1
                pix.append((y, x))
                if x < minx: minx = x
                if x > maxx: maxx = x
                if y < miny: miny = y
                if y > maxy: maxy = y
                for dy, dx in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    ny, nx = y + dy, x + dx
                    if 0 <= ny < h and 0 <= nx < w and seen[ny, nx]:
                        seen[ny, nx] = False
                        q.append((ny, nx))
            if n >= min_area:
                out.append({"area": n, "pix": pix,
                            "bbox": (minx, miny, maxx - minx + 1, maxy - miny + 1)})
        return out

    @staticmethod
    def _hole_mask(bg_rgb, bg_lum):
        """变体 A：缺口是去饱和、中暗的覆盖层（亮度 40~140、饱和度 ≤22）。"""
        a = bg_rgb.astype(np.int16)
        sat = (a.max(2) - a.min(2)).astype(np.float32)
        return (bg_lum >= 40) & (bg_lum <= 140) & (sat <= 22)

    @staticmethod
    def _iou(a_mask, a_off, b_mask, b_off, shift=(0, 0)):
        """两个掩码在画布上的交并比（可整体平移）。"""
        ax0, ay0 = a_off
        bx0, by0 = b_off[0] + shift[0], b_off[1] + shift[1]
        x0 = min(ax0, bx0); y0 = min(ay0, by0)
        x1 = max(ax0 + a_mask.shape[1], bx0 + b_mask.shape[1])
        y1 = max(ay0 + a_mask.shape[0], by0 + b_mask.shape[0])
        A = np.zeros((y1 - y0, x1 - x0), bool)
        B = np.zeros_like(A)
        A[ay0 - y0:ay0 - y0 + a_mask.shape[0],
          ax0 - x0:ax0 - x0 + a_mask.shape[1]] = a_mask
        B[by0 - y0:by0 - y0 + b_mask.shape[0],
          bx0 - x0:bx0 - x0 + b_mask.shape[1]] = b_mask
        inter = (A & B).sum()
        union = (A | B).sum()
        return inter / union if union else 0.0

    def find_hole(self, bg_rgb, bg_lum, piece_mask, piece_bbox, expected_y=None):
        """连通域 + 掩码 IoU 找缺口内容原点。

        阈值掩码会被抗锯齿边缘内缩；y 方向已知精确值（拼图只水平移动），
        用 y 量出的内缩量修正 x，修正量只有 1~2 px，且不总成立——拿不准时
        以原始包围盒为准（详见 README §5.4）。
        """
        pw, ph = piece_bbox[2], piece_bbox[3]
        mask = self._hole_mask(bg_rgb, bg_lum)
        comps = self._components(mask, int(piece_mask.sum() * 0.35))
        pm = piece_mask[piece_bbox[1]:piece_bbox[1] + ph,
                        piece_bbox[0]:piece_bbox[0] + pw]
        cands = []
        for c in comps:
            cx, cy, cw, ch = c["bbox"]
            if not (0.6 * pw <= cw <= 1.45 * pw and 0.55 * ph <= ch <= 1.6 * ph):
                continue
            cm = np.zeros((ch, cw), bool)
            for y, x in c["pix"]:
                cm[y - cy, x - cx] = True
            best = (0.0, 0, 0)
            for dy in range(-4, 5):
                for dx in range(-4, 5):
                    score = self._iou(pm, (0, 0), cm, (dx, dy))
                    if score > best[0]:
                        best = (score, dx, dy)
            cands.append((best[0], cx + best[1], cy + best[2], cw, ch, cx, cy))
        if not cands:
            return None
        cands.sort(reverse=True)
        iou, hx, hy, cw, ch, bx, by = cands[0]
        corr = None
        if expected_y is not None:
            corr = int(by - expected_y)
            if -1 <= corr <= 6:
                hx = bx - corr
                hy = int(expected_y)
            else:
                corr = None
        return {"hole_x": int(hx), "hole_y": int(hy), "iou": round(float(iou), 3),
                "comp_w": int(cw), "comp_h": int(ch), "edge_corr": corr,
                "comp_bbox": [int(bx), int(by)], "method": "mask",
                "margin": round(float(cands[0][0] - cands[1][0]), 3)
                if len(cands) > 1 else None}

    def match_piece(self, bg_rgb, sprite_rgba, fg, expected_y=None):
        """模板匹配回退（变体 B：缺口 = 原图 × k，k≈0.37~0.45）。

        在 y 已知值附近 ±6 px 逐列做零均值归一化相关，只取内缩 3 px 的
        不透明核心；用 k<0.8（缺口一定更暗）排掉平坦亮斑的假峰。
        """
        sx, sy = fg["sprite_pos"]
        w, h = fg["size_2d"]
        init_x, init_y = fg["init_pos"]
        crop = sprite_rgba[sy:sy + h, sx:sx + w]
        mask = crop[:, :, 3] > 128
        if not mask.any():
            raise ValueError("empty piece mask")
        ys, xs = np.nonzero(mask)
        ox, oy = int(xs.min()), int(ys.min())
        pw, ph = int(xs.max() - ox + 1), int(ys.max() - oy + 1)
        piece = crop[oy:oy + ph, ox:ox + pw, :3].astype(np.float32)
        pl = piece.mean(2)
        core = mask[oy:oy + ph, ox:ox + pw].copy()
        for _ in range(3):                       # 内缩，避开抗锯齿边
            core = (core & np.roll(core, 1, 0) & np.roll(core, -1, 0)
                    & np.roll(core, 1, 1) & np.roll(core, -1, 1))
        if core.sum() < 50:
            core = mask[oy:oy + ph, ox:ox + pw].copy()

        y0 = int(expected_y if expected_y is not None else init_y + oy)
        H, W = bg_rgb.shape[:2]
        bgl = bg_rgb.astype(np.float32)
        bg_l = bgl.mean(2)
        a = piece[core]
        pa = pl[core]
        pa0 = pa - pa.mean()
        dena = float(np.sqrt((pa0 * pa0).sum())) + 1e-9
        scores = []
        for y in range(max(0, y0 - 6), min(H - ph, y0 + 6) + 1):
            for x in range(0, W - pw + 1):
                p = bg_l[y:y + ph, x:x + pw][core]
                p0 = p - p.mean()
                ncc = float((pa0 * p0).sum() /
                            (dena * (float(np.sqrt((p0 * p0).sum())) + 1e-9)))
                b = bgl[y:y + ph, x:x + pw][core]
                k = float((a * b).sum() / ((a * a).sum() + 1e-6))
                resid = float(np.abs(b - a * k).mean())
                scores.append((ncc, -resid, x, y, k, resid))
        scores.sort(reverse=True)
        dark = [s for s in scores if s[4] < 0.8]
        pool = dark if dark else scores
        ncc, _neg, best_x, best_y, k, resid = pool[0]
        around = [s for s in pool if abs(s[2] - best_x) > pw // 2]
        second = around[0][0] if around else None
        return {"hole_x": int(best_x), "hole_y": int(y0), "iou": round(float(ncc), 3),
                "comp_w": pw, "comp_h": ph, "edge_corr": None,
                "comp_bbox": [int(best_x), int(best_y)], "method": "template",
                "margin": round(ncc - second, 3) if second is not None else None,
                "k": round(float(k), 3), "resid": round(resid, 2)}


# 兼容旧版模块级调用
def answer_captcha_recognizer(bg_path, sprite_path, dsi):
    """模块级快捷入口：只用 captcha-recognizer 识别。"""
    return GapRecognizer("captcha-recognizer")._recognize_model(bg_path, sprite_path, dsi)


def answer_builtin(bg_path, sprite_path, dsi):
    """模块级快捷入口：只用内置解算。"""
    return GapRecognizer("builtin")._recognize_builtin(bg_path, sprite_path, dsi)


def answer_from_session(bg_path, sprite_path, dsi, engine="captcha-recognizer"):
    """模块级快捷入口：按 engine 选择识别器（失败自动回退）。"""
    return GapRecognizer(engine).recognize(bg_path, sprite_path, dsi)


# --------------------------------------------------------------------------- #
# 3. 拖动轨迹 + TDC 事件串
# --------------------------------------------------------------------------- #
class Trajectory:
    """生成拖动轨迹，并序列化成 collect 里的事件串。"""

    # 步长池取自 2026-10-24 抓到的真实事件串：dt 多集中在 3~11 ms，
    # 偶发 20/37/40/41/50/80 ms 停顿（scripts/real_event_capture.json）。
    STEP_POOL = (3, 3, 3, 4, 4, 4, 5, 6, 6, 6, 6, 6, 7, 8, 9, 9, 9, 9, 9, 9,
                 9, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 11, 11,
                 11, 11, 11, 11, 11, 12, 16, 20, 20, 20, 37, 40, 40, 41, 50, 50,
                 80)

    @classmethod
    def make(cls, init_x, init_y, target_x, target_y, duration_ms=None, n=None):
        """生成接近真实客户端的拖动轨迹，返回 {elapsed_ms: "x,y"}。

        轨迹为 ease-out，末端有轻微过冲再回落到目标点；duration_ms 默认
        600~1000 ms。n 参数仅为兼容旧调用保留，不参与计算。
        """
        if duration_ms is None:
            duration_ms = random.randint(600, 1000)
        dx = target_x - init_x
        dy = target_y - init_y
        over = random.uniform(0.01, 0.035)          # 末端过冲比例
        drift = random.uniform(-1.5, 1.5)           # 人手纵向漂移

        def pos(p):
            if p < 0.85:
                e = (1 - (1 - p / 0.85) ** 3) * (1 + over)
            else:                                    # 收尾：回落到 1.0
                q = (p - 0.85) / 0.15
                e = 1 + over * (1 - q) * (1 - q)
            return int(round(init_x + dx * e)), int(round(init_y + dy * e + drift))

        pts = {}
        t = 0
        while t < duration_ms:
            pts[t] = "%d,%d" % pos(min(1.0, t / float(duration_ms)))
            t += random.choice(cls.STEP_POOL)
        pts[duration_ms] = "%d,%d" % (target_x, target_y)
        return pts

    @staticmethod
    def event_trace(traj, start_ms=None):
        """{elapsed_ms: "x,y"} -> 事件 JSON：[[dx,dy,dt], ...]。

        真实样本与 TDC.setData 的结果同形：首元素是绝对坐标 + 相对时间，
        其后都是相对上一点的位移/时间差，末尾固定 [1,1,12]。
        """
        items = sorted((int(ms), v) for ms, v in traj.items())
        if start_ms is None:
            start_ms = random.randint(600, 2000)
        out = []
        prev = None
        for ms, xy in items:
            x, y = [int(t) for t in xy.split(",")]
            if prev is None:
                out.append([x, y, start_ms + ms])
            else:
                out.append([x - prev[0], y - prev[1], ms - prev[2]])
            prev = (x, y, ms)
        out.append([1, 1, 12])
        return json.dumps(out, separators=(",", ":"))


# 兼容旧版模块级调用
def make_trajectory(init_x, init_y, target_x, target_y, duration_ms=None, n=None):
    """模块级快捷入口：生成轨迹。"""
    return Trajectory.make(init_x, init_y, target_x, target_y, duration_ms, n)


def make_event_trace(traj, start_ms=None):
    """模块级快捷入口：轨迹 -> 事件串。"""
    return Trajectory.event_trace(traj, start_ms)


# --------------------------------------------------------------------------- #
# 4. collect 明文构造
#    回放某个 build 的明文布局，填入 now_sec/counter，按需嵌入事件串后加密。
# --------------------------------------------------------------------------- #
class CollectBuilder:
    """把模板布局变成可提交的 collect。

    布局来自 PROFILE["layout"]：prefix/tokens/suffix 三段拼接，动态字段
    （now_sec、counter 及其空格补位）在对应 token 上替换。
    事件串的写入方式与 tdc.js 一致：空格补齐到 24 的整数倍，前 24 字符
    替换头部槽位，其余拼在 counter 补位之后。
    """

    EVENT_INSERT_AFTER = 28        # cur9 布局里 counter 补位 = tokens[28]

    def __init__(self, profile):
        self.profile = profile
        self.layout = profile["layout"]
        self.cipher = TDCCipher(profile)

    def build_plaintext(self, now_sec, counter=1, events=None):
        """生成 collect 明文（bytes，末尾补 \\x00 到 8 字节倍数）。"""
        toks = list(self.layout["tokens"])
        dyn = self.layout.get("dynamic") or {}

        # 动态字段：Unix 秒与调用序号
        if dyn.get("now_sec") is not None:
            toks[int(dyn["now_sec"])] = str(int(now_sec))
        if dyn.get("counter") is not None:
            toks[int(dyn["counter"])] = str(int(counter))
            nd = len(str(int(counter)))
            # 某些 build 用固定宽度的空格串对齐 counter
            for j, width in (dyn.get("pads") or {}).items():
                w = int(width) - nd
                if w >= 0:
                    toks[int(j)] = " " * w

        # 事件串：前 24 字符占头部槽位，余下插进 counter 补位之后
        head = self.layout["prefix"]
        insert = ""
        if events is not None:
            ev = str(events)
            ev += " " * ((-len(ev)) % 24)
            head = ev[:24] + '{"cd":['
            if len(ev) > 24:
                insert = ev[24:]

        s = head + ",".join(toks) + self.layout["suffix"]
        if insert:
            j = self.EVENT_INSERT_AFTER
            off = len(head) + sum(len(t) for t in toks[:j]) + j + len(toks[j])
            s = s[:off] + insert + s[off:]
        return (s + "\x00" * ((-len(s)) % 8)).encode("latin-1")

    def make_collect(self, now_sec, counter=1, events=None):
        """明文 -> (collect 字符串, 明文)；函数内置解密回环自检。"""
        pt = self.build_plaintext(now_sec, counter, events=events)
        data = self.cipher.get_data(pt)
        back = self.cipher.decode_data(data)
        if back != pt:
            raise SystemExit("collect self-check failed (decrypt != plaintext)")
        return data, pt


# 兼容旧版模块级调用
def build_plaintext(now_sec, counter=1, events=None):
    """模块级快捷入口：生成明文。"""
    return CollectBuilder(PROFILE).build_plaintext(now_sec, counter, events=events)


def make_collect(now_sec, counter=1, events=None):
    """模块级快捷入口：生成 collect（带自检）。"""
    return CollectBuilder(PROFILE).make_collect(now_sec, counter, events=events)


# --------------------------------------------------------------------------- #
# 5. 完整流程：prehandle -> 取图 -> 识别 -> collect -> PoW -> verify
# --------------------------------------------------------------------------- #
class TencentCaptchaFlow:
    """一次完整的腾讯滑块验证流程。

    典型用法：
        flow = TencentCaptchaFlow()
        code, result = flow.run(submit=True)
    """

    def __init__(self, recognizer="captcha-recognizer"):
        self.recognizer_engine = recognizer
        self.recognizer = GapRecognizer(recognizer)
        self.builder = CollectBuilder(PROFILE)

    # ---- HTTP 会话 ----
    @staticmethod
    def make_session():
        """新建 requests.Session，并带上与浏览器一致的常用请求头。"""
        s = requests.Session()
        s.headers.update({
            "User-Agent": UA, "Accept": "*/*",
            "Referer": "https://cloud.tencent.com/",
            "Origin": "https://cloud.tencent.com",
            "sec-ch-ua": '"Chromium";v="146", "Not-A.Brand";v="24", '
                         '"Google Chrome";v="146"',
            "sec-ch-ua-mobile": "?0",
            "sec-ch-ua-platform": '"Windows"',
        })
        return s

    # ---- prehandle：拿 sess/tkid/图片地址/PoW 配置 ----
    @staticmethod
    def prehandle(s):
        """请求 cap_union_prehandle，返回 (tkid, 响应 JSON)。"""
        tkid = str(int(time.time() * 1000) % 1000000000)
        cb = "_aq_%d" % random.randint(10000, 99999)   # JSONP 回调名
        params = {
            "aid": AID, "protocol": "https", "accver": "1", "showtype": "popup",
            "ua": base64.b64encode(UA.encode()).decode(),
            "noheader": "1", "fb": "1", "aged": "0", "enableAged": "0",
            "enableDarkMode": "0", "grayscale": "1", "clientype": "2",
            "cap_cd": "", "uid": "", "lang": "zh-cn",
            "entry_url": "https://cloud.tencent.com/product/captcha",
            "elder_captcha": "0", "js": "/tgJCap.2f0b2c65.js", "login_appid": "",
            "wb": "2", "tkid": tkid, "subsid": "1", "callback": cb, "sess": "",
        }
        r = s.get(BASE + "/cap_union_prehandle", params=params, timeout=10)
        r.raise_for_status()
        m = re.search(r"^%s\((.*)\)$" % re.escape(cb), r.text.strip(), re.S)
        return tkid, json.loads(m.group(1) if m else r.text)

    # ---- 图片下载 ----
    @staticmethod
    def get_image(s, url, tkid):
        """下载背景图/雪碧图（相对地址补全域名，带上 tkid）。"""
        if url.startswith("/"):
            url = BASE + url
        r = s.get(url + "&tkid=" + tkid, timeout=10)
        r.raise_for_status()
        return r.content

    # ---- 本地 PoW ----
    @staticmethod
    def solve_pow(cfg):
        """暴力搜索 md5(prefix + n) == target，返回 (pow_answer, 耗时 ms)。"""
        prefix, target = cfg["prefix"], cfg["md5"]
        t0 = time.time()
        n = 0
        while hashlib.md5((prefix + str(n)).encode()).hexdigest() != target:
            n += 1
        return prefix + str(n), max(1, int((time.time() - t0) * 1000))

    # ---- 主流程 ----
    def run(self, submit=True):
        """跑完整条链路；submit=True 时提交一次 verify，返回 (退出码, 结果)。"""
        result = {"submit": submit, "build_sha": PROFILE["sha256_16"],
                  "recognizer": self.recognizer_engine}

        # 1) prehandle：拿会话与挑战参数
        s = self.make_session()
        tkid, pre = self.prehandle(s)
        data = pre["data"]
        sess = pre.get("sess") or data.get("sess") or ""
        if not sess:
            raise SystemExit("sess missing in prehandle response")
        dsi = data["dyn_show_info"]
        pow_cfg = data["comm_captcha_cfg"]["pow_cfg"]
        fg = [e for e in dsi["fg_elem_list"] if e.get("id") == 1][0]
        init_x, init_y = fg["init_pos"]
        print("prehandle: sess=%d tkid=%s init_pos=%s pow=%s" % (
            len(sess), tkid, fg["init_pos"], pow_cfg["prefix"]))

        # 2) 下载两张图（writes 到 OUT 目录，方便复现/排查）
        open(BG, "wb").write(self.get_image(s, dsi["bg_elem_cfg"]["img_url"], tkid))
        open(SP, "wb").write(self.get_image(s, dsi["sprite_url"], tkid))
        print("images: bg=%d sprite=%d bytes" % (
            os.path.getsize(BG), os.path.getsize(SP)))

        # 3) 识别缺口并算出 ans
        ans = self.recognizer.recognize(BG, SP, dsi)
        print("ans: %s  engine=%s  method=%s  iou=%s  conf=%s" % (
            ans["data"], ans.get("engine"), ans["hole"].get("method", "mask"),
            ans["hole"].get("iou"), ans["hole"].get("confidence")))

        # 4) 轨迹 + 事件串（真实节奏，末端回正）
        traj = Trajectory.make(init_x, init_y, ans["x"], ans["y"])
        events = Trajectory.event_trace(traj)
        print("trajectory: %d points -> event trace %d chars (embedded in collect)" %
              (len(traj), len(events)))

        # 5) 构造并加密 collect（文件内自检解密回环）
        now = int(time.time())
        collect, pt = self.builder.make_collect(now, counter=1, events=events)
        tlg = len(collect)                     # 注意：tlg 用原始长度（含 %XX）
        eks = PROFILE["eks"]
        print("collect: plaintext=%d raw=%d decoded=%d eks=%d  now=%d" % (
            len(pt), tlg, len(urllib.parse.unquote(collect)), len(eks), now))
        result.update({"ans": ans["data"], "ans_meta": ans["hole"],
                       "init_pos": [init_x, init_y], "traj_points": len(traj),
                       "sess_len": len(sess), "tkid": tkid,
                       "collect_len": tlg, "plaintext_len": len(pt),
                       "collect_decoded_len": len(urllib.parse.unquote(collect)),
                       "eks_len": len(eks), "now_sec": now,
                       "plaintext_head": pt[:120].decode("latin-1", "replace")})

        # 6) PoW：本地穷举，耗时一并提交
        pow_answer, pow_ms = self.solve_pow(pow_cfg)
        print("pow: %s in %d ms" % (pow_answer, pow_ms))

        # 7) 组装 verify 请求体
        ans_json = json.dumps([{"elem_id": 1, "type": "DynAnswerType_POS",
                                "data": ans["data"]}], separators=(",", ":"))
        body = {"collect": collect, "tlg": str(tlg), "eks": eks, "sess": sess,
                "ans": ans_json, "tkid": tkid,
                "pow_answer": pow_answer, "pow_calc_time": str(pow_ms)}
        result.update({"pow_answer": pow_answer, "pow_calc_time": pow_ms,
                       "body": {k: (v if len(v) < 300 else "len=%d" % len(v))
                                for k, v in body.items()}})

        if not submit:
            print("DRY RUN: nothing posted. --submit sends exactly one POST.")
            return 0, result

        # 8) 提交（整次调用仅此一条 POST，无重试）
        print("POST verify (authorized: one submission per invocation)")
        t0 = time.time()
        r = s.post(BASE + "/cap_union_new_verify", data=body, timeout=15)
        post_ms = int((time.time() - t0) * 1000)
        print("HTTP", r.status_code, r.text[:600])
        result.update({"http": r.status_code, "response": r.text[:4000],
                       "post_ms": post_ms})
        try:
            err = json.loads(r.text).get("errorCode")
        except Exception:
            err = None
        return (0 if err == "0" else 2), result


# --------------------------------------------------------------------------- #
# 6. 命令行入口
# --------------------------------------------------------------------------- #
def main():
    """解析参数并执行一次流程。"""
    submit = AUTHORIZED_SUBMIT
    if "--dry-run" in sys.argv:
        submit = False
    elif "--submit" in sys.argv:
        submit = True

    engine = "captcha-recognizer"
    for i, a in enumerate(sys.argv):
        if a == "--recognizer" and i + 1 < len(sys.argv):
            engine = sys.argv[i + 1]
        elif a.startswith("--recognizer="):
            engine = a.split("=", 1)[1]
    if engine not in ("captcha-recognizer", "builtin"):
        raise SystemExit("--recognizer must be captcha-recognizer or builtin")

    code, result = TencentCaptchaFlow(engine).run(submit)
    json.dump(result, open(OUT, "w"), indent=1)
    print("result ->", OUT)
    sys.exit(code)


if __name__ == "__main__":
    main()
