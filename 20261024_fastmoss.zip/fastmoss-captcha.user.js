// ==UserScript==
// @name         FastMoss 验证码测试面板
// @namespace    fastmoss-captcha-test
// @version      1.0.0
// @description  在 fastmoss.com 同源环境下单独调出腾讯防水墙验证码，人工完成并提交 ticket（联调自用）
// @match        https://www.fastmoss.com/*
// @run-at       document-idle
// @grant        none
// ==/UserScript==

(function () {
  'use strict';
  if (window.__fmCaptchaPanel) return;
  window.__fmCaptchaPanel = true;

  const state = { appid: null, ticket: '', randstr: '' };

  const host = document.createElement('div');
  host.style.cssText = 'position:fixed;right:16px;bottom:16px;z-index:2147483647;font:13px/1.5 ui-monospace,Consolas,monospace;';
  document.documentElement.appendChild(host);
  const root = host.attachShadow({ mode: 'open' });

  root.innerHTML = `
    <style>
      .wrap{background:#171a21;color:#e6e8ee;border:1px solid #2c3340;border-radius:10px;
            padding:10px;width:320px;box-shadow:0 8px 30px rgba(0,0,0,.5)}
      .bar{display:flex;justify-content:space-between;align-items:center;cursor:pointer}
      .title{font-weight:600;font-size:13px}
      .body{margin-top:8px;display:block}
      .body.hide{display:none}
      label{display:block;color:#9aa3b8;font-size:11px;margin:6px 0 2px}
      input{width:100%;box-sizing:border-box;background:#0f1115;color:#e6e8ee;border:1px solid #2c3340;
            border-radius:5px;padding:5px 7px;font:inherit}
      .row{display:flex;gap:8px;margin-top:8px}
      button{flex:1;background:#24406e;color:#dbe7ff;border:1px solid #2f5794;border-radius:6px;
             padding:6px;font:inherit;cursor:pointer}
      button.p{background:#2f6bff;border-color:#2f6bff;color:#fff}
      pre{background:#0b0d11;border:1px solid #232833;border-radius:6px;padding:6px;max-height:140px;
          overflow:auto;white-space:pre-wrap;word-break:break-all;margin:8px 0 0;font-size:11px}
      .ok{color:#4ade80}.bad{color:#f87171}
    </style>
    <div class="wrap">
      <div class="bar" id="bar"><span class="title">FastMoss 验证码测试</span><span id="toggle">▾</span></div>
      <div class="body" id="body">
        <label>type</label><input id="type" type="number" value="1" min="0">
        <label>id (MSG_SAFE_0001 的 data.id，无则 0)</label><input id="id" type="number" value="0" min="0">
        <label>lang</label><input id="lang" type="text" value="zh-CN">
        <div class="row"><button id="cfg">取配置</button><button id="pop" class="p">弹验证码</button></div>
        <div class="row"><button id="ver">提交 ticket</button><button id="clr">清空</button></div>
        <div style="margin-top:6px;font-size:11px">appid: <span id="appid">-</span></div>
        <div style="font-size:11px">ticket: <span id="tk" class="bad">-</span></div>
        <pre id="log"></pre>
      </div>
    </div>`;

  const $ = (s) => root.querySelector(s);
  const lang = () => $('#lang').value.trim() || 'zh-CN';
  const tidy = () => Number($('#type').value || 1);
  const cid = () => Number($('#id').value || 0);

  function log(...a) {
    const line = a.map((x) => (typeof x === 'string' ? x : JSON.stringify(x))).join(' ');
    $('#log').textContent += '[' + new Date().toLocaleTimeString() + '] ' + line + '\n';
    $('#log').scrollTop = $('#log').scrollHeight;
  }

  async function post(path, payload) {
    log('POST', path);
    const res = await fetch(path, {
      method: 'POST', mode: 'cors', credentials: 'same-origin', cache: 'no-store',
      headers: { 'Content-Type': 'application/json', lang: lang() },
      body: JSON.stringify(payload)
    });
    const json = await res.json().catch(() => ({}));
    log('←', res.status, json);
    return json;
  }

  function loadSdk() {
    if (window.TencentCaptcha) return Promise.resolve();
    return new Promise((resolve, reject) => {
      const s = document.createElement('script');
      s.src = 'https://turing.captcha.qcloud.com/TJCaptcha.js';
      s.async = true;
      s.onload = resolve;
      s.onerror = () => reject(new Error('TJCaptcha.js load failed'));
      document.body.appendChild(s);
    });
  }

  async function getConfig() {
    const json = await post('/api/captcha/config', { platform: 1, business_id: 1, scene_id: 1, type: tidy() });
    state.appid = (json && json.data && json.data.appid) || null;
    $('#appid').textContent = state.appid || '(none)';
    return state.appid;
  }

  async function submit(ticket, randstr) {
    const payload = { ticket, randstr, platform: 1, business_id: 1, scene_id: 1, id: cid(), type: tidy(), lang: lang() };
    const path = tidy() === 1 ? '/api/captcha/verify' : '/api/captcha/smsVerify';
    const json = await post(path, payload);
    const ok = json && json.data && json.data.is_ok === 1;
    log(ok ? '✔ is_ok = 1' : '✘ is_ok ≠ 1');
    return ok;
  }

  async function pop() {
    try {
      await loadSdk();
      if (!state.appid) await getConfig();
      if (!state.appid) { log('no appid'); return; }
      log('弹出验证码，请手动完成');
      new window.TencentCaptcha(state.appid, async (r) => {
        log('回调', r);
        const ret = Number(r && r.ret);
        const ticket = (r && (r.ticket || r.Ticket)) || '';
        const randstr = (r && (r.randstr || r.Randstr)) || '';
        state.ticket = ticket; state.randstr = randstr;
        $('#tk').textContent = ticket || '-';
        $('#tk').className = ticket ? 'ok' : 'bad';
        if (ret !== 0 || !ticket || !randstr) { log('未通过，ret=' + ret); return; }
        try { localStorage.setItem('captcha_ticket_data', ticket); } catch (e) {}
        await submit(ticket, randstr);
      }, { userLanguage: lang(), needFeedBack: false }).show();
    } catch (e) { log('err', String(e)); }
  }

  $('#cfg').onclick = () => getConfig().catch((e) => log('err', String(e)));
  $('#pop').onclick = pop;
  $('#ver').onclick = () => (state.ticket ? submit(state.ticket, state.randstr) : log('no ticket'));
  $('#clr').onclick = () => { $('#log').textContent = ''; };
  $('#bar').onclick = () => $('#body').classList.toggle('hide');

  log('已注入，同源模式');
})();
